import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "./useSchool";

/**
 * Returns { periodType: "trimestre"|"semestre", periods: [...], periodLabel }
 * periodType defaults to "trimestre" if not configured.
 */
export function usePeriodType(overrideSchoolId) {
  const [periodType, setPeriodType] = useState("trimestre");

  useEffect(() => {
    const schoolId = overrideSchoolId || getSchoolId();
    if (!schoolId) return;
    base44.entities.SchoolSettings.filter({ school_id: schoolId }).then((list) => {
      if (list[0]?.period_type) setPeriodType(list[0].period_type);
    });
  }, [overrideSchoolId]);

  const periods =
    periodType === "semestre"
      ? ["Semestre 1", "Semestre 2"]
      : ["Trimestre 1", "Trimestre 2", "Trimestre 3"];

  const periodLabel = periodType === "semestre" ? "Semestre" : "Trimestre";

  return { periodType, periods, periodLabel };
}