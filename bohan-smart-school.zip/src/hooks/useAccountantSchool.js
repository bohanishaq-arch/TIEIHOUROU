/**
 * Hook pour récupérer automatiquement l'établissement lié à la comptable
 * connectée, via son enregistrement AppAccess.
 * La comptable est TOUJOURS liée à l'établissement qui a créé son compte.
 */
import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function useAccountantSchool(user) {
  const [schoolId, setSchoolId] = useState(null);
  const [school, setSchool] = useState(null);
  const [schoolSettings, setSchoolSettings] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.email) return;
    async function load() {
      // 1. Trouver le profil AppAccess de la comptable
      const accesses = await base44.entities.AppAccess.filter({
        user_email: user.email.toLowerCase(),
        role: "accountant",
      });
      const p = accesses.find(a => a.is_active !== false) || accesses[0] || null;
      setProfile(p);

      const sid = p?.school_id || null;
      setSchoolId(sid);

      if (sid) {
        // 2. Charger les infos de l'école et ses paramètres en parallèle
        const [schools, settings] = await Promise.all([
          base44.entities.School.filter({ id: sid }),
          base44.entities.SchoolSettings.filter({ school_id: sid }),
        ]);
        setSchool(schools[0] || null);
        setSchoolSettings(settings[0] || null);
      }
      setLoading(false);
    }
    load();
  }, [user?.email]);

  return { schoolId, school, schoolSettings, profile, loading };
}