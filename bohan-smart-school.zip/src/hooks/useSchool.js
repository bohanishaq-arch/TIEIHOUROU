const SCHOOL_KEY = 'scolaris_school_id';
const SCHOOL_NAME_KEY = 'scolaris_school_name';

export function getSchoolId() {
  return sessionStorage.getItem(SCHOOL_KEY) || null;
}

export function getSchoolName() {
  return sessionStorage.getItem(SCHOOL_NAME_KEY) || null;
}

export function setSchool(id, name) {
  if (id) {
    sessionStorage.setItem(SCHOOL_KEY, id);
    sessionStorage.setItem(SCHOOL_NAME_KEY, name || '');
  } else {
    sessionStorage.removeItem(SCHOOL_KEY);
    sessionStorage.removeItem(SCHOOL_NAME_KEY);
  }
}

export function clearSchool() {
  sessionStorage.removeItem(SCHOOL_KEY);
  sessionStorage.removeItem(SCHOOL_NAME_KEY);
}