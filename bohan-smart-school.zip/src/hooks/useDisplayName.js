/**
 * Returns the display name from the AppAccess record (set at login),
 * falling back to the Google account name if not available.
 */
const DISPLAY_NAME_KEY = "bohan_display_name";

export function setDisplayName(name) {
  if (name) sessionStorage.setItem(DISPLAY_NAME_KEY, name);
}

export function getDisplayName(fallback = "") {
  return sessionStorage.getItem(DISPLAY_NAME_KEY) || fallback;
}

export function clearDisplayName() {
  sessionStorage.removeItem(DISPLAY_NAME_KEY);
}