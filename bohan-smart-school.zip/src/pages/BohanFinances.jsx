import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Building2, TrendingUp, DollarSign, CheckCircle, Clock, Download, Filter, ChevronDown, ChevronUp, BadgeCheck } from "lucide-react";
import { motion } from "framer-motion";
import PageHeader from "@/components/PageHeader";

const TYPE_LABEL = { public: "Public 🏛️", prive: "Privé 🏫" };
const TYPE_AMOUNT = { public: 500, prive: 1000 };
const TYPE_COLOR = {
  public: "bg-blue-100 text-blue-700 border-blue-200",
  prive: "bg-violet-100 text-violet-700 border-violet-200",
};

export default function BohanFinances() {
  const { user } = useAuth();
  const [revenues, setRevenues] = useState([]);
  const [schools, setSchools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterSchool, setFilterSchool] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterYear, setFilterYear] = useState("all");
  const [expandedSchool, setExpandedSchool] = useState(null);
  const [collecting, setCollecting] = useState(null);

  async function load() {
    setLoading(true);
    const [revs, schs] = await Promise.all([
      base44.entities.BohanRevenue.list("-enrollment_date", 2000),
      base44.entities.School.list(),
    ]);
    setRevenues(revs);
    setSchools(schs);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  // Filtered revenues
  const filtered = revenues.filter(r => {
    if (filterSchool !== "all" && r.school_id !== filterSchool) return false;
    if (filterStatus === "collected" && !r.is_collected) return false;
    if (filterStatus === "pending" && r.is_collected) return false;
    if (filterYear !== "all" && r.academic_year !== filterYear) return false;
    return true;
  });

  const years = [...new Set(revenues.map(r => r.academic_year).filter(Boolean))].sort().reverse();

  // Global totals
  const totalExpected = filtered.reduce((s, r) => s + (r.amount || 0), 0);
  const totalCollected = filtered.filter(r => r.is_collected).reduce((s, r) => s + (r.amount || 0), 0);
  const totalPending = totalExpected - totalCollected;

  // Per-school summary
  const bySchool = useMemo(() => {
    const map = {};
    revenues.forEach(r => {
      if (!map[r.school_id]) {
        const sch = schools.find(s => s.id === r.school_id);
        map[r.school_id] = {
          school_id: r.school_id,
          school_name: r.school_name || sch?.name || "—",
          school_type: r.school_type || sch?.school_type || "public",
          total: 0,
          collected: 0,
          pending: 0,
          count: 0,
          revenues: [],
        };
      }
      map[r.school_id].total += r.amount || 0;
      map[r.school_id].count += 1;
      if (r.is_collected) map[r.school_id].collected += r.amount || 0;
      else map[r.school_id].pending += r.amount || 0;
      map[r.school_id].revenues.push(r);
    });
    return Object.values(map).sort((a, b) => b.pending - a.pending);
  }, [revenues, schools]);

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">Accès réservé au super-administrateur.</p>
      </div>
    );
  }

  async function handleCollect(revenue) {
    setCollecting(revenue.id);
    await base44.entities.BohanRevenue.update(revenue.id, {
      is_collected: true,
      collected_date: new Date().toISOString().slice(0, 10),
      collected_by: user?.full_name || user?.email,
    });
    await load();
    setCollecting(null);
  }

  async function handleCollectAll(schoolId) {
    const pending = revenues.filter(r => r.school_id === schoolId && !r.is_collected);
    setCollecting("school_" + schoolId);
    for (const r of pending) {
      await base44.entities.BohanRevenue.update(r.id, {
        is_collected: true,
        collected_date: new Date().toISOString().slice(0, 10),
        collected_by: user?.full_name || user?.email,
      });
    }
    await load();
    setCollecting(null);
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="💰 Suivi des financements BOHAN"
        subtitle="Revenus générés par les inscriptions dans tous les établissements"
      />

      {/* Global KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: "Total attendu", value: totalExpected, icon: DollarSign, color: "bg-blue-50 text-blue-600", border: "border-blue-200" },
          { label: "Encaissé", value: totalCollected, icon: CheckCircle, color: "bg-green-50 text-green-600", border: "border-green-200" },
          { label: "En attente", value: totalPending, icon: Clock, color: "bg-amber-50 text-amber-600", border: "border-amber-200" },
        ].map((k, i) => (
          <motion.div key={k.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
            className={`bg-card rounded-2xl border ${k.border} p-5 flex items-center gap-4`}>
            <div className={`w-12 h-12 rounded-xl ${k.color} flex items-center justify-center shrink-0`}>
              <k.icon className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium">{k.label}</p>
              <p className="text-2xl font-bold text-foreground">{k.value.toLocaleString("fr-FR")} <span className="text-sm font-normal text-muted-foreground">XOF</span></p>
              <p className="text-xs text-muted-foreground">{filtered.length} inscription{filtered.length > 1 ? "s" : ""}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Tarifs info */}
      <div className="bg-muted/40 border border-border rounded-xl p-4 flex flex-wrap gap-4 text-sm">
        <div className="flex items-center gap-2">
          <span className="text-xl">🏛️</span>
          <span className="font-semibold text-foreground">École Publique :</span>
          <span className="font-bold text-blue-700">500 XOF</span>
          <span className="text-muted-foreground">/ inscription</span>
        </div>
        <div className="w-px bg-border hidden sm:block" />
        <div className="flex items-center gap-2">
          <span className="text-xl">🏫</span>
          <span className="font-semibold text-foreground">École Privée :</span>
          <span className="font-bold text-violet-700">1 000 XOF</span>
          <span className="text-muted-foreground">/ inscription</span>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <select value={filterSchool} onChange={e => setFilterSchool(e.target.value)}
          className="h-9 rounded-lg border border-input bg-background px-3 text-sm">
          <option value="all">Tous les établissements</option>
          {schools.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="h-9 rounded-lg border border-input bg-background px-3 text-sm">
          <option value="all">Tous statuts</option>
          <option value="pending">En attente</option>
          <option value="collected">Encaissé</option>
        </select>
        <select value={filterYear} onChange={e => setFilterYear(e.target.value)}
          className="h-9 rounded-lg border border-input bg-background px-3 text-sm">
          <option value="all">Toutes les années</option>
          {years.map(y => <option key={y} value={y}>{y}</option>)}
        </select>
      </div>

      {/* Per-school breakdown */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-foreground">Par établissement</h2>
        {bySchool.length === 0 ? (
          <div className="bg-card border border-border rounded-2xl p-12 text-center">
            <DollarSign className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-muted-foreground font-medium">Aucune inscription enregistrée</p>
            <p className="text-sm text-muted-foreground mt-1">Les revenus apparaîtront ici dès la première inscription.</p>
          </div>
        ) : bySchool.map(sch => (
          <div key={sch.school_id} className="bg-card border border-border rounded-2xl overflow-hidden">
            {/* School header */}
            <div className="flex items-center justify-between gap-4 p-4">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Building2 className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-bold text-foreground truncate">{sch.school_name}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${TYPE_COLOR[sch.school_type]}`}>
                      {TYPE_LABEL[sch.school_type]}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">{sch.count} inscription{sch.count > 1 ? "s" : ""} · {TYPE_AMOUNT[sch.school_type]} XOF/élève</p>
                </div>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <div className="text-right hidden sm:block">
                  <p className="text-xs text-muted-foreground">Total</p>
                  <p className="font-bold text-foreground">{sch.total.toLocaleString("fr-FR")} XOF</p>
                </div>
                <div className="text-right hidden sm:block">
                  <p className="text-xs text-amber-600">En attente</p>
                  <p className="font-bold text-amber-700">{sch.pending.toLocaleString("fr-FR")} XOF</p>
                </div>
                {sch.pending > 0 && (
                  <button
                    onClick={() => handleCollectAll(sch.school_id)}
                    disabled={collecting === "school_" + sch.school_id}
                    className="flex items-center gap-1.5 bg-green-600 hover:bg-green-700 disabled:opacity-60 text-white text-xs font-bold px-3 py-2 rounded-xl transition-colors"
                  >
                    <BadgeCheck className="h-3.5 w-3.5" />
                    {collecting === "school_" + sch.school_id ? "…" : "Encaisser tout"}
                  </button>
                )}
                <button onClick={() => setExpandedSchool(expandedSchool === sch.school_id ? null : sch.school_id)}
                  className="p-2 rounded-lg hover:bg-muted transition-colors">
                  {expandedSchool === sch.school_id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Progress bar */}
            <div className="px-4 pb-2">
              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                <span className="text-green-600 font-semibold">Encaissé : {sch.collected.toLocaleString("fr-FR")} XOF</span>
                <span className="mx-1">·</span>
                <span className="text-amber-600 font-semibold">Reste : {sch.pending.toLocaleString("fr-FR")} XOF</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-green-500 h-2 rounded-full transition-all"
                  style={{ width: sch.total > 0 ? `${Math.round((sch.collected / sch.total) * 100)}%` : "0%" }}
                />
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">
                {sch.total > 0 ? Math.round((sch.collected / sch.total) * 100) : 0}% encaissé
              </p>
            </div>

            {/* Expanded rows */}
            {expandedSchool === sch.school_id && (
              <div className="border-t border-border">
                <div className="max-h-64 overflow-y-auto">
                  {sch.revenues.map(r => (
                    <div key={r.id} className="flex items-center gap-3 px-4 py-2.5 border-b border-border/50 last:border-0 hover:bg-muted/30">
                      <div className={`w-2 h-2 rounded-full shrink-0 ${r.is_collected ? "bg-green-500" : "bg-amber-400"}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{r.student_name}</p>
                        <p className="text-xs text-muted-foreground">{r.enrollment_date} · {r.academic_year}</p>
                      </div>
                      <p className="font-bold text-sm text-foreground shrink-0">{(r.amount || 0).toLocaleString("fr-FR")} XOF</p>
                      {r.is_collected ? (
                        <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium shrink-0">Encaissé</span>
                      ) : (
                        <button
                          onClick={() => handleCollect(r)}
                          disabled={collecting === r.id}
                          className="text-[10px] bg-amber-100 text-amber-700 hover:bg-green-100 hover:text-green-700 border border-amber-300 px-2 py-0.5 rounded-full font-medium shrink-0 transition-colors disabled:opacity-60"
                        >
                          {collecting === r.id ? "…" : "Encaisser"}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}