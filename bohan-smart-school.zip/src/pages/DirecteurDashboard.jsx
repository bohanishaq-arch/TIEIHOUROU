import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../hooks/useSchool";
import { motion } from "framer-motion";
import { School, GraduationCap, CheckCircle2, ChevronRight, X } from "lucide-react";

// Sub-components
import DirecteurKpiRow from "../components/directeur/DirecteurKpiRow";
import DirecteurAlerts from "../components/directeur/DirecteurAlerts";
import DirecteurTeacherPanel from "../components/directeur/DirecteurTeacherPanel";
import DirecteurClassPerf from "../components/directeur/DirecteurClassPerf";
import DirecteurQuickNav from "../components/directeur/DirecteurQuickNav";
import DirecteurAIInsights from "../components/directeur/DirecteurAIInsights";
import DirecteurReportsPanel from "../components/directeur/DirecteurReportsPanel";
import ExamValidation from "../components/director/ExamValidation";
import DirecteurFinancePanel from "../components/directeur/DirecteurFinancePanel";

function avg(grades) {
  if (!grades.length) return 0;
  return grades.reduce((s, g) => s + g.score, 0) / grades.length;
}

export default function DirecteurDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState({
    students: [], classes: [], assignments: [], reports: [],
    grades: [], settings: null, exams: [], absences: [], incidents: [], subjects: [],
  });
  const [loading, setLoading] = useState(true);
  const [showExamModal, setShowExamModal] = useState(false);

  const schoolId = getSchoolId();

  useEffect(() => {
    async function load() {
      const f = schoolId ? { school_id: schoolId } : {};
      const [students, classes, assignments, reports, grades, settings, exams, absences, incidents, subjects] =
        await Promise.all([
          base44.entities.Student.filter(f),
          base44.entities.Class.filter(f),
          base44.entities.TeacherAssignment.filter(f),
          base44.entities.TeacherReport.filter(f, "-created_date", 50),
          base44.entities.Grade.filter(f),
          base44.entities.SchoolSettings.filter(f),
          base44.entities.Exam.filter(f),
          base44.entities.Absence.filter(f),
          base44.entities.Incident.filter(f),
          base44.entities.Subject.filter(f),
        ]);

      setData({ students, classes, assignments, reports, grades, settings: settings[0] || null, exams, absences, incidents, subjects });
      setLoading(false);
    }
    load();
  }, [schoolId]);

  // ── Derived stats ──────────────────────────────────────────────────────────
  const stats = useMemo(() => {
    const { students, classes, assignments, grades, absences, incidents, exams, reports } = data;

    const teacherEmails = [...new Set(assignments.map(a => a.teacher_email).filter(Boolean))];

    // Global weighted average
    let totalScore = 0, totalW = 0;
    grades.forEach(g => {
      const sub = data.subjects.find(s => s.id === g.subject_id);
      const coef = sub?.coefficient || 1;
      totalScore += g.score * coef;
      totalW += coef;
    });
    const avgGeneral = totalW ? totalScore / totalW : 0;

    // Success rate
    const successRate = grades.length
      ? Math.round((grades.filter(g => g.score >= 10).length / grades.length) * 100)
      : 0;

    // Pending notes (exams with 0 grades)
    const examIds = new Set(grades.map(g => g.exam_id));
    const pendingNotes = exams.filter(e => !examIds.has(e.id)).length;

    return {
      students: students.length,
      classes: classes.length,
      teachers: teacherEmails.length,
      avgGeneral,
      successRate,
      absences: absences.length,
      incidents: incidents.filter(i => i.status === "signalé").length,
      pendingNotes,
      teacherEmails,
    };
  }, [data]);

  // ── Smart alerts ───────────────────────────────────────────────────────────
  const alerts = useMemo(() => {
    const list = [];
    const { students, grades, exams, reports, incidents } = data;

    // Élèves en difficulté
    const weak = students.filter(s => {
      const sg = grades.filter(g => g.student_id === s.id);
      return sg.length && avg(sg) < 10;
    });
    if (weak.length) {
      list.push({
        type: "danger",
        title: `${weak.length} élève${weak.length > 1 ? "s" : ""} en difficulté`,
        description: `Moyenne < 10. ${weak.slice(0, 3).map(s => `${s.first_name} ${s.last_name}`).join(", ")}${weak.length > 3 ? ` +${weak.length - 3} autres` : ""}.`,
        to: "/averages",
      });
    }

    // Examens en attente de validation
    const pendingExams = exams.filter(e => e.validation_status === "en_attente");
    if (pendingExams.length) {
      list.push({
        type: "warning",
        title: `${pendingExams.length} examen${pendingExams.length > 1 ? "s" : ""} à valider`,
        description: "Des professeurs attendent votre approbation pour procéder.",
        to: null,
        onAction: () => setShowExamModal(true),
      });
    }

    // Rapports en attente
    const pendingRep = reports.filter(r => r.status === "envoyé" || r.status === "lu");
    if (pendingRep.length) {
      list.push({
        type: "info",
        title: `${pendingRep.length} rapport${pendingRep.length > 1 ? "s" : ""} non validés`,
        description: `Rapports de cours envoyés par des professeurs en attente de validation.`,
        to: "/teacher-reports",
      });
    }

    // Incidents non traités
    const openIncidents = data.incidents.filter(i => i.status === "signalé");
    if (openIncidents.length) {
      list.push({
        type: "warning",
        title: `${openIncidents.length} incident${openIncidents.length > 1 ? "s" : ""} non traité${openIncidents.length > 1 ? "s" : ""}`,
        description: `Des incidents disciplinaires attendent votre décision.`,
        to: "/educateur",
      });
    }

    // Bonne performance
    if (!weak.length && !pendingExams.length) {
      list.push({
        type: "success",
        title: "Aucune alerte critique",
        description: `Taux de réussite : ${stats.successRate}%. Les performances générales sont satisfaisantes.`,
      });
    }

    return list;
  }, [data, stats]);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin" />
    </div>
  );

  const schoolName = data.settings?.school_name || "Établissement";
  const firstName = user?.full_name?.split(" ")[0] || "Directeur";

  return (
    <div className="space-y-6" style={{ background: "#F8FAFC", minHeight: "100vh" }}>

      {/* ── Hero Banner ─────────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl shadow-xl"
        style={{ background: "linear-gradient(135deg, #1E3A5F 0%, #1E40AF 50%, #312E81 100%)" }}
      >
        {/* Decorative circles */}
        <div className="absolute top-0 right-0 w-80 h-80 rounded-full opacity-10"
          style={{ background: "radial-gradient(circle, #60A5FA, transparent)", transform: "translate(30%, -30%)" }} />
        <div className="absolute bottom-0 left-20 w-40 h-40 rounded-full opacity-10"
          style={{ background: "radial-gradient(circle, #A78BFA, transparent)", transform: "translateY(30%)" }} />

        <div className="relative px-6 py-5 flex flex-col sm:flex-row sm:items-center gap-4">
          {/* Icon + Title */}
          <div className="flex items-center gap-4 flex-1 min-w-0">
            <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur border border-white/20 flex items-center justify-center shrink-0">
              <GraduationCap className="h-7 w-7 text-white" />
            </div>
            <div className="min-w-0">
              <p className="text-blue-200 text-xs font-medium uppercase tracking-wider">Directeur des Études</p>
              <h1 className="text-xl font-bold text-white truncate">{firstName}</h1>
              <p className="text-blue-300 text-sm mt-0.5 truncate">{schoolName}</p>
            </div>
          </div>

          {/* Stats strip */}
          <div className="flex items-center gap-4 sm:gap-6 shrink-0 bg-white/10 backdrop-blur border border-white/15 rounded-2xl px-4 py-3">
            <StatChip value={stats.students} label="Élèves" />
            <div className="w-px h-8 bg-white/20" />
            <StatChip value={stats.teachers} label="Professeurs" />
            <div className="w-px h-8 bg-white/20" />
            <StatChip value={stats.classes} label="Classes" />
            <div className="w-px h-8 bg-white/20" />
            <StatChip value={`${stats.avgGeneral.toFixed(1)}/20`} label="Moy. générale" />
          </div>
        </div>

        {/* Exam validation CTA if pending */}
        {data.exams.filter(e => e.validation_status === "en_attente").length > 0 && (
          <div className="relative border-t border-white/10 px-6 py-2.5 flex items-center justify-between bg-white/5">
            <p className="text-xs text-blue-200 font-medium">
              📋 {data.exams.filter(e => e.validation_status === "en_attente").length} examen(s) en attente de validation
            </p>
            <button
              onClick={() => setShowExamModal(true)}
              className="text-xs font-bold text-white bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg flex items-center gap-1 transition-colors"
            >
              Valider <ChevronRight size={13} />
            </button>
          </div>
        )}
      </motion.div>

      {/* ── KPI Row ─────────────────────────────────────────────────────── */}
      <DirecteurKpiRow stats={stats} />

      {/* ── Alerts ──────────────────────────────────────────────────────── */}
      <DirecteurAlerts alerts={alerts} />

      {/* ── AI Insights ─────────────────────────────────────────────────── */}
      <DirecteurAIInsights
        grades={data.grades}
        students={data.students}
        classes={data.classes}
        subjects={data.subjects}
      />

      {/* ── Performance + Teacher Panel ──────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <DirecteurClassPerf
          classes={data.classes}
          grades={data.grades}
          subjects={data.subjects}
        />
        <DirecteurTeacherPanel
          teachers={stats.teacherEmails}
          assignments={data.assignments}
          grades={data.grades}
          reports={data.reports}
        />
      </div>

      {/* ── Finance Supervision ──────────────────────────────────────────── */}
      <DirecteurFinancePanel schoolId={schoolId} />

      {/* ── Reports + Quick Nav ──────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <DirecteurReportsPanel reports={data.reports} />
        <DirecteurQuickNav />
      </div>

      {/* ── Exam Validation Modal ────────────────────────────────────────── */}
      {showExamModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
          onClick={() => setShowExamModal(false)}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h2 className="text-base font-bold flex items-center gap-2 text-slate-900">
                <CheckCircle2 className="h-5 w-5 text-violet-500" />
                Validation des examens
              </h2>
              <button onClick={() => setShowExamModal(false)} className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center">
                <X className="h-5 w-5 text-slate-500" />
              </button>
            </div>
            <div className="overflow-y-auto flex-1 p-6">
              <ExamValidation />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatChip({ value, label }) {
  return (
    <div className="text-center">
      <p className="text-lg font-bold text-white leading-none">{value}</p>
      <p className="text-[10px] text-blue-300 mt-0.5 uppercase tracking-wide">{label}</p>
    </div>
  );
}