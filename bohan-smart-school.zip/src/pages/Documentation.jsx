import { useState } from "react";
import {
  BookOpen, ChevronDown, ChevronRight, Users, School, ClipboardList,
  TrendingUp, FileText, BarChart3, UserCog, Settings, ShieldAlert,
  ShieldCheck, UserPlus, Send, Shield, Calendar, DollarSign, Building2,
  GraduationCap, BookMarked, KeyRound, Lock, Mail, Bell, Star, AlertCircle,
  CheckCircle2, Info, Lightbulb, ArrowRight, Layers, Globe, Printer, Eye,
  RefreshCw, Copy, Trash2, Pencil, Search, Filter, Plus, Heart, Award,
  Target, Zap, MessageSquare, Users2, HelpCircle, ChevronUp
} from "lucide-react";

// ─── NOTICE D'UTILISATION COMPLÈTE ────────────────────────────────────────────

const NOTICE_SECTIONS = [
  // ─── 1. PRÉSENTATION ───────────────────────────────────────────────────────
  {
    id: "presentation",
    icon: BookOpen,
    color: "from-blue-500 to-blue-700",
    bg: "bg-blue-50",
    text: "text-blue-700",
    title: "1. Présentation de l'application BOHAN",
    subtitle: "But, contexte et avantages",
    content: [
      {
        type: "intro",
        text: "BOHAN est une plateforme de gestion scolaire numérique 100% en ligne, conçue spécialement pour les établissements scolaires d'Afrique francophone (Côte d'Ivoire et pays voisins). Elle remplace les registres papier, les cahiers de notes manuscrits et les communications désorganisées par un seul outil moderne, accessible depuis n'importe quel téléphone, tablette ou ordinateur."
      },
      {
        type: "acronym",
        letters: [
          { letter: "B", word: "Base", color: "bg-blue-600", desc: "Le socle fondateur — BOHAN est la base centrale sur laquelle repose toute la gestion de l'établissement. Toutes les données (élèves, notes, finances, présences) sont stockées et organisées en un seul endroit fiable." },
          { letter: "O", word: "des Opérations", color: "bg-indigo-600", desc: "Les opérations du quotidien — inscrire un élève, saisir une note, enregistrer un paiement, pointer une absence, valider un examen… BOHAN gère toutes les opérations administratives et pédagogiques de l'école." },
          { letter: "H", word: "Harmonisation", color: "bg-violet-600", desc: "La standardisation des pratiques — BOHAN impose les mêmes règles et formats pour tous les établissements : bulletins officiels, calcul des moyennes, codes permanents, rôles définis. Tout le monde parle le même langage scolaire." },
          { letter: "A", word: "Académique", color: "bg-purple-600", desc: "Centré sur l'académique — l'application est pensée pour le monde scolaire ivoirien : trimestres/semestres, coefficients officiels, bulletins au format du Ministère de l'Éducation Nationale, niveaux de 6ème à Terminale." },
          { letter: "N", word: "Numérique", color: "bg-pink-600", desc: "100% digital — plus de papier perdu, plus de registres manuels, plus de calculs à la main. BOHAN modernise l'école africaine grâce au numérique, accessible sur téléphone, tablette ou ordinateur." },
        ]
      },
      {
        type: "text",
        title: "🎯 À quoi sert BOHAN ?",
        text: "BOHAN permet à un établissement scolaire de gérer l'intégralité de sa vie académique et administrative depuis une seule application : inscrire les élèves, saisir les notes, calculer les moyennes, imprimer les bulletins, suivre les présences, gérer les finances et communiquer entre les différents acteurs de l'école."
      },
      {
        type: "features",
        title: "✅ Avantages pour chaque utilisateur",
        items: [
          {
            name: "📱 Pour les élèves",
            desc: "Consulter ses notes, moyennes et bulletins en temps réel depuis son téléphone. Voir l'emploi du temps, les devoirs à venir, et son état de paiement de frais scolaires sans se déplacer au bureau."
          },
          {
            name: "👨‍🏫 Pour les professeurs",
            desc: "Saisir les notes directement depuis le portable, créer des examens, envoyer des rapports de cours, gérer les présences et communiquer avec les élèves et la direction. Fini les cahiers de notes perdus !"
          },
          {
            name: "🏫 Pour l'administration",
            desc: "Gérer les élèves, classes, matières et finances en quelques clics. Générer des bulletins officiels imprimables, suivre les performances globales et avoir des statistiques complètes sur l'établissement."
          },
          {
            name: "👨‍👩‍👧 Pour les parents",
            desc: "Via l'onglet 'Vue Parent' du portail élève, voir en temps réel les présences, les notes, l'emploi du temps et les examens à venir de son enfant, sans avoir à appeler l'école."
          },
          {
            name: "💰 Pour les comptables",
            desc: "Gérer les inscriptions financières, enregistrer les paiements, imprimer des reçus officiels et suivre les impayés depuis un tableau de bord clair."
          },
          {
            name: "📊 Pour les directeurs",
            desc: "Avoir une vue d'ensemble complète sur l'établissement : notes, examens à valider, incidents disciplinaires, rapports des professeurs, tout en un seul endroit."
          }
        ]
      },
      {
        type: "tip",
        text: "BOHAN est accessible sur tous les appareils : smartphones, tablettes et ordinateurs. Aucune installation requise — il suffit d'ouvrir un navigateur web et de se connecter."
      }
    ]
  },

  // ─── 2. FONCTIONNEMENT GÉNÉRAL ─────────────────────────────────────────────
  {
    id: "fonctionnement",
    icon: Zap,
    color: "from-violet-500 to-purple-700",
    bg: "bg-violet-50",
    text: "text-violet-700",
    title: "2. Fonctionnement général",
    subtitle: "Connexion, comptes et profils utilisateurs",
    content: [
      {
        type: "text",
        title: "🔐 Comment se connecter ?",
        text: "BOHAN utilise la connexion Google pour garantir la sécurité. Chaque utilisateur doit avoir un compte Google (Gmail). Après la connexion Google, un formulaire de validation d'accès s'affiche pour confirmer l'identité dans l'établissement."
      },
      {
        type: "flow",
        title: "📋 Étapes de première connexion",
        steps: [
          "Ouvrez l'application BOHAN depuis votre navigateur (Chrome, Firefox, Safari…)",
          "Cliquez sur 'Se connecter avec Google' et choisissez votre compte Gmail",
          "Le formulaire de validation d'accès apparaît — saisissez votre Code d'accès permanent (fourni par l'administration)",
          "Entrez ensuite votre Mot de passe initial (fourni sur la fiche d'identifiants imprimée)",
          "Le système vérifie votre identité et vous redirige automatiquement vers votre espace selon votre rôle",
          "À la prochaine connexion, seule la connexion Google suffit — le code et mot de passe ne sont demandés qu'une fois"
        ]
      },
      {
        type: "features",
        title: "👥 Les 6 profils d'utilisateurs",
        items: [
          {
            name: "🛡️ Super Administrateur (Admin)",
            desc: "C'est le responsable technique de la plateforme. Il crée et gère tous les établissements, active les licences, et supervise l'ensemble du système. Il a accès à tout, partout."
          },
          {
            name: "🏫 Directeur / Proviseur",
            desc: "Responsable d'un établissement. Il valide les examens des professeurs, supervise les notes, lit les rapports, traite les incidents graves et prend les décisions de fin d'année (admis/redoublant)."
          },
          {
            name: "👨‍🏫 Professeur",
            desc: "Enseigne des matières dans des classes. Il saisit les notes de ses examens, gère les présences en cours, envoie des rapports de cours à la direction et aux élèves, et peut demander des ajustements de matières."
          },
          {
            name: "🎓 Élève",
            desc: "Apprenant inscrit dans une classe. Il consulte ses notes, moyennes, bulletins, emploi du temps, devoirs à venir et état de ses frais scolaires via le portail élève dédié."
          },
          {
            name: "🛡️ Éducateur",
            desc: "Responsable de la discipline et de la vie scolaire. Il gère les absences quotidiennes, les retards, les incidents disciplinaires et envoie des rapports au directeur."
          },
          {
            name: "💰 Comptable",
            desc: "Gère la partie financière : inscription des élèves, enregistrement des paiements, génération de reçus officiels, suivi des impayés et rapports financiers."
          }
        ]
      },
      {
        type: "tip",
        text: "Votre code d'accès permanent et votre mot de passe initial vous ont été remis sur une fiche imprimée par l'administration lors de votre inscription. Conservez-la précieusement !"
      }
    ]
  },

  // ─── 3. FONCTIONNALITÉS COMPLÈTES ──────────────────────────────────────────
  {
    id: "fonctionnalites",
    icon: Layers,
    color: "from-emerald-500 to-teal-700",
    bg: "bg-emerald-50",
    text: "text-emerald-700",
    title: "3. Description des fonctionnalités",
    subtitle: "Tout ce que l'application sait faire",
    content: [
      {
        type: "text",
        title: "📊 Tableau de bord (Dashboard)",
        text: "C'est la première page que vous voyez après votre connexion. Il affiche un résumé de l'activité de l'école : nombre d'élèves, nombre de classes, moyennes générales, alertes importantes, et des graphiques de performance. Il est personnalisé selon votre rôle."
      },
      {
        type: "features",
        title: "📚 Gestion des cours et des classes",
        items: [
          {
            name: "📋 Classes",
            desc: "Chaque classe (ex: 3ème-A, Tle-C) regroupe ses élèves, ses matières et son emploi du temps. L'admin peut créer toutes les classes d'une année scolaire en un seul clic grâce à la génération automatique."
          },
          {
            name: "📖 Matières",
            desc: "Chaque matière a un nom (ex: Mathématiques), un code abrégé (MATH), un coefficient et les niveaux concernés. Le coefficient influence directement le calcul des moyennes. Un programme standard (collège ou lycée) peut être généré automatiquement."
          },
          {
            name: "👨‍🏫 Assignation professeur–matière–classe",
            desc: "L'administrateur assigne chaque professeur à ses matières et ses classes. Un professeur ne voit et ne gère que les données des classes et matières qui lui ont été attribuées."
          },
          {
            name: "📅 Emploi du temps",
            desc: "L'emploi du temps hebdomadaire (lundi au samedi) est créé par l'admin. Il est visible par les professeurs et les élèves. Le système détecte automatiquement les conflits d'horaires."
          }
        ]
      },
      {
        type: "features",
        title: "📝 Gestion des devoirs et examens",
        items: [
          {
            name: "➕ Créer un examen",
            desc: "Le professeur crée un examen en précisant : le type (Devoir, Interrogation, Examen trimestriel, TP, Oral), la matière, la classe, le titre, le chapitre, la date, la durée, le barème et des instructions pour les élèves."
          },
          {
            name: "👁️ Visible par les élèves",
            desc: "Dès qu'un examen est créé, il apparaît automatiquement dans la section 'Devoirs & Examens' du portail élève. L'élève voit la date, le sujet, les instructions et peut s'y préparer à l'avance."
          },
          {
            name: "✅ Validation par le directeur",
            desc: "Selon les paramètres de l'établissement, les examens peuvent nécessiter une validation du directeur avant d'être officiel. Le directeur approuve ou rejette avec une explication."
          },
          {
            name: "📄 Correction publiable",
            desc: "Après l'examen, le professeur peut publier la correction (texte ou fichier PDF). Elle devient visible dans le portail élève uniquement si le professeur choisit de la publier."
          }
        ]
      },
      {
        type: "features",
        title: "📊 Suivi des notes et performances",
        items: [
          {
            name: "🖊️ Saisie des notes",
            desc: "Le professeur saisit les notes de tous les élèves de la classe via un tableau rapide. Il peut ajouter un commentaire personnalisé pour chaque élève (ex: 'Bon travail mais attention à la présentation')."
          },
          {
            name: "📈 Calcul automatique des moyennes",
            desc: "Les moyennes par matière, par trimestre/semestre et la moyenne annuelle finale sont calculées automatiquement. Formule officielle trimestre : (T1×1 + T2×2 + T3×2) ÷ 5."
          },
          {
            name: "🏅 Classements",
            desc: "L'application affiche le classement de chaque élève dans sa classe et dans son niveau, avec son rang, sa moyenne et son évolution."
          },
          {
            name: "🎨 Code couleur des notes",
            desc: "Vert (≥14/20) = Très bien. Jaune (≥10/20) = Passable. Rouge (<10/20) = Insuffisant. Ce code couleur est utilisé partout dans l'application."
          }
        ]
      },
      {
        type: "features",
        title: "✉️ Communication entre élèves et professeurs",
        items: [
          {
            name: "📤 Rapports de cours du professeur",
            desc: "Le professeur envoie des rapports détaillés (objectifs, contenu, activités, devoirs à faire, remarques) depuis son espace. Ces rapports sont visibles dans la section 'Messages' du portail élève."
          },
          {
            name: "📬 Messages reçus par l'élève",
            desc: "L'élève voit dans 'Messages' tous les rapports envoyés par ses professeurs, organisés par date. Les nouveaux messages apparaissent avec un point de notification."
          },
          {
            name: "📋 Rapports à la direction",
            desc: "Les professeurs et éducateurs peuvent envoyer des rapports directement au directeur, qui les lit et peut y répondre depuis son tableau de bord."
          }
        ]
      },
      {
        type: "features",
        title: "🔔 Notifications et alertes",
        items: [
          {
            name: "⚠️ Alertes examens (élèves)",
            desc: "Le portail élève affiche automatiquement des alertes pour les examens à venir. Si l'examen est dans moins de 7 jours : alerte 'BIENTÔT'. Moins de 3 jours : alerte rouge 'URGENT' avec badge animé."
          },
          {
            name: "🔴 Alertes d'impayés",
            desc: "Le tableau de bord affiche les élèves en retard de paiement de frais scolaires, avec le montant restant dû. Le comptable est informé en temps réel."
          },
          {
            name: "📊 Indicateurs de vigilance",
            desc: "Le tableau de bord admin/directeur signale les élèves en difficulté (moyenne < 10), les examens en attente de validation, les notes manquantes et les incidents non traités."
          }
        ]
      },
      {
        type: "features",
        title: "📅 Emploi du temps",
        items: [
          {
            name: "🗓️ Vue hebdomadaire",
            desc: "L'emploi du temps affiche 6 jours (lundi au samedi) avec tous les créneaux horaires. Chaque cours est affiché avec la matière, le professeur, la salle et les horaires. Couleurs distinctes selon la matière."
          },
          {
            name: "⏰ Règles horaires respectées",
            desc: "Le système impose les horaires scolaires officiels : 7h00–12h00 (matin) et 13h30–18h00 (après-midi). Les pauses (10h00–10h15 et 12h00–13h30) ne peuvent pas être occupées par des cours."
          },
          {
            name: "🔴 Détection des conflits",
            desc: "Impossible de placer deux cours pour la même classe ou le même professeur au même moment. Le système bloque automatiquement les conflits avec un message d'erreur clair."
          }
        ]
      },
      {
        type: "features",
        title: "📁 Documents et bulletins",
        items: [
          {
            name: "📄 Bulletins officiels",
            desc: "BOHAN génère automatiquement des bulletins au format officiel ivoirien avec l'en-tête complet (République, Ministère, logo de l'école). Les bulletins sont imprimables en PDF ou consultables en ligne."
          },
          {
            name: "🖨️ Documents imprimables",
            desc: "Bulletins scolaires, fiches d'identifiants, reçus de paiement, carte d'identité scolaire de l'élève — tous peuvent être imprimés directement depuis l'application."
          },
          {
            name: "📸 Photo de l'élève",
            desc: "Chaque élève peut télécharger sa photo depuis le portail élève. Elle apparaît sur sa carte d'identité scolaire numérique et dans son dossier administratif."
          }
        ]
      },
      {
        type: "features",
        title: "⚙️ Paramètres du compte",
        items: [
          {
            name: "👤 Modifier son nom",
            desc: "Depuis le menu profil (icône ronde en haut à droite) → 'Paramètres du compte', vous pouvez modifier le nom affiché dans l'application."
          },
          {
            name: "🔑 Changer son mot de passe",
            desc: "Dans 'Paramètres du compte', onglet 'Mot de passe' : entrez l'ancien mot de passe, le nouveau (minimum 6 caractères) et confirmez. Le changement est immédiat."
          },
          {
            name: "🌙 Mode sombre/clair",
            desc: "L'application s'adapte automatiquement au thème de votre appareil (clair ou sombre), sans configuration manuelle nécessaire."
          }
        ]
      }
    ]
  },

  // ─── 4. GUIDE ÉTAPE PAR ÉTAPE ──────────────────────────────────────────────
  {
    id: "guide",
    icon: Target,
    color: "from-rose-500 to-pink-700",
    bg: "bg-rose-50",
    text: "text-rose-700",
    title: "4. Guide d'utilisation étape par étape",
    subtitle: "Comment faire chaque action concrètement",
    content: [
      {
        type: "flow",
        title: "📚 Comment ajouter un cours / examen (Professeur)",
        steps: [
          "Connectez-vous avec votre compte Google et validez votre accès",
          "Vous êtes automatiquement dirigé vers votre tableau de bord professeur",
          "Cliquez sur la tuile '📝 Devoirs & Examens' dans les actions rapides",
          "Cliquez sur le bouton '+ Nouveau devoir' en haut à droite",
          "Sélectionnez la classe concernée dans le menu déroulant",
          "Sélectionnez la matière (uniquement celles qui vous sont assignées)",
          "Entrez le titre de l'évaluation (ex: 'Devoir N°1 – Les fractions')",
          "Choisissez le type (Devoir, Interrogation, Examen trimestriel, TP, Oral)",
          "Sélectionnez la période (Trimestre 1, 2, 3 ou Semestre 1, 2)",
          "Entrez la date prévue et la durée en minutes",
          "Ajoutez le barème (note maximale, par défaut /20)",
          "Rédigez les instructions pour les élèves dans la zone de texte",
          "Cliquez 'Publier' — l'examen apparaît immédiatement dans le portail des élèves de la classe"
        ]
      },
      {
        type: "flow",
        title: "📊 Comment saisir les notes d'un examen (Professeur)",
        steps: [
          "Depuis votre tableau de bord, cliquez sur 'Notes' dans la navigation ou sur la tuile '📊 Notes'",
          "Filtrez par classe puis par matière — seuls VOS examens apparaissent",
          "Cliquez sur l'examen pour lequel vous voulez saisir les notes",
          "Une grille s'affiche avec tous les élèves de la classe",
          "Pour chaque élève, cliquez sur la case vide et tapez la note (ex: 14.5)",
          "Optionnel : ajoutez un commentaire personnalisé pour l'élève (ex: 'Bonne amélioration mais des erreurs de calcul')",
          "Les notes se sauvegardent automatiquement pendant la saisie — un indicateur de synchronisation confirme l'enregistrement",
          "Une fois tous les élèves notés, cliquez 'Enregistrer et verrouiller' pour finaliser",
          "Une note verrouillée ne peut plus être modifiée sans demande de correction"
        ]
      },
      {
        type: "flow",
        title: "📖 Comment consulter ses devoirs (Élève)",
        steps: [
          "Connectez-vous avec votre compte Google et validez votre accès",
          "Vous êtes redirigé vers le portail élève",
          "Cliquez sur l'onglet '📝 Devoirs & Examens' dans la barre de navigation",
          "La liste de tous les examens de votre classe s'affiche, triés par date",
          "Les examens à venir sont en haut avec leur date, le sujet et les instructions du professeur",
          "Les examens passés montrent votre note obtenue (avec code couleur vert/jaune/rouge)",
          "Si une correction a été publiée, un bouton 'Voir la correction' apparaît",
          "Cliquez sur un examen pour voir tous les détails : chapitre, durée, barème, instructions complètes"
        ]
      },
      {
        type: "flow",
        title: "📈 Comment consulter ses notes et moyennes (Élève)",
        steps: [
          "Depuis le portail élève, cliquez sur l'onglet '📊 Mes notes'",
          "Vos notes sont organisées par trimestre ou semestre",
          "Chaque note affiche la matière, le titre de l'évaluation, le type et votre score (ex: 15/20)",
          "Pour voir vos moyennes calculées, cliquez sur l'onglet '📈 Mes moyennes'",
          "Vous y trouvez vos moyennes par matière et par période, avec les coefficients",
          "La moyenne générale de chaque trimestre/semestre est affichée en gros en haut",
          "Sur la dernière période : la moyenne annuelle finale apparaît avec la formule de calcul"
        ]
      },
      {
        type: "flow",
        title: "✉️ Comment communiquer avec son professeur (Élève)",
        steps: [
          "Depuis le portail élève, cliquez sur l'onglet '✉️ Messages'",
          "Vous voyez tous les rapports et communications envoyés par vos professeurs",
          "Chaque message indique : la matière, le type (cours/devoir/examen), la date et le titre",
          "Cliquez sur 'Voir le contenu complet' pour dépiler les détails complets du rapport",
          "Pour les examens à venir : cliquez sur l'onglet 'Alertes examens' pour voir les dates importantes",
          "Note : la communication directe élève→professeur se fait en dehors de l'application (WhatsApp, face-à-face). BOHAN est une communication professeur→élève/classe"
        ]
      },
      {
        type: "flow",
        title: "👨‍👩‍👧 Comment un parent consulte les infos de son enfant",
        steps: [
          "Demandez à votre enfant de vous ouvrir son portail élève sur son téléphone ou le vôtre",
          "Dans les onglets en haut, cliquez sur '👨‍👩‍👧 Vue Parent'",
          "Vous voyez immédiatement : la carte d'identité de l'enfant avec sa moyenne annuelle",
          "Le bloc 'Vue d'ensemble' montre les présences récentes, absences, nombre de notes et examens à venir",
          "Cliquez sur 'Présences' pour voir l'historique détaillé des présences/absences en cours",
          "Cliquez sur 'Notes' pour consulter toutes les notes par trimestre",
          "Cliquez sur 'Emploi du temps' pour voir les cours de la semaine",
          "Cliquez sur 'Devoirs & Examens' pour voir les évaluations à venir avec dates et sujets",
          "Cliquez sur 'Bulletin' pour consulter le bulletin scolaire officiel par période"
        ]
      },
      {
        type: "flow",
        title: "➕ Comment inscrire un élève (Comptable/Admin)",
        steps: [
          "Allez dans 'Inscription' depuis le menu de navigation",
          "Sélectionnez l'onglet 'Inscription financière'",
          "Recherchez l'élève par son matricule ou son nom, ou créez un nouveau dossier",
          "Sélectionnez la classe affectée à l'élève",
          "Choisissez le mode de paiement : 'Comptant' (tout payer d'un coup) ou 'Échelonné' (en plusieurs fois)",
          "Le système calcule automatiquement les frais selon le barème de la classe",
          "Entrez le montant versé lors de l'inscription et le moyen de paiement (espèces, mobile money, chèque)",
          "Cliquez 'Valider l'inscription' — un reçu officiel imprimable est généré automatiquement"
        ]
      }
    ]
  },

  // ─── 5. OPTIONS AVANCÉES ───────────────────────────────────────────────────
  {
    id: "avancees",
    icon: Settings,
    color: "from-amber-500 to-orange-700",
    bg: "bg-amber-50",
    text: "text-amber-700",
    title: "5. Options avancées",
    subtitle: "Profil, gestion des utilisateurs, statistiques",
    content: [
      {
        type: "features",
        title: "👤 Paramétrage du profil",
        items: [
          {
            name: "🔧 Accéder aux paramètres",
            desc: "Cliquez sur votre avatar (initiale en haut à droite) → menu déroulant → 'Paramètres du compte'. Une fenêtre s'ouvre avec 3 onglets : Nom, Mot de passe, Compte."
          },
          {
            name: "✏️ Modifier son nom d'affichage",
            desc: "Dans l'onglet 'Nom', saisissez votre nouveau nom (ex: 'M. KONÉ Ibrahim') et cliquez 'Enregistrer'. Ce nom apparaîtra dans tous les documents et rapports générés."
          },
          {
            name: "🔑 Changer son mot de passe",
            desc: "Dans l'onglet 'Mot de passe' : entrez l'ancien mot de passe, le nouveau (minimum 6 caractères), confirmez et cliquez 'Changer'. Ne communiquez jamais votre mot de passe à quelqu'un."
          },
          {
            name: "📸 Ajouter une photo (élèves uniquement)",
            desc: "Dans le portail élève, onglet 'Ma carte', cliquez sur 'Ajouter ma photo d'identité' et choisissez une image depuis votre téléphone. La photo apparaît sur la carte d'identité scolaire."
          }
        ]
      },
      {
        type: "features",
        title: "👥 Gestion des utilisateurs (Administrateurs)",
        items: [
          {
            name: "🏫 Créer un établissement",
            desc: "Dans 'Super Admin', cliquez '+ Nouvel établissement'. Entrez le nom, la ville et l'email de l'admin. Un code école et une clé de licence sont générés automatiquement. La licence doit être activée pour que les utilisateurs puissent se connecter."
          },
          {
            name: "➕ Créer un compte utilisateur",
            desc: "Dans 'Inscription', sélectionnez le rôle (professeur, directeur, éducateur, comptable, élève). Remplissez le nom, prénom, date de naissance et email Google. Un code permanent unique est généré. Imprimez la fiche d'identifiants et remettez-la à l'utilisateur."
          },
          {
            name: "🔄 Activer ou désactiver un compte",
            desc: "Dans 'Identifiants d'accès', trouvez l'utilisateur dans la liste. Cliquez sur le badge 'Actif' ou 'Désactivé' pour basculer son état. Un compte désactivé ne peut plus se connecter, même avec les bons identifiants."
          },
          {
            name: "✏️ Modifier un accès",
            desc: "Dans 'Identifiants d'accès', cliquez sur l'icône crayon d'un utilisateur pour modifier son email, son rôle ou son mot de passe. Utile si un utilisateur a changé d'email Google ou oublié son mot de passe."
          },
          {
            name: "🗑️ Supprimer un compte",
            desc: "Le bouton corbeille supprime définitivement l'accès d'un utilisateur. Les données académiques (notes, présences) restent conservées dans la base. À utiliser avec précaution."
          },
          {
            name: "📋 Assigner des matières aux professeurs",
            desc: "Dans 'Professeurs', sélectionnez un professeur et cliquez 'Assigner matières/classes'. Cochez les matières et classes à lui attribuer. Il ne verra que ces données dans son espace."
          }
        ]
      },
      {
        type: "features",
        title: "📊 Statistiques et rapports scolaires",
        items: [
          {
            name: "📈 Page Statistiques",
            desc: "Accessible depuis le menu pour les admins et directeurs. Elle affiche : la moyenne générale de l'établissement, le taux de réussite global (% d'élèves avec moyenne ≥ 10), le classement des matières par performance, et la distribution des notes en graphique."
          },
          {
            name: "🏫 Performance par classe",
            desc: "Graphique comparatif des moyennes de toutes les classes. Permet d'identifier rapidement les classes en difficulté et celles qui excellent."
          },
          {
            name: "📉 Analyse par niveau",
            desc: "Comparez les performances entre niveaux (ex: 6ème vs 5ème vs 4ème) sur une même période."
          },
          {
            name: "👥 Répartition genre",
            desc: "Graphique camembert montrant la proportion garçons/filles dans l'établissement, avec leurs performances comparées."
          },
          {
            name: "🏅 Top élèves",
            desc: "Tableau des meilleurs élèves de chaque classe et de l'établissement, avec leurs moyennes et leur rang."
          },
          {
            name: "📋 Rapports professeurs (Directeur)",
            desc: "Le directeur peut consulter tous les rapports de cours envoyés par les professeurs, filtrer par type, matière ou date, et laisser une réponse ou approbation pour chacun."
          }
        ]
      },
      {
        type: "features",
        title: "⚙️ Configuration de l'établissement",
        items: [
          {
            name: "🏫 Informations officielles",
            desc: "Dans 'Configuration', entrez le nom officiel de l'école, la République, le Ministère, l'adresse, le téléphone, le nom du proviseur, la devise et le logo. Ces infos apparaissent sur tous les bulletins et documents officiels imprimés."
          },
          {
            name: "📅 Trimestres ou Semestres ?",
            desc: "Choisissez l'organisation de l'année scolaire : 3 trimestres (formule T1×1 + T2×2 + T3×2 ÷ 5) ou 2 semestres (moyenne simple). Ce choix est crucial — il affecte tous les calculs et bulletins. À faire en début d'année uniquement."
          }
        ]
      }
    ]
  },

  // ─── 6. SÉCURITÉ ET CONFIDENTIALITÉ ────────────────────────────────────────
  {
    id: "securite",
    icon: Lock,
    color: "from-slate-600 to-slate-800",
    bg: "bg-slate-50",
    text: "text-slate-700",
    title: "6. Sécurité et confidentialité",
    subtitle: "Protection des données et règles d'utilisation",
    content: [
      {
        type: "text",
        title: "🔐 Comment vos données sont protégées",
        text: "BOHAN est hébergé sur une infrastructure cloud sécurisée avec chiffrement des données. Toutes les connexions utilisent le protocole HTTPS (connexion chiffrée). L'authentification via Google ajoute une couche de sécurité supplémentaire."
      },
      {
        type: "features",
        title: "🛡️ Mesures de sécurité en place",
        items: [
          {
            name: "🔑 Double authentification",
            desc: "La connexion nécessite d'abord un compte Google valide, puis un code d'accès permanent + mot de passe interne à BOHAN. Deux barrières de sécurité pour accéder aux données scolaires."
          },
          {
            name: "🔒 Accès limité par rôle",
            desc: "Chaque utilisateur ne voit QUE les données correspondant à son rôle. Un professeur ne peut pas voir les notes d'un autre professeur. Un élève ne voit que ses propres données. Un comptable n'accède pas aux notes."
          },
          {
            name: "🔏 Notes verrouillables",
            desc: "Une fois les notes validées et verrouillées, elles ne peuvent plus être modifiées sans une procédure de demande de correction formelle, tracée et approuvée par le directeur."
          },
          {
            name: "📋 Traçabilité",
            desc: "Toutes les modifications importantes sont horodatées et attribuées à l'utilisateur qui les a faites. Cela permet de savoir qui a modifié quoi et quand."
          },
          {
            name: "🚫 Comptes désactivables",
            desc: "L'administrateur peut immédiatement désactiver le compte d'un utilisateur (ex: professeur qui a quitté l'école). Le compte désactivé ne peut plus se connecter."
          },
          {
            name: "🔢 Blocage après tentatives échouées",
            desc: "Après plusieurs tentatives de connexion incorrectes, le compte est temporairement verrouillé pour empêcher les intrusions. Contactez l'admin pour le déverrouiller."
          }
        ]
      },
      {
        type: "features",
        title: "📜 Règles d'utilisation",
        items: [
          {
            name: "🚫 Ne partagez jamais vos identifiants",
            desc: "Votre code d'accès permanent et votre mot de passe sont personnels et confidentiels. Ne les communiquez à personne, pas même à d'autres élèves ou collègues. Chaque personne doit utiliser son propre compte."
          },
          {
            name: "🔒 Déconnectez-vous sur les appareils partagés",
            desc: "Si vous utilisez un ordinateur ou téléphone partagé (salle informatique, téléphone d'un ami), pensez à vous déconnecter après chaque session via le menu 'Déconnexion'."
          },
          {
            name: "📵 Usage scolaire uniquement",
            desc: "L'application BOHAN est réservée à un usage strictement scolaire. L'utilisation à des fins personnelles non liées à l'école est interdite."
          },
          {
            name: "⚠️ Données réelles uniquement",
            desc: "Ne saisissez que des données exactes et véridiques. Les notes, absences, incidents et informations financières ont des conséquences officielles sur le parcours des élèves."
          },
          {
            name: "📣 Signalement d'anomalies",
            desc: "Si vous constatez une erreur (note incorrecte, absence injustifiée, accès non autorisé), signalez-le immédiatement à l'administration. Ne tentez pas de contourner le système."
          },
          {
            name: "🔏 Confidentialité des données élèves",
            desc: "Les informations des élèves (notes, présences, situation financière) sont confidentielles. Il est interdit de les partager en dehors du cadre scolaire officiel."
          }
        ]
      },
      {
        type: "warning",
        text: "En cas de perte ou de compromission de vos identifiants BOHAN, contactez immédiatement l'administrateur de votre établissement pour réinitialiser votre accès. Ne tentez pas de créer un second compte."
      }
    ]
  },

  // ─── 7. CONCLUSION ─────────────────────────────────────────────────────────
  {
    id: "conclusion",
    icon: Award,
    color: "from-yellow-500 to-amber-600",
    bg: "bg-yellow-50",
    text: "text-yellow-700",
    title: "7. Conclusion",
    subtitle: "Récapitulatif et encouragements",
    content: [
      {
        type: "intro",
        text: "BOHAN est bien plus qu'un simple logiciel scolaire. C'est un écosystème complet qui connecte élèves, professeurs, parents, éducateurs, comptables et direction en un seul endroit, pour une gestion scolaire moderne, transparente et efficace."
      },
      {
        type: "features",
        title: "🏆 Les grands avantages de BOHAN en résumé",
        items: [
          {
            name: "⚡ Gain de temps",
            desc: "Fini les calculs manuels de moyennes, les bulletins manuscrits, les registres papier et les files d'attente au bureau. BOHAN automatise tout et libère un temps précieux pour l'enseignement."
          },
          {
            name: "📱 Accessibilité totale",
            desc: "Depuis n'importe où et n'importe quel appareil. L'élève peut consulter ses notes depuis chez lui à minuit. Le professeur peut saisir une note en classe depuis son téléphone."
          },
          {
            name: "📊 Transparence et traçabilité",
            desc: "Toutes les actions sont enregistrées. Plus de notes 'perdues' ou 'modifiées sans trace'. Les élèves, parents et enseignants voient les mêmes informations en temps réel."
          },
          {
            name: "🤝 Meilleure communication",
            desc: "Les rapports de cours des professeurs, les alertes d'examens, les bulletins publiés en ligne — tout améliore la communication entre l'école et les familles."
          },
          {
            name: "💰 Gestion financière maîtrisée",
            desc: "Les comptables ont une visibilité parfaite sur les paiements, impayés et recettes. Les parents peuvent vérifier leur situation financière sans se déplacer."
          },
          {
            name: "🎯 Prise de décision facilitée",
            desc: "Les directeurs ont des statistiques en temps réel pour identifier les élèves en difficulté, les matières problématiques et prendre des décisions éclairées pour améliorer les résultats."
          }
        ]
      },
      {
        type: "text",
        title: "💪 Adoptez BOHAN au quotidien !",
        text: "Pour que BOHAN soit vraiment utile, chacun doit l'utiliser régulièrement et honnêtement. Les professeurs qui saisissent leurs notes dès la correction, les éducateurs qui enregistrent chaque absence le jour même, les comptables qui enregistrent chaque paiement immédiatement — c'est cette discipline collective qui rend l'application précieuse pour toute la communauté scolaire."
      },
      {
        type: "features",
        title: "📞 Besoin d'aide ?",
        items: [
          {
            name: "📖 Cette documentation",
            desc: "Consultez cette notice à chaque fois que vous avez un doute. Utilisez la barre de recherche en haut pour trouver rapidement ce que vous cherchez."
          },
          {
            name: "👨‍💼 L'administrateur de votre école",
            desc: "Votre premier point de contact pour tout problème d'accès, de mot de passe oublié ou de configuration. Il connaît l'application et peut vous guider."
          },
          {
            name: "🔄 Rechargez la page",
            desc: "Si quelque chose ne fonctionne pas comme attendu, essayez de rafraîchir la page. La plupart des petits problèmes se résolvent ainsi."
          }
        ]
      },
      {
        type: "tip",
        text: "🎉 Bienvenue dans BOHAN ! Ensemble, construisons une école plus moderne, plus transparente et plus efficace. Bonne utilisation à tous !"
      }
    ]
  }
];

// ─── DOCUMENTATION TECHNIQUE (ancien contenu) ────────────────────────────────
const TECH_SECTIONS = [
  {
    id: "intro",
    icon: BookOpen,
    color: "from-blue-500 to-blue-600",
    bg: "bg-blue-50",
    text: "text-blue-700",
    title: "Introduction à BOHAN",
    subtitle: "Vue d'ensemble de la plateforme",
    content: [
      { type: "intro", text: "BOHAN est une plateforme de gestion scolaire numérique complète, conçue pour les établissements scolaires de Côte d'Ivoire et d'Afrique francophone. Elle centralise la gestion des élèves, professeurs, notes, bulletins, présences, finances et communications en un seul outil accessible depuis n'importe quel appareil." },
      { type: "roles", title: "Les 6 rôles de la plateforme", items: [
          { role: "🛡️ Super Administrateur (Admin)", desc: "Accès complet à tout. Gère tous les établissements, crée les licences, configure la plateforme." },
          { role: "🏫 Directeur / Proviseur (user)", desc: "Supervise un établissement. Valide les examens, consulte les rapports des professeurs, gère les inscriptions, voit toutes les statistiques." },
          { role: "👨‍🏫 Professeur (teacher)", desc: "Saisit les notes, crée les examens, envoie des rapports de cours, consulte l'emploi du temps et gère la présence des élèves." },
          { role: "🎓 Élève (student)", desc: "Consulte ses notes, moyennes, bulletins, emploi du temps, les devoirs annoncés et ses frais de scolarité via le portail élève." },
          { role: "🛡️ Éducateur (educator)", desc: "Gère les absences, retards et incidents disciplinaires des élèves. Envoie des rapports quotidiens au directeur." },
          { role: "💰 Comptable (accountant)", desc: "Gère les inscriptions financières, enregistre les paiements, génère les reçus et suit les impayés." },
      ]},
      { type: "flow", title: "Flux de connexion", steps: [
          "L'utilisateur ouvre l'application et clique 'Se connecter avec Google'",
          "Google authentifie l'identité (email Google requis)",
          "BOHAN affiche le formulaire de validation d'accès",
          "L'utilisateur saisit son Code d'accès permanent + Mot de passe initial",
          "Le système vérifie dans la base AppAccess et attribue le rôle",
          "L'utilisateur est redirigé vers son espace selon son rôle"
      ]}
    ]
  },
  {
    id: "superadmin", icon: Building2, color: "from-slate-600 to-slate-700", bg: "bg-slate-50", text: "text-slate-700",
    title: "Super Administration", subtitle: "Gestion multi-établissements",
    content: [
      { type: "text", title: "Qu'est-ce que c'est ?", text: "La page Super Administration est accessible uniquement au compte administrateur principal. Elle permet de créer et gérer tous les établissements inscrits sur la plateforme BOHAN." },
      { type: "features", title: "Fonctionnalités disponibles", items: [
          { name: "➕ Créer un établissement", desc: "Remplissez le nom, la ville et l'email de l'administrateur local. Un code établissement unique et une clé de licence sont générés automatiquement." },
          { name: "✏️ Modifier un établissement", desc: "Mettez à jour le nom, la ville, l'email admin, ou le statut actif/inactif de l'établissement." },
          { name: "🔑 Activer une licence", desc: "Chaque établissement a une clé de licence unique. L'activation se fait en un clic depuis la carte de l'établissement." },
          { name: "👥 Gérer les comptes", desc: "Accédez à tous les comptes AppAccess liés à l'établissement. Créez, modifiez ou désactivez des accès directement." },
          { name: "🪄 Générer les classes", desc: "Génère automatiquement toutes les classes standard pour une année scolaire donnée et des divisions choisies." },
          { name: "📧 Emails autorisés", desc: "Définissez quels emails ou domaines peuvent accéder à l'établissement." }
      ]},
      { type: "tip", text: "Le code de licence est confidentiel. Ne le partagez qu'avec l'administrateur local de chaque établissement." }
    ]
  },
  {
    id: "inscription", icon: UserPlus, color: "from-emerald-500 to-teal-600", bg: "bg-emerald-50", text: "text-emerald-700",
    title: "Inscription du personnel", subtitle: "Création des comptes avec codes permanents",
    content: [
      { type: "text", title: "Qu'est-ce que c'est ?", text: "La page Inscription permet à l'administrateur de créer des comptes pour les professeurs, directeurs, éducateurs et comptables." },
      { type: "features", title: "Inscription d'un utilisateur", items: [
          { name: "📝 Choisir le rôle", desc: "Sélectionnez parmi : Professeur, Élève, Directeur/Proviseur, Éducateur, Comptable." },
          { name: "🔑 Code permanent généré", desc: "Format : PROF-CIB-26KON-150492-03. Ce code est UNIQUE et sert d'identifiant de connexion." },
          { name: "🔒 Mot de passe initial", desc: "Généré aléatoirement. À remettre à l'utilisateur avec le code permanent." },
          { name: "🖨️ Impression", desc: "Le bouton 'Imprimer les identifiants' génère une fiche officielle imprimable avec un guide de connexion." }
      ]},
      { type: "warning", text: "Le mot de passe initial n'est visible qu'une seule fois. Imprimez ou copiez-le immédiatement." }
    ]
  },
  {
    id: "manageaccess", icon: ShieldCheck, color: "from-violet-500 to-purple-600", bg: "bg-violet-50", text: "text-violet-700",
    title: "Identifiants d'accès", subtitle: "Gestion complète des accès utilisateurs",
    content: [
      { type: "text", title: "Qu'est-ce que c'est ?", text: "Cette page liste tous les comptes d'accès créés pour votre établissement. Elle permet de les modifier, désactiver, ou supprimer." },
      { type: "features", title: "Fonctionnalités", items: [
          { name: "🔎 Recherche & filtres", desc: "Cherchez par nom, email ou code d'accès. Filtrez par rôle." },
          { name: "👁️ Afficher les mots de passe", desc: "Bouton œil pour révéler/masquer le mot de passe d'un utilisateur." },
          { name: "🔄 Activer / Désactiver", desc: "Basculez l'état du compte. Un compte désactivé ne peut plus se connecter." },
          { name: "✏️ Modifier un accès", desc: "Modifiez l'email, le rôle, l'identifiant ou le mot de passe." },
          { name: "🗑️ Supprimer", desc: "Supprime définitivement le compte d'accès." }
      ]}
    ]
  },
  {
    id: "grades", icon: ClipboardList, color: "from-rose-500 to-pink-600", bg: "bg-rose-50", text: "text-rose-700",
    title: "Notes & Examens", subtitle: "Saisie et gestion des évaluations",
    content: [
      { type: "text", title: "Qu'est-ce que c'est ?", text: "La page Notes centralise la création des examens et la saisie des notes. C'est le cœur pédagogique de la plateforme." },
      { type: "features", title: "Créer un examen", items: [
          { name: "📋 Type d'évaluation", desc: "Devoir, Interrogation, Examen trimestriel, TP, Oral." },
          { name: "📅 Date & Durée", desc: "Date de l'évaluation et durée en minutes. Visibles par les élèves dans 'Devoirs & Examens'." },
          { name: "🔒 Verrouillage", desc: "Un examen verrouillé ne peut plus être modifié. Les notes associées sont également verrouillées." }
      ]},
      { type: "features", title: "Saisie des notes", items: [
          { name: "📊 Tableau de saisie", desc: "Grille avec tous les élèves de la classe. Saisie rapide note par note." },
          { name: "💬 Commentaire par élève", desc: "Champ de commentaire individuel visible par l'élève dans son portail." },
          { name: "📝 Demande de correction", desc: "Un professeur peut demander la correction d'une note avec un motif. Workflow : Éducateur → Directeur." }
      ]},
      { type: "tip", text: "Les professeurs ne voient que les notes de LEURS matières et LEURS classes. Les admins et directeurs voient tout." }
    ]
  },
  {
    id: "averages", icon: TrendingUp, color: "from-orange-500 to-amber-600", bg: "bg-orange-50", text: "text-orange-700",
    title: "Moyennes", subtitle: "Calcul automatique et classements",
    content: [
      { type: "text", title: "Comment sont calculées les moyennes ?", text: "Le système calcule automatiquement les moyennes par matière, par période et la moyenne annuelle pondérée." },
      { type: "features", title: "Types de moyennes", items: [
          { name: "📈 Moyenne générale du trimestre", desc: "Moyenne pondérée : Σ(moyenne_matière × coefficient) / Σ(coefficients)." },
          { name: "🏆 Moyenne annuelle (trimestre)", desc: "Formule officielle : (T1 × 1 + T2 × 2 + T3 × 2) / 5." },
          { name: "📐 Moyenne annuelle (semestre)", desc: "Simple moyenne des deux semestres : (S1 + S2) / 2." },
          { name: "🏅 Classements", desc: "Tableau des élèves d'une classe ordonnés par moyenne décroissante avec rang." }
      ]}
    ]
  },
  {
    id: "bulletins", icon: FileText, color: "from-cyan-500 to-blue-600", bg: "bg-cyan-50", text: "text-cyan-700",
    title: "Bulletins scolaires", subtitle: "Génération des bulletins officiels",
    content: [
      { type: "text", title: "Qu'est-ce que c'est ?", text: "Les bulletins sont les documents officiels remis aux élèves. BOHAN génère automatiquement des bulletins au format officiel ivoirien." },
      { type: "features", title: "Contenu d'un bulletin", items: [
          { name: "🏫 En-tête officiel", desc: "République, Ministère de l'Éducation, nom de l'établissement, ville, devise, logo." },
          { name: "📊 Tableau des notes", desc: "Colonne par matière avec la moyenne du trimestre et le coefficient." },
          { name: "🏆 Distinction", desc: "Aucune, Encouragements, Félicitations ou Tableau d'honneur." },
          { name: "⚖️ Décision de fin d'année", desc: "Sur le dernier bulletin : Admis(e), Redoublant(e), Exclu(e), Transféré(e)." },
          { name: "✅ Publier le bulletin", desc: "Une fois publié, l'élève peut voir son bulletin depuis son portail." }
      ]}
    ]
  },
  {
    id: "schedule", icon: Calendar, color: "from-indigo-500 to-blue-600", bg: "bg-indigo-50", text: "text-indigo-700",
    title: "Emploi du temps", subtitle: "Planification hebdomadaire des cours",
    content: [
      { type: "text", title: "Qu'est-ce que c'est ?", text: "L'emploi du temps organise les créneaux horaires de chaque classe pour la semaine." },
      { type: "features", title: "Règles et fonctionnement", items: [
          { name: "🌅 Horaires scolaires", desc: "Matin : 07h00 → 12h00. Après-midi : 13h30 → 18h00." },
          { name: "🔴 Détection des conflits", desc: "Le système empêche de placer deux cours pour la même classe ou le même prof au même moment." },
          { name: "📅 Vue hebdomadaire", desc: "6 colonnes (Lundi→Samedi) avec les créneaux colorés par matière." }
      ]}
    ]
  },
  {
    id: "teacher", icon: UserCog, color: "from-amber-500 to-orange-600", bg: "bg-amber-50", text: "text-amber-700",
    title: "Espace Professeur", subtitle: "Toutes les fonctions enseignantes",
    content: [
      { type: "features", title: "Modules disponibles", items: [
          { name: "🎓 Ma carte", desc: "Carte professeur digitale avec photo, nom, matières enseignées, classes assignées et code permanent." },
          { name: "📝 Devoirs & Examens", desc: "Création et gestion des examens. Ajout de corrections publiables pour les élèves." },
          { name: "✅ Présences", desc: "Saisie des présences/absences pour chaque cours avec statut par élève." },
          { name: "📤 Envoyer un rapport", desc: "Rapport de cours visible par le directeur ET les élèves de la classe." },
          { name: "📋 Demander une matière", desc: "Demande d'attribution pour une matière/classe supplémentaire." }
      ]},
      { type: "tip", text: "Un professeur ne voit QUE ses classes et matières assignées. Aucune donnée des autres professeurs n'est visible." }
    ]
  },
  {
    id: "portal", icon: GraduationCap, color: "from-blue-500 to-indigo-600", bg: "bg-blue-50", text: "text-blue-700",
    title: "Portail Élève", subtitle: "L'espace personnel de chaque apprenant",
    content: [
      { type: "features", title: "Onglets disponibles", items: [
          { name: "🎓 Ma carte", desc: "Carte d'identité scolaire digitale avec photo, matricule, classe, niveau. Synchronisation en temps réel." },
          { name: "👨‍👩‍👧 Vue Parent", desc: "Vue dédiée aux parents : présences en temps réel, notes, emploi du temps, examens à venir et bulletins de leur enfant." },
          { name: "📅 Emploi du temps", desc: "Emploi du temps complet de la classe pour la semaine." },
          { name: "📈 Mes moyennes", desc: "Moyennes par matière et par période. Code couleur : vert ≥14, jaune ≥10, rouge <10." },
          { name: "💰 Frais de scolarité", desc: "État complet du paiement avec barre de progression et historique de chaque versement." },
          { name: "✉️ Messages", desc: "Rapports des professeurs + Alertes examens à venir avec compte à rebours." }
      ]},
      { type: "tip", text: "Si un élève ne trouve pas son dossier au premier login, il peut lier son compte en saisissant son numéro étudiant (matricule)." }
    ]
  },
  {
    id: "accountant", icon: DollarSign, color: "from-emerald-500 to-green-600", bg: "bg-emerald-50", text: "text-emerald-700",
    title: "Espace Comptable", subtitle: "Gestion financière de l'établissement",
    content: [
      { type: "features", title: "Modules disponibles", items: [
          { name: "➕ Nouvelle inscription", desc: "Formulaire complet avec sélection de classe, mode de paiement et calcul automatique des frais." },
          { name: "💳 Suivi des paiements", desc: "Liste toutes les inscriptions avec filtres par statut. Génération de reçus imprimables." },
          { name: "📈 Graphique financier", desc: "Évolution mensuelle des recettes, répartition par type de frais." },
          { name: "⚙️ Tarifs scolaires", desc: "Configuration des tarifs par niveau avec droit d'inscription, frais de scolarité et avance." }
      ]}
    ]
  },
  {
    id: "educator", icon: Shield, color: "from-teal-500 to-cyan-600", bg: "bg-teal-50", text: "text-teal-700",
    title: "Espace Éducateur", subtitle: "Suivi disciplinaire et vie scolaire",
    content: [
      { type: "features", title: "Modules de l'éducateur", items: [
          { name: "✅ Gestion des présences", desc: "Saisie des absences et retards journaliers avec justification. Notification possible aux parents." },
          { name: "⚠️ Gestion des incidents", desc: "Signalement d'incidents disciplinaires avec niveau de gravité. Le directeur traite les cas graves." },
          { name: "📋 Rapports quotidiens", desc: "Envoi d'un bilan journalier au directeur : absences du jour, incidents, observations." }
      ]}
    ]
  },
  {
    id: "stats", icon: BarChart3, color: "from-violet-500 to-purple-600", bg: "bg-violet-50", text: "text-violet-700",
    title: "Statistiques", subtitle: "Analyse de la performance scolaire",
    content: [
      { type: "features", title: "Indicateurs disponibles", items: [
          { name: "📊 Moyenne générale", desc: "Moyenne de l'ensemble des notes saisies dans l'établissement." },
          { name: "✅ Taux de réussite", desc: "Pourcentage d'élèves ayant une moyenne ≥ 10." },
          { name: "📈 Meilleures matières", desc: "Classement des matières par moyenne décroissante." },
          { name: "📉 Distribution des notes", desc: "Graphique en barres : répartition des notes par tranches." },
          { name: "🏫 Performance par classe", desc: "Comparaison des moyennes entre les différentes classes." }
      ]}
    ]
  },
  {
    id: "config", icon: Settings, color: "from-gray-500 to-slate-600", bg: "bg-gray-50", text: "text-gray-700",
    title: "Configuration", subtitle: "Paramètres officiels et personnalisation",
    content: [
      { type: "features", title: "Paramètres configurables", items: [
          { name: "🏫 Nom de l'établissement", desc: "Nom officiel tel qu'il apparaîtra sur les bulletins." },
          { name: "🖼️ Logo", desc: "Upload du logo de l'établissement. Affiché sur les en-têtes des bulletins et reçus." },
          { name: "📅 Organisation de l'année", desc: "Choisir entre Trimestre (3 périodes) ou Semestre (2 périodes). Affecte tous les calculs." }
      ]},
      { type: "warning", text: "Changer l'organisation de l'année (trimestre ↔ semestre) en cours d'année peut affecter les bulletins déjà générés. Faites ce choix en début d'année uniquement." }
    ]
  }
];

// ─── SECTION RENDERER ─────────────────────────────────────────────────────────
function Section({ section, isOpen, onToggle }) {
  const Icon = section.icon;
  return (
    <div className="bg-white border border-border rounded-2xl overflow-hidden shadow-sm">
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-4 px-5 py-4 text-left hover:bg-muted/30 transition-colors"
      >
        <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${section.color} flex items-center justify-center shrink-0 shadow-md`}>
          <Icon className="h-5 w-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-foreground text-sm">{section.title}</p>
          <p className="text-xs text-muted-foreground">{section.subtitle}</p>
        </div>
        {isOpen
          ? <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
          : <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
        }
      </button>

      {isOpen && (
        <div className="border-t border-blue-800 bg-blue-900 px-5 pb-5 pt-4 space-y-5">
          {section.content.map((block, i) => (
            <div key={i}>
              {block.type === "intro" && (
                <div className="bg-blue-800 border border-blue-600 rounded-xl p-4">
                  <p className="text-sm text-white leading-relaxed">{block.text}</p>
                </div>
              )}
              {block.type === "acronym" && (
                <div className="space-y-3">
                  <h4 className="font-bold text-white text-sm flex items-center gap-2">
                    <Star className="h-4 w-4 text-amber-400" />
                    Que signifie <span className="tracking-widest font-black text-amber-300">BOHAN</span> ?
                  </h4>
                  <div className="space-y-2">
                    {block.letters.map((item, j) => (
                      <div key={j} className="flex items-start gap-3 rounded-xl border border-blue-600 overflow-hidden">
                        <div className={`${item.color} text-white font-black text-xl w-14 shrink-0 flex items-center justify-center self-stretch`}>
                          {item.letter}
                        </div>
                        <div className="py-3 pr-3 flex-1">
                          <p className="font-bold text-sm text-white">{item.word}</p>
                          <p className="text-xs text-blue-200 mt-0.5 leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {block.type === "text" && (
                <div>
                  {block.title && <h4 className="font-bold text-white text-sm mb-2 flex items-center gap-2"><Info className="h-4 w-4 text-blue-300" />{block.title}</h4>}
                  <p className="text-sm text-blue-100 leading-relaxed">{block.text}</p>
                </div>
              )}
              {block.type === "roles" && (
                <div>
                  <h4 className="font-bold text-white text-sm mb-3">{block.title}</h4>
                  <div className="space-y-2">
                    {block.items.map((item, j) => (
                      <div key={j} className="flex items-start gap-3 bg-blue-800 border border-blue-600 rounded-xl p-3">
                        <div className="flex-1">
                          <p className="font-semibold text-sm text-white">{item.role}</p>
                          <p className="text-xs text-blue-200 mt-0.5 leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {block.type === "flow" && (
                <div>
                  <h4 className="font-bold text-white text-sm mb-3">{block.title}</h4>
                  <div className="space-y-1.5">
                    {block.steps.map((step, j) => (
                      <div key={j} className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-white">{j + 1}</span>
                        </div>
                        <p className="text-sm text-blue-100 leading-relaxed pt-0.5">{step}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {block.type === "features" && (
                <div>
                  <h4 className="font-bold text-white text-sm mb-3 flex items-center gap-2">
                    <Layers className="h-4 w-4 text-blue-300" />
                    {block.title}
                  </h4>
                  <div className="space-y-2">
                    {block.items.map((item, j) => (
                      <div key={j} className="bg-blue-800 border border-blue-600 rounded-xl p-3.5">
                        <p className="font-semibold text-sm text-white mb-1">{item.name}</p>
                        <p className="text-xs text-blue-200 leading-relaxed">{item.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {block.type === "tip" && (
                <div className="flex items-start gap-3 bg-amber-600/30 border border-amber-400/50 rounded-xl p-4">
                  <Lightbulb className="h-4 w-4 text-amber-300 shrink-0 mt-0.5" />
                  <p className="text-sm text-amber-100 leading-relaxed">{block.text}</p>
                </div>
              )}
              {block.type === "warning" && (
                <div className="flex items-start gap-3 bg-red-600/30 border border-red-400/50 rounded-xl p-4">
                  <AlertCircle className="h-4 w-4 text-red-300 shrink-0 mt-0.5" />
                  <p className="text-sm text-red-100 leading-relaxed">{block.text}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── PAGE PRINCIPALE ──────────────────────────────────────────────────────────
export default function Documentation() {
  const [mode, setMode] = useState("notice"); // "notice" | "tech"
  const [openSections, setOpenSections] = useState({ presentation: true });
  const [search, setSearch] = useState("");

  const SECTIONS = mode === "notice" ? NOTICE_SECTIONS : TECH_SECTIONS;

  function toggle(id) {
    setOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
  }
  function expandAll() {
    const all = {};
    SECTIONS.forEach(s => { all[s.id] = true; });
    setOpenSections(all);
  }
  function collapseAll() {
    setOpenSections({});
  }

  const filtered = search
    ? SECTIONS.filter(s =>
        s.title.toLowerCase().includes(search.toLowerCase()) ||
        s.subtitle.toLowerCase().includes(search.toLowerCase()) ||
        s.content.some(b =>
          (b.title && b.title.toLowerCase().includes(search.toLowerCase())) ||
          (b.text && b.text.toLowerCase().includes(search.toLowerCase())) ||
          (b.items && b.items.some(i =>
            i.name?.toLowerCase().includes(search.toLowerCase()) ||
            i.desc?.toLowerCase().includes(search.toLowerCase())
          )) ||
          (b.steps && b.steps.some(st => st.toLowerCase().includes(search.toLowerCase())))
        )
      )
    : SECTIONS;

  return (
    <div className="max-w-3xl mx-auto space-y-4 pb-10">

      {/* ── Hero Header ── */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center shadow-lg">
            <GraduationCap className="h-7 w-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-widest">BOHAN</h1>
            <p className="text-slate-300 text-sm">Gestion scolaire numérique · Documentation officielle</p>
          </div>
        </div>
        <div className="bg-white/10 border border-white/20 rounded-xl px-4 py-3">
          <p className="text-sm text-slate-200">Ce dossier contient la <strong className="text-white">notice d'utilisation complète</strong> et la documentation technique de BOHAN.</p>
          <p className="text-xs text-slate-400 mt-1">Version 2026 · Mis à jour le 05/05/2026</p>
        </div>
      </div>

      {/* ── Mode tabs ── */}
      <div className="flex gap-2 bg-card border border-border rounded-xl p-1.5">
        <button
          onClick={() => { setMode("notice"); setOpenSections({ presentation: true }); setSearch(""); }}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
            mode === "notice" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <BookMarked className="h-4 w-4" />
          📋 Notice d'utilisation
        </button>
        <button
          onClick={() => { setMode("tech"); setOpenSections({ intro: true }); setSearch(""); }}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
            mode === "tech" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Settings className="h-4 w-4" />
          ⚙️ Documentation technique
        </button>
      </div>

      {/* ── Search & controls ── */}
      <div className="flex gap-2 items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Rechercher dans la documentation…"
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <button onClick={expandAll} className="text-xs font-medium text-primary bg-primary/10 hover:bg-primary/20 px-3 py-2.5 rounded-xl transition-colors whitespace-nowrap">Tout ouvrir</button>
        <button onClick={collapseAll} className="text-xs font-medium text-muted-foreground bg-muted hover:bg-muted-foreground/20 px-3 py-2.5 rounded-xl transition-colors whitespace-nowrap">Tout fermer</button>
      </div>

      {/* ── Quick index ── */}
      {!search && (
        <div className="bg-card border border-border rounded-2xl p-4">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-3">📑 Sommaire rapide</p>
          <div className="flex flex-wrap gap-2">
            {SECTIONS.map(s => {
              const Icon = s.icon;
              return (
                <button
                  key={s.id}
                  onClick={() => {
                    setOpenSections(prev => ({ ...prev, [s.id]: true }));
                    setTimeout(() => document.getElementById(`sec-${s.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
                  }}
                  className="flex items-center gap-1.5 text-xs font-medium text-foreground bg-muted hover:bg-primary/10 hover:text-primary px-3 py-1.5 rounded-lg transition-colors"
                >
                  <Icon className="h-3 w-3" />
                  {s.title}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Sections ── */}
      {filtered.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground">
          <Search className="h-10 w-10 mx-auto mb-3 opacity-30" />
          <p>Aucun résultat pour « {search} »</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(section => (
            <div key={section.id} id={`sec-${section.id}`}>
              <Section
                section={section}
                isOpen={!!openSections[section.id]}
                onToggle={() => toggle(section.id)}
              />
            </div>
          ))}
        </div>
      )}

      {/* ── Footer ── */}
      <div className="text-center text-xs text-muted-foreground py-4 border-t border-border">
        BOHAN — Gestion scolaire numérique · Documentation officielle © 2026<br />
        <span className="text-[10px]">Notice d'utilisation complète · 7 chapitres · Guide étape par étape · Sécurité & Confidentialité</span>
      </div>
    </div>
  );
}