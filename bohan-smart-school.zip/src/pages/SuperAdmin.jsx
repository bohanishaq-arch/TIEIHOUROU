import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Plus, Building2, Pencil, Trash2, X, ShieldCheck, MapPin, Mail, RefreshCw, KeyRound, Copy, CheckCircle, Wand2, Loader2, Users, BadgeCheck } from "lucide-react";
import AccountManager from "../components/super/AccountManager";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import PageHeader from "../components/PageHeader";
import { setSchool } from "../hooks/useSchool";
import { useNavigate } from "react-router-dom";
import AuthorizedEmailsManager from "../components/AuthorizedEmailsManager";

const EMPTY_FORM = { name: "", code: "", city: "", country: "Côte d'Ivoire", admin_email: "", is_active: true, school_type: "public" };

const SCHOOL_TYPE_CONFIG = {
  public: {
    label: "École Publique",
    description: "Proviseur + Économe (finances)",
    roles: ["Proviseur", "Économe"],
    color: "bg-blue-100 text-blue-700 border-blue-200",
    icon: "🏛️",
  },
  prive: {
    label: "École Privée",
    description: "Chef d'établissement + Directeur des études + Comptable",
    roles: ["Chef d'établissement", "Directeur des études", "Comptable"],
    color: "bg-violet-100 text-violet-700 border-violet-200",
    icon: "🏫",
  },
};

function generateLicenseKey(city) {
  const prefix = "SCOL";
  const cityCode = (city || "XXX").substring(0, 3).toUpperCase();
  const year = new Date().getFullYear();
  const seq = String(Math.floor(Math.random() * 999) + 1).padStart(3, "0");
  return `${prefix}-${cityCode}-${year}-${seq}`;
}

function generateSchoolCode(name, city) {
  const nameCode = name.substring(0, 3).toUpperCase();
  const cityCode = (city || "XXX").substring(0, 2).toUpperCase();
  const seq = String(Math.floor(Math.random() * 99) + 1).padStart(2, "0");
  return `${nameCode}-${cityCode}-${seq}`;
}

function LicenseKeyDisplay({ licenseKey, activated }) {
  const [copied, setCopied] = useState(false);
  function handleCopy() {
    navigator.clipboard.writeText(licenseKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }
  return (
    <div className="flex items-center gap-1.5 mt-1">
      <KeyRound className="h-3 w-3 text-muted-foreground shrink-0" />
      <code className="text-[10px] font-mono text-muted-foreground tracking-wide">{licenseKey}</code>
      <button onClick={handleCopy} className="shrink-0">
        {copied ? <CheckCircle className="h-3 w-3 text-green-600" /> : <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />}
      </button>
      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-medium ${activated ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}`}>
        {activated ? "Activée" : "Non activée"}
      </span>
    </div>
  );
}

export default function SuperAdmin() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [schools, setSchools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [emailManager, setEmailManager] = useState(null);
  const [accountManager, setAccountManager] = useState(null);
  const [classGen, setClassGen] = useState(null); // school for class generation
  const [classGenYear, setClassGenYear] = useState(`${new Date().getFullYear()}-${new Date().getFullYear() + 1}`);
  const [classGenDivisions, setClassGenDivisions] = useState("A");
  const [classGenLoading, setClassGenLoading] = useState(false);
  const [classGenDone, setClassGenDone] = useState(false);

  async function load() {
    setLoading(true);
    const list = await base44.entities.School.list("-created_date");
    setSchools(list);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">Accès réservé au super-administrateur.</p>
      </div>
    );
  }

  function resetForm() {
    setForm(EMPTY_FORM);
    setEditing(null);
    setShowForm(false);
  }

  function openEdit(s) {
    setEditing(s);
    setForm({ name: s.name, code: s.code || "", city: s.city || "", country: s.country || "Côte d'Ivoire", admin_email: s.admin_email || "", is_active: s.is_active ?? true, school_type: s.school_type || "public" });
    setShowForm(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    if (editing) {
      await base44.entities.School.update(editing.id, form);
    } else {
      const licenseKey = generateLicenseKey(form.city);
      const schoolCode = generateSchoolCode(form.name, form.city);
      await base44.entities.School.create({ ...form, code: schoolCode, license_key: licenseKey, license_activated: false });
    }
    resetForm();
    load();
  }

  async function handleDelete(id) {
    if (!confirm("Supprimer cet établissement ? Toutes ses données resteront en base mais ne seront plus accessibles.")) return;
    await base44.entities.School.delete(id);
    load();
  }

  const STANDARD_LEVELS = [
    "6ème", "5ème", "4ème", "3ème", "2nde",
    "1ère A", "1ère C", "1ère D", "Tle A", "Tle C", "Tle D"
  ];

  async function handleGenerateClasses() {
    setClassGenLoading(true);
    const divisions = classGenDivisions.split(",").map(d => d.trim().toUpperCase()).filter(Boolean);
    // For lycée levels that already have a series in name, ignore division
    const lyceePattern = /^(1ère|Tle)/;
    const classesToCreate = [];
    for (const level of STANDARD_LEVELS) {
      if (lyceePattern.test(level)) {
        classesToCreate.push({ school_id: classGen.id, name: `${level}`, level, division: "1", academic_year: classGenYear });
      } else {
        for (const div of divisions) {
          classesToCreate.push({ school_id: classGen.id, name: `${level}-${div}`, level, division: div, academic_year: classGenYear });
        }
      }
    }
    await base44.entities.Class.bulkCreate(classesToCreate);
    setClassGenLoading(false);
    setClassGenDone(true);
  }

  function handleManage(school) {
    setSchool(school.id, school.name);
    navigate("/");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Super Administration" subtitle={`${schools.length} établissement${schools.length !== 1 ? "s" : ""} enregistré${schools.length !== 1 ? "s" : ""}`}>
        <Button variant="outline" size="sm" onClick={load} className="gap-2">
          <RefreshCw className="h-3.5 w-3.5" /> Actualiser
        </Button>
        <Button onClick={() => { resetForm(); setShowForm(true); }} className="gap-2">
          <Plus className="h-4 w-4" /> Nouvel établissement
        </Button>
      </PageHeader>

      {showForm && (
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">{editing ? "Modifier l'établissement" : "Ajouter un établissement"}</h3>
            <Button variant="ghost" size="icon" onClick={resetForm}><X className="h-4 w-4" /></Button>
          </div>
          <form onSubmit={handleSave} className="space-y-5">
            {/* Type d'établissement */}
            <div>
              <Label className="mb-2 block">Type d'établissement *</Label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {Object.entries(SCHOOL_TYPE_CONFIG).map(([key, cfg]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setForm(f => ({ ...f, school_type: key }))}
                    className={`text-left p-4 rounded-xl border-2 transition-all ${form.school_type === key ? "border-primary bg-primary/5" : "border-border bg-muted/20 hover:bg-muted/40"}`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xl">{cfg.icon}</span>
                      <span className="font-semibold text-sm text-foreground">{cfg.label}</span>
                      {form.school_type === key && <span className="ml-auto w-4 h-4 rounded-full bg-primary flex items-center justify-center"><span className="w-2 h-2 rounded-full bg-white" /></span>}
                    </div>
                    <p className="text-xs text-muted-foreground">{cfg.description}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {cfg.roles.map(r => <span key={r} className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${cfg.color}`}>{r}</span>)}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><Label>Nom *</Label><Input className="mt-1" value={form.name} onChange={(e) => { const name = e.target.value; setForm((p) => ({ ...p, name, code: editing ? p.code : generateSchoolCode(name, p.city) })); }} required placeholder="Ex: Lycée Moderne d'Abidjan" /></div>
              <div><Label>Code établissement <span className="text-muted-foreground text-xs">(auto-généré)</span></Label><Input className="mt-1 bg-muted/50 font-mono" value={form.code} readOnly placeholder="Généré automatiquement" /></div>
              <div><Label>Ville</Label><Input className="mt-1" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} placeholder="Ex: Abidjan" /></div>
              <div><Label>Pays</Label><Input className="mt-1" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></div>
              <div><Label>Email de l'administrateur local</Label><Input className="mt-1" type="email" value={form.admin_email} onChange={(e) => setForm({ ...form, admin_email: e.target.value })} placeholder="admin@ecole.ci" /></div>
              <div className="flex items-center gap-3 pt-5">
                <input type="checkbox" id="active" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} />
                <Label htmlFor="active">Établissement actif</Label>
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="outline" onClick={resetForm}>Annuler</Button>
              <Button type="submit">{editing ? "Enregistrer" : "Créer l'établissement"}</Button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-32">
          <div className="w-6 h-6 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
        </div>
      ) : schools.length === 0 ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <Building2 className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground font-medium">Aucun établissement créé</p>
          <p className="text-sm text-muted-foreground mt-1">Commencez par créer votre premier établissement.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {schools.map((s) => (
            <div key={s.id} className="bg-card rounded-xl border border-border p-5 space-y-3 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                    <Building2 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground leading-tight">{s.name}</p>
                    <div className="flex flex-wrap items-center gap-1 mt-1">
                      {s.code && <span className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded">{s.code}</span>}
                      {s.school_type && (
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${SCHOOL_TYPE_CONFIG[s.school_type]?.color}`}>
                          {SCHOOL_TYPE_CONFIG[s.school_type]?.icon} {SCHOOL_TYPE_CONFIG[s.school_type]?.label}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium shrink-0 ${s.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                  {s.is_active ? "Actif" : "Inactif"}
                </span>
              </div>
              <div className="space-y-1">
                {s.city && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                    <MapPin className="h-3 w-3" /> {s.city}{s.country ? `, ${s.country}` : ""}
                  </p>
                )}
                {s.admin_email && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                    <Mail className="h-3 w-3" /> {s.admin_email}
                  </p>
                )}
                {s.license_key && (
                  <LicenseKeyDisplay licenseKey={s.license_key} activated={s.license_activated} />
                )}
              </div>
              <div className="space-y-2 pt-1 border-t border-border">
                {s.license_key && !s.license_activated && (
                  <Button
                    size="sm"
                    className="w-full gap-1.5 h-8 text-xs bg-orange-500 hover:bg-orange-600 text-white"
                    onClick={async () => {
                      if (!confirm(`Activer la licence ${s.license_key} pour ${s.name} ?`)) return;
                      await base44.entities.School.update(s.id, { license_activated: true, license_activated_date: new Date().toISOString() });
                      load();
                    }}
                  >
                    <BadgeCheck className="h-3.5 w-3.5" /> Activer la licence
                  </Button>
                )}
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="flex-1 gap-1.5 h-8 text-xs" onClick={() => setAccountManager(s)}>
                    <Users className="h-3.5 w-3.5" /> Comptes
                  </Button>
                  <Button size="sm" className="flex-1 gap-1.5 h-8 text-xs" onClick={() => { setClassGen(s); setClassGenDone(false); }}>
                    <Wand2 className="h-3.5 w-3.5" /> Générer classes
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1 gap-1 h-8 text-xs" onClick={() => setEmailManager(emailManager?.id === s.id ? null : s)}>
                    <Mail className="h-3.5 w-3.5" /> Emails autorisés
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => openEdit(s)}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => handleDelete(s.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Class generator modal */}
      {classGen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4" onClick={() => setClassGen(null)}>
          <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md p-6 space-y-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-foreground">Générer les classes</h3>
                <p className="text-xs text-muted-foreground mt-0.5">{classGen.name}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setClassGen(null)}><X className="h-4 w-4" /></Button>
            </div>
            {classGenDone ? (
              <div className="flex flex-col items-center gap-3 py-6">
                <CheckCircle className="h-12 w-12 text-green-500" />
                <p className="font-semibold text-foreground">Classes générées avec succès !</p>
                <p className="text-xs text-muted-foreground text-center">Toutes les classes standard ont été créées pour l'année {classGenYear}.</p>
                <Button onClick={() => setClassGen(null)} className="mt-2">Fermer</Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <Label>Année scolaire</Label>
                  <Input className="mt-1" value={classGenYear} onChange={e => setClassGenYear(e.target.value)} placeholder="Ex: 2024-2025" />
                </div>
                <div>
                  <Label>Divisions (séparées par virgule)</Label>
                  <Input className="mt-1" value={classGenDivisions} onChange={e => setClassGenDivisions(e.target.value)} placeholder="Ex: A, B, C" />
                  <p className="text-xs text-muted-foreground mt-1">Les niveaux lycée (1ère, Tle) ont déjà leurs séries intégrées.</p>
                </div>
                <div className="bg-muted/50 rounded-lg p-3">
                  <p className="text-xs font-semibold text-foreground mb-1">Niveaux qui seront créés :</p>
                  <p className="text-xs text-muted-foreground">{STANDARD_LEVELS.join(" • ")}</p>
                </div>
                <div className="flex gap-3 pt-2">
                  <Button variant="outline" className="flex-1" onClick={() => setClassGen(null)}>Annuler</Button>
                  <Button className="flex-1 gap-2" onClick={handleGenerateClasses} disabled={classGenLoading}>
                    {classGenLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
                    {classGenLoading ? "Création…" : "Générer"}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {accountManager && <AccountManager school={accountManager} onClose={() => setAccountManager(null)} />}

      {/* Email access manager */}
      {emailManager && (
        <AuthorizedEmailsManager
          school={emailManager}
          onUpdated={() => { load(); }}
        />
      )}
    </div>
  );
}