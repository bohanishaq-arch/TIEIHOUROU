import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../hooks/useSchool";
import { ShieldAlert, CheckCircle, XCircle, Building2, Clock, User, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import PageHeader from "../components/PageHeader";

export default function DirecteurRequests() {
  const { user } = useAuth();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const schoolId = getSchoolId();
    const f = schoolId ? { school_id: schoolId } : {};
    // Charge tous les accès et filtre côté client pour éviter les rate limits
    const all = await base44.entities.AppAccess.filter(f, "-created_date", 500);
    setRequests(all.filter(r => r.role === "user" || r.role === "educator"));
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function approve(record) {
    await base44.entities.AppAccess.update(record.id, { is_active: true });
    load();
  }

  async function reject(record) {
    await base44.entities.AppAccess.update(record.id, { is_active: false });
    load();
  }

  // Le proviseur (verifiedRole=user) peut aussi valider les éducateurs
  const verifiedRole = (() => { try { return sessionStorage.getItem('scolaris_verified_role'); } catch { return null; } })();
  const isDirecteur = verifiedRole === 'user';

  if (user?.role !== "admin" && !isDirecteur) return (
    <div className="flex flex-col items-center justify-center h-64 gap-3">
      <ShieldAlert className="h-10 w-10 text-muted-foreground" />
      <p className="text-muted-foreground">Accès réservé aux administrateurs.</p>
    </div>
  );

  const pending = requests.filter(r => !r.is_active);
  const approved = requests.filter(r => r.is_active);

  return (
    <div className="space-y-6">
      <PageHeader
        title={isDirecteur ? "Gestion des éducateurs" : "Proviseurs, Directeurs & Éducateurs"}
        subtitle={`${pending.length} en attente de validation`}
      />

      {/* Pending */}
      <div className="space-y-3">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
          <Clock className="h-4 w-4 text-amber-500" /> En attente de validation ({pending.length})
        </h2>
        {loading ? (
          <div className="p-10 text-center"><div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" /></div>
        ) : pending.length === 0 ? (
          <div className="bg-muted/30 rounded-xl p-6 text-center text-sm text-muted-foreground">Aucune demande en attente.</div>
        ) : (
          pending.map(r => <RequestCard key={r.id} record={r} onApprove={approve} onReject={reject} />)
        )}
      </div>

      {/* Approved */}
      <div className="space-y-3">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
          <CheckCircle className="h-4 w-4 text-green-500" /> Validés et actifs ({approved.length})
        </h2>
        {approved.length === 0 ? (
          <div className="bg-muted/30 rounded-xl p-6 text-center text-sm text-muted-foreground">Aucun directeur validé.</div>
        ) : (
          approved.map(r => <RequestCard key={r.id} record={r} onApprove={approve} onReject={reject} />)
        )}
      </div>
    </div>
  );
}

function RequestCard({ record, onApprove, onReject }) {
  const isActive = record.is_active;
  return (
    <div className={`bg-card border rounded-xl p-4 flex items-center gap-4 ${isActive ? "border-green-200 bg-green-50/20" : "border-amber-200 bg-amber-50/20"}`}>
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${isActive ? "bg-green-100" : "bg-amber-100"}`}>
        {record.role === "educator"
          ? <Shield className={`h-6 w-6 ${isActive ? "text-green-600" : "text-amber-600"}`} />
          : <Building2 className={`h-6 w-6 ${isActive ? "text-green-600" : "text-amber-600"}`} />}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-foreground">{record.full_name || "—"}</p>
        <p className="text-sm text-muted-foreground">{record.user_email}</p>
        <div className="flex gap-3 mt-1">
          <span className="text-xs text-muted-foreground font-mono bg-muted px-2 py-0.5 rounded">
            {record.access_id}
          </span>
          {record.school_name && (
            <span className="text-xs text-muted-foreground">{record.school_name}</span>
          )}
        </div>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        {isActive ? (
          <>
            <span className="text-xs font-bold text-green-700 bg-green-100 border border-green-300 px-2.5 py-1 rounded-full flex items-center gap-1">
              <CheckCircle className="h-3.5 w-3.5" /> Validé
            </span>
            <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50 text-xs" onClick={() => onReject(record)}>
              <XCircle className="h-3.5 w-3.5 mr-1" /> Révoquer
            </Button>
          </>
        ) : (
          <>
            <span className="text-xs font-medium text-amber-700 bg-amber-100 px-2.5 py-1 rounded-full flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" /> En attente
            </span>
            <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white text-xs gap-1" onClick={() => onApprove(record)}>
              <CheckCircle className="h-3.5 w-3.5" /> Valider
            </Button>
          </>
        )}
      </div>
    </div>
  );
}