import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, BookOpen, Pencil, Trash2, User, Hash, RefreshCw, Users } from "lucide-react";
import TeacherClassAssignment from "../components/subjects/TeacherClassAssignment";
import { getSchoolId } from "../hooks/useSchool";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import TeacherSearchByID from "../components/TeacherSearchByID";
import PageHeader from "../components/PageHeader";
import { X } from "lucide-react";

const LEVELS = ["6ème", "5ème", "4ème", "3ème", "2nde", "1ère", "Terminale", "Tous"];

const PREDEFINED_SUBJECTS = [
  { name: "Français", code: "FR", coefficient: 3 },
  { name: "Mathématiques", code: "MATH", coefficient: 4 },
  { name: "Anglais", code: "ANG", coefficient: 3 },
  { name: "Physique-Chimie", code: "PC", coefficient: 3 },
  { name: "Sciences physiques", code: "SP", coefficient: 3 },
  { name: "SVT", code: "SVT", coefficient: 2 },
  { name: "Histoire-Géographie", code: "HG", coefficient: 2 },
  { name: "EPS", code: "EPS", coefficient: 1 },
  { name: "Philosophie", code: "PHILO", coefficient: 2 },
  { name: "Anglais LV2", code: "ANG2", coefficient: 2 },
  { name: "Allemand", code: "ALL", coefficient: 2 },
  { name: "Espagnol", code: "ESP", coefficient: 2 },
  { name: "Arts plastiques", code: "ART", coefficient: 1 },
  { name: "Musique", code: "MUS", coefficient: 1 },
  { name: "EDHC", code: "EDHC", coefficient: 1 },
  { name: "Conduite", code: "COND", coefficient: 1 },
  { name: "Informatique", code: "INFO", coefficient: 2 },
  { name: "Autre (personnalisée)", code: "", coefficient: 1 },
];

const COLLEGE_LEVELS = ["6ème", "5ème", "4ème", "3ème"];
const LYCEE_LEVELS = ["2nde", "1ère A", "1ère C", "1ère D", "Tle A", "Tle C", "Tle D"];

const MATIERE_COLLEGE = [
  { name: "Français", code: "FR", coefficient: 1 },
  { name: "Anglais", code: "ANG", coefficient: 1 },
  { name: "Allemand", code: "ALL", coefficient: 1 },
  { name: "Espagnol", code: "ESP", coefficient: 1 },
  { name: "Histoire-Géographie", code: "HG", coefficient: 1 },
  { name: "Mathématiques", code: "MATH", coefficient: 1 },
  { name: "Sciences physiques", code: "SP", coefficient: 1 },
  { name: "SVT", code: "SVT", coefficient: 1 },
  { name: "Arts plastiques", code: "ART", coefficient: 1 },
  { name: "Musique", code: "MUS", coefficient: 1 },
  { name: "EPS", code: "EPS", coefficient: 1 },
  { name: "EDHC", code: "EDHC", coefficient: 1 },
  { name: "Conduite", code: "COND", coefficient: 1 },
];

const MATIERE_LYCEE = [
  { name: "Philosophie", code: "PHILO", coefficient: 2 },
  ...MATIERE_COLLEGE,
];

function generateCode(name) {
  if (!name) return "";
  // Remove accents, take first letters of each word, max 5 chars
  const cleaned = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const words = cleaned.trim().split(/\s+/);
  if (words.length === 1) return words[0].substring(0, 5).toUpperCase();
  return words.map((w) => w[0]).join("").toUpperCase().substring(0, 5);
}
const LEVEL_ORDER = ["6ème", "5ème", "4ème", "3ème", "2nde", "1ère", "Terminale", "Tous"];

export default function Subjects() {
  const [activeTab, setActiveTab] = useState("matieres");
  const [subjects, setSubjects] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [filterLevel, setFilterLevel] = useState("all");
  const [form, setForm] = useState({ name: "", code: "", coefficient: 1, teacher_name: "", teacher_email: "", levels: [] });

  const [generating, setGenerating] = useState(false);
  const [customName, setCustomName] = useState(false);

  async function handleGenerateAll() {
    if (!confirm("Cela va créer toutes les matières standard pour le collège (6e–3e) et le lycée (2nde−Tle). Continuer ?")) return;
    setGenerating(true);
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const existing = await base44.entities.Subject.filter(filter);
    const existingNames = new Set(existing.map(s => s.name));
    const toCreate = [];
    MATIERE_COLLEGE.forEach((m) => {
      if (!existingNames.has(m.name)) toCreate.push({ ...m, levels: COLLEGE_LEVELS, school_id: schoolId });
    });
    MATIERE_LYCEE.forEach((m) => {
      if (!existingNames.has(m.name)) toCreate.push({ ...m, levels: LYCEE_LEVELS, school_id: schoolId });
    });
    if (toCreate.length > 0) {
      await base44.entities.Subject.bulkCreate(toCreate);
    }
    setGenerating(false);
    loadData();
  }

  async function loadData() {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const [list, teacherList] = await Promise.all([
      base44.entities.Subject.filter(filter),
      base44.entities.User.filter({ role: "teacher" }),
    ]);
    setSubjects(list);
    setTeachers(teacherList);
    setLoading(false);
  }

  useEffect(() => { loadData(); }, []);

  function openEdit(subject) {
    setEditing(subject);
    setForm({
      name: subject.name, code: subject.code || "", coefficient: subject.coefficient,
      teacher_name: subject.teacher_name || "", teacher_email: subject.teacher_email || "",
      levels: subject.levels || (subject.level && subject.level !== "Tous" ? [subject.level] : []),
    });
    setShowForm(true);
  }

  function handleNameChange(name) {
    setForm((prev) => ({ ...prev, name, code: prev.code || generateCode(name) }));
  }

  function toggleLevel(level) {
    setForm((prev) => ({
      ...prev,
      levels: prev.levels.includes(level) ? prev.levels.filter((l) => l !== level) : [...prev.levels, level],
    }));
  }

  function resetForm() {
    setForm({ name: "", code: "", coefficient: 1, teacher_name: "", teacher_email: "", levels: [] });
    setEditing(null);
    setShowForm(false);
    setCustomName(false);
  }

  function handleSubjectSelect(name) {
    if (name === "Autre (personnalisée)") {
      setCustomName(true);
      setForm((prev) => ({ ...prev, name: "", code: "" }));
    } else {
      setCustomName(false);
      const preset = PREDEFINED_SUBJECTS.find((s) => s.name === name);
      setForm((prev) => ({
        ...prev,
        name,
        code: preset?.code || generateCode(name),
        coefficient: preset?.coefficient ?? prev.coefficient,
      }));
    }
  }

  async function handleSave(e) {
    e.preventDefault();
    if (editing) {
      try {
        await base44.entities.Subject.update(editing.id, form);
      } catch {
        // La matière n'existe plus, on la recrée
        await base44.entities.Subject.create(form);
      }
    } else {
      const schoolId = getSchoolId();
      await base44.entities.Subject.create({ ...form, school_id: schoolId });
    }
    resetForm();
    loadData();
  }

  async function handleDelete(id) {
    await base44.entities.Subject.delete(id);
    loadData();
  }

  const filtered = filterLevel === "all"
    ? subjects
    : subjects.filter((s) => (s.levels && s.levels.includes(filterLevel)) || s.level === filterLevel);

  const grouped = LEVEL_ORDER.reduce((acc, level) => {
    const levelSubjects = filtered.filter((s) =>
      (s.levels && s.levels.includes(level)) || s.level === level
    );
    if (levelSubjects.length > 0) acc[level] = levelSubjects;
    return acc;
  }, {});

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Matières" subtitle={`${subjects.length} matière${subjects.length !== 1 ? 's' : ''} enregistrée${subjects.length !== 1 ? 's' : ''}`}>
        {activeTab === "matieres" && (
          <>
            <Select value={filterLevel} onValueChange={setFilterLevel}>
              <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les niveaux</SelectItem>
                {LEVELS.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={handleGenerateAll} disabled={generating} className="gap-2 border-purple-200 text-purple-700 hover:bg-purple-50">
              {generating ? "Génération..." : "📚 Générer toutes les matières"}
            </Button>
            <Button onClick={() => { resetForm(); setShowForm(true); }} className="gap-2">
              <Plus className="h-4 w-4" /> Nouvelle matière
            </Button>
          </>
        )}
      </PageHeader>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border">
        <button
          onClick={() => setActiveTab("matieres")}
          className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium transition-colors relative ${activeTab === "matieres" ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"}`}
        >
          <BookOpen className="h-4 w-4" /> Liste des matières
        </button>
        <button
          onClick={() => setActiveTab("assignations")}
          className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium transition-colors relative ${activeTab === "assignations" ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"}`}
        >
          <Users className="h-4 w-4" /> Assignation Professeurs → Classes
        </button>
      </div>

      {activeTab === "assignations" && (
        <TeacherClassAssignment />
      )}

      {activeTab === "matieres" && showForm && (
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold">{editing ? "Modifier la matière" : "Ajouter une matière"}</h3>
            <Button variant="ghost" size="icon" onClick={resetForm}><X className="h-4 w-4" /></Button>
          </div>
          <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <Label>Matière *</Label>
              {!editing ? (
                <>
                  <Select value={customName ? "Autre (personnalisée)" : form.name} onValueChange={handleSubjectSelect}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder="Sélectionner une matière" /></SelectTrigger>
                    <SelectContent>
                      {PREDEFINED_SUBJECTS.map((s) => (
                        <SelectItem key={s.name} value={s.name}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {customName && (
                    <Input className="mt-2" placeholder="Nom personnalisé" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value, code: generateCode(e.target.value) })} required />
                  )}
                </>
              ) : (
                <Input className="mt-1" value={form.name} onChange={(e) => handleNameChange(e.target.value)} required />
              )}
            </div>
            <div>
              <Label>Code matière</Label>
              <div className="flex gap-2 mt-1">
                <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="Ex: MATH" maxLength={6} className="font-mono" />
                <Button type="button" variant="outline" size="icon" title="Regénérer" onClick={() => setForm((p) => ({ ...p, code: generateCode(p.name) }))}>
                  <RefreshCw className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
            <div><Label>Coefficient *</Label><Input type="number" min={1} max={10} value={form.coefficient} onChange={(e) => setForm({ ...form, coefficient: Number(e.target.value) })} required /></div>
            <div>
              <Label>Professeur (par ID d'accès)</Label>
              <TeacherSearchByID
                selectedTeacher={form.teacher_email ? { email: form.teacher_email, name: form.teacher_name, id: form.teacher_id } : null}
                onSelect={(teacher) => setForm({ ...form, teacher_email: teacher.email, teacher_name: teacher.name, teacher_id: teacher.id })}
                onClear={() => setForm({ ...form, teacher_email: "", teacher_name: "", teacher_id: "" })}
              />
            </div>
            <div className="md:col-span-2 lg:col-span-3">
              <Label>Niveaux enseignés <span className="text-muted-foreground font-normal text-xs">(sélectionnez un ou plusieurs)</span></Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {LEVELS.map((l) => (
                  <button
                    key={l}
                    type="button"
                    onClick={() => toggleLevel(l)}
                    className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                      form.levels.includes(l)
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-muted text-muted-foreground border-border hover:border-primary hover:text-primary"
                    }`}
                  >
                    {l}
                  </button>
                ))}
              </div>
              {form.levels.length === 0 && <p className="text-xs text-muted-foreground mt-1">Aucun niveau sélectionné (matière commune à tous)</p>}
            </div>
            <div className="md:col-span-2 lg:col-span-3 flex justify-end gap-3 pt-2">
              <Button type="button" variant="outline" onClick={resetForm}>Annuler</Button>
              <Button type="submit">{editing ? "Enregistrer" : "Ajouter"}</Button>
            </div>
          </form>
        </div>
      )}

      {activeTab === "matieres" && Object.keys(grouped).length === 0 && !showForm ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <BookOpen className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">Aucune matière enregistrée.</p>
        </div>
      ) : activeTab === "matieres" ? (
        Object.entries(grouped).map(([level, levelSubjects]) => (
          <div key={level}>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block"></span>
              {level} <span className="font-normal">({levelSubjects.length} matière{levelSubjects.length !== 1 ? 's' : ''})</span>
            </h2>
            <div className="bg-card rounded-xl border border-border overflow-hidden mb-2">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/50 border-b border-border">
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Matière</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Code</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Coeff.</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Professeur</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Niveaux</th>
                    <th className="text-right py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {levelSubjects.map((s) => (
                    <tr key={s.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-accent flex items-center justify-center shrink-0">
                            <BookOpen className="h-3.5 w-3.5 text-accent-foreground" />
                          </div>
                          <span className="font-medium text-foreground">{s.name}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {s.code ? <span className="font-mono text-xs bg-muted px-2 py-0.5 rounded">{s.code}</span> : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-secondary/20 text-sm font-bold text-foreground">{s.coefficient}</span>
                      </td>
                      <td className="py-3 px-4">
                        {s.teacher_name ? (
                          <div className="flex items-center gap-1.5 text-sm">
                            <User className="h-3.5 w-3.5 text-muted-foreground" />
                            {s.teacher_name}
                          </div>
                        ) : <span className="text-muted-foreground text-xs italic">Non assigné</span>}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1">
                          {(s.levels && s.levels.length > 0
                            ? s.levels
                            : s.level ? [s.level] : ["Tous"]
                          ).map((l) => (
                            <span key={l} className="text-xs bg-accent text-accent-foreground px-1.5 py-0.5 rounded">{l}</span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(s)}>
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => handleDelete(s.id)}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))
      ) : null}
    </div>
  );
}