import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Save, Settings, Upload, Image, Calendar } from "lucide-react";
import AuthorizedEmailsManager from "../components/AuthorizedEmailsManager";
import { getSchoolId } from "../hooks/useSchool";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import PageHeader from "../components/PageHeader";

export default function SchoolConfig() {
  const [settings, setSettings] = useState(null);
  const [school, setSchool] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const fileInputRef = useRef();

  useEffect(() => {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    Promise.all([
      base44.entities.SchoolSettings.filter(filter),
      schoolId ? base44.entities.School.filter({ id: schoolId }) : Promise.resolve([]),
    ]).then(([list, schools]) => {
      setSchool(schools[0] || null);
      setSettings(list[0] || {
        republic_name: "RÉPUBLIQUE DE CÔTE D'IVOIRE",
        ministry_name: "MINISTÈRE DE L'ÉDUCATION NATIONALE ET DE L'ALPHABÉTISATION",
        school_motto: "Union - Discipline - Travail",
        school_id: schoolId,
      });
      setLoading(false);
    });
  }, []);

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    if (settings.id) {
      await base44.entities.SchoolSettings.update(settings.id, settings);
    } else {
      const schoolId = getSchoolId();
      const created = await base44.entities.SchoolSettings.create({ ...settings, school_id: schoolId });
      setSettings(created);
    }
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  function set(field, value) {
    setSettings((prev) => ({ ...prev, [field]: value }));
  }

  async function handleLogoUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingLogo(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    set("logo_url", file_url);
    setUploadingLogo(false);
  }

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6 max-w-2xl">
      <PageHeader title="Configuration de l'établissement" subtitle="Informations affichées sur les bulletins officiels" />

      <form onSubmit={handleSave} className="bg-card rounded-xl border border-border p-6 space-y-4">
        <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide flex items-center gap-2">
          <Settings className="h-4 w-4" /> Informations officielles
        </h3>

        {/* Logo upload */}
        <div>
          <Label>Logo de l'établissement</Label>
          <div className="mt-2 flex items-center gap-4">
            {settings.logo_url ? (
              <img src={settings.logo_url} alt="Logo" className="h-20 w-20 object-contain rounded-lg border border-border bg-muted" />
            ) : (
              <div className="h-20 w-20 rounded-lg border-2 border-dashed border-border flex items-center justify-center bg-muted">
                <Image className="h-8 w-8 text-muted-foreground" />
              </div>
            )}
            <div className="space-y-2">
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadingLogo}
                className="flex items-center gap-2 px-4 py-2 text-sm border border-border rounded-lg hover:bg-muted transition-colors disabled:opacity-50"
              >
                <Upload className="h-4 w-4" />
                {uploadingLogo ? "Chargement..." : "Choisir un logo"}
              </button>
              {settings.logo_url && (
                <button type="button" onClick={() => set("logo_url", "")} className="text-xs text-destructive hover:underline">
                  Supprimer le logo
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Organisation de l'année scolaire */}
        <div>
          <Label className="flex items-center gap-1.5"><Calendar className="h-4 w-4" /> Organisation de l'année scolaire *</Label>
          <div className="flex gap-3 mt-2">
            {[
              { value: "trimestre", label: "📅 Trimestres", desc: "3 périodes par an" },
              { value: "semestre", label: "📆 Semestres", desc: "2 périodes par an" },
            ].map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => set("period_type", opt.value)}
                className={`flex-1 border-2 rounded-xl px-4 py-3 text-left transition-all ${
                  (settings.period_type || "trimestre") === opt.value
                    ? "border-primary bg-primary/5 text-primary"
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                <p className="font-semibold text-sm">{opt.label}</p>
                <p className="text-xs text-muted-foreground">{opt.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {[
          { field: "republic_name", label: "Nom de la République" },
          { field: "ministry_name", label: "Ministère" },
          { field: "school_motto", label: "Devise nationale" },
          { field: "school_name", label: "Nom de l'établissement *" },
          { field: "school_address", label: "Adresse" },
          { field: "school_phone", label: "Téléphone" },
          { field: "school_email", label: "Email" },
          { field: "city", label: "Ville" },
          { field: "director_name", label: "Nom du Proviseur / Chef d'établissement" },
        ].map(({ field, label }) => (
          <div key={field}>
            <Label>{label}</Label>
            <Input
              value={settings[field] || ""}
              onChange={(e) => set(field, e.target.value)}
              placeholder={label}
            />
          </div>
        ))}

        <div className="flex justify-end pt-2">
          <Button type="submit" disabled={saving} className="gap-2">
            <Save className="h-4 w-4" />
            {saving ? "Enregistrement..." : saved ? "✓ Enregistré !" : "Enregistrer"}
          </Button>
        </div>
      </form>

      {school && (
        <AuthorizedEmailsManager
          school={school}
          onUpdated={async () => {
            const schoolId = getSchoolId();
            const schools = await base44.entities.School.filter({ id: schoolId });
            setSchool(schools[0] || school);
          }}
        />
      )}
    </div>
  );
}