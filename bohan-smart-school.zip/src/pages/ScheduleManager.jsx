import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../hooks/useSchool";
import { Calendar, Plus, Trash2, AlertTriangle, CheckCircle, Clock, X, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import PageHeader from "../components/PageHeader";

const DAYS = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

// Couleur d'en-tête unique par jour
const DAY_HEADER_COLORS = {
  "Lundi":    "bg-gradient-to-r from-blue-600 to-blue-700",
  "Mardi":    "bg-gradient-to-r from-violet-600 to-purple-700",
  "Mercredi": "bg-gradient-to-r from-emerald-600 to-teal-700",
  "Jeudi":    "bg-gradient-to-r from-orange-500 to-amber-600",
  "Vendredi": "bg-gradient-to-r from-rose-600 to-pink-700",
  "Samedi":   "bg-gradient-to-r from-slate-600 to-gray-700",
};

// Couleur des créneaux : matin vs après-midi
const PALETTE_MATIN = [
  "bg-sky-100 border-sky-300 text-sky-900",
  "bg-blue-100 border-blue-300 text-blue-900",
  "bg-indigo-100 border-indigo-300 text-indigo-900",
  "bg-violet-100 border-violet-300 text-violet-900",
  "bg-cyan-100 border-cyan-300 text-cyan-900",
  "bg-teal-100 border-teal-300 text-teal-900",
  "bg-purple-100 border-purple-300 text-purple-900",
  "bg-blue-50 border-blue-200 text-blue-800",
];
const PALETTE_APMIDI = [
  "bg-amber-100 border-amber-300 text-amber-900",
  "bg-orange-100 border-orange-300 text-orange-900",
  "bg-rose-100 border-rose-300 text-rose-900",
  "bg-pink-100 border-pink-300 text-pink-900",
  "bg-red-100 border-red-300 text-red-900",
  "bg-yellow-100 border-yellow-300 text-yellow-900",
  "bg-fuchsia-100 border-fuchsia-300 text-fuchsia-900",
  "bg-amber-50 border-amber-200 text-amber-800",
];

function getSlotColor(start_time, subject_id, subjectColorIndex) {
  const [h] = start_time.split(":").map(Number);
  const isAfternoon = h >= 13;
  const palette = isAfternoon ? PALETTE_APMIDI : PALETTE_MATIN;
  return palette[subjectColorIndex % palette.length];
}

// School hours: 07:00-12:00 and 13:30-18:00
const TIME_SLOTS = [
  "07:00","07:30","08:00","08:30","09:00","09:30","10:00","10:15",
  "10:30","11:00","11:30","12:00","13:30","14:00","14:30","15:00",
  "15:30","16:00","16:30","17:00","17:30","18:00"
];

function toMinutes(t) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

function validateSlot(slot, existing) {
  const start = toMinutes(slot.start_time);
  const end = toMinutes(slot.end_time);
  const errors = [];

  // Duration check
  const duration = end - start;
  if (duration < 60) errors.push("Le cours doit durer au moins 1 heure.");
  if (duration > 120) errors.push("Le cours ne peut pas dépasser 2 heures.");

  // School hours check
  const morningEnd = toMinutes("12:00");
  const afternoonStart = toMinutes("13:30");
  const schoolStart = toMinutes("07:00");
  const schoolEnd = toMinutes("18:00");
  if (start < schoolStart || end > schoolEnd) errors.push("Hors des horaires scolaires (07h00–18h00).");
  if (start < morningEnd && end > morningEnd) errors.push("Le cours ne peut pas chevaucher la pause méridienne (12h00–13h30).");
  if (start >= morningEnd && start < afternoonStart) errors.push("Pas de cours pendant la pause méridienne (12h00–13h30).");

  // Break check 10:00-10:15
  const breakStart = toMinutes("10:00");
  const breakEnd = toMinutes("10:15");
  if (start < breakEnd && end > breakStart) errors.push("Le cours chevauche la pause (10h00–10h15).");

  // Conflict: same class same time
  const sameClassConflict = existing.filter(e =>
    e.class_id === slot.class_id &&
    e.day === slot.day &&
    e.id !== slot.id &&
    toMinutes(e.start_time) < end &&
    toMinutes(e.end_time) > start
  );
  if (sameClassConflict.length > 0) errors.push(`Conflit : la classe a déjà un cours à ce créneau (${sameClassConflict[0].subject_name}).`);

  // Conflict: same teacher same time
  const sameTeacherConflict = existing.filter(e =>
    e.teacher_email === slot.teacher_email &&
    e.day === slot.day &&
    e.id !== slot.id &&
    toMinutes(e.start_time) < end &&
    toMinutes(e.end_time) > start
  );
  if (sameTeacherConflict.length > 0) errors.push(`Conflit : le professeur enseigne déjà dans la classe ${sameTeacherConflict[0].class_name} à ce créneau.`);

  return errors;
}

const EMPTY_FORM = {
  class_id: "", subject_id: "", teacher_email: "", day: "Lundi",
  start_time: "07:00", end_time: "08:00", room: "", academic_year: new Date().getFullYear() + "-" + (new Date().getFullYear() + 1)
};

export default function ScheduleManager() {
  const { user } = useAuth();
  const [schedules, setSchedules] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState([]);
  const [saving, setSaving] = useState(false);
  const [filterClass, setFilterClass] = useState("");
  const [filterDay, setFilterDay] = useState("");

  const schoolId = getSchoolId();

  async function load() {
    const f = schoolId ? { school_id: schoolId } : {};
    const [s, c, sub, a] = await Promise.all([
      base44.entities.Schedule.filter(f, "day", 500),
      base44.entities.Class.filter(f),
      base44.entities.Subject.filter(f),
      base44.entities.TeacherAssignment.filter(f),
    ]);
    setSchedules(s);
    setClasses(c);
    setSubjects(sub);
    setAssignments(a);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  // Auto-fill teacher when class+subject selected
  useEffect(() => {
    if (form.class_id && form.subject_id) {
      const match = assignments.find(a => a.class_id === form.class_id && a.subject_id === form.subject_id);
      if (match) setForm(f => ({ ...f, teacher_email: match.teacher_email, teacher_name: match.teacher_name }));
    }
  }, [form.class_id, form.subject_id]);

  function handleFormChange(key, val) {
    setForm(f => ({ ...f, [key]: val }));
    setErrors([]);
  }

  async function handleSave(e) {
    e.preventDefault();
    const cls = classes.find(c => c.id === form.class_id);
    const sub = subjects.find(s => s.id === form.subject_id);
    const slot = {
      ...form,
      class_name: cls?.name || "",
      subject_name: sub?.name || "",
      school_id: schoolId,
    };
    const errs = validateSlot(slot, schedules);
    if (errs.length > 0) { setErrors(errs); return; }
    setSaving(true);
    await base44.entities.Schedule.create(slot);
    setSaving(false);
    setShowForm(false);
    setForm(EMPTY_FORM);
    load();
  }

  async function handleDelete(id) {
    await base44.entities.Schedule.delete(id);
    load();
  }

  const filtered = schedules.filter(s =>
    (!filterClass || s.class_id === filterClass) &&
    (!filterDay || s.day === filterDay)
  );

  // Group by day for grid view
  const byDay = DAYS.reduce((acc, d) => {
    acc[d] = filtered.filter(s => s.day === d).sort((a, b) => a.start_time.localeCompare(b.start_time));
    return acc;
  }, {});

  const subjectIndexMap = {};
  subjects.forEach((s, i) => { subjectIndexMap[s.id] = i; });

  const verifiedRole = sessionStorage.getItem("scolaris_verified_role");
  const canEdit = user?.role === "admin" || verifiedRole === "user";

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader title="Emploi du temps" subtitle={`${schedules.length} créneaux planifiés`}>
        {canEdit && (
          <Button onClick={() => { setShowForm(true); setErrors([]); }} className="gap-2">
            <Plus className="h-4 w-4" /> Ajouter un cours
          </Button>
        )}
      </PageHeader>

      {/* School hours info */}
      <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4 flex flex-wrap gap-6 text-sm">
        <div className="flex items-center gap-2 text-indigo-800">
          <Clock className="h-4 w-4" /> <span><strong>Matin :</strong> 07h00 → 12h00</span>
        </div>
        <div className="flex items-center gap-2 text-indigo-800">
          <Clock className="h-4 w-4" /> <span><strong>Pause :</strong> 10h00 → 10h15</span>
        </div>
        <div className="flex items-center gap-2 text-indigo-800">
          <Clock className="h-4 w-4" /> <span><strong>Après-midi :</strong> 13h30 → 18h00</span>
        </div>
        <div className="flex items-center gap-2 text-indigo-800">
          <Clock className="h-4 w-4" /> <span><strong>Durée :</strong> 1h min — 2h max</span>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <select
          value={filterClass}
          onChange={e => setFilterClass(e.target.value)}
          className="border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="">Toutes les classes</option>
          {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select
          value={filterDay}
          onChange={e => setFilterDay(e.target.value)}
          className="border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="">Tous les jours</option>
          {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
        </select>
      </div>

      {/* Timetable grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {DAYS.map(day => (
          <div key={day} className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
            <div className={`${DAY_HEADER_COLORS[day]} px-4 py-3`}>
              <p className="text-white font-bold text-sm">{day}</p>
              <p className="text-white/70 text-xs">{byDay[day].length} cours</p>
            </div>
            <div className="p-3 space-y-2 min-h-[100px]">
              {byDay[day].length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-4">Libre</p>
              ) : byDay[day].map(slot => (
                <div key={slot.id} className={`rounded-xl border p-2.5 ${getSlotColor(slot.start_time, slot.subject_id, subjectIndexMap[slot.subject_id] ?? 0)}`}>
                  <div className="flex items-start justify-between gap-1">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold truncate">{slot.subject_name}</p>
                      <p className="text-xs opacity-75 truncate">{slot.class_name}</p>
                      <p className="text-xs font-semibold mt-1">{slot.start_time} – {slot.end_time}</p>
                      <p className="text-xs opacity-70 truncate">{slot.teacher_name}</p>
                      {slot.room && <p className="text-xs opacity-60">🏫 {slot.room}</p>}
                    </div>
                    {canEdit && (
                      <button onClick={() => handleDelete(slot.id)} className="shrink-0 opacity-50 hover:opacity-100 transition-opacity">
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Add form modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={() => setShowForm(false)}>
          <div className="bg-background rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-100 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-indigo-600" />
                </div>
                <h2 className="text-lg font-bold">Nouveau créneau</h2>
              </div>
              <button onClick={() => setShowForm(false)} className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center">
                <X className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              {errors.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-3 space-y-1">
                  {errors.map((e, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-red-700">
                      <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0 text-red-500" />
                      {e}
                    </div>
                  ))}
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="text-sm font-medium block mb-1.5">Classe *</label>
                  <select value={form.class_id} onChange={e => handleFormChange("class_id", e.target.value)} required className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                    <option value="">Choisir une classe</option>
                    {classes.map(c => <option key={c.id} value={c.id}>{c.name} ({c.level})</option>)}
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="text-sm font-medium block mb-1.5">Matière *</label>
                  <select value={form.subject_id} onChange={e => handleFormChange("subject_id", e.target.value)} required className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                    <option value="">Choisir une matière</option>
                    {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="text-sm font-medium block mb-1.5">Professeur</label>
                  <input
                    type="text"
                    value={form.teacher_name || form.teacher_email}
                    readOnly
                    placeholder="Sélectionnez une classe + matière"
                    className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-muted"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium block mb-1.5">Jour *</label>
                  <select value={form.day} onChange={e => handleFormChange("day", e.target.value)} className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                    {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-sm font-medium block mb-1.5">Salle</label>
                  <input type="text" value={form.room} onChange={e => handleFormChange("room", e.target.value)} placeholder="Ex: Salle 12" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>

                <div>
                  <label className="text-sm font-medium block mb-1.5">Heure début *</label>
                  <select value={form.start_time} onChange={e => handleFormChange("start_time", e.target.value)} className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                    {TIME_SLOTS.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-sm font-medium block mb-1.5">Heure fin *</label>
                  <select value={form.end_time} onChange={e => handleFormChange("end_time", e.target.value)} className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                    {TIME_SLOTS.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2 border-t border-border">
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Annuler</Button>
                <Button type="submit" disabled={saving} className="gap-2">
                  <Save className="h-4 w-4" />
                  {saving ? "Enregistrement…" : "Ajouter le cours"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}