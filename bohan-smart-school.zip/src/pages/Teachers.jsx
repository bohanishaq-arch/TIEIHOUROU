import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getVerifiedRole } from "@/components/AccessGate";
import { UserPlus, Mail, BookOpen, School, RefreshCw, CheckCircle, Copy, Users, Trash2, Wand2, X, Loader2 } from "lucide-react";
import { getSchoolId, getSchoolName } from "../hooks/useSchool";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PageHeader from "../components/PageHeader";

export default function Teachers() {
  const [teachers, setTeachers] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [inviting, setInviting] = useState(false);
  const [inviteSuccess, setInviteSuccess] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  const [appAccessList, setAppAccessList] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [showGenModal, setShowGenModal] = useState(false);
  const [genLoading, setGenLoading] = useState(false);
  const [genDone, setGenDone] = useState(false);
  const [genResult, setGenResult] = useState("");
  const [form, setForm] = useState({ email: "", full_name: "", phone: "", subject_id: "", class_id: "" });
  const [showAssignClass, setShowAssignClass] = useState(false);
  const [assignForm, setAssignForm] = useState({ class_id: "", subject_id: "", access_id_input: "" });
  const [selectedAcc, setSelectedAcc] = useState(null);
  const [accessIdError, setAccessIdError] = useState("");

  const FAKE_TEACHERS = [
    { name: "Kouamé Jean", email: "prof.kouame@test.scolaris" },
    { name: "Adjoua Marie", email: "prof.adjoua@test.scolaris" },
    { name: "Koffi Ibrahim", email: "prof.koffi@test.scolaris" },
    { name: "Traorè Fatou", email: "prof.traore@test.scolaris" },
    { name: "Bamba Thierry", email: "prof.bamba@test.scolaris" },
  ];

  async function handleGenerateTeachers() {
    setGenLoading(true);
    const schoolId = getSchoolId();
    if (!schoolId || subjects.length === 0 || classes.length === 0) { setGenLoading(false); return; }
    // Create AppAccess records for fake teachers
    const accessToCreate = FAKE_TEACHERS.map(t => ({
      school_id: schoolId,
      user_email: t.email,
      access_id: "PROF-" + Math.floor(1000 + Math.random() * 9000),
      access_password: "test1234",
      role: "teacher",
      is_active: true,
      school_name: getSchoolName ? getSchoolName() : "",
    }));
    await base44.entities.AppAccess.bulkCreate(accessToCreate);
    // Create assignments: distribute subjects among fake teachers across classes
    const assignmentsToCreate = [];
    subjects.forEach((sub, si) => {
      const teacher = FAKE_TEACHERS[si % FAKE_TEACHERS.length];
      classes.slice(0, 5).forEach(cls => {
        assignmentsToCreate.push({
          school_id: schoolId,
          teacher_email: teacher.email,
          teacher_name: teacher.name,
          class_id: cls.id,
          class_name: cls.name,
          subject_id: sub.id,
          subject_name: sub.name,
        });
      });
    });
    if (assignmentsToCreate.length > 0) await base44.entities.TeacherAssignment.bulkCreate(assignmentsToCreate);
    await loadData();
    setGenResult(`${FAKE_TEACHERS.length} professeurs et ${assignmentsToCreate.length} assignations créés`);
    setGenLoading(false);
    setGenDone(true);
  }

  async function loadData() {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const [appAccess, subs, cls, me, asgn] = await Promise.all([
      base44.entities.AppAccess.filter(filter),
      base44.entities.Subject.filter(filter),
      base44.entities.Class.filter(filter),
      base44.auth.me(),
      base44.entities.TeacherAssignment.filter(filter),
    ]);
    // Get unique teacher emails from AppAccess records with teacher/user roles for this school
    const teacherEmails = new Set(
      appAccess
        .filter((a) => a.role === "teacher" || a.role === "user")
        .map((a) => a.user_email.toLowerCase())
    );
    // Use AppAccess records directly instead of fetching all users (avoids rate limit)
    const filteredTeachers = appAccess
      .filter((a) => (a.role === "teacher" || a.role === "user") && a.is_active !== false)
      .map((a) => ({ id: a.id, email: a.user_email, full_name: a.full_name, created_date: a.created_date }));
    setTeachers(filteredTeachers);
    setSubjects(subs);
    setClasses(cls);
    setCurrentUser(me);
    setAssignments(asgn);
    setAppAccessList(appAccess);
    setLoading(false);
  }

  useEffect(() => { loadData(); }, []);

  // Generate teacher ID: PROF-XXXX
  function generateTeacherId() {
    return "PROF-" + Math.floor(1000 + Math.random() * 9000);
  }

  async function handleInvite(e) {
    e.preventDefault();
    setInviting(true);
    const teacherId = generateTeacherId();

    // Invite the user with teacher role
    await base44.users.inviteUser(form.email, "user");

    // Store extra info on user entity after invite (find user by email)
    // We store the teacher_id for reference
    setInviteSuccess({
      email: form.email,
      teacherId,
      name: form.full_name,
    });

    setForm({ email: "", full_name: "", phone: "", subject_id: "", class_id: "" });
    setShowForm(false);
    setInviting(false);
    loadData();
  }

  const verifiedRole = getVerifiedRole();
  const isAdmin = currentUser?.role === "admin" || verifiedRole === "user";
  
  const availableTeachers = teachers.filter((t) => t.email);

  async function handleAssignSubject(e) {
    e.preventDefault();
    const selectedClass = classes.find((c) => c.id === assignForm.class_id);
    const selectedSubject = subjects.find((s) => s.id === assignForm.subject_id);
    if (!selectedClass || !selectedSubject || !selectedAcc) return;

    const teacherEmail = selectedAcc.user_email;
    const userRecord = teachers.find(t => t.email?.toLowerCase() === teacherEmail?.toLowerCase());
    const teacherName = userRecord?.full_name || teacherEmail;

    const duplicate = assignments.find(
      (a) => a.class_id === selectedClass.id && a.subject_id === selectedSubject.id && a.teacher_email === teacherEmail
    );
    if (duplicate) { alert("Cette assignation existe déjà."); return; }

    const schoolId = getSchoolId();
    await base44.entities.TeacherAssignment.create({
      teacher_email: teacherEmail,
      teacher_name: teacherName,
      class_id: selectedClass.id,
      class_name: selectedClass.name,
      subject_id: selectedSubject.id,
      subject_name: selectedSubject.name,
      school_id: schoolId,
    });
    setAssignForm({ class_id: "", subject_id: "", access_id_input: "" });
    setSelectedAcc(null);
    setAccessIdError("");
    setShowAssignClass(false);
    loadData();
  }

  async function handleDeleteAssignment(id) {
    await base44.entities.TeacherAssignment.delete(id);
    loadData();
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Users className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">Accès réservé au Proviseur et au Directeur des études.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Gestion des professeurs"
        subtitle={`${teachers.length} professeur${teachers.length !== 1 ? "s" : ""} enregistré${teachers.length !== 1 ? "s" : ""}`}
      >
        <Button variant="outline" onClick={() => { setShowGenModal(true); setGenDone(false); }} className="gap-2 border-purple-200 text-purple-700 hover:bg-purple-50">
          <Wand2 className="h-4 w-4" /> Générer profs test
        </Button>
        <Button onClick={() => setShowForm(true)} className="gap-2">
          <UserPlus className="h-4 w-4" /> Inviter un professeur
        </Button>
      </PageHeader>

      {/* Gen modal */}
      {showGenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4" onClick={() => setShowGenModal(false)}>
          <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md p-6 space-y-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-foreground">Générer des professeurs test</h3>
              <button onClick={() => setShowGenModal(false)} className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center"><X className="h-4 w-4" /></button>
            </div>
            {genDone ? (
              <div className="flex flex-col items-center gap-3 py-6">
                <CheckCircle className="h-12 w-12 text-green-500" />
                <p className="font-semibold text-foreground">Données test créées !</p>
                <p className="text-xs text-muted-foreground text-center">{genResult}</p>
                <Button onClick={() => setShowGenModal(false)}>Fermer</Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-700">
                  ⚠️ Ceci créera {FAKE_TEACHERS.length} professeurs fictifs avec des assignations dans les classes existantes. Uniquement pour les tests.
                </div>
                <div className="bg-muted/50 rounded-lg p-3 space-y-1">
                  <p className="text-xs font-semibold">Professeurs qui seront créés :</p>
                  {FAKE_TEACHERS.map(t => <p key={t.email} className="text-xs text-muted-foreground">• {t.name}</p>)}
                </div>
                {(subjects.length === 0 || classes.length === 0) && (
                  <p className="text-xs text-red-600">Créez d'abord des matières et des classes avant de générer les professeurs.</p>
                )}
                <div className="flex gap-3 pt-2">
                  <Button variant="outline" className="flex-1" onClick={() => setShowGenModal(false)}>Annuler</Button>
                  <Button className="flex-1 gap-2 bg-purple-600 hover:bg-purple-700" onClick={handleGenerateTeachers} disabled={genLoading || subjects.length === 0 || classes.length === 0}>
                    {genLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
                    {genLoading ? "Création…" : "Générer"}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Assign section */}
      <div className="bg-card rounded-xl border border-border p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-foreground flex items-center gap-2">
              <BookOpen className="h-4 w-4 text-primary" />
              Assignations Classe + Matière + Professeur
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5">Plusieurs professeurs peuvent enseigner dans la même classe (matières différentes).</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => setShowAssignClass(!showAssignClass)} className="gap-1">
            {showAssignClass ? "Fermer" : "+ Nouvelle assignation"}
          </Button>
        </div>

        {showAssignClass && (
          <form onSubmit={handleAssignSubject} className="space-y-4 pt-4 border-t border-border">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <Label className="text-xs">Classe *</Label>
                <Select value={assignForm.class_id} onValueChange={(v) => setAssignForm({ ...assignForm, class_id: v })} required>
                  <SelectTrigger className="text-sm"><SelectValue placeholder="Classe" /></SelectTrigger>
                  <SelectContent>
                    {classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Matière *</Label>
                <Select value={assignForm.subject_id} onValueChange={(v) => setAssignForm({ ...assignForm, subject_id: v })} required>
                  <SelectTrigger className="text-sm"><SelectValue placeholder="Matière" /></SelectTrigger>
                  <SelectContent>
                    {subjects.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Identifiant du professeur *</Label>
                <Input
                  className="text-sm font-mono"
                  placeholder="Ex: COU-GU-16-ENS-1727"
                  value={assignForm.access_id_input}
                  onChange={(e) => {
                    const val = e.target.value;
                    setAccessIdError("");
                    setSelectedAcc(null);
                    const acc = appAccessList.find(a =>
                      a.access_id?.trim().toLowerCase() === val.trim().toLowerCase()
                    );
                    if (acc) {
                      setSelectedAcc(acc);
                    } else if (val.trim().length > 3) {
                      setAccessIdError("Aucun professeur trouvé avec cet identifiant.");
                    }
                    setAssignForm(f => ({ ...f, access_id_input: val }));
                  }}
                  required
                />
                {accessIdError && <p className="text-xs text-red-500 mt-1">{accessIdError}</p>}
              </div>
            </div>

            {/* Teacher preview card */}
            {selectedAcc && (() => {
              const userRecord = teachers.find(t => t.email?.toLowerCase() === selectedAcc.user_email?.toLowerCase());
              return (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-lg shrink-0">
                    {(userRecord?.full_name || selectedAcc.user_email || "?")[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground">{userRecord?.full_name || "(Pas encore connecté)"}</p>
                    <p className="text-sm text-muted-foreground">{selectedAcc.user_email}</p>
                    <p className="text-xs font-mono mt-1 text-blue-700 bg-blue-100 inline-block px-2 py-0.5 rounded">
                      ID : {selectedAcc.access_id}
                    </p>
                  </div>
                  <span className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary font-medium capitalize shrink-0">
                    {selectedAcc.role}
                  </span>
                </div>
              );
            })()}

            <div className="flex justify-end">
              <Button type="submit" className="gap-2 text-sm">
                <BookOpen className="h-3.5 w-3.5" /> Assigner
              </Button>
            </div>
          </form>
        )}

        {/* Assignments list */}
        {assignments.length > 0 && (
          <div className="border-t border-border pt-4">
            <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">{assignments.length} assignation{assignments.length !== 1 ? "s" : ""}</p>
            <div className="space-y-1.5">
              {assignments.map((a) => (
                <div key={a.id} className="flex items-center justify-between bg-muted/30 rounded-lg px-3 py-2 text-sm">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-primary">{a.class_name}</span>
                    <span className="text-muted-foreground">→</span>
                    <span className="text-foreground">{a.subject_name}</span>
                    <span className="text-muted-foreground">→</span>
                    <span className="font-medium">{a.teacher_name}</span>
                  </div>
                  <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:text-destructive shrink-0" onClick={() => handleDeleteAssignment(a.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Success banner */}
      {inviteSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-start gap-3">
          <CheckCircle className="h-5 w-5 text-green-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-green-800">Invitation envoyée avec succès !</p>
            <p className="text-sm text-green-700 mt-1">
              <strong>{inviteSuccess.name || inviteSuccess.email}</strong> recevra un email d'invitation pour se connecter à Scolaris.
            </p>
            <div className="mt-2 bg-white border border-green-200 rounded-lg p-3 text-sm font-mono flex items-center justify-between">
              <span>ID Professeur : <strong>{inviteSuccess.teacherId}</strong></span>
              <Button variant="ghost" size="sm" className="h-6 text-xs gap-1"
                onClick={() => navigator.clipboard.writeText(inviteSuccess.teacherId)}>
                <Copy className="h-3 w-3" /> Copier
              </Button>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => setInviteSuccess(null)}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Invitation form */}
      {showForm && (
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-semibold text-foreground">Inviter un nouveau professeur</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Le professeur recevra un email avec un lien pour définir son mot de passe.</p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="h-4 w-4" /></Button>
          </div>

          <form onSubmit={handleInvite} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Adresse email *</Label>
              <Input
                type="email"
                placeholder="prof@ecole.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
              />
              <p className="text-xs text-muted-foreground mt-1">L'invitation sera envoyée à cet email.</p>
            </div>
            <div>
              <Label>Nom complet</Label>
              <Input
                placeholder="Ex: Jean Dupont"
                value={form.full_name}
                onChange={(e) => setForm({ ...form, full_name: e.target.value })}
              />
            </div>
            <div>
              <Label>Téléphone</Label>
              <Input
                placeholder="+225 07 XX XX XX XX"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
              />
            </div>
            <div>
              <Label>Matière principale</Label>
              <Select value={form.subject_id} onValueChange={(v) => setForm({ ...form, subject_id: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionner une matière" /></SelectTrigger>
                <SelectContent>
                  {subjects.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2 flex justify-end gap-3 pt-2">
              <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Annuler</Button>
              <Button type="submit" disabled={inviting} className="gap-2">
                {inviting ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
                {inviting ? "Envoi en cours..." : "Envoyer l'invitation"}
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Teachers list */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
          <Users className="h-4 w-4" /> Professeurs de l'établissement
        </h3>
        {teachers.length === 0 ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <Users className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground font-medium">Aucun professeur enregistré</p>
          <p className="text-sm text-muted-foreground mt-1">Invitez des professeurs pour qu'ils puissent accéder à Scolaris.</p>
        </div>
        ) : (
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/50 border-b border-border">
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Professeur</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Email</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Matières assignées</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Inscription</th>
              </tr>
            </thead>
            <tbody>
              {teachers.map((t) => {
                const teacherSubjects = subjects.filter((s) => s.teacher_email && s.teacher_email.toLowerCase() === t.email.toLowerCase());
                const teacherLevels = new Set(teacherSubjects.flatMap((s) => s.levels || (s.level ? [s.level] : [])));
                const teacherClasses = classes.filter((c) => teacherLevels.has(c.level));
                return (
                <tr key={t.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-sm shrink-0">
                        {(t.full_name || t.email || "?")[0].toUpperCase()}
                      </div>
                      <span className="font-medium">{t.full_name || "—"}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-muted-foreground text-sm">{t.email}</td>
                  <td className="py-3 px-4">
                  {teacherSubjects.length === 0 ? (
                    <span className="text-muted-foreground text-xs italic">Aucune matière</span>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {teacherSubjects.map((s) => (
                        <span key={s.id} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                          <BookOpen className="h-3 w-3" /> {s.name}
                        </span>
                      ))}
                    </div>
                  )}
                  </td>
                  <td className="py-3 px-4 text-xs text-muted-foreground">
                    {t.created_date ? new Date(t.created_date).toLocaleDateString("fr-FR") : "—"}
                  </td>
                </tr>
              );
              })}
            </tbody>
          </table>
        </div>
        )}
      </div>
    </div>
  );
}