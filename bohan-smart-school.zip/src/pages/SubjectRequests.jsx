import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../hooks/useSchool";
import { CheckCircle, XCircle, Clock, MessageSquare, User, BookOpen, School, Loader2, Check, X } from "lucide-react";
import PageHeader from "../components/PageHeader";

const STATUS_CONFIG = {
  en_attente: { label: "En attente", color: "bg-yellow-100 text-yellow-700 border-yellow-200", icon: Clock },
  approuvee: { label: "Approuvée", color: "bg-green-100 text-green-700 border-green-200", icon: CheckCircle },
  rejetee: { label: "Rejetée", color: "bg-red-100 text-red-700 border-red-200", icon: XCircle },
};

export default function SubjectRequests() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(null);
  const [adminNote, setAdminNote] = useState({});
  const [filter, setFilter] = useState("en_attente");

  async function loadRequests() {
    const schoolId = getSchoolId();
    const filter_obj = schoolId ? { school_id: schoolId } : {};
    const reqs = await base44.entities.SubjectRequest.filter(filter_obj);
    setRequests(reqs.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
    setLoading(false);
  }

  useEffect(() => { loadRequests(); }, []);

  async function handleApprove(req) {
    setProcessing(req.id);
    // Update request status
    await base44.entities.SubjectRequest.update(req.id, {
      status: "approuvee",
      admin_note: adminNote[req.id] || "",
    });
    // Auto-create TeacherAssignment
    const existing = await base44.entities.TeacherAssignment.filter({
      teacher_email: req.teacher_email,
      class_id: req.class_id,
      subject_id: req.subject_id,
    });
    if (existing.length === 0) {
      await base44.entities.TeacherAssignment.create({
        school_id: req.school_id,
        teacher_email: req.teacher_email,
        teacher_name: req.teacher_name,
        class_id: req.class_id,
        class_name: req.class_name,
        subject_id: req.subject_id,
        subject_name: req.subject_name,
      });
    }
    await loadRequests();
    setProcessing(null);
  }

  async function handleReject(req) {
    setProcessing(req.id);
    await base44.entities.SubjectRequest.update(req.id, {
      status: "rejetee",
      admin_note: adminNote[req.id] || "",
    });
    await loadRequests();
    setProcessing(null);
  }

  const filtered = requests.filter((r) => r.status === filter);
  const pendingCount = requests.filter((r) => r.status === "en_attente").length;

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="Demandes d'enseignement"
        subtitle={`${pendingCount} demande${pendingCount !== 1 ? "s" : ""} en attente de validation`}
      />

      {/* Filter tabs */}
      <div className="flex gap-2 border-b border-border">
        {Object.entries(STATUS_CONFIG).map(([key, cfg]) => {
          const Icon = cfg.icon;
          const count = requests.filter((r) => r.status === key).length;
          return (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium whitespace-nowrap transition-colors border-b-2 -mb-px ${
                filter === key ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className="h-4 w-4" />
              {cfg.label}
              {count > 0 && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full font-bold ${filter === key ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {filtered.length === 0 ? (
        <div className="bg-muted/40 rounded-xl border border-border p-10 text-center">
          <BookOpen className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="font-semibold text-foreground">Aucune demande {STATUS_CONFIG[filter]?.label?.toLowerCase()}</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((req) => {
            const sc = STATUS_CONFIG[req.status];
            const Icon = sc.icon;
            const isProcessing = processing === req.id;

            return (
              <div key={req.id} className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
                {/* Header */}
                <div className="flex items-start justify-between p-5 gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <User className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-bold text-foreground">{req.teacher_name}</p>
                      <p className="text-xs text-muted-foreground">{req.teacher_email}</p>
                      {req.teacher_access_id && (
                        <p className="text-xs font-mono text-muted-foreground mt-0.5">{req.teacher_access_id}</p>
                      )}
                    </div>
                  </div>
                  <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${sc.color}`}>
                    <Icon className="h-3.5 w-3.5" />
                    {sc.label}
                  </span>
                </div>

                {/* Details */}
                <div className="px-5 pb-4 grid grid-cols-2 gap-3">
                  <div className="bg-muted/40 rounded-xl p-3 flex items-center gap-3">
                    <BookOpen className="h-5 w-5 text-primary shrink-0" />
                    <div>
                      <p className="text-xs text-muted-foreground">Matière demandée</p>
                      <p className="font-semibold text-sm text-foreground">{req.subject_name}</p>
                    </div>
                  </div>
                  <div className="bg-muted/40 rounded-xl p-3 flex items-center gap-3">
                    <School className="h-5 w-5 text-primary shrink-0" />
                    <div>
                      <p className="text-xs text-muted-foreground">Classe</p>
                      <p className="font-semibold text-sm text-foreground">{req.class_name}</p>
                    </div>
                  </div>
                </div>

                {req.motivation && (
                  <div className="px-5 pb-4">
                    <div className="flex items-start gap-2 bg-blue-50 border border-blue-100 rounded-xl px-3 py-2.5 text-sm text-blue-800">
                      <MessageSquare className="h-4 w-4 shrink-0 mt-0.5" />
                      <p className="italic">{req.motivation}</p>
                    </div>
                  </div>
                )}

                <p className="px-5 pb-3 text-xs text-muted-foreground">
                  Soumise le {new Date(req.created_date).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })}
                </p>

                {/* Actions (only for pending) */}
                {req.status === "en_attente" && (
                  <div className="px-5 pb-5 space-y-3 border-t border-border pt-4">
                    <div>
                      <label className="text-xs font-medium text-muted-foreground block mb-1">Note (optionnel)</label>
                      <input
                        type="text"
                        value={adminNote[req.id] || ""}
                        onChange={(e) => setAdminNote((n) => ({ ...n, [req.id]: e.target.value }))}
                        placeholder="Ajouter une note pour le professeur..."
                        className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
                      />
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={() => handleReject(req)}
                        disabled={isProcessing}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 border border-red-200 text-red-600 rounded-xl text-sm font-medium hover:bg-red-50 transition-colors disabled:opacity-60"
                      >
                        {isProcessing ? <Loader2 className="h-4 w-4 animate-spin" /> : <X className="h-4 w-4" />}
                        Rejeter
                      </button>
                      <button
                        onClick={() => handleApprove(req)}
                        disabled={isProcessing}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-green-600 text-white rounded-xl text-sm font-medium hover:bg-green-700 transition-colors disabled:opacity-60"
                      >
                        {isProcessing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                        Approuver & Ajouter
                      </button>
                    </div>
                  </div>
                )}

                {req.admin_note && req.status !== "en_attente" && (
                  <div className="px-5 pb-4">
                    <p className="text-xs bg-muted rounded-lg px-3 py-2">Note admin : {req.admin_note}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}