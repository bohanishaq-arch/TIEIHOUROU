import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../hooks/useSchool";
import { X, GraduationCap } from "lucide-react";

import TeacherCard from "@/components/teacher/TeacherCard";
import TeacherReportForm from "@/components/teacher/TeacherReportForm";
import TeacherStats from "@/components/teacher/TeacherStats";
import TeacherSchedule from "@/components/teacher/TeacherSchedule";
import TeacherGradesList from "@/components/teacher/TeacherGradesList";
import TeacherAttendance from "@/components/teacher/TeacherAttendance";
import TeacherSubjectRequest from "@/components/teacher/TeacherSubjectRequest";
import TeacherOnboarding from "@/components/teacher/TeacherOnboarding";
import TeacherHistory from "@/components/teacher/TeacherHistory";
import TeacherExamManager from "@/components/teacher/TeacherExamManager";
import TeacherStudentsList from "@/components/teacher/TeacherStudentsList";
import TeacherAttendanceManager from "@/components/teacher/TeacherAttendanceManager";
import ProfileSettings from "@/components/ProfileSettings";

import TeacherHeroCard from "@/components/teacher/dashboard/TeacherHeroCard";
import TeacherKpiCards from "@/components/teacher/dashboard/TeacherKpiCards";
import TeacherTodayPanel from "@/components/teacher/dashboard/TeacherTodayPanel";
import TeacherClassCards from "@/components/teacher/dashboard/TeacherClassCards";
import TeacherRecentActivities from "@/components/teacher/dashboard/TeacherRecentActivities";
import TeacherQuickActions from "@/components/teacher/dashboard/TeacherQuickActions";

const MODAL_TABS = [
  { id: "card", label: "Ma carte" },
  { id: "overview", label: "Vue d'ensemble" },
  { id: "students", label: "Mes élèves" },
  { id: "schedule", label: "Emploi du temps" },
  { id: "exams", label: "Devoirs & Examens" },
  { id: "grades", label: "Notes" },
  { id: "attendance", label: "Présences" },
  { id: "attendance-new", label: "Saisie présences" },
  { id: "report", label: "Envoyer un rapport" },
  { id: "subject-request", label: "Demander une matière" },
  { id: "historique", label: "Mon historique" },
];

export default function TeacherDashboard() {
  const { user } = useAuth();
  const [activeModal, setActiveModal] = useState(null);
  const [data, setData] = useState({ subjects: [], classes: [], grades: [], students: [], assignments: [], schedules: [], exams: [], absences: [] });
  const [teacherProfile, setTeacherProfile] = useState(null);
  const [onboardingRequest, setOnboardingRequest] = useState(null);
  const [loading, setLoading] = useState(true);

  async function reloadData() {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const [subjects, classes, grades, students, assignments] = await Promise.all([
      base44.entities.Subject.filter(filter),
      base44.entities.Class.filter(filter),
      base44.entities.Grade.filter(filter),
      base44.entities.Student.filter(filter),
      base44.entities.TeacherAssignment.filter(filter),
    ]);
    setData(prev => ({ ...prev, subjects, classes, grades, students, assignments }));
  }

  useEffect(() => {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    async function load() {
      const [subjects, classes, grades, students, assignments, accesses, schedules, exams, absences] = await Promise.all([
        base44.entities.Subject.filter(filter),
        base44.entities.Class.filter(filter),
        base44.entities.Grade.filter(filter),
        base44.entities.Student.filter(filter),
        base44.entities.TeacherAssignment.filter(filter),
        base44.entities.AppAccess.filter({ user_email: user?.email?.toLowerCase() }),
        base44.entities.Schedule.filter({ teacher_email: user?.email?.toLowerCase() }),
        base44.entities.Exam.filter({ teacher_email: user?.email?.toLowerCase() }),
        base44.entities.Absence.filter(filter),
      ]);
      const profile = accesses.find(a => a.role === 'teacher' && a.is_active !== false);
      setTeacherProfile(profile || null);
      setData({ subjects, classes, grades, students, assignments, schedules, exams, absences });
      if (profile) {
        const requests = await base44.entities.AccessRequest.filter({ email: user?.email?.toLowerCase() });
        const req = requests.find(r => r.role_requested === 'teacher');
        setOnboardingRequest(req || null);
      }
      if (!profile) setActiveModal('card');
      setLoading(false);
    }
    load();
  }, []);

  // Derived data
  const myAssignments = data.assignments.filter(a => {
    const emailMatch = a.teacher_email?.toLowerCase() === (user?.email || "").toLowerCase();
    const nameMatch = teacherProfile?.full_name && a.teacher_name?.toLowerCase() === teacherProfile.full_name.toLowerCase();
    return emailMatch || nameMatch;
  });
  const myClassIds = new Set(myAssignments.map(a => a.class_id));
  const mySubjectIds = new Set(myAssignments.map(a => a.subject_id));
  const myClasses = data.classes.filter(c => myClassIds.has(c.id));
  const mySubjects = data.subjects.filter(s => mySubjectIds.has(s.id));
  const myStudents = data.students.filter(s => myClassIds.has(s.class_id));
  const myGrades = data.grades.filter(g => mySubjectIds.has(g.subject_id) && myClassIds.has(g.class_id));

  // Today's schedule
  const days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  const today = days[new Date().getDay()];
  const todaySchedule = data.schedules
    .filter(s => s.day === today)
    .sort((a, b) => (a.start_time || "").localeCompare(b.start_time || ""))
    .map(s => ({
      start_time: s.start_time,
      end_time: s.end_time,
      subject_name: s.subject_name || mySubjects.find(sub => sub.id === s.subject_id)?.name || "—",
      class_name: s.class_name || myClasses.find(c => c.id === s.class_id)?.name || "—",
    }));

  // Devoirs à corriger = exams créés par ce prof dont les notes ne sont pas encore toutes saisies
  const devoirsCount = data.exams.length;

  // Absences à traiter (non justifiées dans mes classes)
  const absencesCount = data.absences.filter(a => myClassIds.has(a.class_id) && a.type === "absent").length;

  // General average across my grades
  const generalAvg = myGrades.length
    ? Math.round(myGrades.reduce((acc, g) => acc + g.score, 0) / myGrades.length * 10) / 10
    : null;

  // Todos
  const todos = [
    ...(devoirsCount > 0 ? [{ label: `Corriger les devoirs${myClasses[0] ? ` (${myClasses[0].name})` : ""}`, count: devoirsCount, urgent: false }] : []),
    ...(myGrades.length === 0 && myClasses.length > 0 ? [{ label: `Saisir les notes${myClasses[1] ? ` (${myClasses[1].name})` : ""}`, count: 10, urgent: true }] : []),
  ];

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-violet-200 border-t-violet-600 rounded-full animate-spin" />
    </div>
  );

  const modalLabel = MODAL_TABS.find(t => t.id === activeModal)?.label || "";

  return (
    <div className="space-y-5 min-h-screen" style={{ background: "#F8FAFC" }}>

      {/* Hero Card */}
      <TeacherHeroCard
        teacherName={teacherProfile?.full_name || user?.full_name}
        todayCourses={todaySchedule.length}
        devoirsCount={devoirsCount}
        absencesCount={absencesCount}
        onViewSchedule={() => setActiveModal("schedule")}
      />

      {/* KPI Cards */}
      <TeacherKpiCards
        classesCount={myClasses.length}
        studentsCount={myStudents.length}
        examsCount={devoirsCount}
        generalAvg={generalAvg}
      />

      {/* Middle row: Today + Classes + Recent activities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <TeacherTodayPanel todaySchedule={todaySchedule} todos={todos} />
        <TeacherClassCards
          myClasses={myClasses}
          myStudents={myStudents}
          myGrades={myGrades}
          myAssignments={myAssignments}
          onOpenModal={setActiveModal}
        />
        <TeacherRecentActivities
          teacherEmail={user?.email}
          mySubjectIds={mySubjectIds}
          myClassIds={myClassIds}
          onOpenModal={setActiveModal}
        />
      </div>

      {/* Quick Actions */}
      <TeacherQuickActions onOpenModal={setActiveModal} />

      {/* Modal */}
      {activeModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-violet-100 flex items-center justify-center">
                  <GraduationCap className="h-4 w-4 text-violet-600" />
                </div>
                <h2 className="text-base font-bold text-gray-900">{modalLabel}</h2>
              </div>
              <button onClick={() => setActiveModal(null)} className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors">
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>
            <div className="overflow-y-auto flex-1 p-6">
              {activeModal === "card" && <TeacherCard myClasses={myClasses} mySubjects={mySubjects} myAssignments={myAssignments} onProfileLinked={(profile) => { setTeacherProfile(profile); setActiveModal(null); reloadData(); }} />}
              {activeModal === "overview" && <TeacherStats myClasses={myClasses} mySubjects={mySubjects} myStudents={myStudents} myGrades={myGrades} myAssignments={myAssignments} />}
              {activeModal === "students" && <TeacherStudentsList myClasses={myClasses} mySubjects={mySubjects} myStudents={myStudents} myGrades={myGrades} myAssignments={myAssignments} />}
              {activeModal === "exams" && <TeacherExamManager myClasses={myClasses} mySubjects={mySubjects} myAssignments={myAssignments} />}
              {activeModal === "grades" && <TeacherGradesList myClasses={myClasses} mySubjects={mySubjects} myStudents={myStudents} myGrades={myGrades} />}
              {activeModal === "attendance" && <TeacherAttendance myClasses={myClasses} myStudents={myStudents} myAssignments={myAssignments} />}
              {activeModal === "attendance-new" && <TeacherAttendanceManager teacherEmail={user?.email} schoolId={getSchoolId()} />}
              {activeModal === "schedule" && <TeacherSchedule myClasses={myClasses} mySubjects={mySubjects} myAssignments={myAssignments} />}
              {activeModal === "report" && <TeacherReportForm myClasses={myClasses} mySubjects={mySubjects} myAssignments={myAssignments} onClose={() => setActiveModal(null)} />}
              {activeModal === "subject-request" && <TeacherSubjectRequest myAssignments={myAssignments} />}
              {activeModal === "historique" && <TeacherHistory />}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}