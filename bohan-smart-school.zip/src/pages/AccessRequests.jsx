import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Check, X, Clock, ShieldAlert, RefreshCw, UserCheck } from "lucide-react";
import { getSchoolId, getSchoolName } from "../hooks/useSchool";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import PageHeader from "../components/PageHeader";

const STATUS_LABEL = {
  en_attente: { label: "En attente", color: "bg-amber-100 text-amber-700", icon: Clock },
  approuvee:  { label: "Approuvée",  color: "bg-green-100 text-green-700", icon: Check },
  rejetee:    { label: "Rejetée",    color: "bg-red-100 text-red-700",     icon: X },
};

const ROLE_LABEL = { user: "Administration", teacher: "Professeur", student: "Élève", admin: "Directeur / Admin" };

function generateId(name) {
  const prefix = (name || "SCO")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, "")
    .substring(0, 3)
    .toUpperCase()
    .padEnd(3, "X");
  return prefix + "-" + Math.random().toString(36).substring(2, 7).toUpperCase();
}

function generatePwd() {
  return Math.random().toString(36).substring(2, 10);
}

export default function AccessRequests() {
  const { user } = useAuth();
  const [requests, setRequests]     = useState([]);
  const [loading, setLoading]       = useState(true);
  const [processing, setProcessing] = useState(null);
  const [approveRoles, setApproveRoles] = useState({});
  const [error, setError]           = useState(null);

  const schoolId = getSchoolId();

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const list = schoolId
        ? await base44.entities.AccessRequest.filter({ school_id: schoolId }, "-created_date", 200)
        : await base44.entities.AccessRequest.list("-created_date", 200);
      setRequests(list);
    } catch (e) {
      setError("Impossible de charger les demandes.");
    } finally {
      setLoading(false);
    }
  }, [schoolId]);

  useEffect(() => { load(); }, [load]);

  async function approve(req) {
   const chosenRole = approveRoles[req.id] || req.role_requested || "user";
   setProcessing(req.id);
   setError(null);

   try {
     const inviteRole = chosenRole === "admin" ? "admin" : "user";
     await base44.users.inviteUser(req.email, inviteRole);

     const accessId  = generateId(req.full_name);
     const accessPwd = generatePwd();

     await base44.entities.AppAccess.create({
       user_email:      req.email,
       access_id:       accessId,
       access_password: accessPwd,
       role:            chosenRole,
       full_name:       req.full_name,
       is_active:       true,
       school_id:       schoolId,
       school_name:     getSchoolName() || "",
     });

     // If teacher, create TeacherAssignment record for visibility
     if (chosenRole === "teacher") {
       await base44.entities.TeacherAssignment.create({
         teacher_email: req.email,
         teacher_name: req.full_name,
         school_id: schoolId,
         class_id: "",
         subject_id: "",
       });
     }

     await base44.entities.AccessRequest.update(req.id, { status: "approuvee" });

     load();
   } catch (e) {
     setError(`Erreur lors de l'approbation de ${req.full_name} : ${e?.message || "erreur inconnue"}`);
   } finally {
     setProcessing(null);
   }
  }

  async function reject(req) {
    setProcessing(req.id);
    setError(null);
    try {
      await base44.entities.AccessRequest.update(req.id, { status: "rejetee" });
      load();
    } catch (e) {
      setError(`Erreur lors du rejet : ${e?.message || "erreur inconnue"}`);
    } finally {
      setProcessing(null);
    }
  }

  if (user?.role !== "admin") return (
    <div className="flex flex-col items-center justify-center h-64 gap-3">
      <ShieldAlert className="h-10 w-10 text-muted-foreground" />
      <p className="text-muted-foreground">Accès réservé aux administrateurs.</p>
    </div>
  );

  const pending = requests.filter((r) => r.status === "en_attente");
  const others  = requests.filter((r) => r.status !== "en_attente");

  return (
    <div className="space-y-6">
      <PageHeader
        title="Demandes d'accès"
        subtitle={`${pending.length} demande${pending.length !== 1 ? "s" : ""} en attente`}
      >
        <Button variant="outline" size="sm" onClick={load} disabled={loading} className="gap-2">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} /> Actualiser
        </Button>
      </PageHeader>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3 flex items-center gap-2">
          <X className="h-4 w-4 shrink-0" /> {error}
        </div>
      )}

      {pending.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-amber-600 flex items-center gap-2">
            <Clock className="h-4 w-4" /> En attente d'approbation
          </h3>
          {pending.map((req) => (
            <div key={req.id} className="bg-card border-2 border-amber-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-start gap-4">
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-bold text-foreground">{req.full_name}</p>
                  <span className="text-xs bg-muted px-2 py-0.5 rounded-full text-muted-foreground">
                    {ROLE_LABEL[req.role_requested] || req.role_requested}
                  </span>
                </div>
                <p className="text-sm text-primary">{req.email}</p>
                {req.school_name && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1">🏫 {req.school_name}</p>
                )}
                {req.role_requested === "student" && req.student_number && (
                  <p className="text-xs text-muted-foreground">Matricule : <span className="font-mono font-medium text-foreground">{req.student_number}</span></p>
                )}
                {req.role_requested === "teacher" && req.subjects_taught && (
                  <p className="text-xs text-muted-foreground">Matières : <span className="font-medium text-foreground">{req.subjects_taught}</span></p>
                )}
                {req.message && <p className="text-xs text-muted-foreground italic">"{req.message}"</p>}
                <p className="text-xs text-muted-foreground">
                  {new Date(req.created_date).toLocaleString("fr-FR")}
                </p>
                <div className="pt-1">
                  <Select
                    value={approveRoles[req.id] || req.role_requested || "user"}
                    onValueChange={(v) => setApproveRoles((prev) => ({ ...prev, [req.id]: v }))}
                  >
                    <SelectTrigger className="h-8 text-xs w-48">
                      <UserCheck className="h-3.5 w-3.5 mr-1" />
                      <SelectValue placeholder="Choisir le rôle" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Élève</SelectItem>
                      <SelectItem value="teacher">Professeur</SelectItem>
                      <SelectItem value="user">Administration</SelectItem>
                      <SelectItem value="admin">Directeur / Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex gap-2 shrink-0">
                <Button
                  size="sm" variant="outline"
                  className="gap-1.5 border-red-200 text-red-600 hover:bg-red-50"
                  disabled={processing === req.id}
                  onClick={() => reject(req)}
                >
                  <X className="h-3.5 w-3.5" /> Rejeter
                </Button>
                <Button
                  size="sm"
                  className="gap-1.5 bg-green-600 hover:bg-green-700"
                  disabled={processing === req.id}
                  onClick={() => approve(req)}
                >
                  <Check className="h-3.5 w-3.5" />
                  {processing === req.id ? "…" : "Approuver"}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {pending.length === 0 && !loading && (
        <div className="bg-card border border-border rounded-xl p-8 text-center text-muted-foreground text-sm">
          <Clock className="h-8 w-8 mx-auto mb-3 opacity-30" />
          Aucune demande en attente.
        </div>
      )}

      {others.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-muted-foreground mb-3">Historique</h3>
          <div className="bg-card rounded-xl border border-border overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50 border-b border-border">
                  <th className="text-left py-2 px-4 text-xs font-semibold text-muted-foreground">Nom</th>
                  <th className="text-left py-2 px-4 text-xs font-semibold text-muted-foreground">Email</th>
                  <th className="text-left py-2 px-4 text-xs font-semibold text-muted-foreground">École</th>
                  <th className="text-left py-2 px-4 text-xs font-semibold text-muted-foreground">Rôle</th>
                  <th className="text-left py-2 px-4 text-xs font-semibold text-muted-foreground">Détails</th>
                  <th className="text-left py-2 px-4 text-xs font-semibold text-muted-foreground">Statut</th>
                  <th className="text-right py-2 px-4 text-xs font-semibold text-muted-foreground">Date</th>
                </tr>
              </thead>
              <tbody>
                {others.map((req) => {
                  const s    = STATUS_LABEL[req.status] ?? STATUS_LABEL.en_attente;
                  const Icon = s.icon;
                  const detail =
                    req.role_requested === "student" && req.student_number ? `Matricule: ${req.student_number}`
                    : req.role_requested === "teacher" && req.subjects_taught ? req.subjects_taught
                    : "—";
                  return (
                    <tr key={req.id} className="border-b border-border/50 last:border-0">
                      <td className="py-2 px-4 font-medium">{req.full_name}</td>
                      <td className="py-2 px-4 text-muted-foreground text-xs">{req.email}</td>
                      <td className="py-2 px-4 text-xs text-muted-foreground">{req.school_name || "—"}</td>
                      <td className="py-2 px-4 text-xs text-muted-foreground">{ROLE_LABEL[req.role_requested] || req.role_requested}</td>
                      <td className="py-2 px-4 text-xs text-muted-foreground">{detail}</td>
                      <td className="py-2 px-4">
                        <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium ${s.color}`}>
                          <Icon className="h-3 w-3" />{s.label}
                        </span>
                      </td>
                      <td className="py-2 px-4 text-right text-xs text-muted-foreground">
                        {new Date(req.created_date).toLocaleDateString("fr-FR")}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}