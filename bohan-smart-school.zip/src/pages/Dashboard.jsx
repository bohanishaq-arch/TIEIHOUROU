import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { getSchoolId, getSchoolName } from "../hooks/useSchool";
import { useAuth } from "@/lib/AuthContext";
import { Bell, Search } from "lucide-react";

// Desktop components (unchanged)
import KpiCards from "../components/dashboard/KpiCards";
import AlertCards from "../components/dashboard/AlertCards";
import EvolutionChart from "../components/dashboard/EvolutionChart";
import RecentActivities from "../components/dashboard/RecentActivities";
import StudentRankings from "../components/dashboard/StudentRankings";
import ClassAveragesChart from "../components/dashboard/ClassAveragesChart";
import SubjectPerformance from "../components/dashboard/SubjectPerformance";
import QuickActions from "../components/dashboard/QuickActions";

// Mobile premium components
import MobileHeader from "../components/dashboard/MobileHeader";
import MobileAlertCards from "../components/dashboard/MobileAlertCards";
import MobileKpiGrid from "../components/dashboard/MobileKpiGrid";
import MobileQuickActions from "../components/dashboard/MobileQuickActions";

export default function Dashboard() {
  const [stats, setStats] = useState({
    students: 0, classes: 0, subjects: 0, teachers: 0, grades: 0,
    weakStudents: 0, decliningClasses: 0, unjustifiedAbsences: 0,
  });
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const schoolName = getSchoolName();

  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? "Bonjour" : hour < 18 ? "Bon après-midi" : "Bonsoir";
  const currentYear = `${now.getFullYear()}-${now.getFullYear() + 1}`;

  useEffect(() => {
    async function loadStats() {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      const [students, classes, subjects, teachers, grades, absences] = await Promise.all([
        base44.entities.Student.filter(filter, "-created_date", 500),
        base44.entities.Class.filter(filter, "-created_date", 100),
        base44.entities.Subject.filter(filter, "-created_date", 100),
        base44.entities.AppAccess.filter({ ...filter, role: "teacher" }, "-created_date", 100),
        base44.entities.Grade.filter(filter, "-created_date", 1000),
        base44.entities.Absence.filter(filter, "-created_date", 200),
      ]);

      const byStudent = {};
      grades.forEach(g => {
        if (!byStudent[g.student_id]) byStudent[g.student_id] = [];
        byStudent[g.student_id].push(g.score);
      });
      const weakStudents = Object.values(byStudent).filter(scores => {
        const a = scores.reduce((s, v) => s + v, 0) / scores.length;
        return a < 10;
      }).length;

      const unjustifiedAbsences = absences.filter(a => a.type === "absent").length;

      setStats({
        students: students.length,
        classes: classes.length,
        subjects: subjects.length,
        teachers: teachers.length,
        grades: grades.length,
        weakStudents,
        decliningClasses: Math.max(0, Math.floor(classes.length * 0.1)),
        unjustifiedAbsences,
      });
      setLoading(false);
    }
    loadStats();
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen" style={{ background: "#F8FAFC" }}>

      {/* ════════════════════════════════════════════════
          MOBILE LAYOUT — dark premium style
          ════════════════════════════════════════════════ */}
      <div
        className="lg:hidden min-h-screen"
        style={{ background: "linear-gradient(160deg, #1a2340 0%, #0f172a 50%, #111827 100%)" }}
      >
        {/* Header dark */}
        <MobileHeader />

        <div className="px-4 space-y-5 pb-8">

          {/* Alertes */}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest mb-2.5" style={{ color: "rgba(255,255,255,0.35)" }}>
              Alertes & Notifications
            </p>
            <MobileAlertCards stats={stats} />
          </div>

          {/* KPIs */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <p className="text-[10px] font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.35)" }}>
                Tableau de bord
              </p>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold" style={{ background: "rgba(96,165,250,0.15)", color: "#60a5fa" }}>
                Aujourd'hui
              </span>
            </div>
            <MobileKpiGrid stats={stats} />
          </div>

          {/* Activité récente */}
          <div
            className="rounded-2xl px-4 py-4"
            style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <p className="text-sm font-bold text-white mb-3">Activité récente</p>
            <RecentActivities compact />
          </div>

          {/* Graphique */}
          <div
            className="rounded-2xl px-4 py-4"
            style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <p className="text-sm font-bold text-white mb-1">Évolution des moyennes</p>
            <p className="text-xs mb-3" style={{ color: "rgba(255,255,255,0.4)" }}>Par trimestre</p>
            <EvolutionChart />
          </div>

          {/* Actions rapides */}
          <MobileQuickActions />

          <div className="h-6" />
        </div>
      </div>


      {/* ════════════════════════════════════════════════
          DESKTOP LAYOUT — identique à avant
          ════════════════════════════════════════════════ */}
      <div className="hidden lg:block space-y-6">

        {/* Cloud Header Banner */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 px-6 py-5 shadow-lg">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-3 animate-cloud-slow opacity-20" style={{ left: "-10%" }}>
              <svg width="160" height="60" viewBox="0 0 160 60" fill="white">
                <ellipse cx="80" cy="45" rx="75" ry="18"/>
                <ellipse cx="55" cy="35" rx="40" ry="22"/>
                <ellipse cx="95" cy="30" rx="45" ry="25"/>
                <ellipse cx="120" cy="38" rx="32" ry="18"/>
              </svg>
            </div>
            <div className="absolute top-8 animate-cloud-medium opacity-15" style={{ left: "-5%" }}>
              <svg width="120" height="45" viewBox="0 0 120 45" fill="white">
                <ellipse cx="60" cy="35" rx="55" ry="13"/>
                <ellipse cx="40" cy="26" rx="30" ry="17"/>
                <ellipse cx="75" cy="22" rx="34" ry="19"/>
                <ellipse cx="95" cy="28" rx="24" ry="14"/>
              </svg>
            </div>
            <div className="absolute top-5 animate-cloud-reverse opacity-20" style={{ right: "-15%" }}>
              <svg width="180" height="65" viewBox="0 0 180 65" fill="white">
                <ellipse cx="90" cy="50" rx="82" ry="18"/>
                <ellipse cx="60" cy="38" rx="44" ry="24"/>
                <ellipse cx="110" cy="32" rx="50" ry="27"/>
                <ellipse cx="140" cy="42" rx="36" ry="20"/>
              </svg>
            </div>
          </div>
          <div className="relative flex items-center justify-between gap-3">
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl font-bold text-white">
                {greeting}, {user?.full_name?.split(" ")[0] || "Administrateur"} 👋
              </h1>
              <p className="text-sm text-blue-200 mt-0.5 truncate">
                {schoolName || "Voici un aperçu de votre établissement"}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <div className="hidden sm:flex items-center gap-2 bg-white/20 backdrop-blur border border-white/30 rounded-xl px-3 py-2 min-w-[200px]">
                <Search className="h-4 w-4 text-white/70 shrink-0" />
                <input className="flex-1 text-sm bg-transparent outline-none placeholder:text-white/60 text-white" placeholder="Rechercher…" readOnly />
              </div>
              <button className="relative w-9 h-9 bg-white/20 backdrop-blur border border-white/30 rounded-xl flex items-center justify-center hover:bg-white/30 transition-all">
                <Bell className="h-4 w-4 text-white" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-400 rounded-full border border-white" />
              </button>
              <div className="flex items-center gap-1.5 bg-white/20 backdrop-blur border border-white/30 rounded-xl px-2.5 py-2">
                <span className="text-sm font-medium text-white">{currentYear}</span>
              </div>
            </div>
          </div>
        </div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <AlertCards stats={stats} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <KpiCards stats={stats} />
        </motion.div>

        <div className="grid grid-cols-3 gap-5">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-gray-900">Évolution des moyennes générales</h3>
                <p className="text-xs text-gray-400 mt-0.5">Par trimestre / semestre</p>
              </div>
              <select className="text-xs border border-gray-200 rounded-lg px-2 py-1.5 text-gray-600 bg-white focus:outline-none">
                <option>Par trimestre</option>
                <option>Par semestre</option>
              </select>
            </div>
            <EvolutionChart />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
            <RecentActivities />
          </motion.div>
        </div>

        <div className="grid grid-cols-3 gap-5">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <StudentRankings />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-gray-900">Moyenne par classe</h3>
                <p className="text-xs text-gray-400">Toutes classes</p>
              </div>
            </div>
            <ClassAveragesChart />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-gray-900">Performances par matière</h3>
                <p className="text-xs text-gray-400">Classement des moyennes</p>
              </div>
            </div>
            <SubjectPerformance />
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }}>
          <QuickActions />
        </motion.div>
      </div>

    </div>
  );
}