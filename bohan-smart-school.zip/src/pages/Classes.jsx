import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Wand2, X, CheckCircle, Loader2 } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { getSchoolId } from "../hooks/useSchool";
import { Button } from "@/components/ui/button";
import PageHeader from "../components/PageHeader";
import ClassCard from "../components/classes/ClassCard";
import ClassForm from "../components/classes/ClassForm";
import ClassDetail from "../components/classes/ClassDetail";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Classes() {
  const [classes, setClasses] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingClass, setEditingClass] = useState(null);
  const [viewingClass, setViewingClass] = useState(null);
  const [subjects, setSubjects] = useState([]);
  const [filterLevel, setFilterLevel] = useState("all");
  const [showGenModal, setShowGenModal] = useState(false);
  const [genYear, setGenYear] = useState(`${new Date().getFullYear()}-${new Date().getFullYear() + 1}`);
  const [genDivisions, setGenDivisions] = useState("A");
  const [genLoading, setGenLoading] = useState(false);
  const [genDone, setGenDone] = useState(false);

  const LEVELS = [
    "6ème", "5ème", "4ème", "3ème", "2nde",
    "1ère A", "1ère C", "1ère D",
    "Tle A", "Tle C", "Tle D",
  ];

  async function loadData() {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const [classList, studentList, subjectList] = await Promise.all([
      base44.entities.Class.filter(filter),
      base44.entities.Student.filter(filter),
      base44.entities.Subject.filter(filter),
    ]);
    setClasses(classList);
    setStudents(studentList);
    setSubjects(subjectList);
    setLoading(false);
  }

  useEffect(() => { loadData(); }, []);

  async function handleGenerateClasses() {
    setGenLoading(true);
    const schoolId = getSchoolId();
    const divisions = genDivisions.split(",").map(d => d.trim().toUpperCase()).filter(Boolean);
    const lyceePattern = /^(1ère|Tle)/;
    const classesToCreate = [];
    for (const level of LEVELS) {
      if (lyceePattern.test(level)) {
        classesToCreate.push({ school_id: schoolId, name: level, level, division: "1", academic_year: genYear });
      } else {
        for (const div of divisions) {
          classesToCreate.push({ school_id: schoolId, name: `${level}-${div}`, level, division: div, academic_year: genYear });
        }
      }
    }
    await base44.entities.Class.bulkCreate(classesToCreate);
    await loadData();
    setGenLoading(false);
    setGenDone(true);
  }

  async function handleSave(data) {
    if (editingClass) {
      await base44.entities.Class.update(editingClass.id, data);
    } else {
      const schoolId = getSchoolId();
      await base44.entities.Class.create({ ...data, school_id: schoolId });
    }
    setShowForm(false);
    setEditingClass(null);
    loadData();
  }

  async function handleDelete(id) {
    await base44.entities.Class.delete(id);
    loadData();
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const filteredClasses = filterLevel === "all" ? classes : classes.filter((c) => c.level === filterLevel);

  // Group by level for display
  const grouped = LEVELS.reduce((acc, level) => {
    const levelClasses = filteredClasses.filter((c) => c.level === level);
    if (levelClasses.length > 0) acc[level] = levelClasses;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <PageHeader title="Classes" subtitle={`${classes.length} classe${classes.length !== 1 ? 's' : ''} créée${classes.length !== 1 ? 's' : ''}`}>
        <Select value={filterLevel} onValueChange={setFilterLevel}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les niveaux</SelectItem>
            {LEVELS.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button variant="outline" onClick={() => { setShowGenModal(true); setGenDone(false); }} className="gap-2 border-purple-200 text-purple-700 hover:bg-purple-50">
          <Wand2 className="h-4 w-4" />
          Générer les classes
        </Button>
        <Button onClick={() => { setEditingClass(null); setShowForm(true); }} className="gap-2">
          <Plus className="h-4 w-4" />
          Nouvelle classe
        </Button>
      </PageHeader>

      {showForm && (
        <ClassForm
          classData={editingClass}
          onSave={handleSave}
          onCancel={() => { setShowForm(false); setEditingClass(null); }}
        />
      )}

      {Object.keys(grouped).length === 0 && !showForm ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <p className="text-muted-foreground">Aucune classe créée. Commencez par ajouter une classe.</p>
        </div>
      ) : (
        Object.entries(grouped).map(([level, levelClasses]) => (
          <div key={level}>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block"></span>
              {level} <span className="font-normal">({levelClasses.length} classe{levelClasses.length !== 1 ? 's' : ''})</span>
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {levelClasses.map((c) => {
                const studentCount = students.filter((s) => s.class_id === c.id).length;
                return (
                  <ClassCard
                    key={c.id}
                    classData={c}
                    studentCount={studentCount}
                    onEdit={() => { setEditingClass(c); setShowForm(true); }}
                    onDelete={() => handleDelete(c.id)}
                    onView={() => setViewingClass(c)}
                  />
                );
              })}
            </div>
          </div>
        ))
      )}

      {/* Generation modal */}
      {showGenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4" onClick={() => setShowGenModal(false)}>
          <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md p-6 space-y-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-foreground">Générer les classes standard</h3>
              <Button variant="ghost" size="icon" onClick={() => setShowGenModal(false)}><X className="h-4 w-4" /></Button>
            </div>
            {genDone ? (
              <div className="flex flex-col items-center gap-3 py-6">
                <CheckCircle className="h-12 w-12 text-green-500" />
                <p className="font-semibold text-foreground">Classes générées avec succès !</p>
                <p className="text-xs text-muted-foreground text-center">Toutes les classes ont été créées pour l'année {genYear}.</p>
                <Button onClick={() => setShowGenModal(false)}>Fermer</Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <Label>Année scolaire</Label>
                  <Input className="mt-1" value={genYear} onChange={e => setGenYear(e.target.value)} placeholder="Ex: 2024-2025" />
                </div>
                <div>
                  <Label>Divisions (séparées par virgule)</Label>
                  <Input className="mt-1" value={genDivisions} onChange={e => setGenDivisions(e.target.value)} placeholder="Ex: A, B, C" />
                  <p className="text-xs text-muted-foreground mt-1">Les niveaux lycée (1ère A/C/D, Tle A/C/D) ont déjà leurs séries intégrées.</p>
                </div>
                <div className="bg-muted/50 rounded-lg p-3">
                  <p className="text-xs font-semibold mb-1">Niveaux générés :</p>
                  <p className="text-xs text-muted-foreground">{LEVELS.join(" • ")}</p>
                </div>
                <div className="flex gap-3 pt-2">
                  <Button variant="outline" className="flex-1" onClick={() => setShowGenModal(false)}>Annuler</Button>
                  <Button className="flex-1 gap-2 bg-purple-600 hover:bg-purple-700" onClick={handleGenerateClasses} disabled={genLoading}>
                    {genLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
                    {genLoading ? "Création…" : "Générer"}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {viewingClass && (
        <ClassDetail
          classData={viewingClass}
          students={students}
          subjects={subjects}
          onClose={() => setViewingClass(null)}
          onEdit={(c) => { setViewingClass(null); setEditingClass(c); setShowForm(true); }}
        />
      )}
    </div>
  );
}