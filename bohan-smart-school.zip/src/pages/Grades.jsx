import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getVerifiedRole } from "@/components/AccessGate";
import { getSchoolId } from "../hooks/useSchool";
import { Plus, ClipboardList, AlertCircle } from "lucide-react";
import { usePeriodType } from "@/hooks/usePeriodType";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PageHeader from "../components/PageHeader";
import ExamForm from "../components/grades/ExamForm";
import ExamList from "../components/grades/ExamList";
import GradeTable from "../components/grades/GradeTable";
import GradeEntryModal from "../components/grades/GradeEntryModal";
import CorrectionModal from "../components/grades/CorrectionModal";

const TABS = [
  { id: "exams", label: "Examens" },
  { id: "grades", label: "Notes" },
  { id: "corrections", label: "Corrections" },
];

export default function Grades() {
  const { user } = useAuth();
  const effectiveRole = user?.role === 'admin' ? 'admin' : (getVerifiedRole() || user?.role);
  const isTeacher = effectiveRole === 'teacher';
  const { periods, periodLabel } = usePeriodType();
  const [tab, setTab] = useState("exams");
  const [exams, setExams] = useState([]);
  const [grades, setGrades] = useState([]);
  const [students, setStudents] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [classes, setClasses] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showExamForm, setShowExamForm] = useState(false);
  const [editingExam, setEditingExam] = useState(null);
  const [selectedExam, setSelectedExam] = useState(null);
  const [correctionGrade, setCorrectionGrade] = useState(null);
  const [filterClass, setFilterClass] = useState("all");
  const [filterTrimester, setFilterTrimester] = useState("all");

  async function loadData() {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const [examList, gradeList, studentList, subjectList, classList, me, asgn] = await Promise.all([
      base44.entities.Exam.filter(filter, "-created_date"),
      base44.entities.Grade.filter(filter, "-created_date"),
      base44.entities.Student.filter(filter),
      base44.entities.Subject.filter(filter),
      base44.entities.Class.filter(filter),
      base44.auth.me(),
      base44.entities.TeacherAssignment.filter(filter),
    ]);
    setExams(examList);
    setGrades(gradeList);
    setStudents(studentList);
    setSubjects(subjectList);
    setClasses(classList);
    setCurrentUser(me);
    setAssignments(asgn);
    setLoading(false);
  }

  useEffect(() => { loadData(); }, []);

  // Exam CRUD
  async function handleSaveExam(data) {
    if (editingExam) {
      await base44.entities.Exam.update(editingExam.id, data);
    } else {
      const schoolId = getSchoolId();
      await base44.entities.Exam.create({ ...data, school_id: schoolId });
    }
    setShowExamForm(false);
    setEditingExam(null);
    loadData();
  }

  async function handleLockExam(exam) {
    await base44.entities.Exam.update(exam.id, { is_locked: true, locked_date: new Date().toISOString() });
    loadData();
  }

  async function handleDeleteExam(id) {
    await base44.entities.Exam.delete(id);
    loadData();
  }

  // Teacher scope: only their assigned class+subject combinations
  const myAssignments = isTeacher
    ? assignments.filter((a) => a.teacher_email?.toLowerCase() === currentUser?.email?.toLowerCase())
    : [];
  const teacherSubjectIds = isTeacher ? new Set(myAssignments.map((a) => a.subject_id)) : null;
  const teacherClassIds = isTeacher ? new Set(myAssignments.map((a) => a.class_id)) : null;

  const visibleExams = isTeacher ? exams.filter((e) => teacherSubjectIds?.has(e.subject_id)) : exams;
  const visibleGrades = isTeacher ? grades.filter((g) => teacherSubjectIds?.has(g.subject_id)) : grades;
  const visibleClasses = isTeacher ? classes.filter((c) => teacherClassIds?.has(c.id)) : classes;
  const visibleStudents = isTeacher ? students.filter((s) => teacherClassIds?.has(s.class_id)) : students;

  // Grade filtering
  const filteredGrades = visibleGrades.filter((g) => {
    if (filterClass !== "all" && g.class_id !== filterClass) return false;
    if (filterTrimester !== "all" && g.trimester !== filterTrimester) return false;
    return true;
  });

  // Corrections pending
  const corrections = visibleGrades.filter((g) => g.correction_requested);

  const studentMap = {};
  students.forEach((s) => (studentMap[s.id] = `${s.first_name} ${s.last_name}`));
  const subjectMap = {};
  subjects.forEach((s) => (subjectMap[s.id] = s.name));

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Examens & Notes" subtitle={`${visibleExams.length} examen${visibleExams.length !== 1 ? 's' : ''} • ${visibleGrades.length} note${visibleGrades.length !== 1 ? 's' : ''}`}>
        {tab === "exams" && !isTeacher && (
          <Button onClick={() => { setEditingExam(null); setShowExamForm(true); }} className="gap-2">
            <Plus className="h-4 w-4" /> Créer un examen
          </Button>
        )}
      </PageHeader>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 text-sm font-medium transition-colors relative ${
              tab === t.id
                ? "text-primary border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
            {t.id === "corrections" && corrections.length > 0 && (
              <span className="ml-2 inline-flex items-center justify-center w-5 h-5 rounded-full bg-destructive text-destructive-foreground text-xs font-bold">
                {corrections.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Tab: Examens */}
      {tab === "exams" && (
        <>
          {showExamForm && (
            <ExamForm
              exam={editingExam}
              subjects={subjects}
              classes={visibleClasses}
              onSave={handleSaveExam}
              onCancel={() => { setShowExamForm(false); setEditingExam(null); }}
            />
          )}
          <ExamList
            exams={visibleExams}
            subjects={subjects}
            classes={visibleClasses}
            onEdit={(ex) => { setEditingExam(ex); setShowExamForm(true); }}
            onDelete={handleDeleteExam}
            onLock={handleLockExam}
            onSelectExam={setSelectedExam}
          />
        </>
      )}

      {/* Tab: Notes */}
      {tab === "grades" && (
        <>
          <div className="flex flex-wrap gap-3">
            <Select value={filterClass} onValueChange={setFilterClass}>
              <SelectTrigger className="w-48"><SelectValue placeholder="Toutes les classes" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les classes</SelectItem>
                {visibleClasses.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterTrimester} onValueChange={setFilterTrimester}>
              <SelectTrigger className="w-48"><SelectValue placeholder={`Tous les ${periodLabel}s`} /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les {periodLabel}s</SelectItem>
                {periods.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <GradeTable
            grades={filteredGrades}
            students={visibleStudents}
            subjects={subjects}
            classes={visibleClasses}
            onRequestCorrection={(g) => setCorrectionGrade(g)}
            currentUser={currentUser}
          />
        </>
      )}

      {/* Tab: Corrections */}
      {tab === "corrections" && (
        <div className="space-y-3">
          {corrections.length === 0 ? (
            <div className="bg-card rounded-xl border border-border p-12 text-center">
              <AlertCircle className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground">Aucune demande de correction en cours</p>
            </div>
          ) : (
            <div className="bg-card rounded-xl border border-border overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/50 border-b border-border">
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Élève</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Matière</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Note</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Motif</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Statut</th>
                    <th className="text-right py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {corrections.map((g) => {
                    const statusColors = {
                      en_attente_educateur: "bg-yellow-100 text-yellow-700",
                      en_attente_directeur: "bg-blue-100 text-blue-700",
                      approuvee: "bg-green-100 text-green-700",
                      rejetee: "bg-red-100 text-red-700",
                    };
                    const statusLabels = {
                      en_attente_educateur: "Attente éducateur",
                      en_attente_directeur: "Attente directeur",
                      approuvee: "Approuvée",
                      rejetee: "Rejetée",
                    };
                    return (
                      <tr key={g.id} className="border-b border-border/50 hover:bg-muted/20">
                        <td className="py-3 px-4 font-medium">{studentMap[g.student_id] || "—"}</td>
                        <td className="py-3 px-4 text-muted-foreground">{subjectMap[g.subject_id] || "—"}</td>
                        <td className="py-3 px-4">
                          <span className="font-semibold">{g.score}/{g.max_score}</span>
                          {g.corrected_score !== undefined && g.corrected_score !== null && (
                            <span className="ml-2 text-green-600 text-xs">→ {g.corrected_score}</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-muted-foreground text-xs max-w-xs truncate">{g.correction_reason || "—"}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[g.correction_status] || "bg-gray-100 text-gray-600"}`}>
                            {statusLabels[g.correction_status] || "En attente"}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => setCorrectionGrade(g)}>
                            Traiter
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Modals */}
      {selectedExam && (
        <GradeEntryModal
          exam={selectedExam}
          students={visibleStudents}
          subjects={subjects}
          classes={visibleClasses}
          onClose={() => setSelectedExam(null)}
          onSaved={loadData}
        />
      )}
      {correctionGrade && (
        <CorrectionModal
          grade={correctionGrade}
          studentName={studentMap[correctionGrade.student_id] || "—"}
          subjectName={subjectMap[correctionGrade.subject_id] || "—"}
          currentUser={currentUser}
          onClose={() => setCorrectionGrade(null)}
          onSaved={loadData}
        />
      )}
    </div>
  );
}