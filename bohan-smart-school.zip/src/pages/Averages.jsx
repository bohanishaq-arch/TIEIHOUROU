import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Trophy, TrendingUp, BookOpen, Users, ChevronDown, ChevronUp } from "lucide-react";
import { getSchoolId } from "../hooks/useSchool";
import PageHeader from "../components/PageHeader";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePeriodType } from "@/hooks/usePeriodType";

function scoreColor(avg) {
  if (avg === null || avg === undefined) return "text-muted-foreground";
  if (avg >= 14) return "text-green-600";
  if (avg >= 10) return "text-yellow-600";
  return "text-red-600";
}

function scoreBg(avg) {
  if (avg === null || avg === undefined) return "bg-muted text-muted-foreground";
  if (avg >= 14) return "bg-green-100 text-green-700";
  if (avg >= 10) return "bg-yellow-100 text-yellow-700";
  return "bg-red-100 text-red-700";
}

function avg(scores) {
  if (!scores.length) return null;
  return scores.reduce((a, b) => a + b, 0) / scores.length;
}

function weightedAvg(subjectScores) {
  // subjectScores: [{score, coefficient}]
  if (!subjectScores.length) return null;
  const totalCoef = subjectScores.reduce((a, s) => a + s.coefficient, 0);
  if (totalCoef === 0) return null;
  const sum = subjectScores.reduce((a, s) => a + s.score * s.coefficient, 0);
  return sum / totalCoef;
}

export default function Averages() {
  const { periods, periodLabel } = usePeriodType();
  const [grades, setGrades] = useState([]);
  const [students, setStudents] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);

  const [tab, setTab] = useState("class"); // class | level
  const [filterClass, setFilterClass] = useState("all");
  const [filterTrimester, setFilterTrimester] = useState("all");
  const [filterLevel, setFilterLevel] = useState("all");
  const [sortBy, setSortBy] = useState("rank"); // rank | name
  const [expandedStudent, setExpandedStudent] = useState(null);

  useEffect(() => {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    Promise.all([
      base44.entities.Grade.filter(filter),
      base44.entities.Student.filter(filter),
      base44.entities.Subject.filter(filter),
      base44.entities.Class.filter(filter),
    ]).then(([g, st, su, cl]) => {
      setGrades(g);
      setStudents(st);
      setSubjects(su);
      setClasses(cl);
      setLoading(false);
    });
  }, []);

  const subjectMap = {};
  subjects.forEach((s) => (subjectMap[s.id] = s));
  const classMap = {};
  classes.forEach((c) => (classMap[c.id] = c));

  const levels = [...new Set(classes.map((c) => c.level))].sort();

  // Compute per-student averages
  function computeStudentData(studentList, gradeList) {
    return studentList.map((student) => {
      const studentGrades = gradeList.filter((g) => g.student_id === student.id);

      // Per subject averages
      const subjectAverages = {};
      const subjectIds = [...new Set(studentGrades.map((g) => g.subject_id))];
      subjectIds.forEach((sid) => {
        const sGrades = studentGrades.filter((g) => g.subject_id === sid);
        subjectAverages[sid] = avg(sGrades.map((g) => g.score));
      });

      // Per period weighted avg
      const trimesterAverages = {};
      periods.forEach((t) => {
        const tGrades = studentGrades.filter((g) => g.trimester === t);
        const subjectScores = subjectIds.map((sid) => {
          const sGrades = tGrades.filter((g) => g.subject_id === sid);
          if (!sGrades.length) return null;
          const subject = subjectMap[sid];
          return { score: avg(sGrades.map((g) => g.score)), coefficient: subject?.coefficient || 1 };
        }).filter(Boolean);
        trimesterAverages[t] = weightedAvg(subjectScores);
      });

      // Annual average = (T1 + T2×2) / 3 pour semestre, (T1 + T2 + T3×2) / 4 pour trimestre
      const trimVals = periods.map((t) => trimesterAverages[t]);
      let annualAvg = null;
      if (periods.length === 2) {
        // Semestre : (S1 + S2×2) / 3
        const [s1, s2] = trimVals;
        if (s1 !== null && s1 !== undefined && s2 !== null && s2 !== undefined) {
          annualAvg = (s1 + s2 * 2) / 3;
        } else if (s2 !== null && s2 !== undefined) {
          annualAvg = s2;
        } else if (s1 !== null && s1 !== undefined) {
          annualAvg = s1;
        }
      } else if (periods.length === 3) {
        // Trimestre : (T1 + T2 + T3×2) / 4 — le dernier trimestre est coefficient 2
        const [t1, t2, t3] = trimVals;
        if (t1 !== null && t1 !== undefined && t2 !== null && t2 !== undefined && t3 !== null && t3 !== undefined) {
          annualAvg = (t1 + t2 + t3 * 2) / 4;
        } else {
          // Calcul partiel avec les périodes disponibles
          const available = trimVals.filter((v) => v !== null && v !== undefined);
          annualAvg = available.length > 0 ? available.reduce((a, b) => a + b, 0) / available.length : null;
        }
      } else {
        const available = trimVals.filter((v) => v !== null && v !== undefined);
        annualAvg = available.length > 0 ? available.reduce((a, b) => a + b, 0) / available.length : null;
      }

      return {
        student,
        subjectAverages,
        trimesterAverages,
        annualAvg,
        class: classMap[student.class_id],
      };
    }).sort((a, b) => (b.annualAvg ?? -1) - (a.annualAvg ?? -1));
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  // Filter students
  let filteredGrades = grades;
  if (filterTrimester !== "all") filteredGrades = grades.filter((g) => g.trimester === filterTrimester);

  const classStudents = filterClass !== "all"
    ? students.filter((s) => s.class_id === filterClass)
    : students;

  const levelStudents = filterLevel !== "all"
    ? students.filter((s) => classMap[s.class_id]?.level === filterLevel)
    : students;

  const classData = computeStudentData(classStudents, filteredGrades);
  const levelData = computeStudentData(levelStudents, filteredGrades);

  const displayData = tab === "class" ? classData : levelData;

  // Subject list for expanded view
  const subjectList = subjects.filter((s) => {
    if (filterClass !== "all") {
      const cls = classes.find((c) => c.id === filterClass);
      return cls && (s.level === cls.level || s.level === "Tous" || !s.level);
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Moyennes & Classements"
        subtitle="Calcul automatique des moyennes par matière, trimestre et année"
      />

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border">
        {[
          { id: "class", label: "Classement par classe" },
          { id: "level", label: "Classement par niveau" },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 text-sm font-medium transition-colors relative ${
              tab === t.id ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        {tab === "class" && (
          <Select value={filterClass} onValueChange={setFilterClass}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Toutes les classes" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes les classes</SelectItem>
              {classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        )}
        {tab === "level" && (
          <Select value={filterLevel} onValueChange={setFilterLevel}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Tous les niveaux" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les niveaux</SelectItem>
              {levels.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
        )}
        <Select value={filterTrimester} onValueChange={setFilterTrimester}>
          <SelectTrigger className="w-48"><SelectValue placeholder={`Tous les ${periodLabel}s`} /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toute l'année</SelectItem>
            {periods.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Rankings table */}
      {displayData.length === 0 ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <Users className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">Aucun élève trouvé</p>
        </div>
      ) : (
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/50 border-b border-border">
                <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground uppercase w-12">Rang</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Élève</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Classe</th>
                {filterTrimester === "all" ? (
                  <>
                    {periods.map((p, i) => (
                      <th key={p} className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">P{i+1}</th>
                    ))}
                    <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Moy. annuelle</th>
                  </>
                ) : (
                  <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Moyenne {filterTrimester}</th>
                )}
                <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground uppercase w-10"></th>
              </tr>
            </thead>
            <tbody>
              {displayData.map((item, idx) => {
                const isExpanded = expandedStudent === item.student.id;
                const displayAvg = filterTrimester === "all"
                  ? item.annualAvg
                  : item.trimesterAverages[filterTrimester];

                return (
                  <>
                    <tr
                      key={item.student.id}
                      className={`border-b border-border/50 hover:bg-muted/20 transition-colors cursor-pointer ${isExpanded ? "bg-accent/30" : ""}`}
                      onClick={() => setExpandedStudent(isExpanded ? null : item.student.id)}
                    >
                      <td className="py-3 px-4 text-center">
                        {idx === 0 ? <Trophy className="h-4 w-4 text-yellow-500 mx-auto" /> :
                         idx === 1 ? <Trophy className="h-4 w-4 text-gray-400 mx-auto" /> :
                         idx === 2 ? <Trophy className="h-4 w-4 text-amber-600 mx-auto" /> :
                         <span className="text-muted-foreground font-mono text-xs">{idx + 1}</span>}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-medium text-foreground">{item.student.first_name} {item.student.last_name}</p>
                        <p className="text-xs text-muted-foreground font-mono">{item.student.student_number}</p>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground text-sm">{item.class?.name || "—"}</td>
                      {filterTrimester === "all" ? (
                         <>
                           {periods.map((p) => (
                             <td key={p} className="py-3 px-4 text-center">
                               {item.trimesterAverages[p] !== null && item.trimesterAverages[p] !== undefined
                                 ? <span className={`text-sm font-semibold ${scoreColor(item.trimesterAverages[p])}`}>{item.trimesterAverages[p].toFixed(2)}</span>
                                 : <span className="text-muted-foreground text-xs">—</span>}
                             </td>
                           ))}
                           <td className="py-3 px-4 text-center">
                            {item.annualAvg !== null && item.annualAvg !== undefined
                              ? <span className={`inline-flex px-2.5 py-1 rounded-full text-sm font-bold ${scoreBg(item.annualAvg)}`}>{item.annualAvg.toFixed(2)}</span>
                              : <span className="text-muted-foreground text-xs">—</span>}
                          </td>
                        </>
                      ) : (
                        <td className="py-3 px-4 text-center">
                          {displayAvg !== null && displayAvg !== undefined
                            ? <span className={`inline-flex px-2.5 py-1 rounded-full text-sm font-bold ${scoreBg(displayAvg)}`}>{displayAvg.toFixed(2)}</span>
                            : <span className="text-muted-foreground text-xs">—</span>}
                        </td>
                      )}
                      <td className="py-3 px-4 text-center text-muted-foreground">
                        {isExpanded ? <ChevronUp className="h-4 w-4 mx-auto" /> : <ChevronDown className="h-4 w-4 mx-auto" />}
                      </td>
                    </tr>

                    {/* Expanded: per-subject averages */}
                    {isExpanded && (
                      <tr key={`${item.student.id}-detail`} className="bg-accent/20 border-b border-border">
                        <td colSpan={8} className="py-4 px-8">
                          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-2">
                            <BookOpen className="h-3.5 w-3.5" /> Moyennes par matière
                          </p>
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                            {subjectList.map((sub) => {
                              const subAvg = item.subjectAverages[sub.id];
                              if (subAvg === undefined || subAvg === null) return null;
                              return (
                                <div key={sub.id} className="bg-card rounded-lg p-3 border border-border/50">
                                  <p className="text-xs text-muted-foreground truncate">{sub.name}</p>
                                  <p className="text-xs text-muted-foreground mb-1">Coeff. {sub.coefficient}</p>
                                  <span className={`text-base font-bold ${scoreColor(subAvg)}`}>{subAvg.toFixed(2)}</span>
                                  <span className="text-xs text-muted-foreground">/20</span>
                                </div>
                              );
                            })}
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}