import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Search } from "lucide-react";
import { Label } from "@/components/ui/label";
import { getSchoolId } from "../hooks/useSchool";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import PageHeader from "../components/PageHeader";
import StudentTable from "../components/students/StudentTable";
import StudentForm from "../components/students/StudentForm";
import StudentDetail from "../components/students/StudentDetail";

export default function Students() {
  const [students, setStudents] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [viewingStudent, setViewingStudent] = useState(null);


  async function loadData() {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const studentList = await base44.entities.Student.filter(filter, "-created_date");
    const classList = await base44.entities.Class.filter(filter);
    setStudents(studentList);
    setClasses(classList);
    setLoading(false);
  }

  useEffect(() => {
    loadData();
  }, []);

  const filtered = students.filter(
    (s) =>
      s.first_name?.toLowerCase().includes(search.toLowerCase()) ||
      s.last_name?.toLowerCase().includes(search.toLowerCase()) ||
      s.student_number?.toLowerCase().includes(search.toLowerCase())
  );



  async function handleSave(data) {
    if (editingStudent) {
      await base44.entities.Student.update(editingStudent.id, data);
    } else {
      const schoolId = getSchoolId();
      await base44.entities.Student.create({ ...data, school_id: schoolId });
    }
    setShowForm(false);
    setEditingStudent(null);
    loadData();
  }

  async function handleDelete(id) {
    try {
      await base44.entities.Student.delete(id);
    } catch (e) {
      // Student already deleted or not found — just refresh the list
    }
    loadData();
  }

  function handleEdit(student) {
    setEditingStudent(student);
    setViewingStudent(null);
    setShowForm(true);
  }

  function handleView(student) {
    setViewingStudent(student);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Élèves" subtitle={`${students.length} élèves inscrits`}>
        <Button onClick={() => { setEditingStudent(null); setShowForm(true); }} className="gap-2">
          <Plus className="h-4 w-4" />
          Nouvel élève
        </Button>
      </PageHeader>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Rechercher un élève..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {showForm && (
        <StudentForm
          student={editingStudent}
          classes={classes}
          onSave={handleSave}
          onCancel={() => { setShowForm(false); setEditingStudent(null); }}
          totalStudents={students.length}
        />
      )}

      <StudentTable
        students={filtered}
        classes={classes}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onView={handleView}
      />


      {viewingStudent && (
        <StudentDetail
          student={viewingStudent}
          classes={classes}
          onClose={() => setViewingStudent(null)}
          onEdit={(s) => { setViewingStudent(null); handleEdit(s); }}
        />
      )}
    </div>
  );
}