import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../hooks/useSchool";
import { Shield, Users, AlertTriangle, Clock, UserX, Send, X, ClipboardList, Star, ShieldAlert } from "lucide-react";
import ProfileSettings from "@/components/ProfileSettings";
import AbsenceManager from "@/components/educator/AbsenceManager";
import IncidentManager from "@/components/educator/IncidentManager";
import EduReportForm from "@/components/educator/EduReportForm";
import AttendanceReview from "@/components/educator/AttendanceReview";
import ConductFaultManager from "@/components/educator/ConductFaultManager";
import ConductScoreViewer from "@/components/educator/ConductScoreViewer";

const TABS = [
  { id: "attendance",    label: "Pointages prof",       icon: ClipboardList },
  { id: "absences",      label: "Absences & Retards",   icon: UserX },
  { id: "incidents",     label: "Discipline",            icon: AlertTriangle },
  { id: "conduct",       label: "Notes de conduite",     icon: Star },
  { id: "faults",        label: "Fautes disciplinaires", icon: ShieldAlert },
  { id: "reports",       label: "Rapports proviseur",    icon: Send },
];

export default function EducateurDashboard() {
  const { user } = useAuth();
  const [activeModal, setActiveModal] = useState(null);
  const [data, setData] = useState({ students: [], classes: [], absences: [], incidents: [] });
  const [loading, setLoading] = useState(true);
  const [eduProfile, setEduProfile] = useState(null);

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const f = schoolId ? { school_id: schoolId } : {};
      const today = new Date().toISOString().slice(0, 10);
      const [students, classes, absences, incidents, accesses] = await Promise.all([
        base44.entities.Student.filter(f),
        base44.entities.Class.filter(f),
        base44.entities.Absence.filter(f, "-date", 200),
        base44.entities.Incident.filter(f, "-date", 100),
        base44.entities.AppAccess.filter({ user_email: user?.email?.toLowerCase() }),
      ]);
      const profile = accesses.find(a => a.role === "educator" && a.is_active !== false);
      setEduProfile(profile || null);
      setData({ students, classes, absences, incidents });
      setLoading(false);
    }
    load();
  }, []);

  const today = new Date().toISOString().slice(0, 10);
  const todayAbsences = data.absences.filter(a => a.date === today && a.type === "absent");
  const todayRetards = data.absences.filter(a => a.date === today && a.type === "retard");
  const openIncidents = data.incidents.filter(i => i.status === "signalé");

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-teal-200 border-t-teal-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-teal-600 via-teal-700 to-emerald-800 p-6 text-white shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/4" />
        <div className="relative flex items-center gap-4">
          <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center shrink-0">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-teal-100 text-sm font-medium">Espace Éducateur</p>
            <h1 className="text-2xl font-bold">{eduProfile?.full_name || user?.full_name || "Éducateur"}</h1>
            <p className="text-teal-200 text-sm mt-0.5">{eduProfile?.school_name || user?.email}</p>
            {eduProfile && <p className="text-teal-300 text-xs font-mono mt-0.5">{eduProfile.access_id}</p>}
          </div>
          <ProfileSettings
            currentName={eduProfile?.full_name || user?.full_name || ""}
            onSaved={(name) => setEduProfile(prev => ({ ...prev, full_name: name }))}
          />
          <div className="ml-auto hidden sm:flex gap-4">
            <StatBadge value={data.students.length} label="Élèves" />
            <div className="w-px bg-white/20" />
            <StatBadge value={data.classes.length} label="Classes" />
            <div className="w-px bg-white/20" />
            <StatBadge value={openIncidents.length} label="Incidents" />
          </div>
        </div>
      </div>

      {/* Today summary */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4 text-center">
          <UserX className="h-6 w-6 text-red-500 mx-auto mb-1" />
          <p className="text-2xl font-bold text-red-700">{todayAbsences.length}</p>
          <p className="text-xs text-red-600 mt-0.5">Absents aujourd'hui</p>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center">
          <Clock className="h-6 w-6 text-amber-500 mx-auto mb-1" />
          <p className="text-2xl font-bold text-amber-700">{todayRetards.length}</p>
          <p className="text-xs text-amber-600 mt-0.5">Retards aujourd'hui</p>
        </div>
        <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 text-center">
          <AlertTriangle className="h-6 w-6 text-orange-500 mx-auto mb-1" />
          <p className="text-2xl font-bold text-orange-700">{openIncidents.length}</p>
          <p className="text-xs text-orange-600 mt-0.5">Incidents en cours</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {TABS.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveModal(tab.id)}
              className="flex flex-col items-center justify-center gap-2 py-6 px-3 rounded-2xl bg-white border border-border/50 shadow-sm hover:shadow-md hover:border-teal-300 hover:bg-teal-50/40 transition-all group"
            >
              <div className="w-12 h-12 rounded-xl bg-teal-100 flex items-center justify-center group-hover:bg-teal-200 transition-colors">
                <Icon className="h-6 w-6 text-teal-600" />
              </div>
              <span className="text-sm font-semibold text-foreground text-center">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Recent absences */}
      {data.absences.slice(0, 5).length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-5">
          <h2 className="font-bold text-foreground mb-3 flex items-center gap-2 text-sm">
            <ClipboardList className="h-4 w-4 text-teal-500" /> Dernières absences
          </h2>
          <div className="space-y-2">
            {data.absences.slice(0, 5).map(a => (
              <div key={a.id} className="flex items-center gap-3 py-2 border-b border-border/50 last:border-0">
                <div className={`w-2 h-2 rounded-full ${a.type === "absent" ? "bg-red-500" : a.type === "retard" ? "bg-amber-500" : "bg-green-500"}`} />
                <span className="font-medium text-sm flex-1">{a.student_name}</span>
                <span className="text-xs text-muted-foreground">{a.class_name}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${a.type === "absent" ? "bg-red-100 text-red-700" : a.type === "retard" ? "bg-amber-100 text-amber-700" : "bg-green-100 text-green-700"}`}>
                  {a.type}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modals */}
      {activeModal && (() => {
        const tab = TABS.find(t => t.id === activeModal);
        const Icon = tab?.icon;
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={() => setActiveModal(null)}>
            <div className="bg-background rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-white shrink-0">
                <div className="flex items-center gap-3">
                  {Icon && <div className="w-9 h-9 rounded-xl bg-teal-100 flex items-center justify-center"><Icon className="h-5 w-5 text-teal-600" /></div>}
                  <h2 className="text-lg font-bold">{tab?.label}</h2>
                </div>
                <button onClick={() => setActiveModal(null)} className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="overflow-y-auto flex-1 p-6">
                {activeModal === "attendance" && <AttendanceReview />}
                {activeModal === "absences" && <AbsenceManager students={data.students} classes={data.classes} />}
                {activeModal === "incidents" && <IncidentManager students={data.students} classes={data.classes} />}
                {activeModal === "conduct" && <ConductScoreViewer students={data.students} classes={data.classes} />}
                {activeModal === "faults" && <ConductFaultManager />}
                {activeModal === "reports" && <EduReportForm onClose={() => setActiveModal(null)} />}
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}

function StatBadge({ value, label }) {
  return (
    <div className="text-center">
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-teal-200 text-xs">{label}</p>
    </div>
  );
}