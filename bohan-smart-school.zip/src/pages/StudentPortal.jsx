import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { BookOpen, ClipboardList, TrendingUp, FileText, Bell, GraduationCap, Calendar, Lock, Search, Loader2, CheckCircle, AlertCircle, DollarSign, Mail, MailOpen, Megaphone, Clock, Camera, MessageSquare, LayoutDashboard, UserCheck, Download, ChevronDown, ChevronUp, Users } from "lucide-react";
import StudentAttendanceTab from "../components/student/StudentAttendanceTab";
import StudentMessages from "../components/student/StudentMessages";
import StudentDashboardTab from "../components/student/StudentDashboardTab";
import { useAuth } from "@/lib/AuthContext";
import StudentSchedule from "../components/student/StudentSchedule";
import ExamsTab from "../components/student/StudentExamsTab";
import ParentView from "../components/student/ParentView";
import { getSchoolId } from "../hooks/useSchool";

// ── Period helpers ──────────────────────────────────────────────────────────
function getPeriodsFromSettings(settings) {
  if (settings?.period_type === "semestre") {
    return { periods: ["Semestre 1", "Semestre 2"], periodType: "semestre" };
  }
  return { periods: ["Trimestre 1", "Trimestre 2", "Trimestre 3"], periodType: "trimestre" };
}

// Weighted final average for trimester system: (T1×1 + T2×2 + T3×2) / 5
// For semester system: simple average of both semesters
function calcFinalAvg(periodType, avgFn, periods) {
  if (periodType === "semestre") {
    const avgs = periods.map(p => avgFn(p)).filter(v => v !== null);
    return avgs.length ? avgs.reduce((a, b) => a + b, 0) / avgs.length : null;
  }
  // Trimester: (T1×1 + T2×2 + T3×2) / 5
  const [a1, a2, a3] = periods.map(p => avgFn(p));
  if (a1 === null && a2 === null && a3 === null) return null;
  let num = 0, den = 0;
  if (a1 !== null) { num += a1 * 1; den += 1; }
  if (a2 !== null) { num += a2 * 2; den += 2; }
  if (a3 !== null) { num += a3 * 2; den += 2; }
  return den > 0 ? num / den : null;
}

function scoreColor(v) {
  if (v === null || v === undefined) return "text-muted-foreground";
  if (v >= 14) return "text-green-600";
  if (v >= 10) return "text-yellow-600";
  return "text-red-600";
}
function scoreBg(v) {
  if (v === null || v === undefined) return "bg-muted text-muted-foreground";
  if (v >= 14) return "bg-green-100 text-green-700";
  if (v >= 10) return "bg-yellow-100 text-yellow-700";
  return "bg-red-100 text-red-700";
}
function wavg(arr) {
  if (!arr.length) return null;
  const tot = arr.reduce((a, b) => a + b.coef, 0);
  if (!tot) return null;
  return arr.reduce((a, b) => a + b.score * b.coef, 0) / tot;
}
function avg(arr) {
  if (!arr.length) return null;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

const TABS = [
  { id: "dashboard", label: "Tableau de bord", icon: LayoutDashboard },
  { id: "card", label: "Ma carte", icon: GraduationCap },
  { id: "parent", label: "👨‍👩‍👧 Vue Parent", icon: Users },
  { id: "schedule", label: "Emploi du temps", icon: Calendar },
  { id: "attendance", label: "Présences", icon: UserCheck },
  { id: "exams", label: "Devoirs & Examens", icon: ClipboardList },
  { id: "grades", label: "Mes notes", icon: ClipboardList },
  { id: "averages", label: "Mes moyennes", icon: TrendingUp },
  { id: "fees", label: "Frais de scolarité", icon: DollarSign },
  { id: "bulletin", label: "Bulletin", icon: FileText },
  { id: "messages", label: "Messages", icon: Mail },
];

export default function StudentPortal() {
  const { user } = useAuth();
  const [student, setStudent] = useState(null);
  const [classObj, setClassObj] = useState(null);
  const [subjects, setSubjects] = useState([]);
  const [grades, setGrades] = useState([]);
  const [exams, setExams] = useState([]);
  const [bulletins, setBulletins] = useState([]);
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [enrollmentData, setEnrollmentData] = useState(null);
  const [payments, setPayments] = useState([]);

  const [schedules, setSchedules] = useState([]);
  const [teacherReports, setTeacherReports] = useState([]);
  const [selectedPeriod, setSelectedPeriod] = useState(null); // set after settings load
  const [openedMessages, setOpenedMessages] = useState(() => {
    try { return JSON.parse(localStorage.getItem("bohan_opened_msgs") || "[]"); } catch { return []; }
  });
  const [tab, setTab] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get("tab") || "dashboard";
  });
  const [studentNumberInput, setStudentNumberInput] = useState("");
  const [linkLoading, setLinkLoading] = useState(false);
  const [linkError, setLinkError] = useState("");
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  async function handlePhotoUpload(e) {
    const file = e.target.files?.[0];
    if (!file || !student?.id) return;
    setUploadingPhoto(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await base44.entities.Student.update(student.id, { photo_url: file_url });
    setStudent(prev => ({ ...prev, photo_url: file_url }));
    setUploadingPhoto(false);
  }

  async function handleLinkAccount(e) {
    e.preventDefault();
    setLinkError("");
    setLinkLoading(true);
    // Search all students — no school filter at link time, student may not be assigned to one yet
    const allStudents = await base44.entities.Student.filter({});
    const match = allStudents.find(
      (s) => s.student_number?.trim().toLowerCase() === studentNumberInput.trim().toLowerCase()
    );
    if (!match) {
      setLinkError("Aucun élève trouvé avec ce numéro. Vérifiez et réessayez.");
      setLinkLoading(false);
      return;
    }
    await base44.entities.Student.update(match.id, { student_user_email: user.email.toLowerCase() });
    setLinkLoading(false);
    window.location.reload();
  }

  // Load enrollment + payment data
  useEffect(() => {
    async function loadEnrollment() {
      if (!student) { setEnrollmentData(null); setPayments([]); return; }
      // Use the student's own school_id — ignore global selector
      const filter = student.school_id ? { school_id: student.school_id } : {};
      // Match by student_id first, then by student_number (filtered by school_id)
      let enrollments = await base44.entities.Enrollment.filter(filter);
      let enr = enrollments.find(e => e.student_id === student.id)
             || enrollments.find(e => e.first_name?.toLowerCase() === student.first_name?.toLowerCase() && e.last_name?.toLowerCase() === student.last_name?.toLowerCase());
      setEnrollmentData(enr || null);
      if (enr) {
        const pays = await base44.entities.Payment.filter({ enrollment_id: enr.id });
        setPayments(pays.sort((a, b) => new Date(a.payment_date) - new Date(b.payment_date)));
      }
    }
    loadEnrollment();
  }, [student?.id]);

  // Real-time sync: re-fetch student data when it changes in DB
  useEffect(() => {
    if (!student?.id) return;
    const unsub = base44.entities.Student.subscribe((event) => {
      if (event.id === student.id && event.data) {
        setStudent(event.data);
      }
    });
    return unsub;
  }, [student?.id]);

  // Real-time sync for exams
  useEffect(() => {
    if (!student?.class_id) return;
    const unsub = base44.entities.Exam.subscribe((event) => {
      if (event.type === 'create' && event.data?.class_id === student.class_id) {
        setExams((prev) => [...prev, event.data]);
      } else if (event.type === 'update' && event.data?.class_id === student.class_id) {
        setExams((prev) => prev.map((e) => e.id === event.id ? event.data : e));
      } else if (event.type === 'delete') {
        setExams((prev) => prev.filter((e) => e.id !== event.id));
      }
    });
    return unsub;
  }, [student?.class_id]);

  useEffect(() => {
    if (!user?.email) return;
    async function load() {
      const googleEmail = user.email.toLowerCase();

      // Search across ALL students by email (no school filter — student's school_id is the authority)
      const allStudents = await base44.entities.Student.filter({});

      // 1. Try direct match by google email
      let me = allStudents.find((s) => s.student_user_email?.toLowerCase() === googleEmail);

      // 2. If not found, look up via AppAccess to match by name
      if (!me) {
        const accesses = await base44.entities.AppAccess.filter({ role: 'student' });
        const myAccess = accesses.find((a) => a.user_email?.toLowerCase() === googleEmail);
        if (myAccess && myAccess.full_name) {
          const parts = myAccess.full_name.trim().split(' ');
          const fn = parts[0]?.toLowerCase();
          const ln = parts.slice(1).join(' ').toLowerCase();
          me = allStudents.find((s) =>
            s.first_name?.toLowerCase() === fn && s.last_name?.toLowerCase() === ln
          );
        }
      }

      if (!me) {
        setNotFound(true);
        setLoading(false);
        return;
      }

      setStudent(me);

      // Use the student's own school_id as the authoritative filter — ignore global school selector
      const studentSchoolId = me.school_id;
      const filter = studentSchoolId ? { school_id: studentSchoolId } : {};

      // Batch API calls in two groups to avoid rate limits
      const [classes, subs] = await Promise.all([
        base44.entities.Class.filter(filter),
        base44.entities.Subject.filter(filter),
      ]);
      const [g, ex, bul, sett, reports, scheds] = await Promise.all([
        base44.entities.Grade.filter({ student_id: me.id }),
        base44.entities.Exam.filter({ class_id: me.class_id, school_id: studentSchoolId }),
        base44.entities.BulletinData.filter({ student_id: me.id }),
        base44.entities.SchoolSettings.filter(filter),
        base44.entities.TeacherReport.filter({ class_id: me.class_id, school_id: studentSchoolId }),
        base44.entities.Schedule.filter({ class_id: me.class_id, school_id: studentSchoolId }),
      ]);

      const settObj = sett[0] || null;
      const { periods } = getPeriodsFromSettings(settObj);

      setClassObj(classes.find((c) => c.id === me.class_id) || null);
      setSubjects(subs);
      setGrades(g);
      setExams(ex);
      setBulletins(bul);
      setSettings(settObj);
      setSchedules(scheds);
      setTeacherReports(reports.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0)));
      setSelectedPeriod(prev => prev || periods[0]);
      setLoading(false);
    }
    load();
  }, [user]);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
    </div>
  );

  if (notFound) return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] p-4">
      <div className="w-full max-w-md bg-card border border-border rounded-2xl shadow-lg overflow-hidden">
        {/* Header */}
        <div className="bg-primary p-6 text-center">
          <div className="w-14 h-14 bg-white/15 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <GraduationCap className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-lg font-bold text-white">Lier mon dossier élève</h2>
          <p className="text-white/70 text-xs mt-1">Saisissez votre numéro étudiant (matricule)</p>
        </div>

        <div className="p-6 space-y-5">
          {/* Connected account */}
          <div className="flex items-center gap-2 bg-muted rounded-lg px-3 py-2">
            <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-xs shrink-0">
              {(user?.email || "?")[0].toUpperCase()}
            </div>
            <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          </div>

          <form onSubmit={handleLinkAccount} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-1.5">Numéro étudiant (matricule)</label>
              <input
                type="text"
                value={studentNumberInput}
                onChange={(e) => { setStudentNumberInput(e.target.value); setLinkError(""); }}
                placeholder="Ex : 2024-001, ETU-0042…"
                className="w-full border border-input rounded-lg px-3 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                required
                autoFocus
              />
            </div>

            {linkError && (
              <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2.5 text-sm text-red-700">
                <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                {linkError}
              </div>
            )}

            <button
              type="submit"
              disabled={linkLoading || !studentNumberInput.trim()}
              className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-lg px-4 py-2.5 text-sm font-semibold disabled:opacity-60 hover:bg-primary/90 transition-colors"
            >
              {linkLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              {linkLoading ? "Recherche en cours…" : "Lier mon compte"}
            </button>
          </form>

          <p className="text-center text-xs text-muted-foreground">
            Ce numéro vous a été attribué par votre établissement.<br />
            En cas de difficulté, contactez l'administration.
          </p>
        </div>
      </div>
    </div>
  );

  const subjectMap = {};
  subjects.forEach((s) => (subjectMap[s.id] = s));

  const { periods, periodType } = getPeriodsFromSettings(settings);

  function getPeriodAvg(period) {
    const pGrades = grades.filter((g) => g.trimester === period);
    const subIds = [...new Set(pGrades.map((g) => g.subject_id))];
    const arr = subIds.map((sid) => {
      const sGs = pGrades.filter((g) => g.subject_id === sid);
      const s = subjectMap[sid];
      return { score: avg(sGs.map((g) => g.score)), coef: s?.coefficient || 1 };
    }).filter((x) => x.score !== null);
    return wavg(arr);
  }
  // Keep old name for bulletin compat
  const getTrimesterAvg = getPeriodAvg;

  function getSubjectAvgs(period) {
    const pGrades = period === "all" ? grades : grades.filter((g) => g.trimester === period);
    const subIds = [...new Set(pGrades.map((g) => g.subject_id))];
    return subIds.map((sid) => {
      const sGs = pGrades.filter((g) => g.subject_id === sid);
      const s = subjectMap[sid];
      return { subject: s, avg: avg(sGs.map((g) => g.score)), count: sGs.length };
    }).filter((x) => x.subject).sort((a, b) => a.subject.name.localeCompare(b.subject.name));
  }

  const annualAvg = calcFinalAvg(periodType, getPeriodAvg, periods);

  const upcomingExams = exams
    .filter((e) => e.date && new Date(e.date) >= new Date())
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  const pastExams = exams
    .filter((e) => !e.date || new Date(e.date) < new Date())
    .sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));

  const currentPeriod = selectedPeriod || periods[0] || "Trimestre 1";

  return (
    <div className="max-w-5xl mx-auto space-y-4">
      {/* Tabs */}
      <div className="flex gap-1 border-b border-border overflow-x-auto">
        {TABS.map((t) => {
          const Icon = t.icon;
          const urgentCount = t.id === "messages"
            ? upcomingExams.filter(e => {
                const d = Math.ceil((new Date(e.date) - new Date()) / (1000 * 60 * 60 * 24));
                return d >= 0 && d <= 7 && !openedMessages.includes(e.id);
              }).length
            : 0;
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium whitespace-nowrap transition-colors relative ${
                tab === t.id ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"
              }`}>
              <span className="relative">
                <Icon className="h-4 w-4" />
                {urgentCount > 0 && (
                  <span className="absolute -top-2 -right-2 min-w-[16px] h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center px-0.5 animate-pulse">
                    {urgentCount}
                  </span>
                )}
              </span>
              {t.label}
              {urgentCount > 0 && t.id !== tab && (
                <span className="ml-1 text-[9px] font-bold text-red-600 bg-red-100 px-1.5 py-0.5 rounded-full uppercase tracking-wide">
                  URGENT
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ── Tableau de bord ── */}
      {tab === "dashboard" && (
        <StudentDashboardTab
          student={student}
          classObj={classObj}
          settings={settings}
          grades={grades}
          exams={exams}
          subjects={subjects}
          enrollmentData={enrollmentData}
          schedules={schedules}
          annualAvg={annualAvg}
          getPeriodAvg={getPeriodAvg}
          periods={periods}
          periodType={periodType}
          onTabChange={setTab}
        />
      )}

      {/* ── Carte d'identité ── */}
      {tab === "card" && (
        <div className="flex flex-col items-center gap-6">
          {/* Card */}
          <div className="w-full max-w-md bg-gradient-to-br from-primary to-blue-800 rounded-3xl shadow-2xl overflow-hidden text-white">
            {/* Header band */}
            <div className="px-6 pt-5 pb-3 flex items-center justify-between border-b border-white/20">
              <div>
                <p className="text-[10px] uppercase tracking-widest opacity-70">{settings?.republic_name || "RÉPUBLIQUE"}</p>
                <p className="text-xs font-bold opacity-90">{settings?.school_name || "Établissement"}</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center">
                <GraduationCap className="h-6 w-6 text-white" />
              </div>
            </div>

            {/* Body */}
            <div className="px-6 py-5 flex gap-5 items-start">
              {/* Photo */}
              <div className="w-20 h-24 rounded-xl bg-white/15 border-2 border-white/30 overflow-hidden shrink-0 flex items-center justify-center">
                {student.photo_url
                  ? <img src={student.photo_url} alt="photo" className="w-full h-full object-cover" />
                  : <span className="text-4xl font-bold opacity-60">{student.first_name?.[0]?.toUpperCase()}</span>
                }
              </div>
              {/* Info */}
              <div className="flex-1 space-y-1.5">
                <p className="text-lg font-bold leading-tight">{student.last_name} {student.first_name}</p>
                <div className="space-y-1 text-xs opacity-85">
                  <div className="flex gap-2"><span className="opacity-60 w-20 shrink-0">Matricule</span><span className="font-mono font-semibold">{student.student_number}</span></div>
                  <div className="flex gap-2"><span className="opacity-60 w-20 shrink-0">Classe</span><span className="font-semibold">{classObj?.name || "—"}</span></div>
                  <div className="flex gap-2"><span className="opacity-60 w-20 shrink-0">Niveau</span><span>{classObj?.level || "—"}</span></div>
                  <div className="flex gap-2"><span className="opacity-60 w-20 shrink-0">Année</span><span>{classObj?.academic_year || "—"}</span></div>
                  {student.gender && <div className="flex gap-2"><span className="opacity-60 w-20 shrink-0">Sexe</span><span>{student.gender}</span></div>}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-3 bg-black/20 flex items-center justify-between">
              <p className="text-[10px] uppercase tracking-widest opacity-60">Carte d'identité scolaire</p>
              <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                student.status === "Actif" ? "bg-green-400/20 text-green-200" : "bg-red-400/20 text-red-200"
              }`}>{student.status || "Actif"}</span>
            </div>
          </div>

          {/* Photo upload */}
          <label className={`w-full max-w-md flex items-center justify-center gap-2 border-2 border-dashed border-primary/40 rounded-xl px-4 py-3 cursor-pointer hover:bg-primary/5 transition-colors ${uploadingPhoto ? "opacity-60 pointer-events-none" : ""}`}>
            <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} disabled={uploadingPhoto} />
            {uploadingPhoto
              ? <Loader2 className="h-4 w-4 animate-spin text-primary" />
              : <Camera className="h-4 w-4 text-primary" />
            }
            <span className="text-sm font-semibold text-primary">
              {uploadingPhoto ? "Téléversement en cours…" : student.photo_url ? "Changer ma photo d'identité" : "Ajouter ma photo d'identité"}
            </span>
          </label>

          {/* Sync notice */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground bg-card border border-border rounded-xl px-4 py-2.5">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shrink-0" />
            Synchronisation en temps réel — toute mise à jour par l'administration apparaîtra automatiquement.
          </div>

          {/* Extra info */}
          <div className="w-full max-w-md bg-card rounded-xl border border-border p-4 space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Informations complémentaires</p>
            {[
              { label: "Date de naissance", value: student.date_of_birth ? new Date(student.date_of_birth).toLocaleDateString("fr-FR") : "—" },
              { label: "Adresse", value: student.address || "—" },
              { label: "Parent / Tuteur", value: student.parent_name || "—" },
              { label: "Contact parent", value: student.parent_phone || student.parent_email || "—" },
            ].map(({ label, value }) => (
              <div key={label} className="flex justify-between text-sm py-1 border-b border-border/50 last:border-0">
                <span className="text-muted-foreground">{label}</span>
                <span className="font-medium text-foreground text-right max-w-[55%]">{value}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Vue Parent ── */}
      {tab === "parent" && (
        <ParentView
          student={student}
          classObj={classObj}
          subjects={subjects}
          grades={grades}
          exams={exams}
          bulletins={bulletins}
          settings={settings}
          schedules={schedules}
          periods={periods}
          periodType={periodType}
          getPeriodAvg={getPeriodAvg}
          annualAvg={annualAvg}
        />
      )}

      {/* ── Emploi du temps ── */}
      {tab === "schedule" && (
        <StudentSchedule classId={student?.class_id} />
      )}

      {/* ── Présences ── */}
      {tab === "attendance" && (
        <StudentAttendanceTab studentId={student?.id} subjects={subjects} />
      )}

      {tab === "grades" && (
        <div className="space-y-4">
          {periods.map((trimester) => {
            const tGrades = grades.filter((g) => g.trimester === trimester);
            if (!tGrades.length) return null;
            return (
              <div key={trimester}>
                <h3 className="text-sm font-semibold text-foreground mb-3">{trimester}</h3>
                <div className="space-y-2">
                  {tGrades.map((g) => {
                    const exam = exams.find((e) => e.id === g.exam_id);
                    return (
                      <div key={g.id} className="bg-card border border-border rounded-xl p-4 flex items-start gap-4">
                        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 font-bold text-lg ${scoreBg(g.score)}`}>
                          {g.score}/{g.max_score || 20}
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">{subjectMap[g.subject_id]?.name || "Matière"}</p>
                          <p className="text-sm text-muted-foreground mt-0.5">{exam?.title || g.exam_type} • {g.exam_type}</p>
                          {g.comment && <p className="text-xs text-muted-foreground mt-2 italic">Commentaire: {g.comment}</p>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
          {!grades.length && (
            <p className="text-sm text-muted-foreground bg-card rounded-xl border border-border p-6 text-center">Aucune note enregistrée</p>
          )}
        </div>
      )}

      {/* ── Examens ── */}
      {tab === "exams" && (
        <ExamsTab exams={exams} grades={grades} subjects={subjects} subjectMap={subjectMap} periods={periods} scoreBg={scoreBg} />
      )}

      {tab === "averages" && (
        <div className="space-y-6">
          <div className={`grid grid-cols-1 gap-4 ${periods.length === 2 ? "sm:grid-cols-2" : "sm:grid-cols-3"}`}>
            {periods.map((t, idx) => {
              const a = getPeriodAvg(t);
              const weight = periodType === "trimestre" ? (idx === 0 ? 1 : 2) : 1;
              return (
                <div key={t} className="bg-card rounded-xl border border-border p-4 text-center">
                  <p className="text-xs text-muted-foreground mb-1">{t}</p>
                  {periodType === "trimestre" && (
                    <p className="text-[10px] text-muted-foreground mb-1">Coeff. {weight}</p>
                  )}
                  {a !== null
                    ? <span className={`text-2xl font-bold ${scoreColor(a)}`}>{a.toFixed(2)}<span className="text-sm font-normal text-muted-foreground">/20</span></span>
                    : <span className="text-muted-foreground text-sm">—</span>}
                </div>
              );
            })}
          </div>

          {annualAvg !== null && (
            <div className={`rounded-xl p-4 text-center border ${scoreBg(annualAvg)}`}>
              <p className="text-xs font-semibold mb-1">Moyenne générale finale</p>
              {periodType === "trimestre" && (
                <p className="text-[10px] text-muted-foreground mb-1">(T1×1 + T2×2 + T3×2) / 5</p>
              )}
              <span className="text-3xl font-bold">{annualAvg.toFixed(2)}<span className="text-base font-normal">/20</span></span>
            </div>
          )}

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-3">Détail par matière</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {getSubjectAvgs("all").map(({ subject, avg: a, count }) => (
                <div key={subject.id} className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-foreground">{subject.name}</p>
                    <p className="text-xs text-muted-foreground">Coeff. {subject.coefficient} — {count} note{count > 1 ? "s" : ""}</p>
                  </div>
                  <span className={`text-lg font-bold ${scoreColor(a)}`}>{a !== null ? a.toFixed(2) : "—"}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === "fees" && (
        <div className="space-y-4">
          {!enrollmentData ? (
            <div className="text-center py-12">
              <DollarSign className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground font-medium">Aucune inscription trouvée</p>
              <p className="text-sm text-muted-foreground mt-1">Contactez l'administration pour régulariser votre situation.</p>
            </div>
          ) : (
            <>
              {/* Bannière statut */}
              {enrollmentData.payment_status === "complet" && (
                <div className="flex items-center gap-3 bg-emerald-50 border-2 border-emerald-300 rounded-xl p-4">
                  <CheckCircle className="h-6 w-6 text-emerald-600 shrink-0" />
                  <div>
                    <p className="font-bold text-emerald-900">✅ Frais entièrement acquittés</p>
                    <p className="text-sm text-emerald-700">Tous vos frais de scolarité ont été réglés. Merci !</p>
                  </div>
                </div>
              )}
              {enrollmentData.payment_status === "partiel" && (
                <div className="flex items-center gap-3 bg-amber-50 border-2 border-amber-300 rounded-xl p-4">
                  <AlertCircle className="h-6 w-6 text-amber-600 shrink-0" />
                  <div>
                    <p className="font-bold text-amber-900">⚠️ Paiement incomplet</p>
                    <p className="text-sm text-amber-700">Il reste un solde à régler. Contactez le comptable dès que possible.</p>
                  </div>
                </div>
              )}
              {enrollmentData.payment_status === "en_attente" && (
                <div className="flex items-center gap-3 bg-red-50 border-2 border-red-300 rounded-xl p-4">
                  <AlertCircle className="h-6 w-6 text-red-600 shrink-0" />
                  <div>
                    <p className="font-bold text-red-900">🔴 Aucun paiement enregistré</p>
                    <p className="text-sm text-red-700">Veuillez vous rendre au bureau de la comptabilité pour régulariser.</p>
                  </div>
                </div>
              )}

              {/* Barre de progression */}
              {enrollmentData.total_fee > 0 && (
                <div className="bg-card border border-border rounded-xl p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-semibold text-foreground">Progression du paiement</span>
                    <span className="text-sm font-bold text-primary">
                      {Math.round(((enrollmentData.amount_paid || 0) / enrollmentData.total_fee) * 100)}%
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                    <div
                      className={`h-3 rounded-full transition-all ${
                        enrollmentData.payment_status === "complet" ? "bg-emerald-500"
                        : enrollmentData.payment_status === "partiel" ? "bg-amber-500"
                        : "bg-red-400"
                      }`}
                      style={{ width: `${Math.min(100, Math.round(((enrollmentData.amount_paid || 0) / enrollmentData.total_fee) * 100))}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground mt-1.5">
                    <span>0 XOF</span>
                    <span>{(enrollmentData.total_fee || 0).toLocaleString("fr-FR")} XOF</span>
                  </div>
                </div>
              )}

              {/* Résumé 3 chiffres */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center">
                  <p className="text-[10px] text-blue-600 font-semibold uppercase mb-1">Total dû</p>
                  <p className="text-base font-bold text-blue-900">{(enrollmentData.total_fee || 0).toLocaleString("fr-FR")}</p>
                  <p className="text-[10px] text-blue-600 mt-0.5">XOF</p>
                </div>
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center">
                  <p className="text-[10px] text-emerald-600 font-semibold uppercase mb-1">Déjà payé</p>
                  <p className="text-base font-bold text-emerald-900">{(enrollmentData.amount_paid || 0).toLocaleString("fr-FR")}</p>
                  <p className="text-[10px] text-emerald-600 mt-0.5">XOF</p>
                </div>
                <div className={`rounded-xl p-3 text-center border ${enrollmentData.payment_status === "complet" ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200"}`}>
                  <p className={`text-[10px] font-semibold uppercase mb-1 ${enrollmentData.payment_status === "complet" ? "text-emerald-600" : "text-red-600"}`}>Reste à payer</p>
                  <p className={`text-base font-bold ${enrollmentData.payment_status === "complet" ? "text-emerald-900" : "text-red-900"}`}>
                    {Math.max(0, (enrollmentData.total_fee || 0) - (enrollmentData.amount_paid || 0)).toLocaleString("fr-FR")}
                  </p>
                  <p className={`text-[10px] mt-0.5 ${enrollmentData.payment_status === "complet" ? "text-emerald-600" : "text-red-600"}`}>XOF</p>
                </div>
              </div>

              {/* Historique des versements */}
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="bg-muted/50 px-4 py-3 border-b border-border flex items-center justify-between">
                  <p className="text-sm font-bold text-foreground">📋 Historique des versements</p>
                  <span className="text-xs text-muted-foreground">{payments.length} versement{payments.length > 1 ? "s" : ""}</span>
                </div>
                {payments.length === 0 ? (
                  <div className="p-6 text-center text-sm text-muted-foreground">Aucun versement enregistré</div>
                ) : (
                  <div className="divide-y divide-border">
                    {payments.map((p, idx) => (
                      <div key={p.id} className="flex items-center gap-3 px-4 py-3">
                        <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                          <span className="text-xs font-bold text-emerald-700">{idx + 1}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-foreground">
                            Versement {idx + 1}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {p.payment_date ? new Date(p.payment_date).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" }) : "—"}
                            {p.payment_method ? ` • ${p.payment_method}` : ""}
                          </p>
                          {p.receipt_number && (
                            <p className="text-[10px] font-mono text-muted-foreground mt-0.5">Reçu : {p.receipt_number}</p>
                          )}
                        </div>
                        <span className="font-bold text-emerald-700 text-sm shrink-0">+{(p.amount || 0).toLocaleString("fr-FR")} XOF</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Détail des frais */}
              <div className="bg-card border border-border rounded-xl p-4">
                <p className="text-sm font-bold text-foreground mb-3">📊 Détail des frais</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between py-1.5 border-b border-border/50">
                    <span className="text-muted-foreground">Droit d'inscription</span>
                    <span className="font-semibold">{(enrollmentData.enrollment_fee || 0).toLocaleString("fr-FR")} XOF</span>
                  </div>
                  {(enrollmentData.tuition_fee || 0) > 0 && (
                    <div className="flex justify-between py-1.5 border-b border-border/50">
                      <span className="text-muted-foreground">Frais de scolarité</span>
                      <span className="font-semibold">{(enrollmentData.tuition_fee || 0).toLocaleString("fr-FR")} XOF</span>
                    </div>
                  )}
                  {(enrollmentData.platform_fee || 500) > 0 && (
                    <div className="flex justify-between py-1.5 border-b border-border/50">
                      <span className="text-muted-foreground">Frais plateforme BOHAN</span>
                      <span className="font-semibold">{(enrollmentData.platform_fee || 500).toLocaleString("fr-FR")} XOF</span>
                    </div>
                  )}
                  <div className="flex justify-between py-2 font-bold text-base">
                    <span>Total</span>
                    <span className="text-primary">{(enrollmentData.total_fee || 0).toLocaleString("fr-FR")} XOF</span>
                  </div>
                </div>
              </div>

              {/* Mode de paiement + prochaine échéance */}
              <div className="bg-card border border-border rounded-xl p-4 text-sm space-y-2">
                <p className="font-bold text-foreground mb-1">ℹ️ Informations de paiement</p>
                <div className="flex justify-between py-1 border-b border-border/50">
                  <span className="text-muted-foreground">Mode de paiement</span>
                  <span className="font-semibold capitalize">{enrollmentData.payment_mode || "—"}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-border/50">
                  <span className="text-muted-foreground">Année scolaire</span>
                  <span className="font-semibold">{enrollmentData.academic_year || "—"}</span>
                </div>
                {enrollmentData.enrollment_date && (
                  <div className="flex justify-between py-1 border-b border-border/50">
                    <span className="text-muted-foreground">Date d'inscription</span>
                    <span className="font-semibold">{new Date(enrollmentData.enrollment_date).toLocaleDateString("fr-FR")}</span>
                  </div>
                )}
                {payments.length > 0 && (
                  <div className="flex justify-between py-1 border-b border-border/50">
                    <span className="text-muted-foreground">Dernier paiement</span>
                    <span className="font-semibold text-emerald-700">
                      {new Date(payments[payments.length - 1].payment_date).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })}
                    </span>
                  </div>
                )}
                {enrollmentData.payment_status !== "complet" && enrollmentData.payment_mode === "échelonné" && (
                  <div className="mt-2 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2.5">
                    <p className="text-xs font-bold text-amber-900">📅 Paiement échelonné</p>
                    <p className="text-xs text-amber-700 mt-0.5">
                      Vous avez effectué {payments.length} versement{payments.length > 1 ? "s" : ""} sur {enrollmentData.max_installments || "?"}.
                      Rapprochez-vous du comptable pour convenir du prochain versement.
                    </p>
                  </div>
                )}
              </div>

              {/* Contact comptable si impayé */}
              {enrollmentData.payment_status !== "complet" && enrollmentData.accountant_email && (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-sm text-blue-900">
                  <p className="font-semibold mb-1">📞 Besoin d'aide ?</p>
                  <p>Contactez le comptable : <span className="font-mono font-bold">{enrollmentData.accountant_email}</span></p>
                  {enrollmentData.accountant_name && <p className="text-xs mt-1 text-blue-700">{enrollmentData.accountant_name}</p>}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {tab === "messages" && (
        <StudentMessages
          upcomingExams={upcomingExams}
          subjects={subjects}
          teacherReports={teacherReports}
          openedMessages={openedMessages}
          setOpenedMessages={setOpenedMessages}
        />
      )}



      {tab === "bulletin" && (
        <div className="space-y-4">
          <div className="flex gap-2 flex-wrap">
            {periods.map((t) => (
              <button key={t} onClick={() => setSelectedPeriod(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  currentPeriod === t ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"
                }`}>
                {t}
              </button>
            ))}
          </div>

          {(() => {
            const bulletin = bulletins.find((b) => b.trimester === currentPeriod);
            const trimAvg = getTrimesterAvg(currentPeriod);
            const subAvgs = getSubjectAvgs(currentPeriod);
            const isLastPeriod = currentPeriod === periods[periods.length - 1];

            return (
              <div className="bg-card rounded-xl border-2 border-border overflow-hidden">
                <div className="bg-primary text-primary-foreground p-4 text-center">
                  <p className="text-xs opacity-80">{settings?.republic_name || "RÉPUBLIQUE"}</p>
                  <p className="text-sm font-bold">{settings?.school_name || "Établissement"}</p>
                  <p className="text-xs opacity-80">{settings?.school_motto}</p>
                </div>

                <div className="p-5 space-y-4">
                  <div className="grid grid-cols-2 gap-2 text-sm border border-border rounded-lg p-3">
                    <div><span className="text-xs text-muted-foreground">Nom : </span><span className="font-semibold">{student.last_name} {student.first_name}</span></div>
                    <div><span className="text-xs text-muted-foreground">Matricule : </span><span className="font-mono text-xs">{student.student_number}</span></div>
                    <div><span className="text-xs text-muted-foreground">Classe : </span><span className="font-semibold">{classObj?.name || "—"}</span></div>
                    <div><span className="text-xs text-muted-foreground">Période : </span><span className="font-semibold">{currentPeriod}</span></div>
                    {bulletin && (
                      <>
                        <div><span className="text-xs text-muted-foreground">Absences justifiées : </span><span>{bulletin.absences_justified || 0}h</span></div>
                        <div><span className="text-xs text-muted-foreground">Absences non justifiées : </span><span>{bulletin.absences_unjustified || 0}h</span></div>
                      </>
                    )}
                  </div>

                  {subAvgs.length > 0 ? (
                    <table className="w-full text-sm border border-border rounded-lg overflow-hidden">
                      <thead>
                        <tr className="bg-muted/50 border-b border-border">
                          <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Matière</th>
                          <th className="text-center py-2 px-3 text-xs font-semibold text-muted-foreground">Coeff.</th>
                          <th className="text-center py-2 px-3 text-xs font-semibold text-muted-foreground">Moyenne</th>
                        </tr>
                      </thead>
                      <tbody>
                        {subAvgs.map(({ subject, avg: a }) => (
                          <tr key={subject.id} className="border-b border-border/50">
                            <td className="py-2 px-3 font-medium">{subject.name}</td>
                            <td className="py-2 px-3 text-center text-muted-foreground">{subject.coefficient}</td>
                            <td className="py-2 px-3 text-center">
                              <span className={`font-bold ${scoreColor(a)}`}>{a !== null ? a.toFixed(2) : "—"}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="bg-muted/30 font-bold border-t border-border">
                          <td colSpan={2} className="py-2 px-3 text-sm">Moyenne de la période</td>
                          <td className="py-2 px-3 text-center">
                            <span className={`text-base font-bold ${scoreColor(trimAvg)}`}>
                              {trimAvg !== null ? trimAvg.toFixed(2) : "—"}/20
                            </span>
                          </td>
                        </tr>
                        {/* Show final weighted average on last period bulletin */}
                        {isLastPeriod && annualAvg !== null && (
                          <tr className="bg-primary/10 font-bold border-t-2 border-primary/30">
                            <td colSpan={2} className="py-2 px-3 text-sm text-primary">
                              Moyenne générale finale
                              {periodType === "trimestre" && <span className="text-[10px] font-normal text-muted-foreground ml-1">(T1×1 + T2×2 + T3×2) / 5</span>}
                            </td>
                            <td className="py-2 px-3 text-center">
                              <span className={`text-lg font-extrabold ${scoreColor(annualAvg)}`}>
                                {annualAvg.toFixed(2)}/20
                              </span>
                            </td>
                          </tr>
                        )}
                      </tfoot>
                    </table>
                  ) : (
                    <p className="text-center text-sm text-muted-foreground py-6">Aucune note pour cette période</p>
                  )}

                  {bulletin?.council_appreciation && (
                    <div className="border border-border rounded-lg p-3">
                      <p className="text-xs text-muted-foreground mb-1">Appréciation du conseil :</p>
                      <p className="text-sm italic">{bulletin.council_appreciation}</p>
                    </div>
                  )}

                  {bulletin?.distinction && bulletin.distinction !== "Aucune" && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-center">
                      <p className="text-xs text-yellow-700 font-semibold">🏆 {bulletin.distinction}</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}