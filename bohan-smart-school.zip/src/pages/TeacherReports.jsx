import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../hooks/useSchool";
import { BookOpen, ClipboardList, FlaskConical, RefreshCw, Eye, X, ShieldAlert, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import PageHeader from "../components/PageHeader";

const TYPE_CONFIG = {
  cours: { label: "Cours", icon: BookOpen, color: "bg-blue-100 text-blue-700" },
  devoir: { label: "Devoir", icon: ClipboardList, color: "bg-amber-100 text-amber-700" },
  examen: { label: "Examen", icon: FlaskConical, color: "bg-purple-100 text-purple-700" },
};

const STATUS_COLOR = {
  envoyé: "bg-amber-100 text-amber-700",
  lu: "bg-blue-100 text-blue-700",
  approuvé: "bg-green-100 text-green-700",
  archivé: "bg-muted text-muted-foreground",
};

export default function TeacherReports() {
  const { user } = useAuth();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [filterType, setFilterType] = useState("all");
  const [filterTeacher, setFilterTeacher] = useState("all");
  const [filterDate, setFilterDate] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const list = await base44.entities.TeacherReport.filter(filter, "-date", 300);
    setReports(list);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function markAsRead(report) {
    if (report.status === "envoyé") {
      await base44.entities.TeacherReport.update(report.id, { status: "lu" });
      setSelected(r => r ? { ...r, status: "lu" } : r);
      load();
    }
  }

  async function approveReport(report) {
    await base44.entities.TeacherReport.update(report.id, {
      status: "approuvé",
      approved_by: user?.full_name || user?.email,
      approved_date: new Date().toISOString(),
    });
    setSelected(r => r ? { ...r, status: "approuvé", approved_by: user?.full_name || user?.email } : r);
    load();
  }

  const verifiedRole = (() => { try { return sessionStorage.getItem('scolaris_verified_role'); } catch { return null; } })();
  const isDirecteur = verifiedRole === 'user';
  if (user?.role !== "admin" && !isDirecteur) return (
    <div className="flex flex-col items-center justify-center h-64 gap-3">
      <ShieldAlert className="h-10 w-10 text-muted-foreground" />
      <p className="text-muted-foreground">Accès réservé au proviseur et aux administrateurs.</p>
    </div>
  );

  const teachers = [...new Set(reports.map(r => r.teacher_name).filter(Boolean))];

  const filtered = reports.filter(r => {
    if (filterType !== "all" && r.report_type !== filterType) return false;
    if (filterTeacher !== "all" && r.teacher_name !== filterTeacher) return false;
    if (filterDate && r.date !== filterDate) return false;
    return true;
  });

  const unread = reports.filter(r => r.status === "envoyé").length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Rapports des professeurs"
        subtitle={`${unread} nouveau${unread !== 1 ? "x" : ""} rapport${unread !== 1 ? "s" : ""} non lu${unread !== 1 ? "s" : ""}`}
      >
        <Button variant="outline" size="sm" onClick={load} disabled={loading} className="gap-2">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} /> Actualiser
        </Button>
      </PageHeader>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les types</SelectItem>
            <SelectItem value="cours">📖 Cours</SelectItem>
            <SelectItem value="devoir">📝 Devoirs</SelectItem>
            <SelectItem value="examen">🧪 Examens</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterTeacher} onValueChange={setFilterTeacher}>
          <SelectTrigger className="w-52"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les professeurs</SelectItem>
            {teachers.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>
        <Input type="date" value={filterDate} onChange={e => setFilterDate(e.target.value)} className="w-44" />
        {(filterType !== "all" || filterTeacher !== "all" || filterDate) && (
          <Button variant="ghost" size="sm" onClick={() => { setFilterType("all"); setFilterTeacher("all"); setFilterDate(""); }}>
            <X className="h-3.5 w-3.5 mr-1" /> Effacer
          </Button>
        )}
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        {loading ? (
          <div className="p-10 text-center"><div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" /></div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center">
            <BookOpen className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-muted-foreground text-sm">Aucun rapport trouvé.</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/50 border-b border-border">
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Type</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Professeur</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Classe</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Matière</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Titre</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Date</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground">Statut</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => {
                const cfg = TYPE_CONFIG[r.report_type] || TYPE_CONFIG.cours;
                return (
                  <tr key={r.id} className={`border-b border-border/50 hover:bg-muted/20 transition-colors ${r.status === "envoyé" ? "bg-green-50/30" : ""}`}>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}>
                        <cfg.icon className="h-3 w-3" />
                        {cfg.label}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium">{r.teacher_name || r.teacher_email}</td>
                    <td className="py-3 px-4 text-muted-foreground">{r.class_name || "—"}</td>
                    <td className="py-3 px-4 text-muted-foreground">{r.subject_name || "—"}</td>
                    <td className="py-3 px-4 font-medium text-foreground">{r.title}</td>
                    <td className="py-3 px-4 text-muted-foreground text-xs">{r.date ? new Date(r.date).toLocaleDateString("fr-FR") : "—"}</td>
                    <td className="py-3 px-4 text-center">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLOR[r.status] || STATUS_COLOR.envoyé}`}>
                        {r.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setSelected(r); if (r.status === "envoyé") markAsRead(r); }}>
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Detail Modal */}
      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={() => setSelected(null)}>
          <div className="bg-background rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-border sticky top-0 bg-background">
              <div>
                <div className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium mb-2 ${TYPE_CONFIG[selected.report_type]?.color}`}>
                  {selected.report_type === "cours" ? "📖 Cours" : selected.report_type === "devoir" ? "📝 Devoir" : "🧪 Examen"}
                </div>
                <h2 className="text-lg font-bold text-foreground">{selected.title}</h2>
                <p className="text-sm text-muted-foreground">{selected.teacher_name} · {selected.class_name} · {selected.subject_name} · {selected.date && new Date(selected.date).toLocaleDateString("fr-FR")}</p>
              </div>
              <div className="flex items-center gap-2">
                {selected.status !== "approuvé" && (
                  <Button size="sm" className="gap-1.5 bg-green-600 hover:bg-green-700 text-white" onClick={() => approveReport(selected)}>
                    <CheckCircle className="h-4 w-4" /> Approuver le rapport
                  </Button>
                )}
                {selected.status === "approuvé" && (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-green-100 text-green-700 border border-green-300">
                    <CheckCircle className="h-3.5 w-3.5" /> Approuvé par {selected.approved_by}
                  </span>
                )}
                <button onClick={() => setSelected(null)} className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center">
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-5">
              {selected.objectives && <Section label="Objectifs" value={selected.objectives} />}
              {selected.content && <Section label={selected.report_type === "cours" ? "Contenu du cours" : "Consignes / Contenu"} value={selected.content} />}
              {selected.activities && <Section label="Activités réalisées" value={selected.activities} />}
              {selected.due_date && <Section label={selected.report_type === "devoir" ? "Date de rendu" : "Date de l'examen"} value={new Date(selected.due_date).toLocaleDateString("fr-FR")} />}
              {selected.duration && <Section label="Durée" value={selected.duration} />}
              {selected.competencies && <Section label="Compétences évaluées" value={selected.competencies} />}
              {selected.grading_scale && <Section label="Barème" value={selected.grading_scale} />}
              {selected.remarks && <Section label="Remarques" value={selected.remarks} />}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Section({ label, value }) {
  return (
    <div>
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">{label}</p>
      <p className="text-sm text-foreground whitespace-pre-line bg-muted/40 rounded-lg px-3 py-2">{value}</p>
    </div>
  );
}