import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { FileText, Wand2, Loader2, CheckCircle } from "lucide-react";
import { getSchoolId } from "../hooks/useSchool";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PageHeader from "../components/PageHeader";
import OfficialReportCard from "../components/reports/OfficialReportCard";

export default function Reports() {
  const [students, setStudents] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [grades, setGrades] = useState([]);
  const [bulletins, setBulletins] = useState([]);
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedClass, setSelectedClass] = useState("all");
  const [selectedTrimester, setSelectedTrimester] = useState("Trimestre 1");
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [genDone, setGenDone] = useState(false);
  const [genResult, setGenResult] = useState("");

  useEffect(() => {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    Promise.all([
      base44.entities.Student.filter(filter, "-created_date", 500),
      base44.entities.Class.filter(filter, "-created_date", 100),
      base44.entities.Subject.filter(filter, "-created_date", 100),
      base44.entities.Grade.filter(filter, "-created_date", 2000),
      base44.entities.BulletinData.filter(filter, "-created_date", 500),
      base44.entities.SchoolSettings.filter(filter, "-created_date", 10),
    ]).then(([s, c, sub, g, b, sett]) => {
      setStudents(s);
      setClasses(c);
      setSubjects(sub);
      setGrades(g);
      setBulletins(b);
      setSettings(sett[0] || null);
      setLoading(false);
    });
  }, []);

  const filteredStudents = selectedClass === "all"
    ? students
    : students.filter((s) => s.class_id === selectedClass);

  async function handleGenerateGrades() {
    if (selectedClass === "all") return alert("Veuillez sélectionner une classe.");
    setGenerating(true);
    setGenDone(false);

    const classStudents = students.filter((s) => s.class_id === selectedClass);
    const cls = classes.find((c) => c.id === selectedClass);
    const classSubjects = subjects.filter((s) => {
      return !s.level || s.level === "Tous" || s.level === cls?.level ||
        (s.levels && s.levels.includes(cls?.level));
    });

    const schoolId = getSchoolId();
    const EXAM_TYPES = ["Devoir", "Interrogation", "Devoir", "Interrogation"];
    const gradesToCreate = [];
    const academicYear = cls?.academic_year || `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`;

    for (const student of classStudents) {
      for (const subject of classSubjects) {
        // Check existing grades for this student/subject/trimester
        const existing = grades.filter(
          (g) => g.student_id === student.id && g.subject_id === subject.id && g.trimester === selectedTrimester
        );
        const needed = 4 - existing.length;
        for (let i = 0; i < needed; i++) {
          const score = Math.round((8 + Math.random() * 12) * 4) / 4; // between 8 and 20, step 0.25
          gradesToCreate.push({
            school_id: schoolId,
            student_id: student.id,
            subject_id: subject.id,
            class_id: selectedClass,
            score: Math.min(20, score),
            max_score: 20,
            exam_type: EXAM_TYPES[(existing.length + i) % 4],
            trimester: selectedTrimester,
            academic_year: academicYear,
            comment: "",
          });
        }
      }
    }

    if (gradesToCreate.length > 0) {
      await base44.entities.Grade.bulkCreate(gradesToCreate);
      // Reload grades
      const schoolId2 = getSchoolId();
      const filter = schoolId2 ? { school_id: schoolId2 } : {};
      const newGrades = await base44.entities.Grade.filter(filter);
      setGrades(newGrades);
    }

    setGenResult(`${gradesToCreate.length} notes générées pour ${classStudents.length} élèves et ${classSubjects.length} matières.`);
    setGenerating(false);
    setGenDone(true);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Bulletins officiels" subtitle="Génération des bulletins de notes trimestriels" />

      <div className="flex flex-wrap gap-3 items-center">
        <Select value={selectedClass} onValueChange={(v) => { setSelectedClass(v); setSelectedStudent(null); }}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Classe" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes les classes</SelectItem>
            {classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={selectedTrimester} onValueChange={(v) => { setSelectedTrimester(v); setSelectedStudent(null); }}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="Trimestre 1">Trimestre 1</SelectItem>
            <SelectItem value="Trimestre 2">Trimestre 2</SelectItem>
            <SelectItem value="Trimestre 3">Trimestre 3</SelectItem>
          </SelectContent>
        </Select>
        <Button
          variant="outline"
          className="gap-2 border-purple-200 text-purple-700 hover:bg-purple-50"
          onClick={handleGenerateGrades}
          disabled={generating || selectedClass === "all"}
        >
          {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
          {generating ? "Génération…" : "Générer les notes (4/matière)"}
        </Button>
      </div>

      {genDone && (
        <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-lg px-4 py-2 text-sm text-green-800">
          <CheckCircle className="h-4 w-4 text-green-600" />
          {genResult}
          <button className="ml-auto text-xs text-green-600 underline" onClick={() => setGenDone(false)}>Fermer</button>
        </div>
      )}

      {selectedStudent ? (
        <div>
          <Button variant="outline" size="sm" onClick={() => setSelectedStudent(null)} className="mb-4">
            ← Retour à la liste
          </Button>
          <OfficialReportCard
            student={selectedStudent}
            classObj={classes.find((c) => c.id === selectedStudent.class_id)}
            subjects={subjects.filter((s) => {
              const cls = classes.find((c) => c.id === selectedStudent.class_id);
              return !s.level || s.level === "Tous" || s.level === cls?.level;
            })}
            grades={grades}
            bulletinData={bulletins.find((b) => b.student_id === selectedStudent.id && b.trimester === selectedTrimester) || null}
            settings={settings}
            allStudents={students}
            allGrades={grades}
            trimester={selectedTrimester}
          />
        </div>
      ) : (
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50 border-b border-border">
                  <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Matricule</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Nom complet</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Classe</th>
                  <th className="text-right py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredStudents.length === 0 ? (
                  <tr><td colSpan={4} className="py-12 text-center text-muted-foreground">Aucun élève trouvé</td></tr>
                ) : filteredStudents.map((s) => {
                  const classObj = classes.find((c) => c.id === s.class_id);
                  return (
                    <tr key={s.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                      <td className="py-3 px-4 font-mono text-xs text-primary">{s.student_number}</td>
                      <td className="py-3 px-4 font-medium">{s.last_name} {s.first_name}</td>
                      <td className="py-3 px-4 text-muted-foreground">{classObj?.name || "—"}</td>
                      <td className="py-3 px-4 text-right">
                        <Button variant="outline" size="sm" className="gap-1 h-8 text-xs"
                          onClick={() => setSelectedStudent(s)}>
                          <FileText className="h-3 w-3" /> Voir bulletin
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}