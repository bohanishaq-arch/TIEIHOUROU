import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import useAccountantSchool from "../hooks/useAccountantSchool";
import {
  DollarSign, UserPlus, ClipboardList, BarChart3, Settings, X,
  Receipt, TrendingUp, KeyRound, Building2, Users, AlertTriangle,
  CheckCircle, Bell, ChevronRight, GraduationCap, FileText, Search
} from "lucide-react";
import { motion } from "framer-motion";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Legend } from "recharts";
import EnrollmentForm from "@/components/accountant/EnrollmentForm";
import PaymentTracker from "@/components/accountant/PaymentTracker";
import SchoolFeesManager from "@/components/accountant/SchoolFeesManager";
import ReceiptHistory from "@/components/accountant/ReceiptHistory";
import FinancialChart from "@/components/accountant/FinancialChart";
import StudentAccessHistory from "@/components/accountant/StudentAccessHistory";

const DAYS_FR = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];

const MODALS = [
  { id: "enroll",   label: "Nouvelle inscription",  icon: UserPlus },
  { id: "payments", label: "Suivi des paiements",   icon: ClipboardList },
  { id: "receipts", label: "Historique des reçus",  icon: Receipt },
  { id: "access",   label: "Rechercher un élève",   icon: Search },
  { id: "chart",    label: "Rapport financier",     icon: BarChart3 },
  { id: "fees",     label: "Tarifs scolaires",      icon: Settings },
];

function DonutChart({ paid, partial, unpaid, total }) {
  const data = [
    { name: "Payés", value: paid, color: "#10b981" },
    { name: "Partiels", value: partial, color: "#f59e0b" },
    { name: "Impayés", value: unpaid, color: "#ef4444" },
  ].filter(d => d.value > 0);

  const paidPct = total > 0 ? Math.round((paid / total) * 100) : 0;
  const partialPct = total > 0 ? Math.round((partial / total) * 100) : 0;
  const unpaidPct = total > 0 ? Math.round((unpaid / total) * 100) : 0;

  return (
    <div className="flex flex-col sm:flex-row items-center gap-6">
      <div className="relative w-48 h-48 shrink-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} cx="50%" cy="50%" innerRadius={52} outerRadius={78} dataKey="value" strokeWidth={2}>
              {data.map((entry, index) => (
                <Cell key={index} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip formatter={(v, n) => [`${v} élèves`, n]} />
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <p className="text-xs text-muted-foreground font-medium">Total</p>
          <p className="text-2xl font-bold text-foreground">{total}</p>
          <p className="text-[10px] text-muted-foreground">élèves</p>
        </div>
      </div>
      <div className="space-y-3 flex-1">
        <div className="flex items-center gap-3">
          <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-foreground">Payés</p>
            <p className="text-xs text-muted-foreground">{paidPct}% ({paid} élèves)</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="w-3 h-3 rounded-full bg-amber-400 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-foreground">Partiels</p>
            <p className="text-xs text-muted-foreground">{partialPct}% ({partial} élèves)</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="w-3 h-3 rounded-full bg-red-500 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-foreground">Impayés</p>
            <p className="text-xs text-muted-foreground">{unpaidPct}% ({unpaid} élèves)</p>
          </div>
        </div>
        {paidPct >= 50 && (
          <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2 mt-2">
            <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
            <p className="text-xs text-emerald-700 font-semibold">Bonne nouvelle ! {paidPct}% des élèves sont à jour.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function WeeklyChart({ payments }) {
  const weekData = useMemo(() => {
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0=Sun
    const monday = new Date(now);
    monday.setDate(now.getDate() - ((dayOfWeek + 6) % 7));

    return DAYS_FR.map((day, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      const dateStr = d.toISOString().slice(0, 10);
      const total = payments
        .filter(p => p.payment_date?.slice(0, 10) === dateStr)
        .reduce((s, p) => s + (p.amount || 0), 0);
      return { day, montant: total };
    });
  }, [payments]);

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-white border border-border rounded-xl shadow-lg p-3 text-xs">
        <p className="font-bold text-foreground">{label}</p>
        <p className="text-emerald-600 font-semibold">{(payload[0]?.value || 0).toLocaleString("fr-FR")} XOF</p>
      </div>
    );
  };

  return (
    <ResponsiveContainer width="100%" height={200}>
      <LineChart data={weekData} margin={{ top: 10, right: 10, bottom: 0, left: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
        <XAxis dataKey="day" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
        <YAxis
          tickFormatter={v => v >= 1000 ? (v / 1000).toFixed(0) + "k" : v}
          tick={{ fontSize: 11, fill: "#94a3b8" }}
          axisLine={false}
          tickLine={false}
          width={40}
        />
        <Tooltip content={<CustomTooltip />} />
        <Line
          type="monotone"
          dataKey="montant"
          name="Montant (XOF)"
          stroke="#10b981"
          strokeWidth={2.5}
          dot={{ r: 4, fill: "#10b981", stroke: "#fff", strokeWidth: 2 }}
          activeDot={{ r: 6 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

export default function AccountantDashboard() {
  const { user } = useAuth();
  const { schoolId, school, schoolSettings, profile, loading: schoolLoading } = useAccountantSchool(user);
  const [activeModal, setActiveModal] = useState(null);
  const [classes, setClasses] = useState([]);
  const [fees, setFees] = useState([]);
  const [enrollments, setEnrollments] = useState([]);
  const [payments, setPayments] = useState([]);
  const [dataLoading, setDataLoading] = useState(true);

  async function loadData(sid) {
    const id = sid || schoolId;
    if (!id) { setDataLoading(false); return; }
    const f = { school_id: id };
    const [cls, schoolFees, enrs, pays] = await Promise.all([
      base44.entities.Class.filter(f),
      base44.entities.SchoolFees.filter(f),
      base44.entities.Enrollment.filter(f, "-enrollment_date", 200),
      base44.entities.Payment.filter(f, "-payment_date", 500),
    ]);
    setClasses(cls);
    setFees(schoolFees);
    setEnrollments(enrs);
    setPayments(pays);
    setDataLoading(false);
  }

  useEffect(() => {
    if (!schoolLoading && schoolId) loadData(schoolId);
    else if (!schoolLoading && !schoolId) setDataLoading(false);
  }, [schoolLoading, schoolId]);

  const loading = schoolLoading || dataLoading;

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin" />
    </div>
  );

  if (!schoolId) return (
    <div className="flex flex-col items-center justify-center h-64 gap-3 text-center">
      <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center">
        <Building2 className="h-7 w-7 text-amber-600" />
      </div>
      <p className="font-bold text-foreground">Aucun établissement associé</p>
      <p className="text-sm text-muted-foreground max-w-xs">
        Votre compte comptable n'est pas encore lié à un établissement. Contactez l'administrateur.
      </p>
    </div>
  );

  const schoolName = school?.name || schoolSettings?.school_name || profile?.school_name || "Établissement";
  const schoolCode = school?.code || "—";
  const schoolLogo = schoolSettings?.logo_url || null;
  const accountantId = profile?.access_id || "CPT-000";
  const accountantName = (profile?.full_name || user?.full_name || "Comptable").toUpperCase();

  // Stats
  const totalEnrollments = enrollments.length;
  const totalCollected = payments.reduce((s, p) => s + (p.amount || 0), 0);
  const fullPaid = enrollments.filter(e => e.payment_status === "complet").length;
  const partial = enrollments.filter(e => e.payment_status === "partiel").length;
  const pending = enrollments.filter(e => e.payment_status === "en_attente").length;
  const unpaidCount = pending + partial;

  // Reçus ce mois-ci
  const thisMonth = new Date().toISOString().slice(0, 7);
  const receiptsThisMonth = payments.filter(p => p.payment_date?.slice(0, 10).startsWith(thisMonth)).length;

  // Alerts
  const alerts = [
    ...(unpaidCount > 0 ? [{ type: "warning", msg: "Élèves en retard de paiement", sub: `${unpaidCount} élève${unpaidCount > 1 ? "s" : ""} en paiement partiel ou non réglé`, modal: "payments" }] : []),
    { type: "info", msg: "Sauvegarde effectuée", sub: `Dernière sauvegarde : aujourd'hui à ${new Date().getHours().toString().padStart(2,"0")}:${new Date().getMinutes().toString().padStart(2,"0")}` },
  ];

  const schoolInfo = {
    id: schoolId, name: schoolName, logo_url: schoolLogo,
    address: schoolSettings?.school_address || school?.city || "",
    phone: schoolSettings?.school_phone || "",
    email: schoolSettings?.school_email || "",
    director: schoolSettings?.director_name || "",
    republic: schoolSettings?.republic_name || "RÉPUBLIQUE DE CÔTE D'IVOIRE",
    ministry: schoolSettings?.ministry_name || "",
  };

  return (
    <div className="space-y-6">

      {/* ── Hero Banner ── */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl shadow-lg"
        style={{ background: "linear-gradient(135deg, #d1fae5 0%, #a7f3d0 40%, #6ee7b7 100%)" }}
      >
        {/* School building illustration (SVG background) */}
        <div className="absolute right-0 top-0 bottom-0 w-48 opacity-20 pointer-events-none"
          style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 120'%3E%3Crect x='60' y='40' width='80' height='70' fill='%23065f46'/%3E%3Crect x='80' y='60' width='20' height='30' fill='%23fff'/%3E%3Crect x='110' y='60' width='15' height='20' fill='%23fff'/%3E%3Crect x='50' y='40' width='100' height='8' fill='%23047857'/%3E%3Cpolygon points='100,10 50,40 150,40' fill='%23065f46'/%3E%3Ccircle cx='100' cy='25' r='5' fill='%23fbbf24'/%3E%3C/svg%3E")`,
            backgroundRepeat: "no-repeat", backgroundPosition: "center right", backgroundSize: "contain"
          }}
        />

        <div className="relative px-6 py-5 flex items-center gap-4">
          {/* Logo */}
          <div className="w-20 h-20 rounded-2xl bg-white/60 border-2 border-emerald-300 flex items-center justify-center overflow-hidden shrink-0 shadow-md">
            {schoolLogo
              ? <img src={schoolLogo} alt={schoolName} className="w-full h-full object-contain p-1" />
              : (
                <div className="flex flex-col items-center text-emerald-700">
                  <GraduationCap className="h-8 w-8" />
                </div>
              )
            }
          </div>
          {/* Text */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="text-sm font-bold text-emerald-800">Espace Comptable</span>
              <span className="bg-white/70 text-emerald-700 font-mono text-xs px-2 py-0.5 rounded-full border border-emerald-300">
                ID : {accountantId}
              </span>
            </div>
            <p className="text-emerald-700 text-sm">Bienvenue,</p>
            <h1 className="text-2xl font-black text-emerald-900 leading-tight">{accountantName}</h1>
            <p className="text-xs font-bold text-emerald-700 mt-0.5">COMPTABLE</p>
            <p className="text-xs text-emerald-600 font-semibold mt-0.5 underline cursor-pointer">{schoolName}</p>
          </div>
        </div>
      </motion.div>

      {/* ── 4 Stat Cards ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            label: "Inscriptions totales", value: totalEnrollments, sub: "Élèves inscrits",
            icon: Users, iconBg: "bg-emerald-100", iconColor: "text-emerald-600", modal: "payments"
          },
          {
            label: "Impayés", value: unpaidCount, sub: "Élèves concernés",
            icon: AlertTriangle, iconBg: "bg-amber-100", iconColor: "text-amber-600", modal: "payments"
          },
          {
            label: "Total encaissé", value: totalCollected.toLocaleString("fr-FR"), sub: "XOF collectés",
            icon: DollarSign, iconBg: "bg-blue-100", iconColor: "text-blue-600", modal: "chart"
          },
          {
            label: "Reçus émis", value: receiptsThisMonth, sub: "Ce mois-ci",
            icon: Receipt, iconBg: "bg-purple-100", iconColor: "text-purple-600", modal: "receipts"
          },
        ].map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            onClick={() => setActiveModal(card.modal)}
            className="bg-white border border-border rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className={`w-10 h-10 rounded-xl ${card.iconBg} flex items-center justify-center`}>
                <card.icon className={`h-5 w-5 ${card.iconColor}`} />
              </div>
            </div>
            <p className="text-xs font-semibold text-muted-foreground mb-1">{card.label}</p>
            <p className="text-3xl font-bold text-foreground">{card.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{card.sub}</p>
            <div className="flex items-center gap-1 mt-2 text-xs text-primary font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
              Voir plus <ChevronRight className="h-3 w-3" />
            </div>
          </motion.div>
        ))}
      </div>

      {/* ── Donut + Line Chart ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Donut */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white border border-border rounded-2xl p-5 shadow-sm"
        >
          <h3 className="text-sm font-bold text-foreground mb-4">Répartition des paiements</h3>
          <DonutChart
            paid={fullPaid}
            partial={partial}
            unpaid={pending}
            total={totalEnrollments}
          />
        </motion.div>

        {/* Line chart */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="bg-white border border-border rounded-2xl p-5 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-foreground">Évolution des encaissements</h3>
            <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-lg font-medium">Cette semaine</span>
          </div>
          <WeeklyChart payments={payments} />
          <div className="flex items-center gap-2 mt-2">
            <span className="w-8 h-0.5 bg-emerald-500 inline-block rounded-full" />
            <span className="text-xs text-muted-foreground">Montant (XOF)</span>
          </div>
        </motion.div>
      </div>

      {/* ── Actions rapides + Alertes ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white border border-border rounded-2xl p-5 shadow-sm"
        >
          <h3 className="text-sm font-bold text-foreground mb-4">Actions rapides</h3>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {MODALS.map(({ id, label, icon: Icon }, i) => (
              <button
                key={id}
                onClick={() => setActiveModal(id)}
                className="flex flex-col items-center gap-2 p-3 rounded-xl border border-border hover:border-emerald-300 hover:bg-emerald-50 transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-muted group-hover:bg-emerald-100 flex items-center justify-center transition-colors">
                  <Icon className="h-5 w-5 text-muted-foreground group-hover:text-emerald-600" />
                </div>
                <span className="text-[10px] font-semibold text-muted-foreground text-center leading-tight">{label}</span>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Alertes */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45 }}
          className="bg-white border border-border rounded-2xl p-5 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-foreground">Alertes & notifications</h3>
            <button onClick={() => setActiveModal("payments")} className="text-xs text-primary font-semibold hover:underline flex items-center gap-1">
              Voir tout <ChevronRight className="h-3 w-3" />
            </button>
          </div>
          <div className="space-y-3">
            {alerts.map((alert, i) => (
              <div key={i} className={`flex items-start gap-3 rounded-xl p-3 border ${
                alert.type === "warning"
                  ? "bg-amber-50 border-amber-200"
                  : "bg-blue-50 border-blue-200"
              }`}>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                  alert.type === "warning" ? "bg-amber-100" : "bg-blue-100"
                }`}>
                  {alert.type === "warning"
                    ? <AlertTriangle className="h-4 w-4 text-amber-600" />
                    : <Bell className="h-4 w-4 text-blue-600" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-semibold ${alert.type === "warning" ? "text-amber-800" : "text-blue-800"}`}>
                    {alert.msg}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">{alert.sub}</p>
                </div>
                {alert.modal ? (
                  <button
                    onClick={() => setActiveModal(alert.modal)}
                    className="text-xs font-bold text-amber-700 bg-white border border-amber-300 px-2.5 py-1 rounded-lg hover:bg-amber-50 shrink-0"
                  >
                    Voir
                  </button>
                ) : (
                  <CheckCircle className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />
                )}
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* ── Modal ── */}
      {activeModal && (() => {
        const tab = MODALS.find(t => t.id === activeModal);
        const Icon = tab?.icon;
        const label = tab?.label || "Détails";
        return (
          <div
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4 bg-black/50 backdrop-blur-sm"
            onClick={() => setActiveModal(null)}
          >
            <div
              className="bg-background w-full sm:max-w-3xl sm:rounded-2xl rounded-t-3xl shadow-2xl max-h-[92vh] sm:max-h-[90vh] overflow-hidden flex flex-col"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex justify-center pt-3 pb-1 sm:hidden">
                <div className="w-10 h-1 bg-muted-foreground/20 rounded-full" />
              </div>
              <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-card shrink-0">
                <div className="flex items-center gap-3">
                  {Icon && <div className="w-8 h-8 rounded-xl bg-emerald-100 flex items-center justify-center"><Icon className="h-4 w-4 text-emerald-700" /></div>}
                  <h2 className="text-base font-bold">{label}</h2>
                </div>
                <button onClick={() => setActiveModal(null)} className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="overflow-y-auto flex-1 p-4 sm:p-6">
                {activeModal === "enroll" && <EnrollmentForm classes={classes} fees={fees} schoolId={schoolId} schoolInfo={schoolInfo} schoolType={school?.school_type || "public"} onSuccess={() => loadData(schoolId)} />}
                {activeModal === "payments" && <PaymentTracker schoolId={schoolId} schoolInfo={schoolInfo} />}
                {activeModal === "receipts" && <ReceiptHistory schoolId={schoolId} schoolInfo={schoolInfo} />}
                {activeModal === "chart" && <FinancialChart payments={payments} enrollments={enrollments} />}
                {activeModal === "access" && <StudentAccessHistory schoolId={schoolId} />}
                {activeModal === "fees" && <SchoolFeesManager fees={fees} onUpdate={() => loadData(schoolId)} schoolType={school?.school_type || "public"} />}
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}