import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId, getSchoolName } from "../hooks/useSchool";
import { Plus, Pencil, Trash2, ShieldCheck, Eye, EyeOff, RefreshCw, ShieldAlert, Copy, CheckCheck, Loader2, KeyRound, RotateCcw, Lock } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import PageHeader from "../components/PageHeader";

function generateId() {
  return "SCO-" + Math.random().toString(36).substring(2, 8).toUpperCase();
}
function generatePwd() {
  return Math.random().toString(36).substring(2, 10);
}

// Rôles que l'informaticien peut créer dans son école
const ROLE_OPTIONS = [
  { value: "teacher", label: "👨‍🏫 Professeur" },
  { value: "user", label: "🧑‍💼 Directeur / Chef d'établissement" },
  { value: "educator", label: "🛡️ Éducateur" },
  { value: "accountant", label: "💰 Comptable" },
  { value: "student", label: "🎓 Élève" },
];

export default function ManageAccess() {
  const { user } = useAuth();
  const [accesses, setAccesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterRole, setFilterRole] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ user_email: "", access_id: "", access_password: "", role: "student", is_active: true });
  const [showPwd, setShowPwd] = useState({});
  const [newCreds, setNewCreds] = useState(null);
  const [licenseCode, setLicenseCode] = useState("");
  const [foundSchool, setFoundSchool] = useState(null);
  const [checkingCode, setCheckingCode] = useState(false);
  const [codeError, setCodeError] = useState("");
  const [copied, setCopied] = useState(false);
  const codeTimer = useRef(null);

  useEffect(() => {
    // Pre-fill school from context
    const sid = getSchoolId();
    const sname = getSchoolName();
    if (sid && sname) setFoundSchool({ id: sid, name: sname });
  }, []);

  useEffect(() => {
    if (!licenseCode.trim() || licenseCode.trim().length < 5) return;
    clearTimeout(codeTimer.current);
    codeTimer.current = setTimeout(checkLicenseCode, 600);
    return () => clearTimeout(codeTimer.current);
  }, [licenseCode]);

  async function checkLicenseCode() {
    setCheckingCode(true);
    setCodeError("");
    setFoundSchool(null);
    const schools = await base44.entities.School.filter({ license_key: licenseCode.trim() });
    const school = schools.find((s) => s.is_active && s.license_activated);
    if (!school) {
      setCodeError("Code invalide ou établissement inactif.");
    } else {
      setFoundSchool(school);
    }
    setCheckingCode(false);
  }

  async function load() {
    setLoading(true);
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const list = await base44.entities.AppAccess.filter(filter, "-created_date", 200);
    setAccesses(list);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function openNew() {
    setEditing(null);
    setForm({ user_email: "", access_id: generateId(), access_password: generatePwd(), role: "student", is_active: true });
    setShowForm(true);
    setNewCreds(null);
  }

  function openEdit(a) {
    setEditing(a);
    setForm({ user_email: a.user_email, access_id: a.access_id, access_password: a.access_password, role: a.role || "student", is_active: a.is_active });
    setShowForm(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    if (editing) {
      await base44.entities.AppAccess.update(editing.id, { ...form });
    } else {
      if (!foundSchool) return;
      await base44.entities.AppAccess.create({
        ...form,
        school_id: foundSchool.id,
        school_name: foundSchool.name,
      });
      setNewCreds({
        email: form.user_email,
        id: form.access_id,
        pwd: form.access_password,
        school: foundSchool.name,
        role: form.role,
        licenseCode: licenseCode.trim(),
      });
    }
    setShowForm(false);
    setEditing(null);
    load();
  }

  async function handleDelete(id) {
    await base44.entities.AppAccess.delete(id);
    load();
  }

  async function handleResetPin(a) {
    if (!confirm(`Réinitialiser le PIN de ${a.full_name || a.user_email} ? L'utilisateur devra en créer un nouveau à sa prochaine connexion.`)) return;
    await base44.entities.AppAccess.update(a.id, { pin_hash: null, pin_set: false, failed_attempts: 0, locked_until: null });
    load();
  }

  async function handleUnlock(a) {
    await base44.entities.AppAccess.update(a.id, { failed_attempts: 0, locked_until: null });
    load();
  }

  async function toggleActive(a) {
    await base44.entities.AppAccess.update(a.id, { is_active: !a.is_active });
    load();
  }

  const verifiedRole = (() => { try { return sessionStorage.getItem('scolaris_verified_role') || ""; } catch { return ""; } })();
  // Accès : admin BOHAN, directeur (user), ou informaticien (it_manager)
  if (user?.role !== "admin" && verifiedRole !== "user" && verifiedRole !== "it_manager") return (
    <div className="flex flex-col items-center justify-center h-64 gap-3">
      <ShieldAlert className="h-10 w-10 text-muted-foreground" />
      <p className="text-muted-foreground">Accès réservé à l'informaticien ou aux administrateurs.</p>
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader title="Gestion des accès" subtitle="Identifiants d'accès à l'application">
        <Button variant="outline" size="sm" onClick={load} className="gap-2">
          <RefreshCw className="h-3.5 w-3.5" /> Actualiser
        </Button>
        <Button onClick={openNew} className="gap-2">
          <Plus className="h-4 w-4" /> Nouvel accès
        </Button>
      </PageHeader>

      {newCreds && (
        <div className="bg-green-50 border-2 border-green-300 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <p className="font-bold text-green-800 text-sm">✅ Accès créé avec succès — Transmettez ces informations à l'utilisateur</p>
            <button onClick={() => setNewCreds(null)} className="text-green-600 hover:text-green-800 text-xs font-semibold">✕ Fermer</button>
          </div>
          <div className="bg-white border border-green-200 rounded-lg p-4 font-mono text-sm space-y-2">
            <p className="text-xs text-muted-foreground font-sans font-semibold uppercase tracking-wide mb-3">Identifiants de connexion</p>
            {newCreds.email && <p><span className="text-muted-foreground font-sans">Email :</span> <strong>{newCreds.email}</strong></p>}
            <p><span className="text-muted-foreground font-sans">Identifiant :</span> <strong className="text-primary">{newCreds.id}</strong></p>
            <p><span className="text-muted-foreground font-sans">Mot de passe :</span> <strong>{newCreds.pwd}</strong></p>
            <p><span className="text-muted-foreground font-sans">Code établissement :</span> <strong>{newCreds.licenseCode}</strong></p>
            <p><span className="text-muted-foreground font-sans">École :</span> <strong>{newCreds.school}</strong></p>
            <p><span className="text-muted-foreground font-sans">Rôle :</span> <strong>{newCreds.role === "student" ? "Élève" : newCreds.role === "teacher" ? "Professeur" : "Direction / Admin"}</strong></p>
          </div>
          <button
            onClick={() => {
              navigator.clipboard.writeText(
                `Accès Scolaris\nIdentifiant: ${newCreds.id}\nMot de passe: ${newCreds.pwd}\nCode établissement: ${newCreds.licenseCode}\nÉcole: ${newCreds.school}\nRôle: ${newCreds.role === "student" ? "Élève" : newCreds.role === "teacher" ? "Professeur" : "Direction"}`
              );
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
            className="flex items-center gap-2 text-sm text-green-700 font-semibold hover:text-green-900 transition-colors"
          >
            {copied ? <CheckCheck className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? "Copié !" : "Copier tous les identifiants"}
          </button>
        </div>
      )}

      {showForm && (
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="font-semibold mb-4">{editing ? "Modifier l'accès" : "Créer un accès utilisateur"}</h3>
          <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 gap-4">

            {/* School license code — only on create */}
            {!editing && (
              <div className="md:col-span-2">
                <Label className="flex items-center gap-1.5">
                  <KeyRound className="h-3.5 w-3.5 text-muted-foreground" />
                  Code de l'établissement *
                </Label>
                <div className="flex gap-2 mt-1">
                  <Input
                    value={licenseCode}
                    onChange={(e) => { setLicenseCode(e.target.value); setFoundSchool(null); setCodeError(""); }}
                    placeholder="Ex: SCO-ABCD-1234"
                    className={foundSchool ? "border-green-400" : codeError ? "border-red-400" : ""}
                  />
                  <Button type="button" variant="outline" onClick={checkLicenseCode} disabled={checkingCode || !licenseCode.trim()} className="shrink-0">
                    {checkingCode ? <Loader2 className="h-4 w-4 animate-spin" /> : "Vérifier"}
                  </Button>
                </div>
                {codeError && <p className="text-xs text-red-600 mt-1">{codeError}</p>}
                {foundSchool && (
                  <div className="mt-2 flex items-center gap-2 bg-green-50 border border-green-200 rounded-lg px-3 py-2">
                    <CheckCheck className="h-4 w-4 text-green-600 shrink-0" />
                    <p className="text-sm font-semibold text-green-800">{foundSchool.name}</p>
                  </div>
                )}
              </div>
            )}

            <div>
              <Label>Email de l'utilisateur *</Label>
              <Input className="mt-1" type="email" value={form.user_email}
                onChange={(e) => setForm({ ...form, user_email: e.target.value })} required />
            </div>

            <div>
              <Label>Rôle *</Label>
              <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ROLE_OPTIONS.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Identifiant d'accès *</Label>
              <div className="flex gap-2 mt-1">
                <Input value={form.access_id} onChange={(e) => setForm({ ...form, access_id: e.target.value })} required />
                <Button type="button" variant="outline" size="icon" onClick={() => setForm({ ...form, access_id: generateId() })}>
                  <RefreshCw className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>

            <div>
              <Label>Mot de passe d'accès *</Label>
              <div className="flex gap-2 mt-1">
                <Input value={form.access_password} onChange={(e) => setForm({ ...form, access_password: e.target.value })} required />
                <Button type="button" variant="outline" size="icon" onClick={() => setForm({ ...form, access_password: generatePwd() })}>
                  <RefreshCw className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-4">
              <input type="checkbox" id="active" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} />
              <Label htmlFor="active">Accès actif</Label>
            </div>

            <div className="md:col-span-2 flex justify-end gap-3 pt-2">
              <Button type="button" variant="outline" onClick={() => { setShowForm(false); setEditing(null); }}>Annuler</Button>
              <Button type="submit" disabled={!editing && !foundSchool}>
                {editing ? "Enregistrer" : "Créer l'accès"}
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-2 flex-wrap items-center">
        <input
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Rechercher par nom, email, code…"
          className="flex-1 min-w-48 h-9 rounded-lg border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        />
        {["all","student","teacher","user","educator","accountant"].map(r => (
          <button key={r} onClick={() => setFilterRole(r)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filterRole === r ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}>
            {r === "all" ? `Tous (${accesses.length})` : r === "student" ? `Élèves (${accesses.filter(a=>a.role==="student").length})` : r === "teacher" ? `Profs (${accesses.filter(a=>a.role==="teacher").length})` : r === "educator" ? `Éduc. (${accesses.filter(a=>a.role==="educator").length})` : r === "accountant" ? `Compt. (${accesses.filter(a=>a.role==="accountant").length})` : `Dir. (${accesses.filter(a=>a.role==="user").length})`}
          </button>
        ))}
      </div>

      <div className="bg-card rounded-xl border border-border overflow-hidden">
        {loading ? (
          <div className="p-8 text-center"><div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" /></div>
        ) : accesses.length === 0 ? (
          <div className="p-10 text-center">
            <ShieldCheck className="h-8 w-8 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Aucun accès créé. Commencez par en créer un.</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/50 border-b border-border">
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Nom / Email</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">École</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Rôle</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Identifiant</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Mot de passe</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground">Statut</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {accesses.filter(a => {
                const matchRole = filterRole === "all" || a.role === filterRole;
                const q = searchQuery.toLowerCase();
                const matchSearch = !q || a.full_name?.toLowerCase().includes(q) || a.user_email?.toLowerCase().includes(q) || a.access_id?.toLowerCase().includes(q);
                return matchRole && matchSearch;
              }).map((a) => (
                <tr key={a.id} className="border-b border-border/50 hover:bg-muted/20">
                  <td className="py-3 px-4">
                    {a.full_name && <p className="font-semibold text-sm text-foreground">{a.full_name}</p>}
                    <p className="text-primary text-xs">{a.user_email}</p>
                  </td>
                  <td className="py-3 px-4 text-xs text-muted-foreground">{a.school_name || "—"}</td>
                  <td className="py-3 px-4 text-xs">
                    <span className={`px-2 py-0.5 rounded-full font-medium ${
                      a.role === "student" ? "bg-blue-100 text-blue-700" :
                      a.role === "teacher" ? "bg-purple-100 text-purple-700" :
                      "bg-amber-100 text-amber-700"
                    }`}>
                      {a.role === "student" ? "Élève" : a.role === "teacher" ? "Professeur" : "Direction"}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-sm font-bold">{a.access_id}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs">{showPwd[a.id] ? a.access_password : "••••••••"}</span>
                      <button onClick={() => setShowPwd((p) => ({ ...p, [a.id]: !p[a.id] }))} className="text-muted-foreground hover:text-foreground">
                        {showPwd[a.id] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex flex-col items-center gap-1">
                      <button onClick={() => toggleActive(a)}
                        className={`text-xs px-2 py-0.5 rounded-full font-medium transition-colors ${a.is_active ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-red-100 text-red-700 hover:bg-red-200"}`}>
                        {a.is_active ? "Actif" : "Désactivé"}
                      </button>
                      {a.locked_until && new Date(a.locked_until) > new Date()
                        ? <span className="text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded-full font-medium">🔒 Verrouillé</span>
                        : a.pin_set
                        ? <span className="text-[10px] bg-emerald-100 text-emerald-600 px-1.5 py-0.5 rounded-full font-medium">PIN ✓</span>
                        : <span className="text-[10px] bg-amber-100 text-amber-600 px-1.5 py-0.5 rounded-full font-medium">PIN non défini</span>
                      }
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {/* Verrouillé ? */}
                      {a.locked_until && new Date(a.locked_until) > new Date() && (
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-amber-500 hover:text-amber-600" title="Déverrouiller" onClick={() => handleUnlock(a)}>
                          <Lock className="h-3.5 w-3.5" />
                        </Button>
                      )}
                      {/* Réinitialiser PIN */}
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-500 hover:text-blue-600" title="Réinitialiser le PIN" onClick={() => handleResetPin(a)}>
                        <RotateCcw className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(a)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => handleDelete(a.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}