import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../hooks/useSchool";
import { UserPlus, GraduationCap, Users, Building2, Copy, Check, Eye, EyeOff, RefreshCw, Printer, Shield } from "lucide-react";

const ROLES = [
  { value: "teacher", label: "Professeur", prefix: "PROF", icon: GraduationCap, color: "bg-blue-100 text-blue-700 border-blue-200" },
  { value: "student", label: "Élève", prefix: "ETU", icon: Users, color: "bg-green-100 text-green-700 border-green-200" },
  { value: "user", label: "Directeur / Proviseur", prefix: "DIR", icon: Building2, color: "bg-purple-100 text-purple-700 border-purple-200" },
  { value: "educator", label: "Éducateur", prefix: "EDU", icon: Shield, color: "bg-teal-100 text-teal-700 border-teal-200" },
  { value: "accountant", label: "Comptable", prefix: "CPT", icon: Building2, color: "bg-emerald-100 text-emerald-700 border-emerald-200" },
];

function getSchoolCode() {
  // Génère un code court (3 lettres) depuis le nom de l'établissement stocké en session
  const schoolName = sessionStorage.getItem('scolaris_school_name') || "";
  if (!schoolName) return "SCH";
  const cleaned = schoolName.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/[^A-Z0-9\s]/g, "");
  const words = cleaned.trim().split(/\s+/).filter(w => !["DE", "DU", "LA", "LE", "LES", "ET", "DES", "L"].includes(w));
  if (words.length === 1) return words[0].slice(0, 3).padEnd(3, "X");
  return words.slice(0, 3).map(w => w[0]).join("").padEnd(3, "X");
}

function generateCode(role, lastName, birthDate, inscriptionDate) {
  const prefix = ROLES.find(r => r.value === role)?.prefix || "USR";
  const schoolCode = getSchoolCode();
  const year = String(inscriptionDate.getFullYear()).slice(-2);
  const namePart = lastName.trim().toUpperCase().replace(/\s/g, "").slice(0, 3).padEnd(3, "X");
  
  let birthPart = "000000";
  if (birthDate) {
    // Parse YYYY-MM-DD directly without timezone conversion
    const parts = String(birthDate).split("-");
    const dd = (parts[2] || "00").padStart(2, "0");
    const mm = (parts[1] || "00").padStart(2, "0");
    const yy = (parts[0] || "0000").slice(-2);
    birthPart = `${dd}${mm}${yy}`;
  }
  
  const day = String(inscriptionDate.getDate()).padStart(2, "0");
  return `${prefix}-${schoolCode}-${year}${namePart}-${birthPart}-${day}`;
}

function generatePassword() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789@#!";
  return Array.from({ length: 10 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  function handleCopy() {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }
  return (
    <button onClick={handleCopy} className="ml-2 p-1 rounded hover:bg-muted transition-colors">
      {copied ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5 text-muted-foreground" />}
    </button>
  );
}

function PrintCredentials({ result, schoolName }) {
  function handlePrint() {
    const roleName = result.role === "teacher" ? "Professeur" : result.role === "student" ? "Élève" : result.role === "educator" ? "Éducateur" : "Directeur";
    const win = window.open("", "_blank", "width=400,height=520");
    win.document.write(`
      <!DOCTYPE html><html><head><title>Identifiants - ${result.fullName}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 24px; max-width: 400px; margin: 0 auto; }
        .header { text-align: center; border-bottom: 2px solid #1e40af; padding-bottom: 16px; margin-bottom: 20px; }
        .school { font-size: 12px; color: #64748b; margin-bottom: 4px; }
        .title { font-size: 18px; font-weight: bold; color: #1e40af; }
        .badge { display: inline-block; background: #dbeafe; color: #1e40af; font-size: 11px; padding: 3px 10px; border-radius: 20px; margin-top: 4px; }
        .row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #e2e8f0; }
        .label { color: #64748b; font-size: 12px; }
        .value { font-weight: bold; font-size: 13px; font-family: monospace; }
        .warning { margin-top: 16px; background: #fef9c3; border: 1px solid #fbbf24; padding: 10px; border-radius: 8px; font-size: 11px; color: #92400e; text-align: center; }
        .guide { margin-top: 20px; border: 2px solid #1e40af; border-radius: 10px; overflow: hidden; }
        .guide-title { background: #1e40af; color: white; font-size: 13px; font-weight: bold; padding: 8px 14px; }
        .steps { padding: 12px 14px; background: #f8faff; }
        .step { display: flex; gap: 10px; margin-bottom: 12px; align-items: flex-start; font-size: 12px; color: #1e293b; }
        .step:last-child { margin-bottom: 0; }
        .num { background: #1e40af; color: white; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 11px; flex-shrink: 0; }
        .footer { margin-top: 18px; text-align: center; font-size: 10px; color: #94a3b8; }
      </style></head><body>
      <div class="header">
        <div class="school">${schoolName || "BOHAN — Gestion scolaire numérique"}</div>
        <div class="title">${result.fullName}</div>
        <span class="badge">${roleName}</span>
      </div>
      <div class="row"><span class="label">Code d'accès (identifiant)</span><span class="value">${result.code}</span></div>
      ${result.studentNumber ? `<div class="row"><span class="label">N° Étudiant</span><span class="value">${result.studentNumber}</span></div>` : ''}
      <div class="row"><span class="label">Email de connexion</span><span class="value">${result.email}</span></div>
      <div class="row"><span class="label">Mot de passe initial</span><span class="value">${result.password}</span></div>
      <div class="warning">⚠️ Conservez ces informations en lieu sûr. Ne les partagez pas.</div>

      <div class="guide">
        <div class="guide-title">📱 Comment ouvrir votre compte ?</div>
        <div class="steps">
          <div class="step"><span class="num">1</span><div><strong>Rendez-vous sur le site :</strong><br/>Ouvrez un navigateur web (Chrome, Firefox…) et accédez à l’application VeriNote.</div></div>
          <div class="step"><span class="num">2</span><div><strong>Connectez-vous avec Google :</strong><br/>Cliquez sur <em>« Se connecter avec Google »</em> et utilisez votre adresse email <strong>${result.email}</strong>.</div></div>
          <div class="step"><span class="num">3</span><div><strong>Entrez votre code permanent :</strong><br/>Au formulaire de vérification, saisissez votre code permanent : <strong>${result.code}</strong></div></div>
          <div class="step"><span class="num">4</span><div><strong>Entrez votre mot de passe initial :</strong><br/>Saisissez le mot de passe : <strong>${result.password}</strong><br/><span style="color:#92400e">⚠️ Pensez à le changer dès votre première connexion.</span></div></div>
          <div class="step"><span class="num">5</span><div><strong>Accès validé 🎉</strong><br/>Vous avez accès à votre espace <em>${roleName}</em> sur VeriNote.</div></div>
        </div>
      </div>

      <div class="footer">Généré le ${new Date().toLocaleDateString("fr-FR")} — BOHAN</div>
      </body></html>
    `);
    win.document.close();
    win.focus();
    win.print();
    win.close();
  }
  return (
    <button
      onClick={handlePrint}
      className="w-full flex items-center justify-center gap-2 border border-primary text-primary rounded-xl px-4 py-3 font-semibold hover:bg-primary/5 transition-colors"
    >
      <Printer className="h-5 w-5" />
      Imprimer les identifiants
    </button>
  );
}

const EMPTY = {
  role: "teacher",
  last_name: "",
  first_name: "",
  birth_date: "",
  email: "",
  class_ids: [],
  subject_id: "",
  class_category: "",
};

const COLLEGE_LEVELS = ["6ème", "5ème", "4ème", "3ème"];
const LYCEE_LEVELS = ["2nde", "1ère A", "1ère C", "1ère D", "Tle A", "Tle C", "Tle D"];

export default function Inscription() {
  const { user } = useAuth();
  const [form, setForm] = useState(EMPTY);
  const [schoolName, setSchoolName] = useState("");
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState(null);
  const [showPwd, setShowPwd] = useState(false);
  const [password, setPassword] = useState(() => generatePassword());
  const today = new Date();

  // Student lookup state
  const [studentNumber, setStudentNumber] = useState("");
  const [foundStudent, setFoundStudent] = useState(null);
  const [studentEmail, setStudentEmail] = useState("");
  const [lookupError, setLookupError] = useState("");
  const [lookupLoading, setLookupLoading] = useState(false);

  async function handleStudentLookup(e) {
    e.preventDefault();
    setLookupError("");
    setLookupLoading(true);
    setFoundStudent(null);
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const all = await base44.entities.Student.filter(filter);
    const match = all.find(s => s.student_number?.trim().toLowerCase() === studentNumber.trim().toLowerCase());
    if (!match) {
      setLookupError("Aucun élève trouvé avec ce numéro. Vérifiez le N° étudiant.");
    } else {
      setFoundStudent(match);
      setStudentEmail(match.student_user_email || "");
    }
    setLookupLoading(false);
  }

  async function handleStudentLink(e) {
    e.preventDefault();
    setSaving(true);
    const schoolId = getSchoolId();
    const emailLower = studentEmail.trim().toLowerCase();
    const fullName = `${foundStudent.first_name} ${foundStudent.last_name}`;

    // Générer un identifiant unique pour l'élève (similaire aux professeurs)
    const studentAccessId = generateCode("student", foundStudent.last_name, foundStudent.date_of_birth, today);

    // Update student record with login email
    await base44.entities.Student.update(foundStudent.id, { student_user_email: emailLower });

    // Create or update AppAccess with the new generated access_id (not the student_number)
    const existing = await base44.entities.AppAccess.filter({ user_email: emailLower });
    if (existing.length === 0) {
      await base44.entities.AppAccess.create({
        school_id: schoolId,
        user_email: emailLower,
        full_name: fullName,
        access_id: studentAccessId,
        access_password: password,
        role: "student",
        is_active: true,
      });
    } else {
      // Mettre à jour l'enregistrement existant avec le nouvel identifiant généré
      await base44.entities.AppAccess.update(existing[0].id, {
        access_id: studentAccessId,
        access_password: password,
        full_name: fullName,
        role: "student",
        is_active: true,
      });
    }

    // Pre-register the student in Base44 so they can log in with Google immediately
    try {
      await base44.users.inviteUser(emailLower, 'user');
    } catch {
      // Already registered or non-bloquant
    }

    setResult({
      code: studentAccessId,
      studentNumber: foundStudent.student_number,
      email: emailLower,
      fullName: fullName,
      role: "student",
      password,
    });
    setSaving(false);
  }

  useEffect(() => {
    async function loadSchool() {
      const schoolId = getSchoolId();
      if (!schoolId) return;
      const [settings, cls, subs] = await Promise.all([
        base44.entities.SchoolSettings.filter({ school_id: schoolId }),
        base44.entities.Class.filter({ school_id: schoolId }),
        base44.entities.Subject.filter({ school_id: schoolId }),
      ]);
      if (settings[0]?.school_name) setSchoolName(settings[0].school_name);
      setClasses(cls);
      setSubjects(subs);
    }
    loadSchool();
  }, []);

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">Accès réservé au Super Administrateur.</p>
      </div>
    );
  }

  const previewCode = form.last_name
    ? generateCode(form.role, form.last_name, form.birth_date, today)
    : null;

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);

    const schoolId = getSchoolId();
    const code = generateCode(form.role, form.last_name, form.birth_date, today);
    const fullName = `${form.first_name.trim()} ${form.last_name.trim()}`;

    const domainMap = { teacher: "professeur.is", user: "direction.is", educator: "educateur.is" };
    const generatedEmail = form.email.trim() ||
      `${form.last_name.trim().toLowerCase().replace(/\s/g, "")}@${domainMap[form.role] || "ecole.is"}`;

    await base44.entities.AppAccess.create({
      school_id: schoolId,
      user_email: generatedEmail,
      full_name: fullName,
      access_id: code,
      access_password: password,
      role: form.role,
      is_active: (form.role === 'user' || form.role === 'educator') ? false : true,
    });

    // If teacher with subject, create TeacherAssignment
    if (form.role === "teacher" && form.subject_id) {
      const selectedSubject = subjects.find(s => s.id === form.subject_id);
      // Create assignment for each selected class
      const classesToAssign = form.class_ids.length > 0 ? form.class_ids : [""];
      for (const classId of classesToAssign) {
        await base44.entities.TeacherAssignment.create({
          school_id: schoolId,
          teacher_email: generatedEmail,
          teacher_name: fullName,
          subject_id: form.subject_id,
          subject_name: selectedSubject?.name || "",
          class_id: classId,
          class_name: classId ? classes.find(c => c.id === classId)?.name || "" : "",
        });
      }
    }

    // Pre-register the user in Base44 so they can log in with Google immediately
    // Base44 inviteUser only accepts 'user' or 'admin' — we store the real role in AppAccess
    const baseRole = ['admin'].includes(form.role) ? 'admin' : 'user';
    try {
      await base44.users.inviteUser(generatedEmail, baseRole);
    } catch {
      // Already registered or non-bloquant
    }

    setResult({ code, email: generatedEmail, fullName, role: form.role, password });
    setSaving(false);
  }

  function handleReset() {
    setResult(null);
    setForm(EMPTY);
    setPassword(generatePassword());
  }

  const selectedRole = ROLES.find(r => r.value === form.role);

  // ── STUDENT MODE: lookup + link email ──
  if (form.role === "student" && !result) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-green-100 flex items-center justify-center">
            <Users className="h-6 w-6 text-green-700" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Lier un compte élève</h1>
            <p className="text-sm text-muted-foreground">Recherchez l'élève par son N° étudiant et associez son email de connexion</p>
          </div>
        </div>

        {/* Role switcher */}
        <div className="bg-card rounded-2xl border border-border p-4">
          <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wide">Changer de type d'inscription</p>
          <div className="grid grid-cols-3 gap-2">
            {ROLES.filter(r => r.value !== "student").map(r => {
              const Icon = r.icon;
              return (
                <button key={r.value} type="button" onClick={() => setForm(f => ({...f, role: r.value}))}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 border-border text-muted-foreground hover:border-muted-foreground text-xs font-medium transition-all">
                  <Icon className="h-4 w-4" />{r.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 1 — lookup */}
        <div className="bg-card rounded-2xl border border-border shadow-sm p-6 space-y-5">
          <form onSubmit={handleStudentLookup} className="space-y-4">
            <div>
              <label className="text-sm font-semibold text-foreground block mb-1.5">N° Étudiant *</label>
              <div className="flex gap-2">
                <input value={studentNumber} onChange={e => { setStudentNumber(e.target.value); setLookupError(""); setFoundStudent(null); }}
                  placeholder="Ex: SCO-2026-0001" required
                  className="flex-1 border border-input rounded-lg px-3 py-2.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                <button type="submit" disabled={lookupLoading || !studentNumber.trim()}
                  className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold disabled:opacity-60 hover:bg-primary/90 transition-colors">
                  {lookupLoading ? "..." : "Rechercher"}
                </button>
              </div>
              {lookupError && <p className="text-xs text-red-600 mt-1.5">{lookupError}</p>}
            </div>
          </form>

          {foundStudent && (
            <form onSubmit={handleStudentLink} className="space-y-4 border-t border-border pt-4">
              {/* Student info card */}
              <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-start gap-4">
                {foundStudent.photo_url
                  ? <img src={foundStudent.photo_url} className="w-14 h-14 rounded-xl object-cover border-2 border-green-300" />
                  : <div className="w-14 h-14 rounded-xl bg-green-200 flex items-center justify-center text-green-700 font-bold text-xl">{foundStudent.first_name?.[0]}</div>
                }
                <div>
                  <p className="font-bold text-green-900 text-base">{foundStudent.first_name} {foundStudent.last_name}</p>
                  <p className="text-xs text-green-700 font-mono">{foundStudent.student_number}</p>
                  <p className="text-xs text-green-600 mt-0.5">{foundStudent.status} {foundStudent.class_id ? "• Classe affectée" : ""}</p>
                  {foundStudent.student_user_email && <p className="text-xs text-muted-foreground mt-0.5">Élève actuel: {foundStudent.student_user_email}</p>}
                </div>
              </div>

              <div>
                <label className="text-sm font-semibold text-foreground block mb-1.5">Email de connexion Google *</label>
                <input type="email" value={studentEmail} onChange={e => setStudentEmail(e.target.value)} required
                  placeholder="email@gmail.com"
                  className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                <p className="text-xs text-muted-foreground mt-1">L'élève se connectera avec cet email Google. Un code d'accès unique sera généré automatiquement pour lui.</p>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground block mb-1.5">Mot de passe initial</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input type={showPwd ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)}
                      className="w-full border border-input rounded-lg px-3 py-2.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring pr-10" />
                    <button type="button" onClick={() => setShowPwd(p => !p)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                      {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  <button type="button" onClick={() => setPassword(generatePassword())} className="px-3 py-2 border border-input rounded-lg hover:bg-muted"><RefreshCw className="h-4 w-4 text-muted-foreground" /></button>
                </div>
              </div>

              <button type="submit" disabled={saving || !studentEmail.trim()}
                className="w-full flex items-center justify-center gap-2 bg-green-600 text-white rounded-xl px-4 py-3 font-semibold hover:bg-green-700 transition-colors disabled:opacity-60">
                {saving ? "Enregistrement..." : <><Check className="h-5 w-5" /> Lier le compte élève</>}
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
          <UserPlus className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Inscription du personnel</h1>
          <p className="text-sm text-muted-foreground">Créer un compte avec code permanent unique</p>
        </div>
      </div>

      {result ? (
        /* SUCCESS CARD */
        <div className="bg-card rounded-2xl border-2 border-green-300 shadow-lg overflow-hidden">
          <div className="bg-green-500 p-5 text-white text-center">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-2">
              <Check className="h-7 w-7" />
            </div>
            <h2 className="text-lg font-bold">Compte créé avec succès !</h2>
            <p className="text-green-100 text-sm">{result.fullName} — {ROLES.find(r => r.value === result.role)?.label}</p>
          </div>

          <div className="p-6 space-y-4">
            <p className="text-sm text-center text-muted-foreground font-semibold uppercase tracking-wide">
              📋 Identifiants à remettre à la personne
            </p>

            {[
              { label: "Code d'accès (identifiant de connexion)", value: result.code, mono: true, highlight: true },
              ...(result.studentNumber ? [{ label: "N° Étudiant", value: result.studentNumber, mono: true, highlight: false }] : []),
              { label: "Email de connexion", value: result.email, mono: true },
              { label: "Mot de passe initial", value: result.password, mono: true },
            ].map(({ label, value, mono, highlight }) => (
              <div key={label} className={`flex items-center justify-between rounded-xl px-4 py-3 border ${highlight ? "bg-primary/5 border-primary/20" : "bg-muted border-border"}`}>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">{label}</p>
                  <p className={`font-bold text-foreground ${mono ? "font-mono" : ""} ${highlight ? "text-primary text-lg" : ""}`}>{value}</p>
                </div>
                <CopyBtn text={value} />
              </div>
            ))}

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-700 text-center">
              ⚠️ Notez ces informations maintenant. Le mot de passe initial ne sera plus visible ensuite.
            </div>

            <PrintCredentials result={result} schoolName={schoolName} />

            <button
              onClick={handleReset}
              className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl px-4 py-3 font-semibold hover:bg-primary/90 transition-colors"
            >
              <UserPlus className="h-4 w-4" />
              Inscrire une autre personne
            </button>
          </div>
        </div>
      ) : (
        /* FORM */
        <form onSubmit={handleSubmit} className="bg-card rounded-2xl border border-border shadow-sm p-6 space-y-6">
          {/* Role selector — Élève = lookup, autres = création */}
          <div>
            <label className="text-sm font-semibold text-foreground block mb-3">Rôle *</label>
            <div className="grid grid-cols-3 gap-3">
              {ROLES.map(r => {
                const Icon = r.icon;
                return (
                  <button
                    key={r.value}
                    type="button"
                    onClick={() => setForm(f => ({ ...f, role: r.value }))}
                    className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 text-sm font-medium transition-all ${
                      form.role === r.value ? r.color + " border-current shadow-sm" : "bg-card border-border hover:border-muted-foreground text-muted-foreground"
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    {r.label}
                  </button>
                );
              })}
            </div>
            {form.role === "student" && (
              <p className="text-xs text-green-700 bg-green-50 border border-green-200 rounded-lg px-3 py-2 mt-2">
                ℹ️ Pour les élèves, sélectionnez « Élève » ci-dessus pour accéder au système de liaison par N° étudiant.
              </p>
            )}
          </div>

          {form.role === "teacher" && (
            <div className="space-y-4 border-t border-border pt-4">
              <h3 className="text-sm font-semibold text-foreground">Attribution de matière et classes</h3>
              <div>
                <label className="text-sm font-medium text-foreground block mb-1.5">Matière *</label>
                <select value={form.subject_id} onChange={e => setForm(f => ({...f, subject_id: e.target.value}))} required
                  className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                  <option value="">-- Sélectionner une matière --</option>
                  {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2.5">Catégorie de classes (optionnel)</label>
                <div className="grid grid-cols-3 gap-2">
                  {[{v: "college", l: "Collège"}, {v: "lycee", l: "Lycée"}, {v: "both", l: "Les deux"}].map(c => {
                    const isActive = form.class_category === c.v;
                    return (
                      <button key={c.v} type="button" onClick={() => setForm(f => ({...f, class_category: f.class_category === c.v ? "" : c.v, class_ids: []}))} 
                        className={isActive ? "px-3 py-2 rounded-lg border-2 text-xs font-medium transition-all bg-blue-600 text-white border-blue-600" : "px-3 py-2 rounded-lg border-2 text-xs font-medium transition-all border-border hover:border-muted-foreground"}
                      >
                        {c.l}
                      </button>
                    );
                  })}
                </div>
                {form.class_category && (
                  <div className="mt-3 space-y-2">
                    <p className="text-xs text-muted-foreground font-semibold">Classes disponibles :</p>
                    <div className="flex flex-wrap gap-2">
                      {classes.filter(c => {
                        if (form.class_category === "college") return COLLEGE_LEVELS.includes(c.level);
                        if (form.class_category === "lycee") return LYCEE_LEVELS.includes(c.level);
                        return COLLEGE_LEVELS.includes(c.level) || LYCEE_LEVELS.includes(c.level);
                      }).map(c => {
                        const isSelected = form.class_ids.includes(c.id);
                        return (
                          <button key={c.id} type="button" onClick={() => setForm(f => ({...f, class_ids: f.class_ids.includes(c.id) ? f.class_ids.filter(id => id !== c.id) : [...f.class_ids, c.id]}))} 
                            className={isSelected ? "text-xs px-2.5 py-1 rounded-lg border-2 font-medium transition-all bg-green-100 border-green-600 text-green-700" : "text-xs px-2.5 py-1 rounded-lg border-2 font-medium transition-all border-border hover:bg-muted"}
                          >
                            {c.name}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Names */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-1.5">Nom de famille *</label>
              <input type="text" value={form.last_name} onChange={e => setForm(f => ({ ...f, last_name: e.target.value }))}
                placeholder="Ex: KONE" className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring uppercase" required />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-1.5">Prénom *</label>
              <input type="text" value={form.first_name} onChange={e => setForm(f => ({ ...f, first_name: e.target.value }))}
                placeholder="Ex: YAHAYA" className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" required />
            </div>
          </div>

          {/* Birth date */}
          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Date de naissance *</label>
            <input type="date" value={form.birth_date} onChange={e => setForm(f => ({ ...f, birth_date: e.target.value }))}
              className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" required />
          </div>

          {/* Email (optional) */}
          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">
              Email de connexion <span className="text-muted-foreground font-normal">(laissez vide pour génération automatique)</span>
            </label>
            <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
              placeholder={form.role === 'teacher' ? 'Ex: kone@professeur.is' : 'Ex: kone@direction.is'}
              className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>

          {/* Password */}
          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Mot de passe initial</label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input type={showPwd ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)}
                  className="w-full border border-input rounded-lg px-3 py-2.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring pr-10" />
                <button type="button" onClick={() => setShowPwd(p => !p)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <button type="button" onClick={() => setPassword(generatePassword())}
                className="px-3 py-2 border border-input rounded-lg hover:bg-muted transition-colors">
                <RefreshCw className="h-4 w-4 text-muted-foreground" />
              </button>
            </div>
          </div>

          {/* Code preview */}
          {previewCode && (
            <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
              <p className="text-xs text-muted-foreground mb-1">Code permanent qui sera généré :</p>
              <p className="font-mono font-bold text-primary text-xl tracking-wider">{previewCode}</p>
            </div>
          )}

          <button type="submit" disabled={saving || !form.last_name || !form.first_name || !form.birth_date || (form.role === "teacher" && !form.subject_id)}
            className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl px-4 py-3 font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60"
          >
            {saving ? "Création en cours…" : (<><UserPlus className="h-5 w-5" />Créer le compte</>)}
          </button>
        </form>
      )}
    </div>
  );
}