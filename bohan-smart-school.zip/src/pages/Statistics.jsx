import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { BarChart3, TrendingUp, Award, Users } from "lucide-react";
import { getSchoolId } from "../hooks/useSchool";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import PageHeader from "../components/PageHeader";
import StatCard from "../components/StatCard";

const COLORS = ["hsl(215, 60%, 28%)", "hsl(42, 80%, 55%)", "hsl(160, 50%, 40%)", "hsl(280, 50%, 55%)", "hsl(350, 65%, 55%)"];

export default function Statistics() {
  const [students, setStudents] = useState([]);
  const [grades, setGrades] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      const [s, g, sub, c] = await Promise.all([
        base44.entities.Student.filter(filter),
        base44.entities.Grade.filter(filter),
        base44.entities.Subject.filter(filter),
        base44.entities.Class.filter(filter),
      ]);
      setStudents(s);
      setGrades(g);
      setSubjects(sub);
      setClasses(c);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  // Compute stats
  const totalAvg = grades.length > 0
    ? Math.round((grades.reduce((s, g) => s + g.score, 0) / grades.length) * 100) / 100
    : 0;

  const passing = grades.filter((g) => g.score >= 10).length;
  const passRate = grades.length > 0 ? Math.round((passing / grades.length) * 100) : 0;

  // Subject averages
  const subjectMap = {};
  subjects.forEach((s) => (subjectMap[s.id] = s.name));
  const subjectAvgs = {};
  grades.forEach((g) => {
    const name = subjectMap[g.subject_id] || "Autre";
    if (!subjectAvgs[name]) subjectAvgs[name] = { total: 0, count: 0 };
    subjectAvgs[name].total += g.score;
    subjectAvgs[name].count += 1;
  });
  const subjectChartData = Object.entries(subjectAvgs)
    .map(([name, v]) => ({ name, moyenne: Math.round((v.total / v.count) * 100) / 100 }))
    .sort((a, b) => b.moyenne - a.moyenne);

  // Distribution
  const distribution = [
    { name: "0-5", count: grades.filter((g) => g.score < 5).length },
    { name: "5-8", count: grades.filter((g) => g.score >= 5 && g.score < 8).length },
    { name: "8-10", count: grades.filter((g) => g.score >= 8 && g.score < 10).length },
    { name: "10-12", count: grades.filter((g) => g.score >= 10 && g.score < 12).length },
    { name: "12-14", count: grades.filter((g) => g.score >= 12 && g.score < 14).length },
    { name: "14-16", count: grades.filter((g) => g.score >= 14 && g.score < 16).length },
    { name: "16-18", count: grades.filter((g) => g.score >= 16 && g.score < 18).length },
    { name: "18-20", count: grades.filter((g) => g.score >= 18).length },
  ];

  // Gender distribution
  const genderData = [
    { name: "Masculin", value: students.filter((s) => s.gender === "Masculin").length },
    { name: "Féminin", value: students.filter((s) => s.gender === "Féminin").length },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title="Statistiques" subtitle="Performance globale de l'établissement" />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Users} label="Total élèves" value={students.length} />
        <StatCard icon={BarChart3} label="Moyenne générale" value={`${totalAvg}/20`} />
        <StatCard icon={TrendingUp} label="Taux de réussite" value={`${passRate}%`} subtitle="Notes ≥ 10" />
        <StatCard icon={Award} label="Notes saisies" value={grades.length} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject averages */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-sm font-semibold mb-4">Moyenne par matière</h3>
          {subjectChartData.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">Aucune donnée</div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={subjectChartData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" domain={[0, 20]} fontSize={11} tick={{ fill: "hsl(var(--muted-foreground))" }} />
                <YAxis type="category" dataKey="name" fontSize={11} width={100} tick={{ fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
                <Bar dataKey="moyenne" fill="hsl(var(--primary))" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Note distribution */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-sm font-semibold mb-4">Distribution des notes</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={distribution}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" fontSize={11} tick={{ fill: "hsl(var(--muted-foreground))" }} />
              <YAxis fontSize={11} tick={{ fill: "hsl(var(--muted-foreground))" }} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
              <Bar dataKey="count" fill="hsl(var(--secondary))" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Gender pie chart */}
      <div className="bg-card rounded-xl border border-border p-5 max-w-md">
        <h3 className="text-sm font-semibold mb-4">Répartition par genre</h3>
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie data={genderData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={5} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
              {genderData.map((entry, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}