/**
 * ParentView — Vue dédiée aux parents pour suivre leur enfant :
 *  - Emploi du temps + présences en temps réel
 *  - Notes & moyennes
 *  - Bulletins
 *  - Devoirs & examens
 */
import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import {
  Users, Calendar, ClipboardList, TrendingUp, FileText,
  CheckCircle2, XCircle, Clock, AlertCircle, GraduationCap,
  ChevronDown, BookOpen, BarChart3,
} from "lucide-react";
import StudentSchedule from "./StudentSchedule";
import StudentAttendanceTab from "./StudentAttendanceTab";

function scoreColor(v) {
  if (v === null || v === undefined) return "text-muted-foreground";
  if (v >= 14) return "text-green-600";
  if (v >= 10) return "text-yellow-600";
  return "text-red-600";
}
function scoreBg(v) {
  if (v === null || v === undefined) return "bg-muted text-muted-foreground";
  if (v >= 14) return "bg-green-100 text-green-700";
  if (v >= 10) return "bg-yellow-100 text-yellow-700";
  return "bg-red-100 text-red-700";
}
function avg(arr) {
  if (!arr.length) return null;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}
function wavg(arr) {
  if (!arr.length) return null;
  const tot = arr.reduce((a, b) => a + b.coef, 0);
  if (!tot) return null;
  return arr.reduce((a, b) => a + b.score * b.coef, 0) / tot;
}

const PARENT_TABS = [
  { id: "overview", label: "Vue d'ensemble", icon: BarChart3 },
  { id: "schedule", label: "Emploi du temps", icon: Calendar },
  { id: "attendance", label: "Présences", icon: CheckCircle2 },
  { id: "grades", label: "Notes", icon: ClipboardList },
  { id: "exams", label: "Devoirs & Examens", icon: BookOpen },
  { id: "bulletin", label: "Bulletin", icon: FileText },
];

export default function ParentView({ student, classObj, subjects, grades, exams, bulletins, settings, schedules, periods, periodType, getPeriodAvg, annualAvg }) {
  const [tab, setTab] = useState("overview");
  const [recentAttendance, setRecentAttendance] = useState([]);
  const [selectedPeriod, setSelectedPeriod] = useState(periods[0] || "");

  // Fetch recent attendance for overview
  useEffect(() => {
    if (!student?.id) return;
    base44.entities.AttendanceSession.filter({ student_id: student.id })
      .then(sessions => {
        const sorted = sessions.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0)).slice(0, 10);
        setRecentAttendance(sorted);
      });
  }, [student?.id]);

  const subjectMap = {};
  subjects.forEach(s => (subjectMap[s.id] = s));

  const absencesCount = recentAttendance.filter(s => s.status === "absent").length;
  const presentsCount = recentAttendance.filter(s => s.status === "présent").length;

  const upcomingExams = exams
    .filter(e => e.date && new Date(e.date) >= new Date())
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  function getSubjectAvgs(period) {
    const pGrades = period === "all" ? grades : grades.filter(g => g.trimester === period);
    const subIds = [...new Set(pGrades.map(g => g.subject_id))];
    return subIds.map(sid => {
      const sGs = pGrades.filter(g => g.subject_id === sid);
      const s = subjectMap[sid];
      return { subject: s, avg: avg(sGs.map(g => g.score)), count: sGs.length };
    }).filter(x => x.subject).sort((a, b) => a.subject.name.localeCompare(b.subject.name));
  }

  const STATUS_CONFIG = {
    présent:         { label: "Présent",          color: "bg-emerald-100 text-emerald-700", icon: CheckCircle2 },
    absent:          { label: "Absent",           color: "bg-red-100 text-red-700",         icon: XCircle },
    retard:          { label: "Retard",           color: "bg-amber-100 text-amber-700",     icon: Clock },
    absent_justifié: { label: "Abs. justifiée",   color: "bg-blue-100 text-blue-700",       icon: AlertCircle },
  };

  return (
    <div className="space-y-4">
      {/* Student identity banner */}
      <div className="bg-gradient-to-r from-violet-600 to-blue-600 rounded-2xl p-4 text-white flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-white/20 border-2 border-white/40 flex items-center justify-center overflow-hidden shrink-0">
          {student.photo_url
            ? <img src={student.photo_url} alt="photo" className="w-full h-full object-cover" />
            : <span className="text-2xl font-bold">{student.first_name?.[0]?.toUpperCase()}</span>
          }
        </div>
        <div>
          <p className="text-xs opacity-70 uppercase tracking-wide">Espace Parent</p>
          <p className="text-lg font-bold">{student.last_name} {student.first_name}</p>
          <p className="text-sm opacity-80">{classObj?.name} • {classObj?.academic_year}</p>
        </div>
        <div className="ml-auto text-right shrink-0">
          {annualAvg !== null && (
            <>
              <p className="text-xs opacity-70">Moyenne annuelle</p>
              <p className={`text-2xl font-extrabold ${annualAvg >= 10 ? "text-green-300" : "text-red-300"}`}>
                {annualAvg.toFixed(2)}/20
              </p>
            </>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border overflow-x-auto">
        {PARENT_TABS.map(t => {
          const Icon = t.icon;
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-2.5 text-sm font-medium whitespace-nowrap transition-colors ${
                tab === t.id ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"
              }`}>
              <Icon className="h-4 w-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* ── Vue d'ensemble ── */}
      {tab === "overview" && (
        <div className="space-y-4">
          {/* KPI Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-card border border-border rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-green-600">{presentsCount}</p>
              <p className="text-xs text-muted-foreground mt-1">Présences récentes</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-red-500">{absencesCount}</p>
              <p className="text-xs text-muted-foreground mt-1">Absences récentes</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-blue-600">{grades.length}</p>
              <p className="text-xs text-muted-foreground mt-1">Notes saisies</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-violet-600">{upcomingExams.length}</p>
              <p className="text-xs text-muted-foreground mt-1">Examens à venir</p>
            </div>
          </div>

          {/* Moyennes par période */}
          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" /> Moyennes par période
            </p>
            <div className={`grid gap-3 ${periods.length === 2 ? "grid-cols-2" : "grid-cols-3"}`}>
              {periods.map((p, idx) => {
                const a = getPeriodAvg(p);
                return (
                  <div key={p} className={`rounded-xl p-3 text-center border ${a !== null ? scoreBg(a) : "bg-muted border-border"}`}>
                    <p className="text-xs font-medium mb-1">{p}</p>
                    <p className={`text-xl font-bold ${scoreColor(a)}`}>{a !== null ? `${a.toFixed(2)}/20` : "—"}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 10 dernières présences */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="bg-muted/40 px-4 py-3 border-b border-border">
              <p className="text-sm font-bold text-foreground">📋 10 dernières présences</p>
            </div>
            {recentAttendance.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-6">Aucune présence enregistrée</p>
            ) : (
              <div className="divide-y divide-border">
                {recentAttendance.map(session => {
                  const cfg = STATUS_CONFIG[session.status] || STATUS_CONFIG["présent"];
                  const Icon = cfg.icon;
                  return (
                    <div key={session.id} className="flex items-center gap-3 px-4 py-3">
                      <span className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${cfg.color}`}>
                        <Icon className="h-4 w-4" />
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{session.subject_name}</p>
                        <p className="text-xs text-muted-foreground">
                          {session.date ? new Date(session.date).toLocaleDateString("fr-FR", { weekday: "short", day: "2-digit", month: "short" }) : "—"}
                          {session.start_time ? ` • ${session.start_time}–${session.end_time}` : ""}
                        </p>
                      </div>
                      <span className={`text-xs font-semibold px-2 py-1 rounded-full ${cfg.color}`}>{cfg.label}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Prochain examen */}
          {upcomingExams.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <p className="text-sm font-bold text-amber-900 mb-2">⚠️ Prochain devoir / examen</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-200 flex items-center justify-center shrink-0">
                  <BookOpen className="h-5 w-5 text-amber-700" />
                </div>
                <div>
                  <p className="font-semibold text-amber-900">{upcomingExams[0].title || upcomingExams[0].exam_type}</p>
                  <p className="text-xs text-amber-700">
                    {subjectMap[upcomingExams[0].subject_id]?.name} •{" "}
                    {new Date(upcomingExams[0].date).toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long" })}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Emploi du temps ── */}
      {tab === "schedule" && (
        <StudentSchedule classId={student?.class_id} />
      )}

      {/* ── Présences ── */}
      {tab === "attendance" && (
        <StudentAttendanceTab studentId={student?.id} subjects={subjects} />
      )}

      {/* ── Notes ── */}
      {tab === "grades" && (
        <div className="space-y-4">
          {periods.map(period => {
            const pGrades = grades.filter(g => g.trimester === period);
            if (!pGrades.length) return null;
            return (
              <div key={period}>
                <h3 className="text-sm font-semibold text-foreground mb-3">{period}</h3>
                <div className="space-y-2">
                  {pGrades.map(g => {
                    const exam = exams.find(e => e.id === g.exam_id);
                    return (
                      <div key={g.id} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
                        <div className={`w-14 h-14 rounded-xl flex items-center justify-center shrink-0 font-bold text-base ${scoreBg(g.score)}`}>
                          {g.score}/{g.max_score || 20}
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">{subjectMap[g.subject_id]?.name || "Matière"}</p>
                          <p className="text-sm text-muted-foreground">{exam?.title || g.exam_type} • {g.exam_type}</p>
                          {g.comment && <p className="text-xs text-muted-foreground mt-1 italic">{g.comment}</p>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
          {!grades.length && (
            <p className="text-center text-sm text-muted-foreground bg-card rounded-xl border border-border p-6">Aucune note enregistrée</p>
          )}
        </div>
      )}

      {/* ── Devoirs & Examens ── */}
      {tab === "exams" && (
        <div className="space-y-4">
          {upcomingExams.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-3">À venir</h3>
              <div className="space-y-2">
                {upcomingExams.map(exam => (
                  <div key={exam.id} className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-200 flex items-center justify-center shrink-0">
                      <BookOpen className="h-5 w-5 text-amber-700" />
                    </div>
                    <div>
                      <p className="font-semibold text-amber-900">{exam.title || exam.exam_type}</p>
                      <p className="text-xs text-amber-700">
                        {subjectMap[exam.subject_id]?.name} •{" "}
                        {new Date(exam.date).toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long" })}
                      </p>
                      {exam.description && <p className="text-xs text-amber-600 mt-1 italic">{exam.description}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-3">Passés</h3>
            <div className="space-y-2">
              {exams.filter(e => !e.date || new Date(e.date) < new Date()).sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0)).map(exam => {
                const grade = grades.find(g => g.exam_id === exam.id);
                return (
                  <div key={exam.id} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center shrink-0">
                      <ClipboardList className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-foreground">{exam.title || exam.exam_type}</p>
                      <p className="text-xs text-muted-foreground">{subjectMap[exam.subject_id]?.name}</p>
                    </div>
                    {grade && (
                      <span className={`text-sm font-bold px-3 py-1 rounded-lg ${scoreBg(grade.score)}`}>
                        {grade.score}/{grade.max_score || 20}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── Bulletin ── */}
      {tab === "bulletin" && (
        <div className="space-y-4">
          <div className="flex gap-2 flex-wrap">
            {periods.map(p => (
              <button key={p} onClick={() => setSelectedPeriod(p)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  selectedPeriod === p ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"
                }`}>
                {p}
              </button>
            ))}
          </div>
          {(() => {
            const bulletin = bulletins.find(b => b.trimester === selectedPeriod);
            const trimAvg = getPeriodAvg(selectedPeriod);
            const subAvgs = getSubjectAvgs(selectedPeriod);
            return (
              <div className="bg-card rounded-xl border-2 border-border overflow-hidden">
                <div className="bg-primary text-primary-foreground p-4 text-center">
                  <p className="text-xs opacity-80">{settings?.republic_name || "RÉPUBLIQUE"}</p>
                  <p className="text-sm font-bold">{settings?.school_name || "Établissement"}</p>
                </div>
                <div className="p-5 space-y-4">
                  <div className="grid grid-cols-2 gap-2 text-sm border border-border rounded-lg p-3">
                    <div><span className="text-xs text-muted-foreground">Nom : </span><span className="font-semibold">{student.last_name} {student.first_name}</span></div>
                    <div><span className="text-xs text-muted-foreground">Classe : </span><span className="font-semibold">{classObj?.name}</span></div>
                    <div><span className="text-xs text-muted-foreground">Période : </span><span className="font-semibold">{selectedPeriod}</span></div>
                    {bulletin && (
                      <>
                        <div><span className="text-xs text-muted-foreground">Absences just. : </span><span>{bulletin.absences_justified || 0}h</span></div>
                        <div><span className="text-xs text-muted-foreground">Absences non just. : </span><span>{bulletin.absences_unjustified || 0}h</span></div>
                      </>
                    )}
                  </div>
                  {subAvgs.length > 0 ? (
                    <table className="w-full text-sm border border-border rounded-lg overflow-hidden">
                      <thead>
                        <tr className="bg-muted/50 border-b border-border">
                          <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Matière</th>
                          <th className="text-center py-2 px-3 text-xs font-semibold text-muted-foreground">Coeff.</th>
                          <th className="text-center py-2 px-3 text-xs font-semibold text-muted-foreground">Moyenne</th>
                        </tr>
                      </thead>
                      <tbody>
                        {subAvgs.map(({ subject, avg: a }) => (
                          <tr key={subject.id} className="border-b border-border/50">
                            <td className="py-2 px-3 font-medium">{subject.name}</td>
                            <td className="py-2 px-3 text-center text-muted-foreground">{subject.coefficient}</td>
                            <td className="py-2 px-3 text-center">
                              <span className={`font-bold ${scoreColor(a)}`}>{a !== null ? a.toFixed(2) : "—"}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="bg-muted/30 font-bold border-t border-border">
                          <td colSpan={2} className="py-2 px-3 text-sm">Moyenne de la période</td>
                          <td className="py-2 px-3 text-center">
                            <span className={`text-base font-bold ${scoreColor(trimAvg)}`}>
                              {trimAvg !== null ? trimAvg.toFixed(2) : "—"}/20
                            </span>
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  ) : (
                    <p className="text-center text-sm text-muted-foreground py-6">Aucune note pour cette période</p>
                  )}
                  {bulletin?.council_appreciation && (
                    <div className="border border-border rounded-lg p-3">
                      <p className="text-xs text-muted-foreground mb-1">Appréciation du conseil :</p>
                      <p className="text-sm italic">{bulletin.council_appreciation}</p>
                    </div>
                  )}
                  {bulletin?.distinction && bulletin.distinction !== "Aucune" && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-center">
                      <p className="text-xs text-yellow-700 font-semibold">🏆 {bulletin.distinction}</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}