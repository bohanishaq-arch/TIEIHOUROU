import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { CheckCircle2, XCircle, Clock, AlertCircle, Calendar, BookOpen, TrendingDown, Filter, ChevronDown, ChevronUp } from "lucide-react";

const STATUS_CONFIG = {
  présent:         { label: "Présent",         color: "bg-emerald-100 text-emerald-700 border-emerald-200", dot: "bg-emerald-500", icon: CheckCircle2 },
  absent:          { label: "Absent",          color: "bg-red-100 text-red-700 border-red-200",             dot: "bg-red-500",     icon: XCircle },
  retard:          { label: "Retard",          color: "bg-amber-100 text-amber-700 border-amber-200",       dot: "bg-amber-500",   icon: Clock },
  absent_justifié: { label: "Abs. justifié",   color: "bg-blue-100 text-blue-700 border-blue-200",          dot: "bg-blue-500",    icon: AlertCircle },
};

export default function StudentAttendanceTab({ studentId, subjects }) {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterSubject, setFilterSubject] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterMonth, setFilterMonth] = useState("all");
  const [expandedDays, setExpandedDays] = useState({});

  useEffect(() => {
    if (!studentId) return;
    base44.entities.AttendanceSession.filter({ student_id: studentId }, "-date", 500)
      .then(s => { setSessions(s); setLoading(false); });
  }, [studentId]);

  const subjectMap = useMemo(() => {
    const m = {};
    subjects.forEach(s => m[s.id] = s);
    return m;
  }, [subjects]);

  // Stats
  const stats = useMemo(() => {
    const total = sessions.length;
    const présents = sessions.filter(s => s.status === "présent").length;
    const absents = sessions.filter(s => s.status === "absent").length;
    const justif = sessions.filter(s => s.status === "absent_justifié").length;
    const retards = sessions.filter(s => s.status === "retard").length;
    const absHours = sessions
      .filter(s => s.status === "absent" || s.status === "absent_justifié")
      .reduce((sum, s) => sum + (s.duration_hours || 1), 0);
    const presHours = sessions
      .filter(s => s.status === "présent" || s.status === "retard")
      .reduce((sum, s) => sum + (s.duration_hours || 1), 0);
    const tauxPresence = total > 0 ? Math.round((présents / total) * 100) : 100;
    return { total, présents, absents, justif, retards, absHours, presHours, tauxPresence };
  }, [sessions]);

  // By subject stats
  const bySubject = useMemo(() => {
    const map = {};
    sessions.forEach(s => {
      if (!map[s.subject_id]) map[s.subject_id] = { name: s.subject_name, présents: 0, absents: 0, retards: 0, justif: 0, absHours: 0, total: 0 };
      map[s.subject_id].total++;
      if (s.status === "présent") map[s.subject_id].présents++;
      else if (s.status === "absent") { map[s.subject_id].absents++; map[s.subject_id].absHours += (s.duration_hours || 1); }
      else if (s.status === "retard") map[s.subject_id].retards++;
      else if (s.status === "absent_justifié") { map[s.subject_id].justif++; map[s.subject_id].absHours += (s.duration_hours || 1); }
    });
    return Object.values(map).sort((a, b) => b.absents - a.absents);
  }, [sessions]);

  // Filtered sessions
  const filtered = useMemo(() => {
    return sessions.filter(s => {
      if (filterSubject !== "all" && s.subject_id !== filterSubject) return false;
      if (filterStatus !== "all" && s.status !== filterStatus) return false;
      if (filterMonth !== "all" && s.date?.slice(0, 7) !== filterMonth) return false;
      return true;
    });
  }, [sessions, filterSubject, filterStatus, filterMonth]);

  // Group by date
  const byDate = useMemo(() => {
    const map = {};
    filtered.forEach(s => {
      if (!map[s.date]) map[s.date] = [];
      map[s.date].push(s);
    });
    return Object.entries(map).sort((a, b) => b[0].localeCompare(a[0]));
  }, [filtered]);

  // Months for filter
  const months = useMemo(() => {
    const m = [...new Set(sessions.map(s => s.date?.slice(0, 7)).filter(Boolean))].sort((a, b) => b.localeCompare(a));
    return m;
  }, [sessions]);

  if (loading) return (
    <div className="flex items-center justify-center h-32">
      <div className="w-6 h-6 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="space-y-5">
      {/* ── Summary Stats ── */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Taux de présence", value: `${stats.tauxPresence}%`, color: stats.tauxPresence >= 90 ? "text-emerald-600" : stats.tauxPresence >= 75 ? "text-amber-600" : "text-red-600", bg: "bg-white border-border" },
          { label: "Heures de présence", value: `${stats.presHours.toFixed(1)}h`, color: "text-emerald-600", bg: "bg-white border-border" },
          { label: "Heures d'absence", value: `${stats.absHours.toFixed(1)}h`, color: "text-red-600", bg: "bg-white border-border" },
          { label: "Absences injustifiées", value: stats.absents, color: "text-red-700", bg: stats.absents >= 3 ? "bg-red-50 border-red-200" : "bg-white border-border" },
        ].map(card => (
          <div key={card.label} className={`rounded-xl border p-4 ${card.bg}`}>
            <p className="text-xs text-muted-foreground font-medium mb-1">{card.label}</p>
            <p className={`text-2xl font-black ${card.color}`}>{card.value}</p>
          </div>
        ))}
      </div>

      {/* Alert if many absences */}
      {stats.absents >= 3 && (
        <div className="flex items-start gap-3 bg-red-50 border-2 border-red-200 rounded-xl p-4">
          <TrendingDown className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-red-800 text-sm">⚠️ Absences répétées détectées</p>
            <p className="text-xs text-red-700 mt-0.5">{stats.absents} absence(s) injustifiée(s) enregistrée(s). Pensez à contacter l'établissement.</p>
          </div>
        </div>
      )}

      {/* ── By Subject ── */}
      <div className="bg-white border border-border rounded-xl overflow-hidden">
        <div className="bg-muted/40 px-4 py-3 border-b border-border">
          <p className="text-sm font-bold text-foreground">Résumé par matière</p>
        </div>
        <div className="divide-y divide-border">
          {bySubject.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">Aucune donnée disponible</p>
          ) : bySubject.map(sub => (
            <div key={sub.name} className="px-4 py-3 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm text-foreground truncate">{sub.name}</p>
                <div className="flex gap-2 mt-1 flex-wrap">
                  <span className="text-[10px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-full font-semibold">{sub.présents} présents</span>
                  <span className="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded-full font-semibold">{sub.absents} absents</span>
                  {sub.retards > 0 && <span className="text-[10px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full font-semibold">{sub.retards} retards</span>}
                  {sub.justif > 0 && <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-full font-semibold">{sub.justif} justifiés</span>}
                </div>
              </div>
              <div className="text-right shrink-0">
                <p className={`text-lg font-black ${sub.absHours > 3 ? "text-red-600" : sub.absHours > 0 ? "text-amber-600" : "text-emerald-600"}`}>
                  {sub.absHours.toFixed(1)}h
                </p>
                <p className="text-[10px] text-muted-foreground">d'absence</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Filters ── */}
      <div className="flex flex-wrap gap-2">
        <select value={filterSubject} onChange={e => setFilterSubject(e.target.value)}
          className="h-8 rounded-lg border border-input bg-background px-2 text-xs focus:outline-none">
          <option value="all">Toutes matières</option>
          {[...new Set(sessions.map(s => s.subject_id))].map(id => {
            const name = sessions.find(s => s.subject_id === id)?.subject_name || id;
            return <option key={id} value={id}>{name}</option>;
          })}
        </select>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="h-8 rounded-lg border border-input bg-background px-2 text-xs focus:outline-none">
          <option value="all">Tous statuts</option>
          {Object.entries(STATUS_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <select value={filterMonth} onChange={e => setFilterMonth(e.target.value)}
          className="h-8 rounded-lg border border-input bg-background px-2 text-xs focus:outline-none">
          <option value="all">Tous les mois</option>
          {months.map(m => <option key={m} value={m}>{new Date(m + "-01").toLocaleDateString("fr-FR", { month: "long", year: "numeric" })}</option>)}
        </select>
        <span className="text-xs text-muted-foreground self-center ml-auto">{filtered.length} séance(s)</span>
      </div>

      {/* ── History by date ── */}
      <div className="space-y-3">
        {byDate.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground text-sm bg-card border border-border rounded-xl">
            <Calendar className="h-10 w-10 mx-auto mb-2 opacity-30" />
            Aucune séance trouvée
          </div>
        ) : byDate.map(([date, daySessions]) => {
          const dayAbsents = daySessions.filter(s => s.status === "absent" || s.status === "absent_justifié").length;
          const isExpanded = expandedDays[date] !== false; // default open
          return (
            <div key={date} className="bg-white border border-border rounded-xl overflow-hidden">
              <button
                onClick={() => setExpandedDays(prev => ({ ...prev, [date]: !isExpanded }))}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors text-left">
                <Calendar className="h-4 w-4 text-muted-foreground shrink-0" />
                <span className="font-semibold text-sm text-foreground flex-1">
                  {new Date(date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}
                </span>
                <span className="text-xs text-muted-foreground">{daySessions.length} cours</span>
                {dayAbsents > 0 && (
                  <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-bold">{dayAbsents} absence{dayAbsents > 1 ? "s" : ""}</span>
                )}
                {isExpanded ? <ChevronUp className="h-4 w-4 text-muted-foreground shrink-0" /> : <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />}
              </button>
              {isExpanded && (
                <div className="border-t border-border divide-y divide-border/50">
                  {daySessions.sort((a, b) => (a.start_time || "").localeCompare(b.start_time || "")).map(session => {
                    const cfg = STATUS_CONFIG[session.status] || STATUS_CONFIG.présent;
                    const Icon = cfg.icon;
                    return (
                      <div key={session.id} className={`flex items-center gap-3 px-4 py-3 ${session.status !== "présent" ? "bg-red-50/30" : ""}`}>
                        <div className="text-center min-w-[52px]">
                          {session.start_time && <p className="text-xs font-bold text-foreground">{session.start_time}</p>}
                          {session.end_time && <p className="text-[10px] text-muted-foreground">{session.end_time}</p>}
                        </div>
                        <div className="w-px h-8 bg-border shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm text-foreground">{session.subject_name}</p>
                          {session.teacher_name && <p className="text-xs text-muted-foreground">👨‍🏫 {session.teacher_name}</p>}
                          {session.reason && <p className="text-xs text-muted-foreground italic mt-0.5">Motif: {session.reason}</p>}
                        </div>
                        {session.duration_hours && (
                          <span className="text-xs text-muted-foreground shrink-0">{session.duration_hours}h</span>
                        )}
                        <div className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border shrink-0 ${cfg.color}`}>
                          <Icon className="h-3.5 w-3.5" />
                          {cfg.label}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}