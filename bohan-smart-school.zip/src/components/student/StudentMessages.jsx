import { useState } from "react";
import { Bell, Mail, MailOpen, Megaphone, Clock, MessageSquare, ChevronDown, ChevronUp, BookOpen, ClipboardList, FlaskConical, BookMarked } from "lucide-react";

export default function StudentMessages({ upcomingExams, subjects, teacherReports, openedMessages, setOpenedMessages }) {
  const [msgTab, setMsgTab] = useState("reports");
  const [expandedReports, setExpandedReports] = useState({});
  const [expandedExams, setExpandedExams] = useState({});

  const examAlerts = upcomingExams.map(exam => {
    const daysUntil = Math.ceil((new Date(exam.date) - new Date()) / (1000 * 60 * 60 * 24));
    const subjName = subjects.find(s => s.id === exam.subject_id)?.name || "Matière";
    const isUrgent = daysUntil <= 3;
    const isSoon = daysUntil <= 7;
    const isRead = openedMessages.includes(exam.id);
    return { exam, daysUntil, subjName, isUrgent, isSoon, isRead };
  });

  const unreadAlerts = examAlerts.filter(m => !m.isRead).length;
  const urgentCount = examAlerts.filter(m => m.isUrgent && !m.isRead).length;

  function markRead(examId) {
    const updated = [...new Set([...openedMessages, examId])];
    setOpenedMessages(updated);
    localStorage.setItem("bohan_opened_msgs", JSON.stringify(updated));
  }

  function toggleReport(id) {
    setExpandedReports(prev => ({ ...prev, [id]: !prev[id] }));
  }

  function toggleExam(id) {
    setExpandedExams(prev => ({ ...prev, [id]: !prev[id] }));
    markRead(id);
  }

  const typeConfig = {
    cours:  { label: "📖 Cours",    color: "bg-blue-100 text-blue-700",   icon: BookOpen },
    devoir: { label: "📝 Devoir",   color: "bg-amber-100 text-amber-700", icon: ClipboardList },
    examen: { label: "🧪 Examen",   color: "bg-purple-100 text-purple-700", icon: FlaskConical },
  };

  return (
    <div className="space-y-3">
      {/* Sub-tabs */}
      <div className="flex gap-1 bg-muted rounded-xl p-1">
        <button onClick={() => setMsgTab("reports")}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-sm font-medium rounded-lg transition-colors ${msgTab === "reports" ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
          <MessageSquare className="h-4 w-4" />
          Messages des professeurs
          {teacherReports.length > 0 && (
            <span className="bg-primary text-primary-foreground text-[10px] px-1.5 rounded-full">{teacherReports.length}</span>
          )}
        </button>
        <button onClick={() => setMsgTab("alerts")}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-sm font-medium rounded-lg transition-colors ${msgTab === "alerts" ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
          <Bell className="h-4 w-4" />
          Alertes examens
          {unreadAlerts > 0 && (
            <span className="bg-red-500 text-white text-[10px] px-1.5 rounded-full animate-pulse">{unreadAlerts}</span>
          )}
        </button>
      </div>

      {/* ── Teacher Reports ── */}
      {msgTab === "reports" && (
        <div className="space-y-3">
          {teacherReports.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center">
              <MessageSquare className="h-14 w-14 text-muted-foreground/30 mx-auto mb-3" />
              <p className="font-semibold text-foreground">Aucun message</p>
              <p className="text-sm text-muted-foreground mt-1">Vos professeurs n'ont pas encore envoyé de rapports.</p>
            </div>
          ) : (
            teacherReports.map((r) => {
              const cfg = typeConfig[r.report_type] || { label: r.report_type, color: "bg-muted text-muted-foreground", icon: BookMarked };
              const Icon = cfg.icon;
              const isExpanded = !!expandedReports[r.id];
              const hasMore = r.content || r.objectives || r.activities || r.remarks || r.due_date || r.duration || r.competencies || r.grading_scale;

              return (
                <div key={r.id} className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
                  {/* Header */}
                  <div className="flex items-start gap-3 px-4 py-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${cfg.color}`}>
                          {cfg.label}
                        </span>
                        {r.subject_name && (
                          <span className="text-[10px] bg-muted text-muted-foreground px-2 py-0.5 rounded-full">{r.subject_name}</span>
                        )}
                        {r.date && (
                          <span className="text-[10px] text-muted-foreground">
                            {new Date(r.date).toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long" })}
                          </span>
                        )}
                      </div>
                      {/* Title — always fully visible */}
                      <p className="font-bold text-foreground text-sm leading-snug">{r.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{r.teacher_name || "Professeur"}{r.class_name ? ` · ${r.class_name}` : ""}</p>
                    </div>
                    {hasMore && (
                      <button onClick={() => toggleReport(r.id)}
                        className="shrink-0 w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-muted-foreground/20 transition-colors ml-2 mt-0.5">
                        {isExpanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                      </button>
                    )}
                  </div>

                  {/* Expandable full content */}
                  {isExpanded && hasMore && (
                    <div className="border-t border-border px-4 pb-4 pt-3 space-y-2.5 bg-muted/10">
                      {r.objectives && (
                        <div className="bg-blue-50 border border-blue-100 rounded-xl px-3 py-2.5">
                          <p className="text-[10px] font-bold text-blue-600 uppercase tracking-wide mb-1">🎯 Objectifs</p>
                          <p className="text-sm text-foreground whitespace-pre-wrap">{r.objectives}</p>
                        </div>
                      )}
                      {r.content && (
                        <div className="bg-muted/50 border border-border rounded-xl px-3 py-2.5">
                          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide mb-1">📄 Contenu du cours</p>
                          <p className="text-sm text-foreground whitespace-pre-wrap">{r.content}</p>
                        </div>
                      )}
                      {r.activities && (
                        <div className="bg-green-50 border border-green-100 rounded-xl px-3 py-2.5">
                          <p className="text-[10px] font-bold text-green-700 uppercase tracking-wide mb-1">⚡ Activités réalisées</p>
                          <p className="text-sm text-foreground whitespace-pre-wrap">{r.activities}</p>
                        </div>
                      )}
                      {r.competencies && (
                        <div className="bg-violet-50 border border-violet-100 rounded-xl px-3 py-2.5">
                          <p className="text-[10px] font-bold text-violet-700 uppercase tracking-wide mb-1">🧠 Compétences évaluées</p>
                          <p className="text-sm text-foreground whitespace-pre-wrap">{r.competencies}</p>
                        </div>
                      )}
                      {r.grading_scale && (
                        <div className="bg-orange-50 border border-orange-100 rounded-xl px-3 py-2.5">
                          <p className="text-[10px] font-bold text-orange-700 uppercase tracking-wide mb-1">📊 Barème</p>
                          <p className="text-sm text-foreground whitespace-pre-wrap">{r.grading_scale}</p>
                        </div>
                      )}
                      {r.remarks && (
                        <div className="bg-amber-50 border border-amber-100 rounded-xl px-3 py-2.5">
                          <p className="text-[10px] font-bold text-amber-700 uppercase tracking-wide mb-1">💬 Remarques</p>
                          <p className="text-sm text-foreground whitespace-pre-wrap">{r.remarks}</p>
                        </div>
                      )}
                      {(r.due_date || r.duration) && (
                        <div className="flex gap-3 flex-wrap">
                          {r.due_date && (
                            <span className="flex items-center gap-1.5 text-sm font-semibold text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-1.5">
                              📅 À rendre le : {new Date(r.due_date).toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}
                            </span>
                          )}
                          {r.duration && (
                            <span className="flex items-center gap-1.5 text-sm font-semibold text-blue-700 bg-blue-50 border border-blue-200 rounded-lg px-3 py-1.5">
                              ⏱ Durée : {r.duration}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* "Voir plus" button if not expanded and there's content */}
                  {!isExpanded && hasMore && (
                    <div className="px-4 pb-3">
                      <button onClick={() => toggleReport(r.id)}
                        className="w-full flex items-center justify-center gap-1.5 text-xs text-primary font-semibold bg-primary/5 hover:bg-primary/10 rounded-xl py-2 transition-colors border border-primary/20">
                        <ChevronDown className="h-3.5 w-3.5" />
                        Voir le contenu complet
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ── Exam Alerts ── */}
      {msgTab === "alerts" && (
        <div className="space-y-3">
          {/* Header summary */}
          <div className="bg-card border border-border rounded-2xl px-5 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Bell className="h-5 w-5 text-primary" />
                {unreadAlerts > 0 && (
                  <span className="absolute -top-2 -right-2 min-w-[18px] h-[18px] bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center px-0.5">
                    {unreadAlerts}
                  </span>
                )}
              </div>
              <div>
                <h2 className="font-bold text-foreground text-base">Alertes examens à venir</h2>
                <p className="text-xs text-muted-foreground">
                  {unreadAlerts > 0 ? `${unreadAlerts} alerte${unreadAlerts > 1 ? "s" : ""} non lue${unreadAlerts > 1 ? "s" : ""}` : "Tout est lu"}
                </p>
              </div>
            </div>
            {urgentCount > 0 && (
              <div className="flex items-center gap-1.5 bg-red-500 text-white text-xs font-bold px-3 py-1.5 rounded-full animate-pulse">
                <Megaphone className="h-3.5 w-3.5" />
                {urgentCount} URGENT{urgentCount > 1 ? "S" : ""}
              </div>
            )}
          </div>

          {examAlerts.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center">
              <MailOpen className="h-14 w-14 text-muted-foreground/30 mx-auto mb-3" />
              <p className="font-semibold text-foreground">Aucun examen à venir</p>
              <p className="text-sm text-muted-foreground mt-1">Profitez-en pour réviser !</p>
            </div>
          ) : (
            examAlerts.map(({ exam, daysUntil, subjName, isUrgent, isSoon, isRead }) => {
              const isExpanded = !!expandedExams[exam.id];
              const hasMore = exam.description || exam.chapter || exam.duration_minutes || exam.teacher_name;

              return (
                <div key={exam.id}
                  className={`bg-card border rounded-2xl overflow-hidden shadow-sm transition-colors ${
                    isUrgent && !isRead ? "border-red-300" : isSoon && !isRead ? "border-amber-300" : "border-border"
                  } ${!isRead ? "bg-blue-50/30" : ""}`}>

                  {/* Main info — always fully visible */}
                  <div className="flex items-start gap-4 px-4 py-4 cursor-pointer" onClick={() => toggleExam(exam.id)}>
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                      isUrgent ? "bg-red-100" : isSoon ? "bg-amber-100" : "bg-blue-100"
                    }`}>
                      {!isRead
                        ? <Mail className={`h-5 w-5 ${isUrgent ? "text-red-600" : isSoon ? "text-amber-600" : "text-blue-600"}`} />
                        : <MailOpen className="h-5 w-5 text-muted-foreground" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        {isUrgent && !isRead && (
                          <span className="text-[10px] font-bold text-white bg-red-500 px-1.5 py-0.5 rounded-full uppercase">🔴 URGENT</span>
                        )}
                        {isSoon && !isUrgent && !isRead && (
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-200 px-1.5 py-0.5 rounded-full uppercase">⚠️ BIENTÔT</span>
                        )}
                        <span className="text-[10px] bg-purple-100 text-purple-700 font-semibold px-2 py-0.5 rounded-full">{exam.exam_type}</span>
                      </div>
                      {/* Title — always full */}
                      <p className={`font-bold text-sm leading-snug ${!isRead ? "text-foreground" : "text-muted-foreground"}`}>
                        {exam.title || subjName}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Matière : <span className="font-semibold text-foreground">{subjName}</span>
                        {exam.chapter ? ` · ${exam.chapter}` : ""}
                      </p>
                      <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                        <span className={`flex items-center gap-1 text-xs font-bold ${isUrgent ? "text-red-600" : isSoon ? "text-amber-600" : "text-blue-600"}`}>
                          <Clock className="h-3 w-3" />
                          {daysUntil === 0 ? "Aujourd'hui !" : daysUntil === 1 ? "Demain !" : `Dans ${daysUntil} jours`}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          📅 {new Date(exam.date).toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}
                        </span>
                      </div>
                    </div>
                    {hasMore && (
                      <div className="shrink-0 mt-0.5">
                        {isExpanded
                          ? <ChevronUp className="h-4 w-4 text-muted-foreground" />
                          : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                      </div>
                    )}
                    {!isRead && (
                      <div className={`w-2.5 h-2.5 rounded-full mt-2 shrink-0 ${isUrgent ? "bg-red-500" : "bg-blue-500"}`} />
                    )}
                  </div>

                  {/* Expanded details */}
                  {isExpanded && hasMore && (
                    <div className="border-t border-border px-4 pb-4 pt-3 space-y-2.5 bg-muted/10">
                      {exam.description && (
                        <div className="bg-card border border-border rounded-xl px-3 py-2.5">
                          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide mb-1">📋 Description / Instructions</p>
                          <p className="text-sm text-foreground whitespace-pre-wrap">{exam.description}</p>
                        </div>
                      )}
                      {exam.chapter && (
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-muted-foreground">📚 Chapitre :</span>
                          <span className="font-semibold text-foreground">{exam.chapter}</span>
                        </div>
                      )}
                      {exam.duration_minutes && (
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-muted-foreground">⏱ Durée :</span>
                          <span className="font-semibold text-foreground">{exam.duration_minutes} minutes</span>
                        </div>
                      )}
                      {exam.teacher_name && (
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-muted-foreground">👨‍🏫 Professeur :</span>
                          <span className="font-semibold text-foreground">{exam.teacher_name}</span>
                        </div>
                      )}
                      {exam.max_score && (
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-muted-foreground">📊 Barème :</span>
                          <span className="font-semibold text-foreground">/{exam.max_score}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* "Voir détails" if has more and not expanded */}
                  {!isExpanded && hasMore && (
                    <div className="px-4 pb-3">
                      <button onClick={() => toggleExam(exam.id)}
                        className="w-full flex items-center justify-center gap-1.5 text-xs text-primary font-semibold bg-primary/5 hover:bg-primary/10 rounded-xl py-2 transition-colors border border-primary/20">
                        <ChevronDown className="h-3.5 w-3.5" />
                        Voir les détails complets
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}