import { useState } from "react";
import { BookOpen, Download, ChevronDown, ChevronUp, FileText, CheckCircle } from "lucide-react";

const typeColors = {
  "Devoir": "bg-blue-100 text-blue-700",
  "Interrogation": "bg-purple-100 text-purple-700",
  "Examen trimestriel": "bg-red-100 text-red-700",
  "TP": "bg-green-100 text-green-700",
  "Oral": "bg-orange-100 text-orange-700",
};

function ExamCard({ exam, grade, subjectMap, scoreBg }) {
  const [open, setOpen] = useState(false);
  const hasCorrection = exam.correction_published && (exam.correction_file_url || exam.correction_text);

  return (
    <div className={`bg-card border rounded-xl overflow-hidden transition-all ${hasCorrection ? "border-emerald-200" : "border-border"}`}>
      <div className="p-4 flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center shrink-0">
          <BookOpen className="h-5 w-5 text-indigo-600" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="font-semibold text-foreground text-sm">{exam.title || exam.exam_type}</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {subjectMap[exam.subject_id]?.name || "—"}
                {exam.date && ` • ${new Date(exam.date).toLocaleDateString("fr-FR")}`}
              </p>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${typeColors[exam.exam_type] || "bg-muted text-muted-foreground"}`}>
                  {exam.exam_type}
                </span>
                {hasCorrection && (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 flex items-center gap-1">
                    <CheckCircle className="h-3 w-3" /> Correction disponible
                  </span>
                )}
              </div>
            </div>
            {grade && (
              <span className={`text-sm font-bold px-3 py-1 rounded-xl shrink-0 ${scoreBg(grade.score)}`}>
                {grade.score}/{grade.max_score || 20}
              </span>
            )}
          </div>

          {exam.description && (
            <p className="text-xs text-muted-foreground mt-2 italic">{exam.description}</p>
          )}

          {/* Bouton voir correction */}
          {hasCorrection && (
            <button
              onClick={() => setOpen(!open)}
              className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-emerald-700 hover:text-emerald-800 transition-colors"
            >
              {open ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
              {open ? "Masquer la correction" : "Voir la correction"}
            </button>
          )}
        </div>
      </div>

      {/* Correction panel */}
      {open && hasCorrection && (
        <div className="border-t border-emerald-100 bg-emerald-50 p-4 space-y-3">
          <p className="text-xs font-bold text-emerald-800 uppercase tracking-wide">✅ Correction du professeur</p>

          {exam.correction_text && (
            <div className="bg-white rounded-xl border border-emerald-200 p-3">
              <p className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">{exam.correction_text}</p>
            </div>
          )}

          {exam.correction_file_url && (
            <a
              href={exam.correction_file_url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-white border border-emerald-200 rounded-xl px-4 py-3 hover:bg-emerald-100 transition-colors w-full"
            >
              <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center shrink-0">
                <FileText className="h-4 w-4 text-emerald-700" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-emerald-800">Télécharger / Voir le fichier de correction</p>
                <p className="text-[10px] text-emerald-600">PDF ou image</p>
              </div>
              <Download className="h-4 w-4 text-emerald-600 shrink-0" />
            </a>
          )}
        </div>
      )}
    </div>
  );
}

export default function StudentExamsTab({ exams, grades, subjects, subjectMap, periods, scoreBg }) {
  const upcoming = exams
    .filter(e => e.date && new Date(e.date) >= new Date())
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  const past = exams
    .filter(e => !e.date || new Date(e.date) < new Date())
    .sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));

  function getGradeForExam(exam) {
    return grades.find(g => g.exam_id === exam.id);
  }

  if (!exams.length) {
    return (
      <div className="text-center py-12">
        <BookOpen className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
        <p className="text-muted-foreground font-medium">Aucun devoir ou examen enregistré</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {upcoming.length > 0 && (
        <div>
          <h3 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-orange-500 inline-block" />
            À venir ({upcoming.length})
          </h3>
          <div className="space-y-3">
            {upcoming.map(exam => (
              <ExamCard key={exam.id} exam={exam} grade={getGradeForExam(exam)} subjectMap={subjectMap} scoreBg={scoreBg} />
            ))}
          </div>
        </div>
      )}

      {past.length > 0 && (
        <div>
          <h3 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-gray-400 inline-block" />
            Passés ({past.length})
          </h3>
          <div className="space-y-3">
            {past.map(exam => (
              <ExamCard key={exam.id} exam={exam} grade={getGradeForExam(exam)} subjectMap={subjectMap} scoreBg={scoreBg} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}