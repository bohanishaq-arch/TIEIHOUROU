import { useState, useMemo } from "react";
import {
  BookOpen, ClipboardList, TrendingUp, FileText, DollarSign,
  Calendar, GraduationCap, ChevronRight, AlertTriangle, Bell,
  CheckCircle2, Clock, Star, Award
} from "lucide-react";
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  LineChart, Line, XAxis, YAxis, CartesianGrid, Legend
} from "recharts";

const MONTHS_FR = ["Sept", "Oct", "Nov", "Déc", "Janv", "Fév", "Mars", "Avr", "Mai", "Jun"];

function scoreColor(v) {
  if (v === null || v === undefined) return "text-muted-foreground";
  if (v >= 14) return "text-emerald-600";
  if (v >= 10) return "text-amber-600";
  return "text-red-600";
}
function scoreBadge(v) {
  if (v === null || v === undefined) return { label: "—", cls: "bg-slate-100 text-slate-500" };
  if (v >= 16) return { label: "Excellente", cls: "bg-emerald-100 text-emerald-700" };
  if (v >= 14) return { label: "Très bien", cls: "bg-green-100 text-green-700" };
  if (v >= 12) return { label: "Bien", cls: "bg-blue-100 text-blue-700" };
  if (v >= 10) return { label: "Passable", cls: "bg-amber-100 text-amber-700" };
  return { label: "Insuffisant", cls: "bg-red-100 text-red-700" };
}

export default function StudentDashboardTab({
  student, classObj, settings, grades, exams, subjects,
  enrollmentData, schedules, annualAvg, getPeriodAvg, periods, periodType,
  onTabChange
}) {
  const subjectMap = useMemo(() => {
    const m = {};
    subjects.forEach(s => m[s.id] = s);
    return m;
  }, [subjects]);

  // ── Donut chart data ─────────────────────────────────────────────────────
  const noteDistribution = useMemo(() => {
    const high = grades.filter(g => g.score >= 14).length;
    const mid  = grades.filter(g => g.score >= 10 && g.score < 14).length;
    const low  = grades.filter(g => g.score < 10).length;
    const total = grades.length;
    return { high, mid, low, total };
  }, [grades]);

  const donutData = [
    { name: "Notes élevées", value: noteDistribution.high, color: "#10b981" },
    { name: "Notes moyennes", value: noteDistribution.mid, color: "#f59e0b" },
    { name: "Notes faibles", value: noteDistribution.low, color: "#ef4444" },
  ].filter(d => d.value > 0);

  // ── Evolution line chart ─────────────────────────────────────────────────
  const evolutionData = useMemo(() => {
    // Build a fake progression based on exam dates or period averages
    const sorted = [...grades].sort((a, b) => {
      const ea = exams.find(e => e.id === a.exam_id);
      const eb = exams.find(e => e.id === b.exam_id);
      return new Date(ea?.date || 0) - new Date(eb?.date || 0);
    });

    // Group by period
    const byPeriod = {};
    grades.forEach(g => {
      if (!byPeriod[g.trimester]) byPeriod[g.trimester] = [];
      byPeriod[g.trimester].push(g.score);
    });

    const result = [];
    periods.forEach((p, i) => {
      const scores = byPeriod[p];
      if (scores?.length) {
        const a = scores.reduce((s, v) => s + v, 0) / scores.length;
        result.push({ period: p.replace("Trimestre ", "T").replace("Semestre ", "S"), avg: parseFloat(a.toFixed(2)) });
      }
    });
    return result;
  }, [grades, exams, periods]);

  // ── Upcoming exams ───────────────────────────────────────────────────────
  const upcomingExams = useMemo(() =>
    exams.filter(e => e.date && new Date(e.date) >= new Date())
         .sort((a, b) => new Date(a.date) - new Date(b.date))
         .slice(0, 3),
    [exams]
  );

  // ── Next course from schedules ────────────────────────────────────────────
  const nextCourse = useMemo(() => {
    if (!schedules?.length) return null;
    const DAYS = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
    const today = DAYS[new Date().getDay()];
    const now = new Date().toTimeString().slice(0,5);
    const todayCourses = schedules
      .filter(s => s.day === today && s.start_time > now)
      .sort((a,b) => a.start_time.localeCompare(b.start_time));
    return todayCourses[0] || null;
  }, [schedules]);

  // ── Financial status ─────────────────────────────────────────────────────
  const finStatus = enrollmentData?.payment_status;

  // ── Alerts ───────────────────────────────────────────────────────────────
  const alerts = useMemo(() => {
    const list = [];
    if (finStatus === "en_attente" || finStatus === "partiel") {
      list.push({ type: "warning", title: "Paiement en attente", sub: "Frais de scolarité — rapprochez-vous du comptable", action: "fees" });
    }
    if (upcomingExams.length > 0) {
      const e = upcomingExams[0];
      const sub = subjectMap[e.subject_id];
      list.push({ type: "info", title: "Prochain devoir / examen", sub: `${sub?.name || "Matière"} — ${e.date ? new Date(e.date).toLocaleDateString("fr-FR") : "Date à confirmer"}`, action: "exams" });
    }
    const recent = [...grades].sort((a,b) => new Date(b.updated_date||0) - new Date(a.updated_date||0))[0];
    if (recent) {
      const sub = subjectMap[recent.subject_id];
      list.push({ type: "success", title: "Nouvelle note publiée", sub: `${sub?.name || "Matière"} — Consulte ta note`, action: "grades" });
    }
    return list.slice(0, 3);
  }, [finStatus, upcomingExams, grades, subjectMap]);

  const badge = scoreBadge(annualAvg);
  const schoolYear = classObj?.academic_year || `${new Date().getFullYear()}-${new Date().getFullYear()+1}`;

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-white border border-gray-200 rounded-xl shadow-lg p-3 text-xs">
        <p className="font-bold text-gray-700 mb-1">{label}</p>
        <p className="text-primary font-semibold">{payload[0]?.value}/20</p>
      </div>
    );
  };

  return (
    <div className="space-y-6">

      {/* ── Hero Banner ─────────────────────────────────────────────────── */}
      <div className="relative rounded-2xl overflow-hidden shadow-xl"
        style={{ background: "linear-gradient(135deg, #1e3a8a 0%, #3730a3 40%, #6d28d9 100%)" }}>

        {/* School silhouette background */}
        <div className="absolute right-0 top-0 bottom-0 w-56 opacity-10 pointer-events-none"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 240 160'%3E%3Crect x='70' y='50' width='100' height='90' fill='white'/%3E%3Crect x='95' y='75' width='25' height='40' fill='%231e3a8a'/%3E%3Crect x='130' y='75' width='20' height='28' fill='%231e3a8a'/%3E%3Cpolygon points='120,15 60,52 180,52' fill='white'/%3E%3Ccircle cx='120' cy='32' r='7' fill='%23fbbf24'/%3E%3Crect x='55' y='50' width='130' height='10' fill='white' opacity='0.7'/%3E%3C/svg%3E")`,
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center right",
            backgroundSize: "contain"
          }}
        />

        <div className="relative p-6 flex items-center gap-5">
          {/* Avatar / Photo */}
          <div className="relative shrink-0">
            <div className="w-20 h-20 rounded-full border-4 border-white/40 overflow-hidden bg-white/20 flex items-center justify-center shadow-lg">
              {student.photo_url
                ? <img src={student.photo_url} alt="photo" className="w-full h-full object-cover" />
                : <span className="text-3xl font-bold text-white/80">{student.first_name?.[0]?.toUpperCase()}</span>
              }
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-400 rounded-full border-2 border-white" />
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-black text-white tracking-wide uppercase">
              {student.last_name} {student.first_name}
            </h1>
            <div className="flex flex-wrap gap-2 mt-2">
              {classObj && (
                <span className="bg-white/20 text-white/90 text-xs font-bold px-3 py-1 rounded-full">{classObj.name}</span>
              )}
              <span className="bg-white/20 text-white/90 text-xs font-mono px-3 py-1 rounded-full">{student.student_number}</span>
              <span className="bg-emerald-400/80 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                <div className="w-1.5 h-1.5 bg-white rounded-full" /> Élève actif
              </span>
            </div>
          </div>

          {/* Stats block */}
          <div className="hidden sm:flex flex-col items-end text-right shrink-0">
            <div className="flex items-center gap-1.5 mb-1">
              <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
              <span className="text-xs text-white/70 font-medium">Moyenne générale</span>
            </div>
            {annualAvg !== null ? (
              <span className="text-4xl font-black text-white">{annualAvg.toFixed(2)}<span className="text-xl font-normal opacity-60">/20</span></span>
            ) : (
              <span className="text-2xl font-bold text-white/50">—/20</span>
            )}
            <div className="text-xs text-white/60 mt-1">Année scolaire {schoolYear}</div>
          </div>
        </div>
      </div>

      {/* ── 4 Summary Cards ─────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Moyenne */}
        <div onClick={() => onTabChange("averages")}
          className="bg-white border border-blue-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer group relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-blue-50 rounded-full -translate-y-4 translate-x-4" />
          <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mb-3">
            <BookOpen className="h-5 w-5 text-blue-600" />
          </div>
          <p className="text-xs text-muted-foreground font-medium mb-0.5">Moyenne générale</p>
          <p className="text-2xl font-black text-blue-700">{annualAvg !== null ? annualAvg.toFixed(2) : "—"}<span className="text-sm font-normal text-muted-foreground">/20</span></p>
          <p className={`text-xs font-semibold mt-1 ${badge.cls} inline-block px-2 py-0.5 rounded-full`}>{badge.label}</p>
          <ChevronRight className="absolute bottom-4 right-4 h-4 w-4 text-blue-300 group-hover:text-blue-500 transition-colors" />
        </div>

        {/* Examens à venir */}
        <div onClick={() => onTabChange("exams")}
          className="bg-white border border-emerald-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer group relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-50 rounded-full -translate-y-4 translate-x-4" />
          <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center mb-3">
            <ClipboardList className="h-5 w-5 text-emerald-600" />
          </div>
          <p className="text-xs text-muted-foreground font-medium mb-0.5">Devoirs en attente</p>
          <p className="text-2xl font-black text-emerald-700">{upcomingExams.length}</p>
          <p className="text-xs text-muted-foreground mt-1">À compléter</p>
          <ChevronRight className="absolute bottom-4 right-4 h-4 w-4 text-emerald-300 group-hover:text-emerald-500 transition-colors" />
        </div>

        {/* Situation financière */}
        <div onClick={() => onTabChange("fees")}
          className="bg-white border border-amber-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer group relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-amber-50 rounded-full -translate-y-4 translate-x-4" />
          <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center mb-3">
            <DollarSign className="h-5 w-5 text-amber-600" />
          </div>
          <p className="text-xs text-muted-foreground font-medium mb-0.5">Situation financière</p>
          {finStatus === "complet"
            ? <><p className="text-xl font-black text-emerald-600">À jour</p><p className="text-xs text-muted-foreground mt-1">Aucun impayé</p></>
            : finStatus === "partiel"
            ? <><p className="text-xl font-black text-amber-600">Partiel</p><p className="text-xs text-muted-foreground mt-1">Solde restant</p></>
            : finStatus === "en_attente"
            ? <><p className="text-xl font-black text-red-600">En attente</p><p className="text-xs text-muted-foreground mt-1">À régulariser</p></>
            : <><p className="text-xl font-black text-muted-foreground">—</p><p className="text-xs text-muted-foreground mt-1">Non renseigné</p></>
          }
          <ChevronRight className="absolute bottom-4 right-4 h-4 w-4 text-amber-300 group-hover:text-amber-500 transition-colors" />
        </div>

        {/* Prochain cours */}
        <div onClick={() => onTabChange("schedule")}
          className="bg-white border border-purple-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer group relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-purple-50 rounded-full -translate-y-4 translate-x-4" />
          <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center mb-3">
            <Calendar className="h-5 w-5 text-purple-600" />
          </div>
          <p className="text-xs text-muted-foreground font-medium mb-0.5">Prochain cours</p>
          {nextCourse
            ? <><p className="text-lg font-black text-purple-700 leading-tight">{nextCourse.subject_name || "Cours"}</p><p className="text-xs text-muted-foreground mt-1">Aujourd'hui · {nextCourse.start_time}</p></>
            : <><p className="text-lg font-black text-muted-foreground">—</p><p className="text-xs text-muted-foreground mt-1">Aucun cours imminent</p></>
          }
          <ChevronRight className="absolute bottom-4 right-4 h-4 w-4 text-purple-300 group-hover:text-purple-500 transition-colors" />
        </div>
      </div>

      {/* ── Charts Row ──────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Donut chart */}
        <div className="bg-white border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Répartition des notes</h3>
          {noteDistribution.total > 0 ? (
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="relative w-44 h-44 shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={donutData} cx="50%" cy="50%" innerRadius={48} outerRadius={72} dataKey="value" strokeWidth={2} stroke="#fff">
                      {donutData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                    </Pie>
                    <Tooltip formatter={(v, n) => [`${v} notes`, n]} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <p className="text-xs text-muted-foreground">Total</p>
                  <p className="text-2xl font-black text-foreground">{noteDistribution.total}</p>
                  <p className="text-[10px] text-muted-foreground">Matières</p>
                </div>
              </div>
              <div className="space-y-2.5 flex-1">
                {[
                  { label: "Notes élevées", count: noteDistribution.high, total: noteDistribution.total, color: "bg-emerald-500", desc: "≥ 14/20" },
                  { label: "Notes moyennes", count: noteDistribution.mid, total: noteDistribution.total, color: "bg-amber-400", desc: "10–13/20" },
                  { label: "Notes faibles", count: noteDistribution.low, total: noteDistribution.total, color: "bg-red-500", desc: "< 10/20" },
                ].map(({ label, count, total, color, desc }) => (
                  <div key={label} className="flex items-center gap-2.5">
                    <span className={`w-3 h-3 rounded-full shrink-0 ${color}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between text-xs mb-0.5">
                        <span className="font-medium text-foreground">{label}</span>
                        <span className="text-muted-foreground">{total > 0 ? Math.round(count/total*100) : 0}% ({count})</span>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${color}`} style={{ width: total > 0 ? `${count/total*100}%` : "0%" }} />
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{desc}</p>
                    </div>
                  </div>
                ))}
                {noteDistribution.high / noteDistribution.total >= 0.5 && (
                  <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2 mt-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                    <p className="text-xs text-emerald-700 font-semibold">Bravo ! Tu maintiens d'excellents résultats.</p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center py-10 text-muted-foreground text-sm">Aucune note enregistrée</div>
          )}
        </div>

        {/* Line chart */}
        <div className="bg-white border border-border rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-foreground">Évolution de la moyenne</h3>
          </div>
          {evolutionData.length > 1 ? (
            <>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={evolutionData} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 20]} tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} width={28} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line
                    type="monotone"
                    dataKey="avg"
                    name="Moyenne"
                    stroke="#6d28d9"
                    strokeWidth={2.5}
                    dot={{ r: 5, fill: "#6d28d9", stroke: "#fff", strokeWidth: 2 }}
                    activeDot={{ r: 7 }}
                  />
                </LineChart>
              </ResponsiveContainer>
              <div className="flex items-center gap-2 mt-2">
                <span className="w-8 h-0.5 bg-purple-600 inline-block rounded-full" />
                <span className="text-xs text-muted-foreground">Moyenne générale /20</span>
              </div>
            </>
          ) : (
            <div className="text-center py-10 text-muted-foreground text-sm">Données insuffisantes pour tracer l'évolution</div>
          )}
        </div>
      </div>

      {/* ── Bottom Row: Quick Actions + Alerts + Card ────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Quick Actions */}
        <div className="bg-white border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Actions rapides</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "Mes notes", icon: BookOpen, color: "bg-blue-100 text-blue-600", tab: "grades" },
              { label: "Devoirs & Examens", icon: ClipboardList, color: "bg-emerald-100 text-emerald-600", tab: "exams" },
              { label: "Emploi du temps", icon: Calendar, color: "bg-purple-100 text-purple-600", tab: "schedule" },
              { label: "Payer mes frais", icon: DollarSign, color: "bg-amber-100 text-amber-600", tab: "fees" },
              { label: "Télécharger bulletin", icon: FileText, color: "bg-red-100 text-red-600", tab: "bulletin" },
              { label: "Mes moyennes", icon: TrendingUp, color: "bg-indigo-100 text-indigo-600", tab: "averages" },
            ].map(({ label, icon: Icon, color, tab }) => (
              <button key={tab} onClick={() => onTabChange(tab)}
                className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-muted/50 transition-all group">
                <div className={`w-10 h-10 rounded-xl ${color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <Icon className="h-5 w-5" />
                </div>
                <span className="text-[10px] font-semibold text-muted-foreground text-center leading-tight">{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Alerts */}
        <div className="bg-white border border-border rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-foreground">Alertes & notifications</h3>
          </div>
          <div className="space-y-3">
            {alerts.length === 0 && (
              <div className="text-center py-6 text-sm text-muted-foreground">Aucune alerte</div>
            )}
            {alerts.map((alert, i) => (
              <button key={i} onClick={() => onTabChange(alert.action)}
                className={`w-full flex items-start gap-3 rounded-xl p-3 border text-left hover:opacity-90 transition-opacity ${
                  alert.type === "warning" ? "bg-amber-50 border-amber-200" :
                  alert.type === "success" ? "bg-emerald-50 border-emerald-200" :
                  "bg-blue-50 border-blue-200"
                }`}>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                  alert.type === "warning" ? "bg-amber-100" :
                  alert.type === "success" ? "bg-emerald-100" :
                  "bg-blue-100"
                }`}>
                  {alert.type === "warning" && <AlertTriangle className="h-4 w-4 text-amber-600" />}
                  {alert.type === "success" && <CheckCircle2 className="h-4 w-4 text-emerald-600" />}
                  {alert.type === "info" && <Clock className="h-4 w-4 text-blue-600" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-bold truncate ${
                    alert.type === "warning" ? "text-amber-800" :
                    alert.type === "success" ? "text-emerald-800" :
                    "text-blue-800"
                  }`}>{alert.title}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{alert.sub}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 mt-1" />
              </button>
            ))}
          </div>
        </div>

        {/* Mini Student Card */}
        <div className="space-y-4">
          <div className="rounded-2xl overflow-hidden shadow-md"
            style={{ background: "linear-gradient(135deg, #1e3a8a 0%, #4338ca 60%, #6d28d9 100%)" }}>
            <div className="p-4 border-b border-white/20 flex items-center justify-between">
              <p className="text-[10px] font-bold text-white/70 uppercase tracking-widest">Carte d'étudiant</p>
              <div className="w-7 h-7 bg-white/20 rounded-lg flex items-center justify-center">
                <GraduationCap className="h-4 w-4 text-white" />
              </div>
            </div>
            <div className="p-4 flex gap-3 items-start">
              <div className="w-14 h-16 rounded-lg bg-white/15 border border-white/30 overflow-hidden shrink-0 flex items-center justify-center">
                {student.photo_url
                  ? <img src={student.photo_url} alt="photo" className="w-full h-full object-cover" />
                  : <span className="text-2xl font-bold text-white/60">{student.first_name?.[0]?.toUpperCase()}</span>
                }
              </div>
              <div className="text-white text-xs space-y-1">
                <p className="font-black text-sm leading-tight">{student.last_name}<br />{student.first_name}</p>
                <p className="text-white/60">Matricule <span className="font-mono font-bold text-white/90">{student.student_number}</span></p>
                <p className="text-white/60">Classe <span className="font-semibold text-white/90">{classObj?.name || "—"}</span></p>
                <p className="text-white/60">Niveau <span className="text-white/90">{classObj?.level || "—"}</span></p>
                <p className="text-white/60">Année <span className="text-white/90">{classObj?.academic_year || "—"}</span></p>
              </div>
            </div>
            {/* QR code placeholder */}
            <div className="px-4 pb-4 flex items-center justify-between">
              <div className="w-12 h-12 bg-white/90 rounded-lg flex items-center justify-center p-1">
                <svg viewBox="0 0 21 21" className="w-full h-full">
                  {/* Simplified QR pattern */}
                  <rect x="0" y="0" width="9" height="9" rx="1" fill="#1e3a8a" />
                  <rect x="1" y="1" width="7" height="7" rx="0.5" fill="white" />
                  <rect x="2" y="2" width="5" height="5" rx="0.5" fill="#1e3a8a" />
                  <rect x="12" y="0" width="9" height="9" rx="1" fill="#1e3a8a" />
                  <rect x="13" y="1" width="7" height="7" rx="0.5" fill="white" />
                  <rect x="14" y="2" width="5" height="5" rx="0.5" fill="#1e3a8a" />
                  <rect x="0" y="12" width="9" height="9" rx="1" fill="#1e3a8a" />
                  <rect x="1" y="13" width="7" height="7" rx="0.5" fill="white" />
                  <rect x="2" y="14" width="5" height="5" rx="0.5" fill="#1e3a8a" />
                  <rect x="11" y="11" width="2" height="2" fill="#1e3a8a" />
                  <rect x="14" y="11" width="2" height="2" fill="#1e3a8a" />
                  <rect x="17" y="11" width="2" height="2" fill="#1e3a8a" />
                  <rect x="11" y="14" width="2" height="2" fill="#1e3a8a" />
                  <rect x="14" y="14" width="2" height="2" fill="#1e3a8a" />
                  <rect x="17" y="17" width="2" height="2" fill="#1e3a8a" />
                  <rect x="11" y="17" width="2" height="2" fill="#1e3a8a" />
                  <rect x="14" y="17" width="2" height="2" fill="#1e3a8a" />
                </svg>
              </div>
              <p className="font-mono text-[9px] text-white/40 tracking-widest">{student.student_number}</p>
            </div>
          </div>

          {/* Next courses mini list */}
          {upcomingExams.length > 0 && (
            <div className="bg-white border border-border rounded-2xl p-4">
              <p className="text-xs font-bold text-foreground mb-3">Prochains examens</p>
              <div className="space-y-2">
                {upcomingExams.map(e => {
                  const sub = subjectMap[e.subject_id];
                  return (
                    <div key={e.id} className="flex items-center gap-2 text-xs">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full shrink-0" />
                      <span className="font-medium text-foreground flex-1 truncate">{sub?.name || "Matière"}</span>
                      <span className="text-muted-foreground shrink-0">{e.date ? new Date(e.date).toLocaleDateString("fr-FR",{day:"2-digit",month:"short"}) : "—"}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}