import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { getVerifiedRole } from "./AccessGate";
import SchoolSelector from "./SchoolSelector";
import { getSchoolId } from "../hooks/useSchool";
import {
  LayoutDashboard,
  Users,
  School,
  UserPlus,
  BookOpen,
  ClipboardList,
  FileText,
  BarChart3,
  GraduationCap,
  X,
  LogOut,
  TrendingUp,
  UserCog,
  Settings,
  ShieldAlert,
  ShieldCheck,
  Building2,
  Send,
  Shield,
  Calendar,
  DollarSign,
} from "lucide-react";
import { base44 } from "@/api/base44Client";

const SUPER_ADMIN_NAV = [
  { label: "Super Admin", icon: Building2, path: "/super-admin" },
];

const ADMIN_NAV = [
  { label: "Tableau de bord", icon: LayoutDashboard, path: "/" },
  { label: "Élèves", icon: Users, path: "/students" },
  { label: "Classes", icon: School, path: "/classes" },
  { label: "Matières", icon: BookOpen, path: "/subjects" },
  { label: "Professeurs", icon: UserCog, path: "/teachers" },
  { label: "Notes", icon: ClipboardList, path: "/grades" },
  { label: "Moyennes", icon: TrendingUp, path: "/averages" },
  { label: "Bulletins", icon: FileText, path: "/reports" },
  { label: "Statistiques", icon: BarChart3, path: "/statistics" },
  { label: "Configuration", icon: Settings, path: "/config" },
  { label: "Accès & Invitations", icon: ShieldAlert, path: "/access-requests" },
  { label: "Identifiants d'accès", icon: ShieldCheck, path: "/manage-access" },
  { label: "Inscription personnel", icon: UserPlus, path: "/inscription" },
  { label: "Demandes d'enseignement", icon: BookOpen, path: "/subject-requests" },
  { label: "Rapports Profs", icon: Send, path: "/teacher-reports" },
  { label: "Emploi du temps", icon: Calendar, path: "/schedule" },
  { label: "Espace Professeur", icon: GraduationCap, path: "/teacher" },
  { label: "Proviseurs & Directeurs", icon: Building2, path: "/directeur-requests" },
];

const EDUCATOR_NAV = [
  { label: "Tableau de bord", icon: Shield, path: "/educateur" },
];

const TEACHER_NAV = [
  { label: "Mon espace", icon: UserCog, path: "/teacher" },
  { label: "Emploi du temps", icon: Calendar, path: "/schedule" },
  { label: "Notes", icon: ClipboardList, path: "/grades" },
  { label: "Bulletins", icon: FileText, path: "/reports" },
];

const STUDENT_NAV = [
  { label: "Ma carte d'identité", icon: GraduationCap, path: "/portal?tab=card" },
  { label: "Emploi du temps", icon: Calendar, path: "/portal?tab=schedule" },
  { label: "Examens à venir", icon: ClipboardList, path: "/portal?tab=exams" },
  { label: "Mes notes", icon: BookOpen, path: "/portal?tab=grades" },
  { label: "Mes moyennes", icon: TrendingUp, path: "/portal?tab=averages" },
  { label: "Bulletins officiels", icon: FileText, path: "/portal?tab=bulletin" },
];

const DIRECTEUR_NAV = [
  { label: "Tableau de bord", icon: LayoutDashboard, path: "/directeur" },
  { label: "Emploi du temps", icon: Calendar, path: "/schedule" },
  { label: "Élèves", icon: Users, path: "/students" },
  { label: "Classes", icon: School, path: "/classes" },
  { label: "Matières", icon: BookOpen, path: "/subjects" },
  { label: "Professeurs", icon: UserCog, path: "/teachers" },
  { label: "Notes", icon: ClipboardList, path: "/grades" },
  { label: "Moyennes", icon: TrendingUp, path: "/averages" },
  { label: "Bulletins", icon: FileText, path: "/reports" },
  { label: "Statistiques", icon: BarChart3, path: "/statistics" },
  { label: "Rapports Profs", icon: Send, path: "/teacher-reports" },
  { label: "Éducateurs", icon: Shield, path: "/directeur-requests" },
  { label: "Identifiants d'accès", icon: ShieldCheck, path: "/manage-access" },
];

const ACCOUNTANT_NAV = [
  { label: "Comptabilité", icon: DollarSign, path: "/comptable" },
];

export default function Sidebar({ onClose }) {
  const location = useLocation();
  const { user } = useAuth();
  const effectiveRole = user?.role === 'admin' ? 'admin' : (getVerifiedRole() || user?.role);
  const isStudent = effectiveRole === "student";
  const isTeacher = effectiveRole === "teacher";
  const isEducator = effectiveRole === "educator";
  const isSuperAdmin = user?.role === "admin";
  const hasSchool = !!getSchoolId();

  const ROLE_LABEL = { admin: "Administrateur", teacher: "Professeur", student: "Élève", user: "Direction", educator: "Éducateur", accountant: "Comptable" };

  // Build nav: super admin items always visible for admins, school-specific items only when a school is selected
  const isDirecteur = effectiveRole === 'user';
  const isAccountant = effectiveRole === 'accountant';

  let navItems;
  if (isStudent) {
    navItems = STUDENT_NAV;
  } else if (isTeacher) {
    navItems = TEACHER_NAV;
  } else if (isEducator) {
    navItems = EDUCATOR_NAV;
  } else if (isAccountant) {
    navItems = ACCOUNTANT_NAV;
  } else if (isDirecteur) {
    navItems = DIRECTEUR_NAV;
  } else if (isSuperAdmin) {
    navItems = hasSchool ? [...SUPER_ADMIN_NAV, ...ADMIN_NAV] : SUPER_ADMIN_NAV;
  } else {
    navItems = ADMIN_NAV;
  }

  return (
    <div className="h-full flex flex-col bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className="flex items-center justify-between h-16 px-5 border-b border-sidebar-border"
        style={{background: 'linear-gradient(135deg, hsl(222,60%,10%) 0%, hsl(222,55%,18%) 100%)'}}>
        <div className="flex items-center gap-2.5">
          <motion.div
            animate={{ y: [0, -4, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center shadow-lg"
          >
            <GraduationCap className="h-5 w-5 text-white" />
          </motion.div>
          <div>
            <h1 className="font-display text-lg font-extrabold text-white tracking-widest" style={{letterSpacing:'0.15em'}}>BOHAN</h1>
            <p className="text-[9px] uppercase tracking-widest text-white/40">Gestion scolaire numérique</p>
          </div>
        </div>
        <button onClick={onClose} className="lg:hidden p-1 rounded hover:bg-sidebar-accent">
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* School selector */}
      <div className="px-0 pt-3">
        <SchoolSelector />
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map((item, i) => {
          const isActive = item.path.includes("?")
          ? location.pathname + location.search === item.path
          : location.pathname === item.path && !location.search;
          return (
            <motion.div
              key={item.path}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.04, duration: 0.2 }}
            >
              <Link
                to={item.path}
                onClick={onClose}
                className={`relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group ${
                  isActive
                    ? "bg-sidebar-primary text-white shadow-lg shadow-black/20"
                    : "text-sidebar-foreground/65 hover:bg-white/10 hover:text-white"
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeNav"
                    className="absolute inset-0 bg-sidebar-primary rounded-xl"
                    style={{ zIndex: -1 }}
                    transition={{ type: "spring", stiffness: 380, damping: 32 }}
                  />
                )}
                <item.icon className={`h-4 w-4 shrink-0 transition-transform duration-200 ${isActive ? "scale-110" : "group-hover:scale-110"}`} />
                <span>{item.label}</span>
              </Link>
            </motion.div>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-3 py-4 border-t border-sidebar-border space-y-1">
        {user && (
          <div className="flex items-center gap-3 px-3 py-2 mb-2 rounded-xl bg-white/5">
            <div className="w-8 h-8 rounded-full bg-sidebar-primary flex items-center justify-center text-white text-xs font-bold shrink-0">
              {(user.full_name || user.email || "?")[0].toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-semibold text-white truncate">{user.full_name || user.email}</p>
              <p className="text-[10px] text-sidebar-foreground/50">{ROLE_LABEL[effectiveRole] || effectiveRole}</p>
            </div>
          </div>
        )}
        <button
          onClick={() => base44.auth.logout()}
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-sidebar-foreground/50 hover:bg-white/10 hover:text-white w-full transition-all duration-200"
        >
          <LogOut className="h-4 w-4" />
          Déconnexion
        </button>
      </div>
    </div>
  );
}