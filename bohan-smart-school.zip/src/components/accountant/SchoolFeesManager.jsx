import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { getVerifiedRole } from "@/components/AccessGate";
import { Lock, Plus, Save, X, Info } from "lucide-react";

const LEVELS = ["6ème","5ème","4ème","3ème","2nde","1ère A","1ère C","1ère D","Tle A","Tle C","Tle D"];

const PLATFORM_FEE_PUBLIC = 500;
const PLATFORM_FEE_PRIVE = 1000;

const EMPTY_FORM = {
  level: "",
  enrollment_fee: 0,
  enrollment_fee_affecte: 0,
  tuition_fee: 0,
  tuition_months: 10,
  advance_amount: 0,
  academic_year: `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`,
  installments_allowed: true,
  max_installments: 3,
};

export default function SchoolFeesManager({ fees, onUpdate, schoolType = "public" }) {
  const platformFee = schoolType === "prive" ? PLATFORM_FEE_PRIVE : PLATFORM_FEE_PUBLIC;
  const { user } = useAuth();
  const verifiedRole = getVerifiedRole();

  // Admin et Directeur peuvent modifier ; Comptable peut seulement ajouter
  const canEdit = user?.role === "admin" || verifiedRole === "user";
  const canAdd = canEdit || verifiedRole === "accountant" || (user?.role !== "admin" && verifiedRole === "accountant");

  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [showAdd, setShowAdd] = useState(false);
  const [addForm, setAddForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  async function handleSaveEdit(fee) {
    setSaving(true);
    await base44.entities.SchoolFees.update(fee.id, {
      enrollment_fee: editForm.enrollment_fee ?? fee.enrollment_fee ?? 0,
      enrollment_fee_affecte: editForm.enrollment_fee_affecte ?? fee.enrollment_fee_affecte ?? 0,
      tuition_fee: editForm.tuition_fee ?? fee.tuition_fee ?? 0,
      tuition_months: editForm.tuition_months ?? fee.tuition_months ?? 10,
      advance_amount: editForm.advance_amount ?? fee.advance_amount ?? 0,
      platform_fee: platformFee,
    });
    setEditingId(null);
    onUpdate && onUpdate();
    setSaving(false);
  }

  async function handleAdd(e) {
    e.preventDefault();
    setSaving(true);
    const schoolId = getSchoolId();
    await base44.entities.SchoolFees.create({ ...addForm, school_id: schoolId, platform_fee: platformFee });
    setShowAdd(false);
    setAddForm(EMPTY_FORM);
    onUpdate && onUpdate();
    setSaving(false);
  }

  // Ni admin, ni directeur, ni comptable
  const isAccountant = verifiedRole === "accountant";
  if (!canEdit && !isAccountant) {
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-3 text-center">
        <div className="w-14 h-14 bg-muted rounded-2xl flex items-center justify-center">
          <Lock className="h-7 w-7 text-muted-foreground" />
        </div>
        <p className="font-semibold text-foreground">Accès restreint</p>
        <p className="text-sm text-muted-foreground max-w-xs">
          Seul le Proviseur / Directeur peut gérer les tarifs scolaires.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {isAccountant && !canEdit
            ? "Vous pouvez consulter et ajouter des tarifs. La modification est réservée au Directeur."
            : "Gérez les frais par niveau et année scolaire."}
        </p>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 bg-primary text-primary-foreground rounded-lg px-3 py-2 text-sm font-semibold hover:bg-primary/90">
          <Plus className="h-4 w-4" /> Ajouter
        </button>
      </div>

      {/* Frais plateforme info */}
      <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-xl px-4 py-2.5 text-xs text-blue-700">
        <Info className="h-4 w-4 shrink-0" />
        <span>Les frais plateforme <strong>BOHAN</strong> sont de <strong>{platformFee.toLocaleString("fr-FR")} XOF</strong> ({schoolType === "prive" ? "établissement privé" : "établissement public"}) et s'appliquent automatiquement à chaque tarif.</span>
      </div>

      {fees.length === 0 && !showAdd && (
        <p className="text-center text-sm text-muted-foreground py-8">Aucun tarif configuré. Cliquez sur "Ajouter" pour commencer.</p>
      )}

      <div className="space-y-3">
        {fees.map(fee => (
          <div key={fee.id} className="bg-card border border-border rounded-xl p-4">
            {editingId === fee.id && canEdit ? (
              <div className="space-y-3">
                <p className="font-semibold text-sm">{fee.level} — {fee.academic_year}</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Inscription — Non-affecté (XOF)</label>
                    <input type="number" value={editForm.enrollment_fee ?? fee.enrollment_fee ?? 0}
                      onChange={e => setEditForm(f => ({ ...f, enrollment_fee: parseInt(e.target.value) }))}
                      className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Inscription — Affecté (XOF)</label>
                    <input type="number" value={editForm.enrollment_fee_affecte ?? fee.enrollment_fee_affecte ?? 0}
                      onChange={e => setEditForm(f => ({ ...f, enrollment_fee_affecte: parseInt(e.target.value) }))}
                      className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Frais de scolarité (XOF)</label>
                    <input type="number" value={editForm.tuition_fee ?? fee.tuition_fee ?? 0}
                      onChange={e => setEditForm(f => ({ ...f, tuition_fee: parseInt(e.target.value) }))}
                      className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Nombre de mois (scolarité)</label>
                    <input type="number" min="1" max="12" value={editForm.tuition_months ?? fee.tuition_months ?? 10}
                      onChange={e => setEditForm(f => ({ ...f, tuition_months: parseInt(e.target.value) }))}
                      className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Avance initiale (XOF)</label>
                    <input type="number" min="0" value={editForm.advance_amount ?? fee.advance_amount ?? 0}
                      placeholder="0"
                      onChange={e => setEditForm(f => ({ ...f, advance_amount: parseInt(e.target.value) }))}
                      className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                </div>
                {/* Frais plateforme non modifiable */}
                <div className="bg-muted/50 border border-border rounded-lg px-3 py-2 flex items-center gap-2 text-xs text-muted-foreground">
                  <Lock className="h-3.5 w-3.5" />
                  Frais plateforme BOHAN : <strong className="text-foreground ml-1">{platformFee.toLocaleString("fr-FR")} XOF</strong> (non modifiable)
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setEditingId(null)} className="border border-input rounded-lg px-3 py-1.5 text-sm hover:bg-muted">Annuler</button>
                  <button onClick={() => handleSaveEdit(fee)} disabled={saving}
                    className="bg-primary text-primary-foreground rounded-lg px-3 py-1.5 text-sm font-semibold flex items-center gap-1 hover:bg-primary/90 disabled:opacity-60">
                    <Save className="h-3.5 w-3.5" />{saving ? "Enregistrement…" : "Sauvegarder"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <p className="font-semibold text-sm">{fee.level} <span className="text-xs text-muted-foreground ml-2">{fee.academic_year}</span></p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-1 mt-2 text-xs">
                  <div>
                    <span className="text-muted-foreground block">Inscription non-affecté</span>
                    <strong className="text-foreground">{(fee.enrollment_fee || 0).toLocaleString("fr-FR")} XOF</strong>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">Inscription affecté</span>
                    <strong className="text-foreground">{(fee.enrollment_fee_affecte || 0).toLocaleString("fr-FR")} XOF</strong>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">Frais de scolarité</span>
                    <strong className="text-foreground">{(fee.tuition_fee || 0).toLocaleString("fr-FR")} XOF</strong>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">Nombre de mois</span>
                    <strong className="text-foreground">{fee.tuition_months || 10} mois</strong>
                  </div>
                  </div>
                  <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                    <Lock className="h-3 w-3" />
                    Frais BOHAN : <strong className="text-foreground ml-1">{platformFee.toLocaleString("fr-FR")} XOF</strong>
                    <span className="ml-3">Total : <strong className="text-foreground">{((fee.enrollment_fee || 0) + (fee.tuition_fee || 0) + platformFee).toLocaleString("fr-FR")} XOF</strong></span>
                  </div>
                </div>
                {canEdit && (
                  <button onClick={() => { setEditingId(fee.id); setEditForm({ enrollment_fee: fee.enrollment_fee ?? 0, enrollment_fee_affecte: fee.enrollment_fee_affecte ?? 0, tuition_fee: fee.tuition_fee ?? 0, tuition_months: fee.tuition_months ?? 10, advance_amount: fee.advance_amount ?? 0 }); }}
                    className="text-xs border border-input rounded-lg px-3 py-1.5 hover:bg-muted font-medium shrink-0">
                    Modifier
                  </button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Add form */}
      {showAdd && (
        <form onSubmit={handleAdd} className="bg-muted/50 border border-border rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="font-semibold text-sm">Nouveau tarif</p>
            <button type="button" onClick={() => setShowAdd(false)} className="w-7 h-7 rounded-full hover:bg-muted flex items-center justify-center"><X className="h-4 w-4" /></button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium block mb-1">Niveau *</label>
              <select value={addForm.level} onChange={e => setAddForm(f => ({ ...f, level: e.target.value }))} required
                className="w-full border border-input rounded-lg px-2 py-1.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                <option value="">-- Choisir --</option>
                {LEVELS.map(l => <option key={l}>{l}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Année scolaire</label>
              <input value={addForm.academic_year} onChange={e => setAddForm(f => ({ ...f, academic_year: e.target.value }))}
                className="w-full border border-input rounded-lg px-2 py-1.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium block mb-1">Inscription — Non-affecté (XOF)</label>
              <input type="number" min="0" value={addForm.enrollment_fee} onChange={e => setAddForm(f => ({ ...f, enrollment_fee: parseInt(e.target.value) }))}
                className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Inscription — Affecté (XOF)</label>
              <input type="number" min="0" value={addForm.enrollment_fee_affecte} onChange={e => setAddForm(f => ({ ...f, enrollment_fee_affecte: parseInt(e.target.value) }))}
                className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Frais de scolarité (XOF)</label>
              <input type="number" min="0" value={addForm.tuition_fee} onChange={e => setAddForm(f => ({ ...f, tuition_fee: parseInt(e.target.value) }))}
                className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Nombre de mois (scolarité)</label>
              <input type="number" min="1" max="12" value={addForm.tuition_months} onChange={e => setAddForm(f => ({ ...f, tuition_months: parseInt(e.target.value) }))}
                className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Avance initiale (XOF)</label>
              <input type="number" min="0" value={addForm.advance_amount} onChange={e => setAddForm(f => ({ ...f, advance_amount: parseInt(e.target.value) }))}
                className="w-full border border-input rounded-lg px-2 py-1.5 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          </div>
          {/* Frais plateforme fixe */}
          <div className="bg-white border border-blue-200 rounded-lg px-3 py-2 flex items-center gap-2 text-xs text-blue-700">
            <Lock className="h-3.5 w-3.5 shrink-0" />
            Frais plateforme BOHAN ({schoolType === "prive" ? "privé" : "public"}) : <strong className="ml-1">{platformFee.toLocaleString("fr-FR")} XOF</strong> (inclus automatiquement, non modifiable)
          </div>
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={() => setShowAdd(false)} className="border border-input rounded-lg px-3 py-1.5 text-sm hover:bg-muted">Annuler</button>
            <button type="submit" disabled={saving || !addForm.level}
              className="bg-primary text-primary-foreground rounded-lg px-4 py-1.5 text-sm font-semibold disabled:opacity-60 hover:bg-primary/90">
              {saving ? "Enregistrement…" : "Ajouter le tarif"}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}