import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { UserPlus, Printer, Check } from "lucide-react";

const LEVELS = ["6ème","5ème","4ème","3ème","2nde","1ère A","1ère C","1ère D","Tle A","Tle C","Tle D"];
const PAYMENT_METHODS = ["espèces","mobile_money","chèque","virement"];

function generateReceiptNumber() {
  const now = new Date();
  return `REC-${now.getFullYear()}${String(now.getMonth()+1).padStart(2,"0")}${String(now.getDate()).padStart(2,"0")}-${Math.floor(Math.random()*9000+1000)}`;
}

function generateStudentNumber(academicYear) {
  const year = academicYear?.split("-")[0] || new Date().getFullYear();
  const seq = String(Math.floor(Math.random() * 9000) + 1000);
  return `SCO-${year}-${seq}`;
}

// Montants BOHAN selon type d'école
const BOHAN_FEE = { public: 500, prive: 1000 };

export default function EnrollmentForm({ classes, fees, schoolId: propSchoolId, schoolInfo, schoolType = "public", onSuccess }) {
  const { user } = useAuth();
  const [step, setStep] = useState(1); // 1=info, 2=paiement
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState(null);
  const [schoolHistory, setSchoolHistory] = useState([]);

  const academicYear = new Date().getFullYear() + "-" + (new Date().getFullYear()+1);
  const [form, setForm] = useState({
    first_name: "", last_name: "", date_of_birth: "", gender: "Masculin",
    status: "Actif", address: "",
    parent_name: "", parent_phone: "", parent_email: "",
    class_id: "", level_requested: "", student_type: "non_affecte",
    academic_year: academicYear,
    student_number: generateStudentNumber(academicYear),
    notes: ""
  });

  const [payment, setPayment] = useState({
    amount_paid: 0, payment_mode: "comptant", payment_method: "espèces"
  });

  // Get fees for selected level — no fallback, must be configured by accountant
  const levelFees = fees.find(f => f.level === form.level_requested) || null;
  const isAffecte = form.student_type === "affecte";
  // Affectés paient SEULEMENT le droit d'inscription (pas la scolarité)
  const enrollmentFee = isAffecte
    ? (levelFees?.enrollment_fee_affecte ?? null)
    : (levelFees?.enrollment_fee ?? null);
  const tuitionFee = isAffecte ? 0 : (levelFees?.tuition_fee ?? null);
  const platformFee = BOHAN_FEE[schoolType] || 500; // Dépend du type d'école
  const advanceAmount = levelFees?.advance_amount ?? 0;
  const tuitionMonths = levelFees?.tuition_months ?? null;
  const feesConfigured = levelFees !== null && enrollmentFee !== null && (isAffecte || tuitionFee !== null);
  const totalFee = feesConfigured ? (enrollmentFee + tuitionFee + platformFee) : 0;

  // Use manually selected class, or auto-find by level
  function findAvailableClass() {
    if (form.class_id) return classes.find(c => c.id === form.class_id) || null;
    const matching = classes.filter(c =>
      c.level === form.level_requested &&
      (c.academic_year === form.academic_year || !c.academic_year)
    );
    return matching[0] || null;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    const schoolId = propSchoolId;
    const assignedClass = findAvailableClass();
    const amountReceived = parseFloat(payment.amount_paid) || 0; // Ce que le parent remet physiquement
    const amountPaid = Math.min(amountReceived, totalFee);       // Montant imputé (jamais > total)
    const changeGiven = Math.max(0, amountReceived - totalFee);  // Monnaie rendue
    const paymentStatus = amountPaid >= totalFee ? "complet" : amountPaid > 0 ? "partiel" : "en_attente";
    const receiptNumber = generateReceiptNumber();

    // 1. Create enrollment
    const enrollment = await base44.entities.Enrollment.create({
      school_id: schoolId,
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      date_of_birth: form.date_of_birth,
      gender: form.gender,
      parent_name: form.parent_name.trim(),
      parent_phone: form.parent_phone.trim(),
      parent_email: form.parent_email.trim() || undefined,
      level_requested: form.level_requested,
      class_id: assignedClass?.id,
      class_name: assignedClass?.name,
      enrollment_fee: enrollmentFee,
      tuition_fee: tuitionFee,
      platform_fee: platformFee,
      total_fee: totalFee,
      amount_paid: amountPaid,
      payment_mode: payment.payment_mode,
      payment_status: paymentStatus,
      enrollment_status: paymentStatus === "complet" ? "validé" : "inscrit",
      accountant_email: user?.email,
      accountant_name: user?.full_name,
      enrollment_date: new Date().toISOString().slice(0,10),
      academic_year: form.academic_year,
      notes: form.notes.trim() || undefined,
    });

    // 2. Record payment if amount > 0
    if (amountPaid > 0) {
      await base44.entities.Payment.create({
        school_id: schoolId,
        enrollment_id: enrollment.id,
        student_name: `${form.first_name} ${form.last_name}`,
        class_name: assignedClass?.name,
        amount: amountPaid,
        payment_type: "inscription",
        payment_date: new Date().toISOString().slice(0,10),
        payment_method: payment.payment_method,
        receipt_number: receiptNumber,
        accountant_email: user?.email,
        accountant_name: user?.full_name,
        academic_year: form.academic_year,
      });
    }

    // 3. Créer automatiquement le dossier élève dès la validation de l'inscription
    const student = await base44.entities.Student.create({
      school_id: schoolId,
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      date_of_birth: form.date_of_birth,
      gender: form.gender,
      address: form.address.trim() || undefined,
      parent_name: form.parent_name.trim(),
      parent_phone: form.parent_phone.trim(),
      parent_email: form.parent_email.trim() || undefined,
      class_id: assignedClass?.id,
      student_number: form.student_number,
      status: form.status,
      school_history: schoolHistory.length > 0 ? schoolHistory : undefined,
    });
    await base44.entities.Enrollment.update(enrollment.id, { student_id: student.id });

    // 4. Enregistrer le revenu BOHAN Group (part automatique sur chaque inscription)
    const bohanAmount = BOHAN_FEE[schoolType] || 500;
    await base44.entities.BohanRevenue.create({
      school_id: schoolId,
      school_name: schoolInfo?.name || "",
      school_type: schoolType,
      enrollment_id: enrollment.id,
      student_name: `${form.first_name} ${form.last_name}`,
      amount: bohanAmount,
      academic_year: form.academic_year,
      enrollment_date: new Date().toISOString().slice(0, 10),
      is_collected: false,
    });

    setResult({ enrollment, receiptNumber, assignedClass, amountPaid, amountReceived, changeGiven, totalFee, paymentStatus, student });
    setSaving(false);
    onSuccess && onSuccess();
  }

  if (result) {
    return (
      <div className="space-y-4">
        <div className="bg-green-50 border-2 border-green-300 rounded-2xl p-5 text-center">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Check className="h-6 w-6 text-green-600" />
          </div>
          <h3 className="font-bold text-green-800 text-lg">Inscription enregistrée !</h3>
          <p className="text-green-700 text-sm mt-1">
            {result.student ? "Élève officiel créé et affecté à " + result.assignedClass?.name : "Inscription enregistrée — paiement en attente"}
          </p>
        </div>

        <div className="bg-card border border-border rounded-xl p-4 space-y-2 text-sm">
          {[
            { label: "Numéro de reçu", value: result.receiptNumber, mono: true },
            { label: "Élève", value: `${result.enrollment.first_name} ${result.enrollment.last_name}` },
            { label: "Classe", value: result.assignedClass?.name || "— (à affecter)"},
            { label: "Total à payer", value: result.totalFee.toLocaleString("fr-FR") + " XOF" },
            { label: "Montant reçu", value: result.amountReceived.toLocaleString("fr-FR") + " XOF" },
            { label: "Montant imputé", value: result.amountPaid.toLocaleString("fr-FR") + " XOF" },
            ...(result.changeGiven > 0 ? [{ label: "💰 Monnaie rendue", value: result.changeGiven.toLocaleString("fr-FR") + " XOF", highlight: true }] : []),
            { label: "Reste dû", value: Math.max(0, result.totalFee - result.amountPaid).toLocaleString("fr-FR") + " XOF" },
            { label: "Statut", value: result.paymentStatus === "complet" ? "✅ Complet" : result.paymentStatus === "partiel" ? "🟡 Partiel" : "🔴 En attente" },
          ].map(({ label, value, mono, highlight }) => (
            <div key={label} className={`flex justify-between py-1 border-b border-border/50 last:border-0 ${highlight ? "bg-amber-50 rounded-lg px-2 -mx-2" : ""}`}>
              <span className={highlight ? "text-amber-700 font-semibold" : "text-muted-foreground"}>{label}</span>
              <span className={`font-semibold ${mono ? "font-mono" : ""} ${highlight ? "text-amber-700" : ""}`}>{value}</span>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => { const yr = new Date().getFullYear()+"-"+(new Date().getFullYear()+1); setResult(null); setForm({ first_name:"",last_name:"",date_of_birth:"",gender:"Masculin",status:"Actif",address:"",parent_name:"",parent_phone:"",parent_email:"",class_id:"",level_requested:"",student_type:"non_affecte",academic_year:yr,student_number:generateStudentNumber(yr),notes:"" }); setSchoolHistory([]); setPayment({ amount_paid:0, payment_mode:"comptant", payment_method:"espèces" }); setStep(1); }}
            className="flex-1 bg-primary text-primary-foreground rounded-xl py-2.5 font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
          >
            <UserPlus className="h-4 w-4" /> Nouvelle inscription
          </button>
          <button
            onClick={async () => {
              let photoUrl = "";
              if (result.student?.id) {
                try { const arr = await base44.entities.Student.filter({ id: result.student.id }); photoUrl = arr[0]?.photo_url || ""; } catch(e) {}
              }
              const en = result.enrollment;
              const cls = result.assignedClass;
              const si = schoolInfo || {};
              const resteDu = Math.max(0, result.totalFee - result.amountPaid);
              const changeGiven = result.changeGiven || 0;
              const amountReceived = result.amountReceived || result.amountPaid;
              const statusLabel = result.paymentStatus==="complet" ? "SOLDÉ" : result.paymentStatus==="partiel" ? "PARTIEL" : "EN ATTENTE";
              const statusColor = result.paymentStatus==="complet" ? "#059669" : result.paymentStatus==="partiel" ? "#d97706" : "#dc2626";
              const statusBg = result.paymentStatus==="complet" ? "#ecfdf5" : result.paymentStatus==="partiel" ? "#fffbeb" : "#fef2f2";
              const statusBorder = result.paymentStatus==="complet" ? "#6ee7b7" : result.paymentStatus==="partiel" ? "#fcd34d" : "#fca5a5";

              const photoHtml = photoUrl
                ? `<img src="${photoUrl}" style="width:80px;height:96px;object-fit:cover;border-radius:6px;border:2px solid #e2e8f0;display:block;" />`
                : `<div style="width:80px;height:96px;border-radius:6px;border:1.5px dashed #cbd5e1;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#f8fafc;color:#94a3b8;font-size:9px;text-align:center;gap:4px"><svg width="24" height="24" fill="none" stroke="#cbd5e1" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>Photo</div>`;

              const logoHtml = si.logo_url
                ? `<img src="${si.logo_url}" style="height:56px;max-width:140px;object-fit:contain;" />`
                : `<div style="font-size:28px;font-weight:900;letter-spacing:3px;color:#1e3a8a;line-height:1">BOHAN</div>`;

              // Installments if needed
              let installmentsHtml = "";
              if (resteDu > 0) {
                const perInst = Math.round(resteDu / 3);
                const baseDate = new Date();
                const installments = [0,1,2].map(i => {
                  const d = new Date(baseDate); d.setMonth(d.getMonth() + (i+1)*2);
                  return { date: d.toLocaleDateString("fr-FR",{day:"2-digit",month:"short",year:"numeric"}), amount: i===2 ? resteDu - perInst*2 : perInst };
                });
                installmentsHtml = `
                  <tr><td colspan="2" style="padding:0;border:none">
                    <div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:6px;padding:10px 14px;margin-top:6px">
                      <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#92400e;margin-bottom:8px">Échéancier suggéré</div>
                      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;text-align:center">
                        ${installments.map((inst,i) => `
                          <div style="background:white;border:1px solid #fde68a;border-radius:5px;padding:6px 4px">
                            <div style="font-size:8px;color:#92400e;font-weight:600">Échéance ${i+1}</div>
                            <div style="font-size:10px;font-weight:800;color:#78350f;margin:3px 0">${inst.amount.toLocaleString("fr-FR")} XOF</div>
                            <div style="font-size:8px;color:#a16207">${inst.date}</div>
                          </div>`).join("")}
                      </div>
                    </div>
                  </td></tr>`;
              }

              const htmlContent = `<!DOCTYPE html>
<html><head>
<meta charset="utf-8">
<title>Reçu d'inscription — ${en.last_name} ${en.first_name}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  html,body{width:210mm;background:#fff;font-family:'Inter',Arial,sans-serif;color:#1e293b}
  @page{size:A4 portrait;margin:0}
  @media print{
    html,body{width:210mm}
    .page{box-shadow:none!important;border-radius:0!important;page-break-after:avoid}
    *{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
  }
  .page{width:210mm;min-height:297mm;background:white;position:relative;overflow:hidden}

  /* ─── HEADER BAND ─── */
  .header-band{background:linear-gradient(135deg,#0f2460 0%,#1d4ed8 55%,#2563eb 100%);color:white;padding:22px 32px 18px;display:flex;align-items:center;justify-content:space-between;position:relative;overflow:hidden}
  .header-band::before{content:'';position:absolute;right:-40px;top:-40px;width:180px;height:180px;background:rgba(255,255,255,.06);border-radius:50%}
  .header-band::after{content:'';position:absolute;right:60px;bottom:-60px;width:140px;height:140px;background:rgba(255,255,255,.04);border-radius:50%}
  .school-info{}
  .school-name{font-size:13px;font-weight:800;letter-spacing:.3px;margin-top:4px;opacity:.95}
  .school-sub{font-size:9px;opacity:.6;margin-top:1px}
  .receipt-badge{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.25);border-radius:10px;padding:10px 18px;text-align:right}
  .receipt-title{font-size:8px;text-transform:uppercase;letter-spacing:2px;opacity:.7;margin-bottom:4px}
  .receipt-number{font-size:15px;font-weight:900;font-family:monospace;letter-spacing:1px}
  .receipt-date{font-size:9px;opacity:.6;margin-top:3px}

  /* ─── WATERMARK STATUS ─── */
  .watermark{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-35deg);font-size:72px;font-weight:900;color:rgba(29,78,216,.04);letter-spacing:6px;pointer-events:none;white-space:nowrap;z-index:0}

  /* ─── CONTENT ─── */
  .content{padding:20px 32px;position:relative;z-index:1}

  /* ─── STATUS BAR ─── */
  .status-bar{background:${statusBg};border:1.5px solid ${statusBorder};border-radius:8px;padding:8px 16px;display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
  .status-dot{width:8px;height:8px;border-radius:50%;background:${statusColor};margin-right:8px;display:inline-block;flex-shrink:0}
  .status-text{font-size:11px;font-weight:700;color:${statusColor};letter-spacing:.5px;text-transform:uppercase}
  .status-amount{font-size:11px;font-weight:700;color:${statusColor}}

  /* ─── SECTION TITLE ─── */
  .sec-title{display:flex;align-items:center;gap:8px;margin:14px 0 8px}
  .sec-title-line{flex:1;height:1px;background:linear-gradient(90deg,#e2e8f0,transparent)}
  .sec-title span{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#64748b;white-space:nowrap}

  /* ─── STUDENT CARD ─── */
  .student-card{display:flex;gap:16px;align-items:flex-start;background:linear-gradient(135deg,#f8faff 0%,#eff6ff 100%);border:1px solid #dbeafe;border-radius:10px;padding:14px 16px}
  .student-info-grid{flex:1;display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px 10px}
  .info-cell .lbl{font-size:8px;font-weight:600;text-transform:uppercase;letter-spacing:.8px;color:#94a3b8;display:block;margin-bottom:2px}
  .info-cell .val{font-size:11px;font-weight:700;color:#1e293b}
  .student-name-row{grid-column:1/-1;margin-bottom:4px}
  .student-name{font-size:18px;font-weight:900;color:#1e3a8a;letter-spacing:.3px}
  .student-id-badge{display:inline-block;background:#dbeafe;color:#1d4ed8;font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;font-family:monospace;margin-left:8px;vertical-align:middle}

  /* ─── PARENT ROW ─── */
  .parent-row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 14px}

  /* ─── FINANCE TABLE ─── */
  .fin-table{width:100%;border-collapse:collapse;font-size:11px;margin-top:2px}
  .fin-table th{background:#1e3a8a;color:white;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;padding:8px 12px;text-align:left}
  .fin-table th:last-child{text-align:right}
  .fin-table td{padding:7px 12px;border-bottom:1px solid #f1f5f9;color:#334155}
  .fin-table td:last-child{text-align:right;font-weight:600;color:#1e293b}
  .fin-table tr:last-child td{border-bottom:none}
  .fin-table .subtotal td{background:#f1f5f9;font-weight:600;color:#475569}
  .fin-table .total-row td{background:#1e3a8a;color:white;font-weight:800;font-size:12px;padding:10px 12px;border:none}
  .fin-table .total-row td:last-child{font-size:14px}
  .fin-table .paid-row td{color:#059669;font-weight:700;background:#f0fdf4}
  .fin-table .due-row td{color:#dc2626;font-weight:700;background:#fef2f2}

  /* ─── SIGNATURE ROW ─── */
  .sig-row{display:flex;justify-content:space-between;align-items:flex-end;margin-top:18px;padding-top:14px;border-top:1px solid #e2e8f0}
  .sig-box{text-align:center}
  .sig-line{width:150px;border-bottom:1.5px solid #94a3b8;margin:32px auto 6px}
  .sig-label{font-size:9px;color:#64748b;font-weight:500}
  .sig-name{font-size:11px;font-weight:700;color:#1e293b;margin-top:2px}

  /* ─── FOOTER ─── */
  .footer{background:linear-gradient(90deg,#0f2460,#1d4ed8);color:white;padding:10px 32px;display:flex;justify-content:space-between;align-items:center;position:absolute;bottom:0;left:0;right:0}
  .footer-left{font-size:9px;opacity:.7;font-weight:500}
  .footer-right{font-size:9px;opacity:.7}
  .footer-brand{font-size:11px;font-weight:800;letter-spacing:2px;opacity:.9}
</style>
</head>
<body>
<div class="page">
  <div class="watermark">${statusLabel}</div>

  <!-- HEADER -->
  <div class="header-band">
    <div class="school-info">
      ${logoHtml}
      <div class="school-name">${si.name || "ÉTABLISSEMENT"}</div>
      ${si.address ? `<div class="school-sub">${si.address}${si.phone ? " · " + si.phone : ""}</div>` : ""}
      ${si.republic ? `<div class="school-sub" style="margin-top:2px;opacity:.5">${si.republic}</div>` : ""}
    </div>
    <div class="receipt-badge">
      <div class="receipt-title">Reçu Officiel d'Inscription</div>
      <div class="receipt-number">${result.receiptNumber}</div>
      <div class="receipt-date">${new Date().toLocaleDateString("fr-FR",{weekday:"long",day:"2-digit",month:"long",year:"numeric"})}</div>
    </div>
  </div>

  <div class="content">

    <!-- STATUS BAR -->
    <div class="status-bar">
      <div style="display:flex;align-items:center">
        <span class="status-dot"></span>
        <span class="status-text">Statut du paiement : ${statusLabel}</span>
      </div>
      <span class="status-amount">Reçu : ${amountReceived.toLocaleString("fr-FR")} XOF · Imputé : ${result.amountPaid.toLocaleString("fr-FR")} XOF${changeGiven > 0 ? " · Rendu : " + changeGiven.toLocaleString("fr-FR") + " XOF" : resteDu > 0 ? " · Reste dû : " + resteDu.toLocaleString("fr-FR") + " XOF" : " · Soldé"}</span>
    </div>

    <!-- STUDENT -->
    <div class="sec-title"><span>Identité de l'élève</span><div class="sec-title-line"></div></div>
    <div class="student-card">
      ${photoHtml}
      <div class="student-info-grid">
        <div class="info-cell student-name-row">
          <span class="student-name">${en.last_name.toUpperCase()} ${en.first_name}</span>
          <span class="student-id-badge">${form.student_number}</span>
        </div>
        <div class="info-cell"><span class="lbl">Date de naissance</span><span class="val">${en.date_of_birth ? new Date(en.date_of_birth).toLocaleDateString("fr-FR") : "—"}</span></div>
        <div class="info-cell"><span class="lbl">Sexe</span><span class="val">${en.gender || "—"}</span></div>
        <div class="info-cell"><span class="lbl">Statut</span><span class="val">${form.status}</span></div>
        <div class="info-cell"><span class="lbl">Classe affectée</span><span class="val">${cls?.name || "—"}</span></div>
        <div class="info-cell"><span class="lbl">Niveau</span><span class="val">${en.level_requested || "—"}</span></div>
        <div class="info-cell"><span class="lbl">Type d'élève</span><span class="val">${form.student_type==="affecte" ? "Affecté" : "Non-affecté"}</span></div>
        <div class="info-cell"><span class="lbl">Année scolaire</span><span class="val">${en.academic_year || "—"}</span></div>
        ${form.address ? `<div class="info-cell" style="grid-column:1/-1"><span class="lbl">Adresse</span><span class="val">${form.address}</span></div>` : ""}
      </div>
    </div>

    <!-- PARENT -->
    <div class="sec-title"><span>Parent / Tuteur légal</span><div class="sec-title-line"></div></div>
    <div class="parent-row">
      <div class="info-cell"><span class="lbl">Nom complet</span><span class="val">${en.parent_name || "—"}</span></div>
      <div class="info-cell"><span class="lbl">Téléphone</span><span class="val">${en.parent_phone || "—"}</span></div>
      <div class="info-cell"><span class="lbl">Email</span><span class="val">${en.parent_email || "—"}</span></div>
    </div>

    <!-- FINANCES -->
    <div class="sec-title"><span>Détail des frais</span><div class="sec-title-line"></div></div>
    <table class="fin-table">
      <thead><tr><th>Désignation</th><th>Détails</th><th>Montant</th></tr></thead>
      <tbody>
        <tr><td>Droit d'inscription</td><td style="color:#64748b;font-size:10px">${form.student_type==="affecte" ? "Élève affecté" : "Élève non-affecté"}</td><td>${(en.enrollment_fee||0).toLocaleString("fr-FR")} XOF</td></tr>
        ${form.student_type!=="affecte" ? `<tr><td>Frais de scolarité</td><td style="color:#64748b;font-size:10px">${tuitionMonths ? tuitionMonths + " mois" : "Annuel"}</td><td>${(en.tuition_fee||0).toLocaleString("fr-FR")} XOF</td></tr>` : ""}
        <tr class="subtotal"><td>Frais plateforme BOHAN</td><td style="font-size:10px">${schoolType === "prive" ? "Établissement privé" : "Établissement public"}</td><td>${platformFee.toLocaleString("fr-FR")} XOF</td></tr>
        <tr class="total-row"><td colspan="2">TOTAL À PAYER</td><td>${result.totalFee.toLocaleString("fr-FR")} XOF</td></tr>
        <tr class="paid-row"><td>✓ Montant reçu du parent</td><td style="color:#064e3b;font-size:10px">${payment.payment_method} · ${payment.payment_mode}</td><td>${amountReceived.toLocaleString("fr-FR")} XOF</td></tr>
        <tr class="paid-row"><td>✓ Montant imputé</td><td style="color:#064e3b;font-size:10px">Affecté à la facture</td><td>${result.amountPaid.toLocaleString("fr-FR")} XOF</td></tr>
        ${changeGiven > 0 ? `<tr style="background:#fef3c7"><td style="color:#92400e;font-weight:700">💰 Monnaie rendue au parent</td><td style="color:#78350f;font-size:10px">Excédent versé</td><td style="color:#92400e;font-weight:800;text-align:right">${changeGiven.toLocaleString("fr-FR")} XOF</td></tr>` : ""}
        ${resteDu > 0 ? `<tr class="due-row"><td colspan="2">Solde restant dû</td><td>${resteDu.toLocaleString("fr-FR")} XOF</td></tr>` : `<tr style="background:#dcfce7"><td colspan="2" style="color:#166534;font-weight:700">✅ Facture intégralement soldée</td><td style="color:#166534;font-weight:800;text-align:right">0 XOF</td></tr>`}
        ${installmentsHtml}
      </tbody>
    </table>

    <!-- SIGNATURES -->
    <div class="sig-row">
      <div style="font-size:10px;color:#64748b;max-width:200px;line-height:1.5">
        <p style="font-weight:700;color:#1e293b;margin-bottom:2px">Mention obligatoire</p>
        <p>Je soussigné(e) <strong>${en.parent_name}</strong> reconnais avoir reçu le présent reçu d'inscription.</p>
      </div>
      <div class="sig-box">
        <div class="sig-line"></div>
        <div class="sig-label">Signature du parent / tuteur</div>
      </div>
      <div class="sig-box">
        <div class="sig-line"></div>
        <div class="sig-label">Comptable · Cachet</div>
        <div class="sig-name">${en.accountant_name || ""}</div>
      </div>
    </div>

  </div><!-- /content -->

  <div class="footer">
    <div>
      <div class="footer-brand">BOHAN</div>
      <div class="footer-left">Plateforme de gestion scolaire numérique</div>
    </div>
    <div class="footer-right">Document généré le ${new Date().toLocaleDateString("fr-FR")} à ${new Date().toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"})} · Réf. ${result.receiptNumber}</div>
  </div>
</div>
</body></html>`;

              // Mobile-compatible: inject into a blob URL or use iframe fallback
              const blob = new Blob([htmlContent], { type: "text/html" });
              const blobUrl = URL.createObjectURL(blob);

              // Try window.open first (desktop), fallback to iframe for mobile
              const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
              if (isMobile) {
                // On mobile: open in same tab or use an iframe print trick
                const iframe = document.createElement("iframe");
                iframe.style.cssText = "position:fixed;top:0;left:0;width:100%;height:100%;border:none;z-index:9999;background:white";
                iframe.src = blobUrl;
                document.body.appendChild(iframe);
                iframe.onload = () => {
                  setTimeout(() => {
                    iframe.contentWindow.print();
                    setTimeout(() => { document.body.removeChild(iframe); URL.revokeObjectURL(blobUrl); }, 1000);
                  }, 500);
                };
              } else {
                const w = window.open(blobUrl, "_blank", "width=820,height=1060");
                if (w) {
                  w.onload = () => { setTimeout(() => { w.print(); URL.revokeObjectURL(blobUrl); }, 500); };
                } else {
                  // Popup blocked fallback
                  window.location.href = blobUrl;
                }
              }
            }}
            className="flex items-center gap-2 border border-primary text-primary rounded-xl px-4 py-2.5 font-semibold hover:bg-primary/5 transition-colors"
          >
            <Printer className="h-4 w-4" /> Imprimer
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Steps */}
      <div className="flex gap-2 mb-2">
        {[{ n: 1, label: "Informations" }, { n: 2, label: "Paiement" }].map(s => (
          <button key={s.n} type="button" onClick={() => step === 1 && s.n === 2 && form.first_name && form.level_requested ? setStep(2) : step > 1 && s.n === 1 ? setStep(1) : null}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-colors ${step === s.n ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
            {s.n}. {s.label}
          </button>
        ))}
      </div>

      {step === 1 && (
        <div className="space-y-4">
          {/* N° Étudiant */}
          <div>
            <label className="text-xs font-medium text-foreground block mb-1">N° Étudiant</label>
            <div className="flex gap-2">
              <input value={form.student_number} onChange={e => setForm(f=>({...f,student_number:e.target.value}))} className="flex-1 border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring font-mono" />
              <button type="button" onClick={() => setForm(f=>({...f,student_number:generateStudentNumber(f.academic_year)}))} className="border border-input rounded-lg px-3 py-2 text-xs hover:bg-muted">🔄</button>
            </div>
          </div>

          {/* Nom & Prénom */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Prénom *</label>
              <input value={form.first_name} onChange={e => setForm(f=>({...f,first_name:e.target.value}))} required placeholder="Prénom" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Nom *</label>
              <input value={form.last_name} onChange={e => setForm(f=>({...f,last_name:e.target.value}))} required placeholder="NOM" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring uppercase" />
            </div>
          </div>

          {/* Date & Sexe */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Date de naissance *</label>
              <input type="date" value={form.date_of_birth} onChange={e => setForm(f=>({...f,date_of_birth:e.target.value}))} required className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Sexe</label>
              <select value={form.gender} onChange={e => setForm(f=>({...f,gender:e.target.value}))} className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                <option>Masculin</option><option>Féminin</option>
              </select>
            </div>
          </div>

          {/* Statut & Adresse */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Statut</label>
              <select value={form.status} onChange={e => setForm(f=>({...f,status:e.target.value}))} className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                <option>Actif</option><option>Inactif</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Adresse</label>
              <input value={form.address} onChange={e => setForm(f=>({...f,address:e.target.value}))} placeholder="Rue, ville, pays" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          </div>

          {/* Classe directe */}
          <div>
            <label className="text-xs font-medium text-foreground block mb-1">Classe *</label>
            <select value={form.class_id} onChange={e => {
              const cls = classes.find(c => c.id === e.target.value);
              setForm(f=>({...f, class_id: e.target.value, level_requested: cls?.level || f.level_requested}));
            }} required className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
              <option value="">-- Sélectionner --</option>
              {classes.map(c => <option key={c.id} value={c.id}>{c.name} ({c.level})</option>)}
            </select>
          </div>

          {/* Type d'élève */}
          <div>
            <label className="text-xs font-medium text-foreground block mb-1">Type d'élève *</label>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setForm(f => ({ ...f, student_type: "non_affecte" }))}
                className={`py-2.5 px-3 rounded-xl border-2 text-sm font-semibold transition-all ${
                  form.student_type === "non_affecte" ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-muted-foreground"
                }`}>
                📝 Non-affecté
                <p className="text-xs font-normal mt-0.5">Inscription + Scolarité</p>
              </button>
              <button type="button" onClick={() => setForm(f => ({ ...f, student_type: "affecte" }))}
                className={`py-2.5 px-3 rounded-xl border-2 text-sm font-semibold transition-all ${
                  form.student_type === "affecte" ? "border-emerald-500 bg-emerald-50 text-emerald-700" : "border-border text-muted-foreground hover:border-muted-foreground"
                }`}>
                ✅ Affecté
                <p className="text-xs font-normal mt-0.5">Inscription uniquement</p>
              </button>
            </div>
          </div>

          {/* Contact parent */}
          <div className="border-t border-border pt-4">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Contact parent / tuteur</p>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-medium text-foreground block mb-1">Nom du parent *</label>
                <input value={form.parent_name} onChange={e => setForm(f=>({...f,parent_name:e.target.value}))} required placeholder="Nom complet" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-foreground block mb-1">Email du parent</label>
                  <input type="email" value={form.parent_email} onChange={e => setForm(f=>({...f,parent_email:e.target.value}))} placeholder="optionnel" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>
                <div>
                  <label className="text-xs font-medium text-foreground block mb-1">Téléphone parent *</label>
                  <input value={form.parent_phone} onChange={e => setForm(f=>({...f,parent_phone:e.target.value}))} required placeholder="+225 07 00 00 00" className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>
              </div>
            </div>
          </div>

          {/* Historique scolaire */}
          <div className="border-t border-border pt-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Historique scolaire</p>
              <button type="button" onClick={() => setSchoolHistory(h => [...h, { academic_year:"", class_name:"", average:"", result:"", observations:"" }])}
                className="text-xs text-primary hover:underline flex items-center gap-1">+ Ajouter une année</button>
            </div>
            {schoolHistory.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-3 bg-muted/50 rounded-lg">Aucun historique enregistré</p>
            ) : (
              <div className="space-y-2">
                {schoolHistory.map((h, i) => (
                  <div key={i} className="bg-muted/40 rounded-lg p-3 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <input placeholder="Année (ex: 2024-2025)" value={h.academic_year} onChange={e => setSchoolHistory(arr => arr.map((x,j)=>j===i?{...x,academic_year:e.target.value}:x))} className="border border-input rounded px-2 py-1 text-xs bg-background" />
                      <input placeholder="Classe" value={h.class_name} onChange={e => setSchoolHistory(arr => arr.map((x,j)=>j===i?{...x,class_name:e.target.value}:x))} className="border border-input rounded px-2 py-1 text-xs bg-background" />
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <input placeholder="Moyenne" type="number" step="0.01" value={h.average} onChange={e => setSchoolHistory(arr => arr.map((x,j)=>j===i?{...x,average:parseFloat(e.target.value)||"" }:x))} className="border border-input rounded px-2 py-1 text-xs bg-background" />
                      <select value={h.result} onChange={e => setSchoolHistory(arr => arr.map((x,j)=>j===i?{...x,result:e.target.value}:x))} className="border border-input rounded px-2 py-1 text-xs bg-background">
                        <option value="">Résultat</option>
                        <option>Admis</option><option>Redoublant</option><option>Transféré</option><option>Exclu</option>
                      </select>
                      <button type="button" onClick={() => setSchoolHistory(h => h.filter((_,j)=>j!==i))} className="text-xs text-red-500 hover:underline">Supprimer</button>
                    </div>
                    <input placeholder="Observations" value={h.observations} onChange={e => setSchoolHistory(arr => arr.map((x,j)=>j===i?{...x,observations:e.target.value}:x))} className="w-full border border-input rounded px-2 py-1 text-xs bg-background" />
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="text-xs font-medium text-foreground block mb-1">Année scolaire</label>
            <input value={form.academic_year} onChange={e => setForm(f=>({...f,academic_year:e.target.value}))} className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>

          <button type="button" onClick={() => setStep(2)} disabled={!form.first_name || !form.last_name || !form.date_of_birth || !form.parent_name || !form.parent_phone || !form.class_id}
            className="w-full bg-primary text-primary-foreground rounded-xl py-2.5 font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60">
            Suivant → Paiement
          </button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4">
          {/* Fee summary */}
          {!feesConfigured ? (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
              <p className="font-bold mb-1">⚠️ Aucun tarif configuré pour le niveau <strong>{form.level_requested}</strong></p>
              <p>La comptable ou le directeur doit d'abord configurer les tarifs scolaires pour ce niveau dans l'onglet <strong>"Tarifs scolaires"</strong>.</p>
            </div>
          ) : (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-1.5 text-sm">
              <p className="font-bold text-blue-800 mb-2">Récapitulatif des frais — {form.level_requested} <span className={`ml-2 text-xs px-2 py-0.5 rounded-full font-semibold ${isAffecte ? "bg-emerald-100 text-emerald-700" : "bg-blue-100 text-blue-700"}`}>{isAffecte ? "Affecté" : "Non-affecté"}</span></p>
              <div className="flex justify-between">
                <span className="text-blue-700">Droit d'inscription ({isAffecte ? "affecté" : "non-affecté"})</span>
                <span className="font-semibold text-blue-900">{enrollmentFee.toLocaleString("fr-FR")} XOF</span>
              </div>
              {!isAffecte && (
                <div className="flex justify-between">
                  <span className="text-blue-700">Frais de scolarité{tuitionMonths ? ` (${tuitionMonths} mois)` : ""}</span>
                  <span className="font-semibold text-blue-900">{tuitionFee.toLocaleString("fr-FR")} XOF</span>
                </div>
              )}
              {!isAffecte && advanceAmount > 0 && (
                <div className="flex justify-between">
                  <span className="text-blue-700">Avance initiale</span>
                  <span className="font-semibold text-blue-900">{advanceAmount.toLocaleString("fr-FR")} XOF</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-blue-700">Frais plateforme BOHAN <span className="text-xs text-muted-foreground">({schoolType === "prive" ? "Privé" : "Public"})</span></span>
                <span className="font-semibold text-blue-900">{platformFee.toLocaleString("fr-FR")} XOF</span>
              </div>
              <div className="border-t border-blue-300 pt-2 flex justify-between font-bold text-blue-900">
                <span>TOTAL</span><span>{totalFee.toLocaleString("fr-FR")} XOF</span>
              </div>
            </div>
          )}

          <div>
            <label className="text-xs font-medium text-foreground block mb-1">Mode de paiement</label>
            <select value={payment.payment_mode} onChange={e => setPayment(p=>({...p,payment_mode:e.target.value}))} className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
              <option value="comptant">Comptant</option>
              <option value="échelonné">Échelonné</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-foreground block mb-1">Moyen de paiement</label>
            <select value={payment.payment_method} onChange={e => setPayment(p=>({...p,payment_method:e.target.value}))} className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
              {PAYMENT_METHODS.map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-foreground block mb-1">Montant versé aujourd'hui (XOF)</label>
            <input type="number" min="0" value={payment.amount_paid} onChange={e => setPayment(p=>({...p,amount_paid:e.target.value}))}
              className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring font-mono" />
            {(() => {
              const received = parseFloat(payment.amount_paid) || 0;
              const change = received - totalFee;
              if (change > 0) return (
                <div className="flex items-center justify-between mt-1 px-3 py-2 bg-amber-50 border border-amber-200 rounded-lg">
                  <span className="text-xs text-amber-700 font-semibold">💰 Monnaie à rendre</span>
                  <span className="text-sm font-bold text-amber-800">{change.toLocaleString("fr-FR")} XOF</span>
                </div>
              );
              if (change < 0) return (
                <p className="text-xs text-muted-foreground mt-1">Reste dû : <span className="font-semibold text-foreground">{Math.abs(change).toLocaleString("fr-FR")} XOF</span></p>
              );
              if (received > 0) return <p className="text-xs text-emerald-600 font-semibold mt-1">✅ Montant exact — aucune monnaie à rendre</p>;
              return null;
            })()}
          </div>

          {findAvailableClass() ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-sm text-green-800">
              ✅ Classe : <span className="font-bold">{findAvailableClass().name}</span>
            </div>
          ) : (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
              ⚠️ Aucune classe sélectionnée.
            </div>
          )}

          <div className="flex gap-3">
            <button type="button" onClick={() => setStep(1)} className="border border-input rounded-xl px-4 py-2.5 text-sm font-semibold hover:bg-muted transition-colors">← Retour</button>
            <button type="submit" disabled={saving || !feesConfigured} className="flex-1 bg-primary text-primary-foreground rounded-xl py-2.5 font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
              <UserPlus className="h-4 w-4" />
              {saving ? "Enregistrement…" : "Valider l'inscription"}
            </button>
          </div>
        </div>
      )}
    </form>
  );
}