import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { Search, Printer, ShieldCheck, Copy, Check, Eye, EyeOff, AlertTriangle, KeyRound, Users, RefreshCw } from "lucide-react";

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  function handle() {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }
  return (
    <button onClick={handle} className="p-1 rounded hover:bg-muted transition-colors shrink-0" title="Copier">
      {copied ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5 text-muted-foreground" />}
    </button>
  );
}

function CredentialRow({ label, value, mono = true, sensitive = false }) {
  const [show, setShow] = useState(!sensitive);
  if (!value) return null;
  return (
    <div className="flex items-center justify-between bg-muted/40 rounded-lg px-3 py-2 gap-2">
      <div className="min-w-0 flex-1">
        <p className="text-[9px] uppercase tracking-wide text-muted-foreground font-semibold">{label}</p>
        <p className={`text-xs font-bold text-foreground truncate ${mono ? "font-mono" : ""}`}>
          {sensitive && !show ? "••••••••••" : value}
        </p>
      </div>
      <div className="flex items-center gap-1 shrink-0">
        {sensitive && (
          <button onClick={() => setShow(s => !s)} className="p-1 rounded hover:bg-muted transition-colors" title={show ? "Masquer" : "Afficher"}>
            {show ? <EyeOff className="h-3.5 w-3.5 text-muted-foreground" /> : <Eye className="h-3.5 w-3.5 text-muted-foreground" />}
          </button>
        )}
        <CopyBtn text={value} />
      </div>
    </div>
  );
}

function printStudentCredentials(student, access) {
  const win = window.open("", "_blank", "width=440,height=620");
  win.document.write(`<!DOCTYPE html><html><head><title>Identifiants — ${student.first_name} ${student.last_name}</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:Arial,sans-serif;background:#f1f5f9;padding:20px;color:#1e293b}
    .page{background:white;max-width:400px;margin:0 auto;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.1)}
    .header{background:linear-gradient(135deg,#065f46 0%,#059669 100%);color:white;padding:22px 24px;text-align:center}
    .logo{font-size:22px;font-weight:900;letter-spacing:2px;margin-bottom:4px}
    .name{font-size:17px;font-weight:bold;margin-bottom:2px}
    .badge{display:inline-block;background:rgba(255,255,255,.2);color:white;font-size:10px;padding:3px 12px;border-radius:20px}
    .body{padding:20px 22px}
    .section{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#64748b;margin:16px 0 8px;border-bottom:1px solid #e2e8f0;padding-bottom:4px}
    .row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:12px}
    .row:last-child{border:none}
    .lbl{color:#64748b}
    .val{font-weight:bold;font-family:monospace;font-size:12px}
    .warn{margin:16px 0;background:#fef9c3;border:1px solid #fbbf24;padding:10px 12px;border-radius:8px;font-size:10px;color:#92400e;text-align:center}
    .steps{border:2px solid #059669;border-radius:10px;overflow:hidden;margin-top:16px}
    .steps-title{background:#059669;color:white;font-size:11px;font-weight:bold;padding:8px 14px}
    .step{display:flex;gap:9px;padding:9px 14px;border-bottom:1px solid #e2e8f0;font-size:10.5px;color:#1e293b;align-items:flex-start}
    .step:last-child{border-bottom:none}
    .num{background:#059669;color:white;border-radius:50%;width:18px;height:18px;min-width:18px;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:10px}
    .footer{background:#f8fafc;border-top:1px solid #e2e8f0;padding:10px 22px;font-size:9px;color:#94a3b8;text-align:center}
    @media print{body{background:white;padding:0}.page{box-shadow:none;border-radius:0}*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}}
  </style></head><body>
  <div class="page">
    <div class="header">
      <div class="logo">BOHAN</div>
      <div class="name">${student.last_name} ${student.first_name}</div>
      <span class="badge">Élève · ${student.class_name || "—"}</span>
    </div>
    <div class="body">
      <div class="section">📋 Informations scolaires</div>
      <div class="row"><span class="lbl">N° Étudiant</span><span class="val">${student.student_number || "—"}</span></div>
      <div class="row"><span class="lbl">Classe</span><span class="val">${student.class_name || "—"}</span></div>
      <div class="row"><span class="lbl">Statut</span><span class="val">${student.status || "Actif"}</span></div>
      ${student.date_of_birth ? `<div class="row"><span class="lbl">Date de naissance</span><span class="val">${new Date(student.date_of_birth).toLocaleDateString("fr-FR")}</span></div>` : ""}

      <div class="section">🔐 Identifiants de connexion</div>
      <div class="row"><span class="lbl">Code d'accès permanent</span><span class="val">${access?.access_id || "—"}</span></div>
      <div class="row"><span class="lbl">Email de connexion</span><span class="val">${access?.user_email || student.student_user_email || "—"}</span></div>
      <div class="row"><span class="lbl">Mot de passe initial</span><span class="val">${access?.access_password || "—"}</span></div>

      ${(student.parent_name || student.parent_phone) ? `
      <div class="section">👨‍👧 Parent / Tuteur</div>
      ${student.parent_name ? `<div class="row"><span class="lbl">Nom</span><span class="val">${student.parent_name}</span></div>` : ""}
      ${student.parent_phone ? `<div class="row"><span class="lbl">Téléphone</span><span class="val">${student.parent_phone}</span></div>` : ""}
      ` : ""}

      <div class="warn">⚠️ Document confidentiel — à remettre uniquement à l'élève ou son tuteur légal.</div>

      <div class="steps">
        <div class="steps-title">📱 Comment se connecter à BOHAN ?</div>
        <div class="step"><span class="num">1</span><div>Ouvrez un navigateur web (Chrome, Firefox…) et accédez à l'application BOHAN.</div></div>
        <div class="step"><span class="num">2</span><div>Cliquez sur <strong>« Se connecter avec Google »</strong> en utilisant l'adresse : <strong>${access?.user_email || student.student_user_email || "—"}</strong></div></div>
        <div class="step"><span class="num">3</span><div>Saisissez votre code permanent : <strong>${access?.access_id || "—"}</strong></div></div>
        <div class="step"><span class="num">4</span><div>Saisissez le mot de passe : <strong>${access?.access_password || "—"}</strong><br/><em style="color:#92400e">Pensez à le changer dès votre première connexion.</em></div></div>
        <div class="step"><span class="num">5</span><div>✅ Vous avez accès à votre espace élève !</div></div>
      </div>
    </div>
    <div class="footer">Généré le ${new Date().toLocaleDateString("fr-FR")} à ${new Date().toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"})} — Plateforme BOHAN</div>
  </div>
  </body></html>`);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 500);
}

export default function StudentAccessHistory({ schoolId: propSchoolId }) {
  const [students, setStudents] = useState([]);
  const [accesses, setAccesses] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterClass, setFilterClass] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [printing, setPrinting] = useState(null);

  async function load() {
    const schoolId = propSchoolId;
    if (!schoolId) { setLoading(false); return; }
    const f = { school_id: schoolId };
    const [studs, accs, cls] = await Promise.all([
      base44.entities.Student.filter(f, "-created_date", 500),
      base44.entities.AppAccess.filter({ role: "student", school_id: schoolId }),
      base44.entities.Class.filter(f),
    ]);
    setStudents(studs);
    setAccesses(accs);
    setClasses(cls);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function getAccess(student) {
    return accesses.find(a =>
      (student.student_user_email && a.user_email?.toLowerCase() === student.student_user_email?.toLowerCase()) ||
      (a.full_name?.toLowerCase() === `${student.first_name} ${student.last_name}`.toLowerCase())
    ) || null;
  }

  function getClassName(student) {
    const cls = classes.find(c => c.id === student.class_id);
    return cls?.name || "—";
  }

  const filtered = students.filter(s => {
    const q = search.toLowerCase();
    const matchSearch = !q ||
      s.first_name?.toLowerCase().includes(q) ||
      s.last_name?.toLowerCase().includes(q) ||
      s.student_number?.toLowerCase().includes(q) ||
      s.student_user_email?.toLowerCase().includes(q) ||
      getAccess(s)?.access_id?.toLowerCase().includes(q);
    const matchClass = !filterClass || s.class_id === filterClass;
    const access = getAccess(s);
    const matchStatus = filterStatus === "all" || (filterStatus === "active" ? !!access : !access);
    return matchSearch && matchClass && matchStatus;
  });

  const withAccess = filtered.filter(s => getAccess(s));
  const withoutAccess = filtered.filter(s => !getAccess(s));

  async function handlePrint(student) {
    setPrinting(student.id);
    const access = getAccess(student);
    const enriched = { ...student, class_name: getClassName(student) };
    printStudentCredentials(enriched, access);
    setPrinting(null);
  }

  if (loading) return (
    <div className="flex justify-center py-16">
      <div className="w-8 h-8 border-4 border-green-200 border-t-green-600 rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Header stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-green-50 border border-green-200 rounded-xl p-3 text-center">
          <p className="text-2xl font-bold text-green-700">{accesses.length}</p>
          <p className="text-xs text-green-600 font-medium">Comptes générés</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center">
          <p className="text-2xl font-bold text-blue-700">{students.length}</p>
          <p className="text-xs text-blue-600 font-medium">Élèves inscrits</p>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-center">
          <p className="text-2xl font-bold text-amber-700">{students.filter(s => !getAccess(s)).length}</p>
          <p className="text-xs text-amber-600 font-medium">Sans compte</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        <div className="flex items-center gap-2 bg-muted/50 border border-border rounded-xl px-3 py-2 flex-1 min-w-48">
          <Search className="h-4 w-4 text-muted-foreground shrink-0" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Nom, N° étudiant, email, code…"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>
        <select value={filterClass} onChange={e => setFilterClass(e.target.value)}
          className="h-10 rounded-xl border border-border bg-background px-3 text-sm">
          <option value="">Toutes les classes</option>
          {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="h-10 rounded-xl border border-border bg-background px-3 text-sm">
          <option value="all">Tous</option>
          <option value="active">Avec compte</option>
          <option value="none">Sans compte</option>
        </select>
        <button onClick={load} title="Actualiser"
          className="h-10 w-10 rounded-xl border border-border bg-background flex items-center justify-center hover:bg-muted transition-colors">
          <RefreshCw className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>

      <p className="text-xs text-muted-foreground">
        <span className="font-semibold text-green-700">{withAccess.length} avec identifiants</span>
        {withoutAccess.length > 0 && <span className="ml-2 font-semibold text-amber-600">{withoutAccess.length} sans compte</span>}
      </p>

      {/* Students WITH access */}
      {withAccess.length > 0 && (
        <div className="space-y-3">
          {withAccess.map(student => {
            const access = getAccess(student);
            const className = getClassName(student);
            return (
              <div key={student.id} className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
                {/* Student header */}
                <div className="flex items-center gap-3 px-4 py-3 bg-green-50/60 border-b border-border/50">
                  {student.photo_url
                    ? <img src={student.photo_url} className="w-10 h-10 rounded-xl object-cover border-2 border-green-200 shrink-0" />
                    : <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
                        {student.first_name?.[0]}{student.last_name?.[0]}
                      </div>
                  }
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-bold text-sm text-foreground">{student.last_name} {student.first_name}</p>
                      <span className="text-[9px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                        <ShieldCheck className="h-2.5 w-2.5" /> Compte actif
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {className} · <span className="font-mono">{student.student_number || "—"}</span>
                    </p>
                  </div>
                  <button
                    onClick={() => handlePrint(student)}
                    disabled={printing === student.id}
                    className="shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl border border-green-300 bg-white hover:bg-green-50 text-green-700 transition-colors disabled:opacity-50 text-xs font-semibold"
                    title="Imprimer la fiche d'identifiants"
                  >
                    <Printer className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">{printing === student.id ? "…" : "Imprimer"}</span>
                  </button>
                </div>

                {/* Credentials */}
                <div className="px-4 py-3 space-y-1.5">
                  <p className="text-[9px] uppercase tracking-widest text-muted-foreground font-bold mb-2 flex items-center gap-1">
                    <KeyRound className="h-3 w-3" /> Identifiants de connexion
                  </p>
                  <CredentialRow label="Code d'accès permanent" value={access?.access_id} />
                  <CredentialRow label="Email de connexion" value={access?.user_email || student.student_user_email} />
                  <CredentialRow label="Mot de passe initial" value={access?.access_password} sensitive />

                  {/* Parent info */}
                  {(student.parent_name || student.parent_phone) && (
                    <div className="flex items-center gap-1.5 pt-1.5 mt-1 border-t border-border/50 text-xs text-muted-foreground">
                      <Users className="h-3.5 w-3.5 shrink-0" />
                      <span>{student.parent_name}{student.parent_phone ? ` · ${student.parent_phone}` : ""}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Students WITHOUT access */}
      {withoutAccess.length > 0 && filterStatus !== "active" && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
            <p className="text-xs font-semibold text-amber-800">
              {withoutAccess.length} élève(s) sans compte lié — rendez-vous dans « Inscription » pour les associer.
            </p>
          </div>
          {withoutAccess.map(student => (
            <div key={student.id} className="bg-card border border-dashed border-amber-300 rounded-xl px-4 py-3 flex items-center gap-3 opacity-75">
              <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center text-amber-600 font-bold text-sm shrink-0">
                {student.first_name?.[0]}{student.last_name?.[0]}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm text-foreground">{student.last_name} {student.first_name}</p>
                <p className="text-xs text-muted-foreground">{getClassName(student)} · <span className="font-mono">{student.student_number || "—"}</span></p>
              </div>
              <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-semibold shrink-0">Sans compte</span>
            </div>
          ))}
        </div>
      )}

      {filtered.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <KeyRound className="h-12 w-12 mx-auto mb-3 opacity-20" />
          <p className="font-semibold">Aucun élève trouvé</p>
          <p className="text-sm mt-1">Modifiez vos critères de recherche.</p>
        </div>
      )}
    </div>
  );
}