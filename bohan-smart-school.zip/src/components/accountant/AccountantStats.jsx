import { DollarSign, Users, AlertTriangle, CheckCircle, TrendingUp } from "lucide-react";

export default function AccountantStats({ enrollments, payments }) {
  const totalEnrollments = enrollments.length;
  const totalCollected = payments.reduce((s, p) => s + (p.amount || 0), 0);
  const totalExpected = enrollments.reduce((s, e) => s + (e.total_fee || 0), 0);
  const fullPaid = enrollments.filter(e => e.payment_status === "complet").length;
  const partial = enrollments.filter(e => e.payment_status === "partiel").length;
  const pending = enrollments.filter(e => e.payment_status === "en_attente").length;

  // Monthly revenue (current month)
  const thisMonth = new Date().toISOString().slice(0, 7);
  const monthlyRevenue = payments.filter(p => p.payment_date?.slice(0,7) === thisMonth).reduce((s, p) => s + (p.amount || 0), 0);

  const stats = [
    { label: "Inscriptions totales", value: totalEnrollments, icon: Users, color: "bg-blue-50 text-blue-700 border-blue-200" },
    { label: "Montant collecté", value: totalCollected.toLocaleString("fr-FR") + " XOF", icon: DollarSign, color: "bg-green-50 text-green-700 border-green-200" },
    { label: "Revenus ce mois", value: monthlyRevenue.toLocaleString("fr-FR") + " XOF", icon: TrendingUp, color: "bg-purple-50 text-purple-700 border-purple-200" },
    { label: "Impayés / Partiels", value: pending + partial, icon: AlertTriangle, color: "bg-red-50 text-red-700 border-red-200" },
    { label: "Paiements complets", value: fullPaid, icon: CheckCircle, color: "bg-emerald-50 text-emerald-700 border-emerald-200" },
    { label: "Reste à collecter", value: (totalExpected - totalCollected).toLocaleString("fr-FR") + " XOF", icon: DollarSign, color: "bg-amber-50 text-amber-700 border-amber-200" },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {stats.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className={`border rounded-xl p-4 ${color}`}>
            <Icon className="h-5 w-5 mb-2" />
            <p className="text-2xl font-bold">{value}</p>
            <p className="text-xs mt-0.5 opacity-80">{label}</p>
          </div>
        ))}
      </div>

      {/* Payment status breakdown */}
      <div className="bg-card border border-border rounded-xl p-4">
        <h3 className="font-semibold text-sm text-foreground mb-3">Suivi des paiements</h3>
        <div className="space-y-2">
          {[
            { label: "Complets", count: fullPaid, total: totalEnrollments, color: "bg-green-500" },
            { label: "Partiels", count: partial, total: totalEnrollments, color: "bg-amber-500" },
            { label: "En attente", count: pending, total: totalEnrollments, color: "bg-red-500" },
          ].map(({ label, count, total, color }) => (
            <div key={label} className="space-y-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{label}</span><span>{count} / {total}</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div className={`h-full rounded-full ${color}`} style={{ width: total ? `${(count/total)*100}%` : "0%" }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}