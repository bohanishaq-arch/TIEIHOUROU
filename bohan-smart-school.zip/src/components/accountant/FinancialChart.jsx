import { useMemo } from "react";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

const MONTHS_FR = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jun", "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc"];

function formatXOF(v) {
  if (v >= 1000000) return (v / 1000000).toFixed(1) + "M";
  if (v >= 1000) return (v / 1000).toFixed(0) + "k";
  return v;
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-border rounded-xl shadow-lg p-3 text-xs space-y-1">
      <p className="font-bold text-foreground mb-1">{label}</p>
      {payload.map(entry => (
        <div key={entry.name} className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full" style={{ background: entry.color }} />
          <span className="text-muted-foreground">{entry.name} :</span>
          <span className="font-semibold text-foreground">{(entry.value || 0).toLocaleString("fr-FR")} XOF</span>
        </div>
      ))}
    </div>
  );
};

export default function FinancialChart({ payments, enrollments }) {
  // Build monthly data for last 12 months
  const monthlyData = useMemo(() => {
    const now = new Date();
    const data = [];
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      data.push({ month: MONTHS_FR[d.getMonth()], key, collected: 0, expected: 0, unpaid: 0 });
    }

    payments.forEach(p => {
      if (!p.payment_date) return;
      const d = new Date(p.payment_date);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const entry = data.find(e => e.key === key);
      if (entry) entry.collected += p.amount || 0;
    });

    enrollments.forEach(e => {
      if (!e.enrollment_date) return;
      const d = new Date(e.enrollment_date);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const entry = data.find(r => r.key === key);
      if (entry) {
        entry.expected += e.total_fee || 0;
        entry.unpaid += Math.max(0, (e.total_fee || 0) - (e.amount_paid || 0));
      }
    });

    return data;
  }, [payments, enrollments]);

  // Summary stats
  const totalCollected = payments.reduce((s, p) => s + (p.amount || 0), 0);
  const totalExpected = enrollments.reduce((s, e) => s + (e.total_fee || 0), 0);
  const totalUnpaid = enrollments.reduce((s, e) => s + Math.max(0, (e.total_fee || 0) - (e.amount_paid || 0)), 0);
  const collectionRate = totalExpected > 0 ? Math.round((totalCollected / totalExpected) * 100) : 0;

  // Trend: compare last month vs previous month
  const lastMonth = monthlyData[monthlyData.length - 1]?.collected || 0;
  const prevMonth = monthlyData[monthlyData.length - 2]?.collected || 0;
  const trend = lastMonth > prevMonth ? "up" : lastMonth < prevMonth ? "down" : "stable";
  const trendPct = prevMonth > 0 ? Math.abs(Math.round(((lastMonth - prevMonth) / prevMonth) * 100)) : 0;

  const statCards = [
    { label: "Total collecté", value: totalCollected.toLocaleString("fr-FR") + " XOF", color: "bg-emerald-50 border-emerald-200 text-emerald-700" },
    { label: "Total attendu", value: totalExpected.toLocaleString("fr-FR") + " XOF", color: "bg-blue-50 border-blue-200 text-blue-700" },
    { label: "Reste à percevoir", value: totalUnpaid.toLocaleString("fr-FR") + " XOF", color: "bg-red-50 border-red-200 text-red-700" },
    { label: "Taux de recouvrement", value: collectionRate + "%", color: "bg-purple-50 border-purple-200 text-purple-700" },
  ];

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-3">
        {statCards.map(c => (
          <div key={c.label} className={`rounded-xl border p-4 ${c.color}`}>
            <p className="text-xs font-medium opacity-70 mb-1">{c.label}</p>
            <p className="text-lg font-bold">{c.value}</p>
          </div>
        ))}
      </div>

      {/* Trend badge */}
      <div className="flex items-center gap-2">
        {trend === "up" && <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-full px-3 py-1 text-xs font-semibold"><TrendingUp className="h-3.5 w-3.5" /> +{trendPct}% vs mois précédent</div>}
        {trend === "down" && <div className="flex items-center gap-1.5 text-red-700 bg-red-50 border border-red-200 rounded-full px-3 py-1 text-xs font-semibold"><TrendingDown className="h-3.5 w-3.5" /> -{trendPct}% vs mois précédent</div>}
        {trend === "stable" && <div className="flex items-center gap-1.5 text-muted-foreground bg-muted border border-border rounded-full px-3 py-1 text-xs font-semibold"><Minus className="h-3.5 w-3.5" /> Stable vs mois précédent</div>}
      </div>

      {/* Area chart — collected over time */}
      <div className="bg-card border border-border rounded-xl p-4">
        <p className="text-sm font-bold text-foreground mb-4">Encaissements mensuels (12 derniers mois)</p>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={monthlyData} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id="gradCollected" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.25} />
                <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="gradExpected" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
            <YAxis tickFormatter={formatXOF} tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} width={45} />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Area type="monotone" dataKey="expected" name="Attendu" stroke="#3b82f6" fill="url(#gradExpected)" strokeWidth={1.5} dot={false} />
            <Area type="monotone" dataKey="collected" name="Collecté" stroke="#10b981" fill="url(#gradCollected)" strokeWidth={2} dot={{ r: 3, fill: "#10b981" }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Bar chart — unpaid per month */}
      <div className="bg-card border border-border rounded-xl p-4">
        <p className="text-sm font-bold text-foreground mb-4">Impayés par mois</p>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={monthlyData} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
            <YAxis tickFormatter={formatXOF} tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} width={45} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="unpaid" name="Impayé" fill="#f87171" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}