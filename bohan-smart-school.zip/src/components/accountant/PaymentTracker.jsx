import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { DollarSign, AlertTriangle, CheckCircle, Clock, Printer, Plus, X, CalendarClock } from "lucide-react";

// Calcule les prochaines échéances de paiement
// intervalMonths: 3 par défaut (tous les 3 mois), 2 si l'année est de 9 mois
function computeNextInstallments(totalFee, amountPaid, lastPaymentDate, intervalMonths = 3, nbInstallments = 3) {
  const resteDu = Math.max(0, totalFee - amountPaid);
  if (resteDu <= 0) return [];
  const baseDate = lastPaymentDate ? new Date(lastPaymentDate) : new Date();
  const perInstallment = Math.round(resteDu / nbInstallments);
  return Array.from({ length: nbInstallments }, (_, i) => {
    const d = new Date(baseDate);
    d.setMonth(d.getMonth() + (i + 1) * intervalMonths);
    const isLast = i === nbInstallments - 1;
    // Last installment gets the remainder to avoid rounding gaps
    const amount = isLast ? resteDu - perInstallment * (nbInstallments - 1) : perInstallment;
    return { date: d.toISOString().slice(0, 10), amount };
  });
}

function generateReceiptNumber() {
  const now = new Date();
  return `REC-${now.getFullYear()}${String(now.getMonth()+1).padStart(2,"0")}${String(now.getDate()).padStart(2,"0")}-${Math.floor(Math.random()*9000+1000)}`;
}

const STATUS_CONFIG = {
  complet: { label: "Complet", icon: CheckCircle, color: "text-green-700 bg-green-100" },
  partiel: { label: "Partiel", icon: Clock, color: "text-amber-700 bg-amber-100" },
  en_attente: { label: "En attente", icon: AlertTriangle, color: "text-red-700 bg-red-100" },
};

async function printReceiptForPayment(payment, enrollment, schoolInfo) {
  let photoUrl = "";
  let studentNumber = "";
  let address = "";
  let status = "Actif";

  if (enrollment?.student_id) {
    const students = await base44.entities.Student.filter({ id: enrollment.student_id });
    const s = students[0];
    if (s) {
      photoUrl = s.photo_url || "";
      studentNumber = s.student_number || "";
      address = s.address || "";
      status = s.status || "Actif";
    }
  }

  const en = enrollment || {};
  const paymentStatus = en.payment_status || "en_attente";
  const statusLabel = paymentStatus === "complet" ? "COMPLET" : paymentStatus === "partiel" ? "PARTIEL" : "EN ATTENTE";
  const statusColor = paymentStatus === "complet" ? "#16a34a" : paymentStatus === "partiel" ? "#d97706" : "#dc2626";
  const tuitionFee = en.tuition_fee || 0;
  const enrollmentFee = en.enrollment_fee || 0;
  const platformFee = en.platform_fee || 500;
  const totalFee = en.total_fee || 0;
  const amountPaid = en.amount_paid || 0;

  const photoHtml = photoUrl
    ? `<img src="${photoUrl}" style="width:90px;height:110px;object-fit:cover;border-radius:8px;border:3px solid #1d4ed8;" />`
    : `<div style="width:90px;height:110px;border-radius:8px;border:2px dashed #94a3b8;display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:10px;text-align:center">Pas de photo</div>`;

  const si = schoolInfo || {};
  const logoHtml = si.logo_url
    ? `<img src="${si.logo_url}" style="height:52px;max-width:120px;object-fit:contain;filter:brightness(0) invert(1)" />`
    : `<div style="font-size:26px;font-weight:900;letter-spacing:2px">BOHAN</div>`;

  const w = window.open("", "_blank", "width=720,height=960");
  w.document.write(`<!DOCTYPE html><html><head><title>Reçu - ${en.first_name} ${en.last_name}</title><style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:Arial,sans-serif;background:#f1f5f9;padding:20px;color:#1e293b}.page{background:white;max-width:660px;margin:0 auto;border-radius:14px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.13)}.header{background:linear-gradient(135deg,#1e3a8a 0%,#1d4ed8 100%);color:white;padding:28px 32px;display:flex;align-items:center;justify-content:space-between}.logo{font-size:26px;font-weight:900;letter-spacing:2px}.sub{font-size:11px;opacity:.7;margin-top:4px}.rnum{background:rgba(255,255,255,.15);border-radius:10px;padding:10px 18px;text-align:center}.rnum .n{font-size:16px;font-weight:800;font-family:monospace}.rnum .l{font-size:10px;opacity:.7}.body{padding:28px 32px}.section{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:#64748b;margin:20px 0 10px;border-bottom:1px solid #e2e8f0;padding-bottom:5px}.student-block{display:flex;gap:20px;align-items:flex-start;background:#f8faff;border-radius:12px;padding:18px;border-left:5px solid #1d4ed8;margin-bottom:4px}.sname{font-size:22px;font-weight:900;color:#1e3a8a;margin-bottom:10px}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:8px}.iitem .lbl{font-size:9px;text-transform:uppercase;letter-spacing:.5px;color:#94a3b8;display:block}.iitem .val{font-size:13px;font-weight:700;color:#1e293b}.parent-block{background:#f8fafc;border-radius:10px;padding:14px 18px;display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px}.ftable{width:100%;border-collapse:collapse;font-size:13px;margin-top:4px}.ftable td{padding:10px 14px;border-bottom:1px solid #f1f5f9}.ftable td:last-child{text-align:right;font-weight:600}.ftable .thead td{background:#f1f5f9;font-weight:700;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:#64748b}.ftable .trow{background:#1e3a8a;color:white;font-size:16px;font-weight:900}.ftable .trow td{border:none;padding:12px 14px}.ftable .gpay td{color:#16a34a}.ftable .gredue td{color:#dc2626}.status-center{text-align:center;margin:24px 0}.badge{display:inline-block;padding:12px 32px;border-radius:50px;font-size:18px;font-weight:900;color:white;background:${statusColor};letter-spacing:1px}.sig-row{display:flex;justify-content:space-between;align-items:flex-end;margin-top:24px;padding-top:18px;border-top:1px solid #e2e8f0}.footer{background:#f8fafc;border-top:1px solid #e2e8f0;padding:12px 32px;display:flex;justify-content:space-between;font-size:10px;color:#94a3b8}@media print{body{background:white;padding:0}.page{box-shadow:none;border-radius:0}*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important;color-adjust:exact!important}}</style></head><body>
  <div class="page">
    <div class="header">
      <div>${logoHtml}<div class="sub" style="margin-top:6px">${si.name || "BOHAN"}</div>${si.address ? `<div style="font-size:9px;opacity:.6;margin-top:2px">${si.address}</div>` : ""}</div>
      <div style="text-align:right"><div style="font-size:10px;opacity:.7;margin-bottom:6px">REÇU OFFICIEL DE PAIEMENT</div><div class="rnum"><div class="l">N° REÇU</div><div class="n">${payment.receipt_number || "—"}</div></div></div>
    </div>
    <div class="body">
      <div class="section">📄 Informations de l'élève</div>
      <div class="student-block">${photoHtml}<div style="flex:1"><div class="sname">${en.last_name || ""} ${en.first_name || ""}</div><div class="grid2">
        <div class="iitem"><span class="lbl">N° Étudiant</span><span class="val">${studentNumber || "—"}</span></div>
        <div class="iitem"><span class="lbl">Classe</span><span class="val">${en.class_name || "—"}</span></div>
        <div class="iitem"><span class="lbl">Niveau</span><span class="val">${en.level_requested || "—"}</span></div>
        <div class="iitem"><span class="lbl">Sexe</span><span class="val">${en.gender || "—"}</span></div>
        <div class="iitem"><span class="lbl">Date de naissance</span><span class="val">${en.date_of_birth ? new Date(en.date_of_birth).toLocaleDateString("fr-FR") : "—"}</span></div>
        <div class="iitem"><span class="lbl">Statut</span><span class="val">${status}</span></div>
        <div class="iitem"><span class="lbl">Année scolaire</span><span class="val">${en.academic_year || "—"}</span></div>
        <div class="iitem"><span class="lbl">Date d'inscription</span><span class="val">${en.enrollment_date ? new Date(en.enrollment_date).toLocaleDateString("fr-FR") : "—"}</span></div>
        ${address ? `<div class="iitem" style="grid-column:1/-1"><span class="lbl">Adresse</span><span class="val">${address}</span></div>` : ""}
      </div></div></div>

      <div class="section">👨‍👧 Parent / Tuteur</div>
      <div class="parent-block">
        <div class="iitem"><span class="lbl">Nom</span><span class="val">${en.parent_name || "—"}</span></div>
        <div class="iitem"><span class="lbl">Téléphone</span><span class="val">${en.parent_phone || "—"}</span></div>
        ${en.parent_email ? `<div class="iitem" style="grid-column:1/-1"><span class="lbl">Email</span><span class="val">${en.parent_email}</span></div>` : ""}
      </div>

      <div class="section">💰 Détail des frais</div>
      <table class="ftable">
        <tr class="thead"><td>Désignation</td><td>Montant</td></tr>
        <tr><td>Droit d'inscription</td><td>${enrollmentFee.toLocaleString("fr-FR")} XOF</td></tr>
        ${tuitionFee > 0 ? `<tr><td>Frais de scolarité</td><td>${tuitionFee.toLocaleString("fr-FR")} XOF</td></tr>` : ""}
        <tr><td>Frais plateforme BOHAN</td><td>${platformFee.toLocaleString("fr-FR")} XOF</td></tr>
        <tr class="trow"><td>TOTAL À PAYER</td><td>${totalFee.toLocaleString("fr-FR")} XOF</td></tr>
        <tr class="gpay"><td>✅ Montant versé</td><td>${amountPaid.toLocaleString("fr-FR")} XOF</td></tr>
        <tr class="gredue"><td>🟥 Reste dû</td><td>${Math.max(0, totalFee - amountPaid).toLocaleString("fr-FR")} XOF</td></tr>
        <tr><td>Mode / Moyen de paiement</td><td>${en.payment_mode || "—"} / ${payment.payment_method || "—"}</td></tr>
        <tr><td>Date de paiement</td><td>${payment.payment_date ? new Date(payment.payment_date).toLocaleDateString("fr-FR") : "—"}</td></tr>
      </table>

      ${Math.max(0, totalFee - amountPaid) > 0 ? (() => {
        const installments = computeNextInstallments(totalFee, amountPaid, payment.payment_date);
        return `<div style="margin:18px 0 8px;padding:14px 18px;background:#fffbeb;border:2px solid #f59e0b;border-radius:10px">
          <p style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#92400e;margin-bottom:10px">📅 Prochaines échéances suggérées</p>
          ${installments.map((inst, i) => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px dashed #fcd34d;font-size:12px">
              <span style="color:#78350f">Échéance ${i+1} — <strong>${new Date(inst.date).toLocaleDateString("fr-FR",{day:"2-digit",month:"long",year:"numeric"})}</strong></span>
              <span style="font-weight:900;color:#92400e">${inst.amount.toLocaleString("fr-FR")} XOF</span>
            </div>`).join("")}
          <p style="font-size:10px;color:#a16207;margin-top:8px">* Dates indicatives — le comptable peut ajuster le montant ou la date lors du prochain versement.</p>
        </div>`;
      })() : ""}

      <div class="status-center"><div class="badge">PAIEMENT : ${statusLabel}</div></div>

      <div class="sig-row">
        <div style="font-size:12px"><div style="font-weight:700;margin-bottom:3px">Comptable</div><div style="color:#64748b">${en.accountant_name || ""}</div></div>
        <div style="text-align:center"><div style="width:160px;border-top:1px dashed #94a3b8;padding-top:8px;font-size:10px;color:#94a3b8">Signature &amp; cachet</div></div>
      </div>
    </div>
    <div class="footer"><span>BOHAN — Plateforme de gestion scolaire</span><span>Réimprimé le ${new Date().toLocaleDateString("fr-FR")} à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</span></div>
  </div></body></html>`);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 600);
}

export default function PaymentTracker({ schoolId: propSchoolId, schoolInfo }) {
  const [enrollments, setEnrollments] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [selectedEnrollment, setSelectedEnrollment] = useState(null);
  const [addPaymentForm, setAddPaymentForm] = useState({ amount: "", payment_method: "espèces" });
  const [addingPayment, setAddingPayment] = useState(false);
  const [reprinting, setReprinting] = useState(null);
  const [installmentConfig, setInstallmentConfig] = useState({ intervalMonths: 3, nbInstallments: 3 });

  async function load() {
    const schoolId = propSchoolId;
    if (!schoolId) { setLoading(false); return; }
    const f = { school_id: schoolId };
    const [enrs, pays] = await Promise.all([
      base44.entities.Enrollment.filter(f, "-enrollment_date", 200),
      base44.entities.Payment.filter(f, "-payment_date", 500),
    ]);
    setEnrollments(enrs);
    setPayments(pays);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleReprint(payment) {
    setReprinting(payment.id);
    const enrollment = enrollments.find(e => e.id === payment.enrollment_id) || null;
    await printReceiptForPayment(payment, enrollment, schoolInfo);
    setReprinting(null);
  }

  async function handleAddPayment(e) {
    e.preventDefault();
    setAddingPayment(true);
    const schoolId = propSchoolId;
    const amount = parseFloat(addPaymentForm.amount);
    const newAmountPaid = (selectedEnrollment.amount_paid || 0) + amount;
    const newStatus = newAmountPaid >= selectedEnrollment.total_fee ? "complet" : "partiel";
    const receiptNumber = generateReceiptNumber();

    await base44.entities.Payment.create({
      school_id: schoolId,
      enrollment_id: selectedEnrollment.id,
      student_name: `${selectedEnrollment.first_name} ${selectedEnrollment.last_name}`,
      class_name: selectedEnrollment.class_name,
      amount,
      payment_type: "scolarité",
      payment_date: new Date().toISOString().slice(0,10),
      payment_method: addPaymentForm.payment_method,
      receipt_number: receiptNumber,
      academic_year: selectedEnrollment.academic_year,
    });

    await base44.entities.Enrollment.update(selectedEnrollment.id, {
      amount_paid: newAmountPaid,
      payment_status: newStatus,
      enrollment_status: newStatus === "complet" ? "validé" : selectedEnrollment.enrollment_status,
    });

    setSelectedEnrollment(null);
    setAddPaymentForm({ amount: "", payment_method: "espèces" });
    await load();
    setAddingPayment(false);
  }

  const filtered = enrollments.filter(e => filter === "all" || e.payment_status === filter);

  if (loading) return <div className="flex justify-center py-10"><div className="w-7 h-7 border-4 border-primary/20 border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap">
        {[
          { v: "all", label: `Tous (${enrollments.length})` },
          { v: "en_attente", label: `En attente (${enrollments.filter(e=>e.payment_status==="en_attente").length})` },
          { v: "partiel", label: `Partiel (${enrollments.filter(e=>e.payment_status==="partiel").length})` },
          { v: "complet", label: `Complet (${enrollments.filter(e=>e.payment_status==="complet").length})` },
        ].map(({ v, label }) => (
          <button key={v} onClick={() => setFilter(v)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filter===v ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}>
            {label}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="space-y-2">
        {filtered.length === 0 && <p className="text-center text-sm text-muted-foreground py-8">Aucune inscription trouvée.</p>}
        {filtered.map(enr => {
          const cfg = STATUS_CONFIG[enr.payment_status] || STATUS_CONFIG.en_attente;
          const Icon = cfg.icon;
          const restDu = (enr.total_fee || 0) - (enr.amount_paid || 0);
          const enrPayments = payments.filter(p => p.enrollment_id === enr.id);
          return (
            <div key={enr.id} className="bg-card border border-border rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground text-sm">{enr.first_name} {enr.last_name}</p>
                  <p className="text-xs text-muted-foreground">{enr.class_name || enr.level_requested} · {enr.academic_year}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-semibold flex items-center gap-1 ${cfg.color}`}>
                    <Icon className="h-3 w-3" />{cfg.label}
                  </span>
                  <button onClick={() => setSelectedEnrollment(enr)}
                    className="text-xs bg-primary text-primary-foreground px-2.5 py-1 rounded-lg font-semibold hover:bg-primary/90 flex items-center gap-1">
                    <Plus className="h-3 w-3" /> Paiement
                  </button>
                </div>
              </div>
              <div className="flex gap-4 text-xs">
                <span className="text-muted-foreground">Total: <span className="font-semibold text-foreground">{(enr.total_fee||0).toLocaleString("fr-FR")} XOF</span></span>
                <span className="text-muted-foreground">Payé: <span className="font-semibold text-green-700">{(enr.amount_paid||0).toLocaleString("fr-FR")} XOF</span></span>
                {restDu > 0 && <span className="text-muted-foreground">Reste: <span className="font-semibold text-red-700">{restDu.toLocaleString("fr-FR")} XOF</span></span>}
              </div>
              {/* Payment history with reprint */}
              {enrPayments.length > 0 && (
                <div className="border-t border-border/50 pt-2 space-y-1.5">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-semibold">Historique ({enrPayments.length} versement{enrPayments.length > 1 ? "s" : ""})</p>
                    {restDu > 0 && (
                      <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-semibold">À compléter</span>
                    )}
                  </div>
                  {enrPayments.map((p, idx) => (
                    <div key={p.id} className="flex items-center justify-between text-xs bg-muted/40 rounded-lg px-3 py-2.5 gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-foreground">Versement {idx + 1}</span>
                          <span className="text-muted-foreground">•</span>
                          <span className="text-muted-foreground">{p.payment_date ? new Date(p.payment_date).toLocaleDateString("fr-FR") : "—"}</span>
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5 text-[9px] text-muted-foreground">
                          <span>{p.payment_method}</span>
                          <span>•</span>
                          <span className="font-mono">{p.receipt_number}</span>
                        </div>
                      </div>
                      <span className="font-bold text-green-700 shrink-0 whitespace-nowrap">+{(p.amount||0).toLocaleString("fr-FR")} XOF</span>
                      <button
                        onClick={() => handleReprint(p)}
                        disabled={reprinting === p.id}
                        className="ml-1 shrink-0 flex items-center gap-1 px-2 py-1 rounded-lg border border-border hover:bg-white text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50 text-[10px]"
                        title="Réimprimer ce reçu"
                      >
                        <Printer className="h-3.5 w-3.5" />
                        {reprinting === p.id ? "…" : "Réimpr."}
                      </button>
                    </div>
                  ))}
                </div>
              )}
              {/* Prochaines échéances */}
              {restDu > 0 && enrPayments.length > 0 && (() => {
                const lastPay = enrPayments[enrPayments.length - 1];
                const installments = computeNextInstallments(enr.total_fee, enr.amount_paid, lastPay.payment_date);
                return (
                  <div className="border-t border-dashed border-amber-300 pt-2 mt-1">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <CalendarClock className="h-3.5 w-3.5 text-amber-600" />
                      <p className="text-[10px] uppercase tracking-wide text-amber-700 font-semibold">Échéances suggérées (tous les 3 mois)</p>
                    </div>
                    <div className="space-y-1">
                      {installments.map((inst, i) => (
                        <div key={i} className="flex items-center justify-between text-xs bg-amber-50 border border-amber-200 rounded-lg px-3 py-1.5">
                          <span className="text-amber-800 font-medium">
                            📅 Échéance {i + 1} — {new Date(inst.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })}
                          </span>
                          <span className="font-bold text-amber-900">{inst.amount.toLocaleString("fr-FR")} XOF</span>
                        </div>
                      ))}
                    </div>
                    <p className="text-[10px] text-amber-600 mt-1">* Dates indicatives — le comptable peut ajuster lors du prochain paiement.</p>
                  </div>
                );
              })()}
            </div>
          );
        })}
      </div>

      {/* Add Payment Modal */}
      {selectedEnrollment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={() => setSelectedEnrollment(null)}>
          <div className="bg-background rounded-2xl shadow-2xl w-full max-w-sm p-6 space-y-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-foreground">Enregistrer un paiement</h3>
              <button onClick={() => setSelectedEnrollment(null)} className="w-7 h-7 rounded-full hover:bg-muted flex items-center justify-center"><X className="h-4 w-4" /></button>
            </div>
            <div className="bg-muted rounded-lg p-3 text-sm space-y-1">
              <p className="font-semibold">{selectedEnrollment.first_name} {selectedEnrollment.last_name}</p>
              <p className="text-muted-foreground text-xs">Reste dû : <span className="font-bold text-red-600">{((selectedEnrollment.total_fee||0)-(selectedEnrollment.amount_paid||0)).toLocaleString("fr-FR")} XOF</span></p>
            </div>
            {/* Echéances suggérées */}
            {(() => {
              const enrPays = payments.filter(p => p.enrollment_id === selectedEnrollment.id);
              const lastPay = enrPays[enrPays.length - 1];
              const installments = computeNextInstallments(selectedEnrollment.total_fee, selectedEnrollment.amount_paid, lastPay?.payment_date);
              if (!installments.length) return null;
              return (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 space-y-1.5">
                  <div className="flex items-center gap-1.5 mb-1">
                    <CalendarClock className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                    <p className="text-xs font-bold text-amber-800">Échéances suggérées (3 versements × 3 mois)</p>
                  </div>
                  {installments.map((inst, i) => (
                    <div key={i} className="flex justify-between items-center text-xs">
                      <span className="text-amber-700">Éch. {i+1} — {new Date(inst.date).toLocaleDateString("fr-FR", { day:"2-digit", month:"short", year:"numeric" })}</span>
                      <span className="font-bold text-amber-900">{inst.amount.toLocaleString("fr-FR")} XOF</span>
                    </div>
                  ))}
                  <p className="text-[10px] text-amber-600 pt-1 border-t border-amber-200">Ajustez le montant ci-dessous si nécessaire.</p>
                </div>
              );
            })()}
            <form onSubmit={handleAddPayment} className="space-y-3">
              <div>
                <label className="text-xs font-medium block mb-1">Montant (XOF) *</label>
                <input type="number" min="1" value={addPaymentForm.amount} onChange={e => setAddPaymentForm(f=>({...f,amount:e.target.value}))} required className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring font-mono" placeholder="Ex: 30000" />
              </div>
              <div>
                <label className="text-xs font-medium block mb-1">Moyen de paiement</label>
                <select value={addPaymentForm.payment_method} onChange={e => setAddPaymentForm(f=>({...f,payment_method:e.target.value}))} className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                  <option value="espèces">Espèces</option>
                  <option value="mobile_money">Mobile Money</option>
                  <option value="chèque">Chèque</option>
                  <option value="virement">Virement</option>
                </select>
              </div>
              <button type="submit" disabled={addingPayment || !addPaymentForm.amount}
                className="w-full bg-primary text-primary-foreground rounded-xl py-2.5 font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
                <DollarSign className="h-4 w-4" />
                {addingPayment ? "Enregistrement…" : "Confirmer le paiement"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}