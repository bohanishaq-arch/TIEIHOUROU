import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { Printer, Search } from "lucide-react";

async function printReceiptForPayment(payment, enrollment, schoolInfo) {
  let photoUrl = "";
  let studentNumber = "";
  let address = "";
  let status = "Actif";
  let accountantFullName = "";

  if (enrollment?.student_id) {
    const students = await base44.entities.Student.filter({ id: enrollment.student_id });
    const s = students[0];
    if (s) {
      photoUrl = s.photo_url || "";
      studentNumber = s.student_number || "";
      address = s.address || "";
      status = s.status || "Actif";
    }
  }

  // Récupérer le nom complet du comptable depuis AppAccess (pas l'email)
  if (enrollment?.accountant_email) {
    const accRecords = await base44.entities.AppAccess.filter({ user_email: enrollment.accountant_email });
    if (accRecords[0]?.full_name) {
      accountantFullName = accRecords[0].full_name;
    }
  }
  if (!accountantFullName) accountantFullName = enrollment?.accountant_name || "";

  const en = enrollment || {};
  const paymentStatus = en.payment_status || "en_attente";
  const statusLabel = paymentStatus === "complet" ? "SOLDÉ" : paymentStatus === "partiel" ? "PARTIEL" : "EN ATTENTE";
  const statusColor = paymentStatus === "complet" ? "#059669" : paymentStatus === "partiel" ? "#d97706" : "#dc2626";
  const statusBg = paymentStatus === "complet" ? "#ecfdf5" : paymentStatus === "partiel" ? "#fffbeb" : "#fef2f2";
  const statusBorder = paymentStatus === "complet" ? "#6ee7b7" : paymentStatus === "partiel" ? "#fcd34d" : "#fca5a5";
  const tuitionFee = en.tuition_fee || 0;
  const enrollmentFee = en.enrollment_fee || 0;
  const platformFee = en.platform_fee || 500;
  const totalFee = en.total_fee || 0;
  const amountPaid = en.amount_paid || 0;
  const resteDu = Math.max(0, totalFee - amountPaid);
  const printDate = new Date().toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" });
  const printTime = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });

  const si = schoolInfo || {};

  const photoHtml = photoUrl
    ? `<img src="${photoUrl}" style="width:88px;height:108px;object-fit:cover;border-radius:8px;border:2px solid #dbeafe;display:block;" />`
    : `<div style="width:88px;height:108px;border-radius:8px;border:2px dashed #cbd5e1;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#f8fafc;color:#94a3b8;font-size:9px;text-align:center;gap:4px;"><svg width="28" height="28" fill="none" stroke="#cbd5e1" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>Pas de photo</div>`;

  const logoHtml = si.logo_url
    ? `<img src="${si.logo_url}" style="height:54px;max-width:130px;object-fit:contain;filter:brightness(0) invert(1)" />`
    : `<div style="font-size:28px;font-weight:900;letter-spacing:3px;color:#fff">BOHAN</div>`;

  const htmlContent = `<!DOCTYPE html>
<html><head>
<meta charset="utf-8">
<title>Facture Pro-Forma — ${en.last_name || ""} ${en.first_name || ""}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  html,body{width:210mm;background:#fff;font-family:'Inter',Arial,sans-serif;color:#1e293b}
  @page{size:A4 portrait;margin:0}
  @media print{
    html,body{width:210mm}
    .page{box-shadow:none!important;border-radius:0!important;page-break-after:avoid}
    *{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
  }
  .page{width:210mm;min-height:297mm;background:white;position:relative;overflow:hidden}

  /* HEADER */
  .header{background:linear-gradient(135deg,#0f2460 0%,#1d4ed8 55%,#2563eb 100%);color:white;padding:22px 32px 18px;display:flex;align-items:center;justify-content:space-between;position:relative;overflow:hidden}
  .header::before{content:'';position:absolute;right:-40px;top:-40px;width:180px;height:180px;background:rgba(255,255,255,.06);border-radius:50%}
  .school-info .school-name{font-size:12px;font-weight:800;margin-top:4px;opacity:.95}
  .school-info .school-sub{font-size:9px;opacity:.55;margin-top:1px}
  .doc-badge{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.25);border-radius:10px;padding:10px 18px;text-align:right;flex-shrink:0}
  .doc-badge .doc-type{font-size:8px;text-transform:uppercase;letter-spacing:2px;opacity:.7;margin-bottom:6px}
  .doc-badge .doc-num{font-size:14px;font-weight:900;font-family:monospace;letter-spacing:.5px}
  .doc-badge .doc-date{font-size:9px;opacity:.55;margin-top:4px}

  /* META BAND */
  .meta-band{background:#f0f4ff;border-bottom:1px solid #dbeafe;padding:8px 32px;display:flex;gap:24px;align-items:center}
  .meta-band .mitem{font-size:10px;color:#64748b}
  .meta-band .mitem strong{color:#1e3a8a;display:block;font-size:11px}

  /* STATUS BAR */
  .status-bar{margin:16px 32px 0;background:${statusBg};border:1.5px solid ${statusBorder};border-radius:10px;padding:10px 18px;display:flex;align-items:center;justify-content:space-between}
  .status-dot{width:8px;height:8px;border-radius:50%;background:${statusColor};margin-right:8px;display:inline-block;flex-shrink:0}
  .status-text{font-size:11px;font-weight:700;color:${statusColor};letter-spacing:.5px;text-transform:uppercase}
  .status-amounts{font-size:11px;color:${statusColor};font-weight:600}

  /* CONTENT */
  .content{padding:14px 32px 20px}

  /* SECTION TITLE */
  .sec-title{display:flex;align-items:center;gap:8px;margin:14px 0 8px}
  .sec-line{flex:1;height:1px;background:linear-gradient(90deg,#e2e8f0,transparent)}
  .sec-label{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#64748b;white-space:nowrap}

  /* STUDENT CARD */
  .student-card{display:flex;gap:16px;align-items:flex-start;background:linear-gradient(135deg,#f8faff,#eff6ff);border:1px solid #dbeafe;border-radius:12px;padding:14px 16px}
  .info-grid{flex:1;display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px 12px}
  .iitem .lbl{font-size:8px;font-weight:600;text-transform:uppercase;letter-spacing:.8px;color:#94a3b8;display:block;margin-bottom:1px}
  .iitem .val{font-size:11px;font-weight:700;color:#1e293b}
  .student-name-row{grid-column:1/-1;margin-bottom:4px}
  .sname{font-size:18px;font-weight:900;color:#1e3a8a}
  .sid-badge{display:inline-block;background:#dbeafe;color:#1d4ed8;font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;font-family:monospace;margin-left:8px;vertical-align:middle}

  /* PARENT */
  .parent-row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 14px}

  /* FINANCE TABLE */
  .fin-table{width:100%;border-collapse:collapse;font-size:11px;margin-top:4px}
  .fin-table th{background:#1e3a8a;color:white;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;padding:8px 12px;text-align:left}
  .fin-table th:last-child{text-align:right}
  .fin-table td{padding:8px 12px;border-bottom:1px solid #f1f5f9;color:#334155}
  .fin-table td:last-child{text-align:right;font-weight:600;color:#1e293b}
  .fin-table tr:last-child td{border-bottom:none}
  .fin-table .subtotal-row td{background:#f1f5f9}
  .fin-table .total-row td{background:#1e3a8a;color:white;font-weight:800;font-size:13px;padding:10px 12px;border:none}
  .fin-table .total-row td:last-child{font-size:15px}
  .fin-table .paid-row td{color:#059669;background:#f0fdf4;font-weight:700}
  .fin-table .due-row td{color:#dc2626;background:#fef2f2;font-weight:700}
  .fin-table .solved-row td{color:#166534;background:#dcfce7;font-weight:700}
  .fin-table .info-row td{color:#334155;background:#f8fafc}

  /* PAYMENT SUMMARY BOX */
  .pay-summary{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}
  .pay-box{border-radius:10px;padding:10px 14px;border:1px solid}
  .pay-box .pb-label{font-size:9px;text-transform:uppercase;letter-spacing:.8px;font-weight:600;margin-bottom:3px}
  .pay-box .pb-value{font-size:16px;font-weight:900}

  /* SIGNATURES */
  .sig-row{display:flex;justify-content:space-between;align-items:flex-end;margin-top:20px;padding-top:14px;border-top:1px solid #e2e8f0}
  .sig-box{text-align:center}
  .sig-line{width:150px;border-bottom:1.5px solid #94a3b8;margin:28px auto 6px}
  .sig-label{font-size:9px;color:#64748b;font-weight:500}
  .sig-name{font-size:11px;font-weight:700;color:#1e293b;margin-top:2px}

  /* FOOTER */
  .footer{background:linear-gradient(90deg,#0f2460,#1d4ed8);color:white;padding:10px 32px;display:flex;justify-content:space-between;align-items:center;position:absolute;bottom:0;left:0;right:0}
  .footer-brand{font-size:11px;font-weight:800;letter-spacing:2px;opacity:.9}
  .footer-info{font-size:9px;opacity:.6}

  /* WATERMARK */
  .watermark{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-35deg);font-size:68px;font-weight:900;color:rgba(29,78,216,.04);letter-spacing:6px;pointer-events:none;white-space:nowrap;z-index:0}
</style>
</head>
<body>
<div class="page">
  <div class="watermark">${statusLabel}</div>

  <!-- HEADER -->
  <div class="header">
    <div class="school-info">
      ${logoHtml}
      <div class="school-name">${si.name || "ÉTABLISSEMENT"}</div>
      ${si.address ? `<div class="school-sub">${si.address}${si.phone ? " · " + si.phone : ""}</div>` : ""}
    </div>
    <div class="doc-badge">
      <div class="doc-type">Facture Pro-Forma · Reçu Officiel</div>
      <div class="doc-num">${payment.receipt_number || "—"}</div>
      <div class="doc-date">Émis le ${printDate}</div>
    </div>
  </div>

  <!-- META BAND -->
  <div class="meta-band">
    <div class="mitem"><strong>Année scolaire</strong>${en.academic_year || "—"}</div>
    <div class="mitem"><strong>Date d'inscription</strong>${en.enrollment_date ? new Date(en.enrollment_date).toLocaleDateString("fr-FR") : "—"}</div>
    <div class="mitem"><strong>Date de paiement</strong>${payment.payment_date ? new Date(payment.payment_date).toLocaleDateString("fr-FR") : "—"}</div>
    <div class="mitem"><strong>Mode de paiement</strong>${en.payment_mode || "—"} · ${payment.payment_method || "—"}</div>
    <div class="mitem"><strong>Comptable</strong>${accountantFullName || "—"}</div>
  </div>

  <!-- STATUS BAR -->
  <div class="status-bar">
    <div style="display:flex;align-items:center">
      <span class="status-dot"></span>
      <span class="status-text">Statut : ${statusLabel}</span>
    </div>
    <span class="status-amounts">
      Versé : ${amountPaid.toLocaleString("fr-FR")} XOF · 
      ${resteDu > 0 ? "Reste dû : " + resteDu.toLocaleString("fr-FR") + " XOF" : "✓ Intégralement soldé"}
    </span>
  </div>

  <div class="content" style="position:relative;z-index:1">

    <!-- ÉLÈVE -->
    <div class="sec-title"><span class="sec-label">Identité de l'élève</span><div class="sec-line"></div></div>
    <div class="student-card">
      ${photoHtml}
      <div class="info-grid">
        <div class="iitem student-name-row">
          <span class="sname">${(en.last_name || "").toUpperCase()} ${en.first_name || ""}</span>
          ${studentNumber ? `<span class="sid-badge">${studentNumber}</span>` : ""}
        </div>
        <div class="iitem"><span class="lbl">Date de naissance</span><span class="val">${en.date_of_birth ? new Date(en.date_of_birth).toLocaleDateString("fr-FR") : "—"}</span></div>
        <div class="iitem"><span class="lbl">Sexe</span><span class="val">${en.gender || "—"}</span></div>
        <div class="iitem"><span class="lbl">Statut</span><span class="val">${status}</span></div>
        <div class="iitem"><span class="lbl">Classe affectée</span><span class="val">${en.class_name || "—"}</span></div>
        <div class="iitem"><span class="lbl">Niveau</span><span class="val">${en.level_requested || "—"}</span></div>
        <div class="iitem"><span class="lbl">Type d'élève</span><span class="val">${enrollmentFee === (en.enrollment_fee_affecte || 0) && tuitionFee === 0 ? "Affecté" : "Non-affecté"}</span></div>
        ${address ? `<div class="iitem" style="grid-column:1/-1"><span class="lbl">Adresse</span><span class="val">${address}</span></div>` : ""}
      </div>
    </div>

    <!-- PARENT -->
    <div class="sec-title"><span class="sec-label">Parent / Tuteur légal</span><div class="sec-line"></div></div>
    <div class="parent-row">
      <div class="iitem"><span class="lbl">Nom complet</span><span class="val">${en.parent_name || "—"}</span></div>
      <div class="iitem"><span class="lbl">Téléphone</span><span class="val">${en.parent_phone || "—"}</span></div>
      <div class="iitem"><span class="lbl">Email</span><span class="val">${en.parent_email || "—"}</span></div>
    </div>

    <!-- FINANCES -->
    <div class="sec-title"><span class="sec-label">Détail des frais scolaires</span><div class="sec-line"></div></div>
    <table class="fin-table">
      <thead><tr><th style="width:55%">Désignation</th><th>Détails</th><th>Montant</th></tr></thead>
      <tbody>
        <tr><td>Droit d'inscription</td><td style="color:#64748b;font-size:10px">${tuitionFee === 0 ? "Élève affecté" : "Élève non-affecté"}</td><td>${enrollmentFee.toLocaleString("fr-FR")} XOF</td></tr>
        ${tuitionFee > 0 ? `<tr><td>Frais de scolarité</td><td style="color:#64748b;font-size:10px">Annuel</td><td>${tuitionFee.toLocaleString("fr-FR")} XOF</td></tr>` : ""}
        <tr class="subtotal-row"><td>Frais plateforme BOHAN</td><td style="font-size:10px;color:#64748b">Service numérique</td><td>${platformFee.toLocaleString("fr-FR")} XOF</td></tr>
        <tr class="total-row"><td colspan="2">TOTAL À PAYER</td><td>${totalFee.toLocaleString("fr-FR")} XOF</td></tr>
        <tr class="paid-row"><td colspan="2">✓ Montant versé par le parent</td><td>${amountPaid.toLocaleString("fr-FR")} XOF</td></tr>
        ${resteDu > 0
          ? `<tr class="due-row"><td colspan="2">Solde restant dû</td><td>${resteDu.toLocaleString("fr-FR")} XOF</td></tr>`
          : `<tr class="solved-row"><td colspan="2">✅ Facture intégralement soldée</td><td>0 XOF</td></tr>`
        }
        <tr class="info-row"><td>Mode / Moyen de paiement</td><td colspan="2" style="text-align:right;color:#334155">${en.payment_mode || "—"} · ${payment.payment_method || "—"}</td></tr>
        <tr class="info-row"><td>Référence du paiement</td><td colspan="2" style="text-align:right;color:#334155;font-family:monospace">${payment.receipt_number || "—"}</td></tr>
      </tbody>
    </table>

    <!-- PAYMENT SUMMARY BOXES -->
    <div class="pay-summary">
      <div class="pay-box" style="background:#eff6ff;border-color:#bfdbfe">
        <div class="pb-label" style="color:#1d4ed8">Total à payer</div>
        <div class="pb-value" style="color:#1e3a8a">${totalFee.toLocaleString("fr-FR")} XOF</div>
      </div>
      <div class="pay-box" style="background:${statusBg};border-color:${statusBorder}">
        <div class="pb-label" style="color:${statusColor}">Statut final</div>
        <div class="pb-value" style="color:${statusColor};font-size:13px">${statusLabel} — ${amountPaid.toLocaleString("fr-FR")} XOF versé</div>
      </div>
    </div>

    <!-- SIGNATURES -->
    <div class="sig-row">
      <div style="font-size:10px;color:#64748b;max-width:200px;line-height:1.5">
        <p style="font-weight:700;color:#1e293b;margin-bottom:2px">Mention obligatoire</p>
        <p>Je soussigné(e) <strong>${en.parent_name || "le parent"}</strong> reconnais avoir reçu ce reçu officiel d'inscription.</p>
      </div>
      <div class="sig-box">
        <div class="sig-line"></div>
        <div class="sig-label">Signature du parent / tuteur</div>
      </div>
      <div class="sig-box">
        <div class="sig-line"></div>
        <div class="sig-label">Comptable · Cachet</div>
        <div class="sig-name">${accountantFullName || "—"}</div>
      </div>
    </div>

  </div>

  <div class="footer">
    <div>
      <div class="footer-brand">BOHAN</div>
      <div class="footer-info">Plateforme de gestion scolaire numérique</div>
    </div>
    <div class="footer-info">Document généré le ${printDate} à ${printTime} · Réf. ${payment.receipt_number || "—"}</div>
  </div>
</div>
</body></html>`;

  const blob = new Blob([htmlContent], { type: "text/html" });
  const blobUrl = URL.createObjectURL(blob);
  const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

  if (isMobile) {
    const iframe = document.createElement("iframe");
    iframe.style.cssText = "position:fixed;top:0;left:0;width:100%;height:100%;border:none;z-index:9999;background:white";
    iframe.src = blobUrl;
    document.body.appendChild(iframe);
    iframe.onload = () => {
      setTimeout(() => {
        iframe.contentWindow.print();
        setTimeout(() => { document.body.removeChild(iframe); URL.revokeObjectURL(blobUrl); }, 1000);
      }, 500);
    };
  } else {
    const w = window.open(blobUrl, "_blank", "width=820,height=1060");
    if (w) {
      w.onload = () => { setTimeout(() => { w.print(); URL.revokeObjectURL(blobUrl); }, 500); };
    } else {
      window.location.href = blobUrl;
    }
  }
}

export default function ReceiptHistory({ schoolId: propSchoolId, schoolInfo }) {
  const [payments, setPayments] = useState([]);
  const [enrollments, setEnrollments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [reprinting, setReprinting] = useState(null);

  useEffect(() => {
    async function load() {
      const schoolId = propSchoolId;
      if (!schoolId) { setLoading(false); return; }
      const f = { school_id: schoolId };
      const [pays, enrs] = await Promise.all([
        base44.entities.Payment.filter(f, "-payment_date", 500),
        base44.entities.Enrollment.filter(f, "-enrollment_date", 200),
      ]);
      setPayments(pays);
      setEnrollments(enrs);
      setLoading(false);
    }
    load();
  }, [propSchoolId]);

  async function handleReprint(payment) {
    setReprinting(payment.id);
    const enrollment = enrollments.find(e => e.id === payment.enrollment_id) || null;
    await printReceiptForPayment(payment, enrollment, schoolInfo);
    setReprinting(null);
  }

  const filtered = payments.filter(p => {
    const q = search.toLowerCase();
    return (
      !q ||
      p.student_name?.toLowerCase().includes(q) ||
      p.receipt_number?.toLowerCase().includes(q) ||
      p.class_name?.toLowerCase().includes(q)
    );
  });

  if (loading) return <div className="flex justify-center py-10"><div className="w-7 h-7 border-4 border-primary/20 border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 bg-muted/50 border border-border rounded-xl px-3 py-2">
        <Search className="h-4 w-4 text-muted-foreground shrink-0" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Rechercher par élève, N° reçu, classe…"
          className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>

      <p className="text-xs text-muted-foreground">{filtered.length} reçu(s) trouvé(s)</p>

      {filtered.length === 0 && (
        <p className="text-center text-sm text-muted-foreground py-10">Aucun reçu trouvé.</p>
      )}

      <div className="space-y-2">
        {filtered.map(p => (
          <div key={p.id} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-foreground">{p.student_name || "—"}</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {p.class_name || "—"} · {p.payment_date ? new Date(p.payment_date).toLocaleDateString("fr-FR") : "—"} · {p.payment_method}
              </p>
              <p className="font-mono text-[11px] text-muted-foreground mt-0.5">{p.receipt_number}</p>
            </div>
            <div className="text-right shrink-0">
              <p className="font-bold text-green-700 text-sm">{(p.amount || 0).toLocaleString("fr-FR")} XOF</p>
              <p className="text-[10px] text-muted-foreground capitalize">{p.payment_type}</p>
            </div>
            <button
              onClick={() => handleReprint(p)}
              disabled={reprinting === p.id}
              className="ml-2 shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl border border-border bg-white hover:bg-emerald-50 hover:border-emerald-300 text-muted-foreground hover:text-emerald-700 transition-colors disabled:opacity-50"
            >
              <Printer className="h-4 w-4" />
              <span className="text-xs font-semibold">{reprinting === p.id ? "…" : "Réimprimer"}</span>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}