import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Search, Loader2, AlertCircle, CheckCircle, X } from "lucide-react";
import { getSchoolId } from "../hooks/useSchool";

export default function TeacherSearchByID({ onSelect, onClear, selectedTeacher }) {
  const [searchId, setSearchId] = useState("");
  const [loading, setLoading] = useState(false);
  const [found, setFound] = useState(null);
  const [error, setError] = useState("");

  async function handleSearch(e) {
    e.preventDefault();
    if (!searchId.trim()) return;
    
    setLoading(true);
    setError("");
    setFound(null);

    try {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      
      // Get all teachers, then filter manually
      const allAccesses = await base44.entities.AppAccess.filter(filter);
      const teachers = allAccesses.filter((a) => a.role === "teacher");
      
      const searchTerm = searchId.trim().toLowerCase();
      const teacher = teachers.find(
        (a) => a.access_id?.toLowerCase() === searchTerm
      );

      if (!teacher) {
        setError(`Aucun professeur trouvé avec l'ID "${searchId}". Vérifiez l'identifiant.`);
        setLoading(false);
        return;
      }

      if (teacher.is_active === false) {
        setError("Ce professeur existe mais son compte est désactivé.");
        setLoading(false);
        return;
      }

      setFound(teacher);
      onSelect({
        email: teacher.user_email,
        name: teacher.full_name,
        id: teacher.access_id,
      });
    } catch (e) {
      setError(`Erreur de recherche : ${e?.message || "Impossible de rechercher"}`);
    } finally {
      setLoading(false);
    }
  }

  if (selectedTeacher) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <CheckCircle className="h-5 w-5 text-green-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-green-700">{selectedTeacher.name}</p>
              <p className="text-xs text-green-600 font-mono">{selectedTeacher.id}</p>
              <p className="text-xs text-green-600 mt-1">{selectedTeacher.email}</p>
            </div>
          </div>
          <button
            onClick={onClear}
            className="text-green-600 hover:text-green-700 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSearch} className="space-y-2">
      <div className="flex gap-2">
        <input
          type="text"
          value={searchId}
          onChange={(e) => setSearchId(e.target.value)}
          placeholder="Ex: PROF-AB-2024-001"
          className="flex-1 border border-input rounded-lg px-3 py-2 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-ring"
        />
        <button
          type="submit"
          disabled={loading || !searchId.trim()}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-60"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          {loading ? "Recherche…" : "Chercher"}
        </button>
      </div>

      {error && (
        <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-sm text-red-700">
          <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
          {error}
        </div>
      )}

      {found && (
        <div className="text-xs text-muted-foreground">
          ✓ Professeur sélectionné : {found.full_name}
        </div>
      )}
    </form>
  );
}