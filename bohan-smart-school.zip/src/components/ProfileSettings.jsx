import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Settings, X, Save, KeyRound, Eye, EyeOff, CheckCircle2, Trash2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * ProfileSettings — modal to update display name AND password.
 * The password change updates the AppAccess record (access_password).
 */
export default function ProfileSettings({ currentName, onSaved, onClose }) {
  // If onClose is passed, we're already open (triggered externally)
  const [open, setOpen] = useState(!onClose);
  const [tab, setTab] = useState("name"); // "name" | "password" | "delete"
  const [name, setName] = useState(currentName || "");
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState("");

  // Password change state
  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [pwdError, setPwdError] = useState("");

  function handleClose() {
    setOpen(false);
    onClose?.();
  }

  function handleOpen() {
    setOpen(true);
    setTab("name");
    setSuccess("");
    setPwdError("");
    setOldPwd(""); setNewPwd(""); setConfirmPwd("");
    setName(currentName || "");
  }

  async function handleDeleteAccount() {
    if (deleteConfirm !== "SUPPRIMER") return;
    setSaving(true);
    await base44.auth.logout();
  }

  async function handleSaveName(e) {
    e.preventDefault();
    setSaving(true);
    await base44.auth.updateMe({ full_name: name.trim() });
    setSaving(false);
    setSuccess("Nom mis à jour avec succès !");
    onSaved && onSaved(name.trim());
    setTimeout(() => setSuccess(""), 3000);
  }

  async function handleChangePassword(e) {
    e.preventDefault();
    setPwdError("");
    if (newPwd.length < 6) { setPwdError("Le mot de passe doit contenir au moins 6 caractères."); return; }
    if (newPwd !== confirmPwd) { setPwdError("Les mots de passe ne correspondent pas."); return; }
    setSaving(true);

    // Find the AppAccess record for the current user and verify old password
    const user = await base44.auth.me();
    const records = await base44.entities.AppAccess.filter({ user_email: user.email?.toLowerCase() });
    const record = records[0];

    if (!record) { setPwdError("Aucun compte d'accès trouvé. Contactez l'administrateur."); setSaving(false); return; }
    if (record.access_password && record.access_password !== oldPwd) {
      setPwdError("Ancien mot de passe incorrect."); setSaving(false); return;
    }

    await base44.entities.AppAccess.update(record.id, { access_password: newPwd });
    setSaving(false);
    setSuccess("Mot de passe changé avec succès !");
    setOldPwd(""); setNewPwd(""); setConfirmPwd("");
    setTimeout(() => setSuccess(""), 3000);
  }

  return (
    <>
      <button
        onClick={handleOpen}
        className="w-9 h-9 rounded-xl bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors shrink-0"
        title="Paramètres du profil"
      >
        <Settings className="h-5 w-5 text-white" />
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={handleClose}>
          <div className="bg-background rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Settings className="h-5 w-5 text-primary" />
                </div>
                <h2 className="text-base font-bold text-foreground">Mon profil</h2>
              </div>
              <button onClick={handleClose} className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center">
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-border overflow-x-auto">
              <button
                onClick={() => { setTab("name"); setSuccess(""); setPwdError(""); }}
                className={`flex-1 py-2.5 text-sm font-semibold whitespace-nowrap transition-colors min-h-[44px] ${tab === "name" ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"}`}
              >
                Nom
              </button>
              <button
                onClick={() => { setTab("password"); setSuccess(""); setPwdError(""); }}
                className={`flex-1 py-2.5 text-sm font-semibold whitespace-nowrap transition-colors flex items-center justify-center gap-1.5 min-h-[44px] ${tab === "password" ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"}`}
              >
                <KeyRound className="h-3.5 w-3.5" /> Mot de passe
              </button>
              <button
                onClick={() => { setTab("delete"); setSuccess(""); setPwdError(""); setDeleteConfirm(""); }}
                className={`flex-1 py-2.5 text-sm font-semibold whitespace-nowrap transition-colors flex items-center justify-center gap-1.5 min-h-[44px] ${tab === "delete" ? "text-destructive border-b-2 border-destructive" : "text-muted-foreground hover:text-destructive"}`}
              >
                <Trash2 className="h-3.5 w-3.5" /> Compte
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Success message */}
              {success && (
                <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-xl px-3 py-2.5 text-sm text-green-700 font-semibold">
                  <CheckCircle2 className="h-4 w-4 shrink-0" /> {success}
                </div>
              )}

              {/* Name tab */}
              {tab === "name" && (
                <form onSubmit={handleSaveName} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-foreground block mb-1.5">Nom affiché dans l'application</label>
                    <input
                      type="text"
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="Ex: M. KONÉ Ibrahim"
                      className="w-full h-10 rounded-lg border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                      required autoFocus
                    />
                    <p className="text-xs text-muted-foreground mt-1">Ce nom apparaîtra dans votre tableau de bord.</p>
                  </div>
                  <div className="flex justify-end gap-3 pt-2 border-t border-border">
                    <Button type="button" variant="outline" onClick={handleClose}>Annuler</Button>
                    <Button type="submit" disabled={saving} className="gap-2">
                      <Save className="h-4 w-4" />
                      {saving ? "Enregistrement…" : "Enregistrer"}
                    </Button>
                  </div>
                </form>
              )}

              {/* Delete account tab */}
              {tab === "delete" && (
                <div className="space-y-4">
                  <div className="flex items-start gap-3 bg-red-50 border border-red-200 rounded-xl p-3">
                    <AlertTriangle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-red-800">Suppression du compte</p>
                      <p className="text-xs text-red-600 mt-0.5">Cette action est irréversible. Votre session sera fermée et votre accès révoqué.</p>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground block mb-1.5">
                      Tapez <span className="font-mono font-bold text-destructive">SUPPRIMER</span> pour confirmer
                    </label>
                    <input
                      type="text"
                      value={deleteConfirm}
                      onChange={e => setDeleteConfirm(e.target.value)}
                      placeholder="SUPPRIMER"
                      className="w-full h-11 rounded-lg border border-red-300 bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-red-400"
                    />
                  </div>
                  <button
                    onClick={handleDeleteAccount}
                    disabled={deleteConfirm !== "SUPPRIMER" || saving}
                    className="w-full flex items-center justify-center gap-2 h-11 rounded-xl bg-destructive text-destructive-foreground text-sm font-semibold disabled:opacity-40 hover:bg-destructive/90 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                    {saving ? "Déconnexion…" : "Supprimer et déconnecter"}
                  </button>
                </div>
              )}

              {/* Password tab */}
              {tab === "password" && (
                <form onSubmit={handleChangePassword} className="space-y-3">
                  {/* Old password */}
                  <div>
                    <label className="text-sm font-medium text-foreground block mb-1.5">Ancien mot de passe</label>
                    <div className="relative">
                      <input
                        type={showOld ? "text" : "password"}
                        value={oldPwd}
                        onChange={e => setOldPwd(e.target.value)}
                        required
                        placeholder="••••••••"
                        className="w-full h-10 rounded-lg border border-input bg-background px-3 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                      />
                      <button type="button" onClick={() => setShowOld(s => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                        {showOld ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {/* New password */}
                  <div>
                    <label className="text-sm font-medium text-foreground block mb-1.5">Nouveau mot de passe</label>
                    <div className="relative">
                      <input
                        type={showNew ? "text" : "password"}
                        value={newPwd}
                        onChange={e => setNewPwd(e.target.value)}
                        required
                        placeholder="Min. 6 caractères"
                        className="w-full h-10 rounded-lg border border-input bg-background px-3 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                      />
                      <button type="button" onClick={() => setShowNew(s => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                        {showNew ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Confirm password */}
                  <div>
                    <label className="text-sm font-medium text-foreground block mb-1.5">Confirmer le nouveau mot de passe</label>
                    <input
                      type="password"
                      value={confirmPwd}
                      onChange={e => setConfirmPwd(e.target.value)}
                      required
                      placeholder="••••••••"
                      className={`w-full h-10 rounded-lg border bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring ${confirmPwd && confirmPwd !== newPwd ? "border-red-400" : "border-input"}`}
                    />
                    {confirmPwd && confirmPwd !== newPwd && (
                      <p className="text-xs text-red-500 mt-1">Les mots de passe ne correspondent pas.</p>
                    )}
                  </div>

                  {pwdError && (
                    <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{pwdError}</p>
                  )}

                  <div className="flex justify-end gap-3 pt-2 border-t border-border">
                    <Button type="button" variant="outline" onClick={handleClose}>Annuler</Button>
                    <Button type="submit" disabled={saving || !oldPwd || !newPwd || newPwd !== confirmPwd} className="gap-2">
                      <KeyRound className="h-4 w-4" />
                      {saving ? "Modification…" : "Changer"}
                    </Button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}