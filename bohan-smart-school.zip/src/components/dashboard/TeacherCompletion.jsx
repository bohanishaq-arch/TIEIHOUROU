import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { CheckCircle, Clock } from "lucide-react";

export default function TeacherCompletion() {
  const [teachers, setTeachers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    Promise.all([
      base44.entities.Grade.filter(filter),
      base44.entities.Subject.filter(filter),
      base44.entities.Class.filter(filter),
      base44.entities.Exam.filter(filter),
    ]).then(([grades, subjects, classes, exams]) => {
      // Group by teacher_name from subjects
      const teacherMap = {};
      subjects.forEach((sub) => {
        if (!sub.teacher_name) return;
        if (!teacherMap[sub.teacher_name]) {
          teacherMap[sub.teacher_name] = { name: sub.teacher_name, totalExams: 0, gradedExams: 0 };
        }
        // Exams for this subject
        const subExams = exams.filter((e) => e.subject_id === sub.id);
        teacherMap[sub.teacher_name].totalExams += subExams.length;
        // Graded = exams that have at least one grade
        subExams.forEach((ex) => {
          const hasGrades = grades.some((g) => g.exam_id === ex.id);
          if (hasGrades) teacherMap[sub.teacher_name].gradedExams += 1;
        });
      });

      setTeachers(Object.values(teacherMap).sort((a, b) => b.gradedExams - a.gradedExams));
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="h-24 flex items-center justify-center"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  if (!teachers.length) return <p className="text-sm text-muted-foreground italic">Aucun professeur assigné</p>;

  return (
    <div className="space-y-2">
      {teachers.map((t, i) => {
        const pct = t.totalExams > 0 ? Math.round((t.gradedExams / t.totalExams) * 100) : 0;
        const done = t.totalExams > 0 && t.gradedExams >= t.totalExams;
        return (
          <div key={i} className="flex items-center gap-3">
            <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${done ? "bg-green-100" : "bg-orange-100"}`}>
              {done ? <CheckCircle className="h-3.5 w-3.5 text-green-600" /> : <Clock className="h-3.5 w-3.5 text-orange-500" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-0.5">
                <p className="text-sm font-medium text-foreground truncate">{t.name}</p>
                <span className="text-xs text-muted-foreground ml-2 shrink-0">{t.gradedExams}/{t.totalExams}</span>
              </div>
              <div className="w-full bg-muted rounded-full h-1.5">
                <div className={`h-1.5 rounded-full ${done ? "bg-green-500" : "bg-orange-400"}`} style={{ width: `${pct}%` }} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}