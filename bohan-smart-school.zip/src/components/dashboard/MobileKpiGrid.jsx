import { Users, School, BookOpen, UserCog, ClipboardList } from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

const CARDS = [
  { key: "students",  label: "Élèves",      icon: Users,         path: "/students",  color: "#60a5fa", glow: "rgba(96,165,250,0.25)" },
  { key: "classes",   label: "Classes",     icon: School,        path: "/classes",   color: "#a78bfa", glow: "rgba(167,139,250,0.25)" },
  { key: "subjects",  label: "Matières",    icon: BookOpen,      path: "/subjects",  color: "#34d399", glow: "rgba(52,211,153,0.25)" },
  { key: "teachers",  label: "Professeurs", icon: UserCog,       path: "/teachers",  color: "#fbbf24", glow: "rgba(251,191,36,0.25)" },
  { key: "grades",    label: "Notes",       icon: ClipboardList, path: "/grades",    color: "#f472b6", glow: "rgba(244,114,182,0.25)" },
];

export default function MobileKpiGrid({ stats }) {
  const navigate = useNavigate();

  return (
    <div className="grid grid-cols-2 gap-3">
      {CARDS.map((card, i) => {
        const Icon = card.icon;
        const value = stats?.[card.key] || 0;

        return (
          <motion.button
            key={card.key}
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.08 + i * 0.06, duration: 0.28 }}
            onClick={() => navigate(card.path)}
            className="rounded-2xl p-4 text-left active:scale-[0.96] transition-transform"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.08)",
              backdropFilter: "blur(8px)",
            }}
          >
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center mb-3"
              style={{ background: card.glow }}
            >
              <Icon size={18} style={{ color: card.color }} />
            </div>
            <p className="text-2xl font-bold leading-none text-white">
              {value.toLocaleString()}
            </p>
            <p className="text-xs font-medium mt-1.5" style={{ color: "rgba(255,255,255,0.45)" }}>
              {card.label}
            </p>
          </motion.button>
        );
      })}

      {CARDS.length % 2 !== 0 && <div />}
    </div>
  );
}