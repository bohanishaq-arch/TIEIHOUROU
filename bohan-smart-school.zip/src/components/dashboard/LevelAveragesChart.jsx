import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

function getColor(avg) {
  if (avg >= 14) return "#16a34a";
  if (avg >= 10) return "#ca8a04";
  return "#dc2626";
}

export default function LevelAveragesChart() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    Promise.all([
      base44.entities.Grade.filter(filter),
      base44.entities.Class.filter(filter),
      base44.entities.Subject.filter(filter),
      base44.entities.Student.filter(filter),
    ]).then(([grades, classes, subjects, students]) => {
      const subjectMap = {};
      subjects.forEach((s) => (subjectMap[s.id] = s));
      const classMap = {};
      classes.forEach((c) => (classMap[c.id] = c));
      const studentClassMap = {};
      students.forEach((s) => (studentClassMap[s.id] = classMap[s.class_id]?.level));

      const levels = [...new Set(classes.map((c) => c.level))].sort();

      const result = levels.map((level) => {
        const levelGrades = grades.filter((g) => {
          const cls = classMap[g.class_id];
          return cls?.level === level;
        });
        const subjectIds = [...new Set(levelGrades.map((g) => g.subject_id))];
        const subjectScores = subjectIds.map((sid) => {
          const sGrades = levelGrades.filter((g) => g.subject_id === sid);
          const coef = subjectMap[sid]?.coefficient || 1;
          const avg = sGrades.reduce((a, g) => a + g.score, 0) / sGrades.length;
          return { avg, coef };
        });
        const totalCoef = subjectScores.reduce((a, s) => a + s.coef, 0);
        const weighted = totalCoef > 0
          ? subjectScores.reduce((a, s) => a + s.avg * s.coef, 0) / totalCoef
          : 0;
        return { name: level, avg: Math.round(weighted * 100) / 100 };
      }).filter((d) => d.avg > 0);

      setData(result);
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="h-48 flex items-center justify-center"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  if (!data.length) return <p className="text-sm text-muted-foreground text-center py-8">Aucune donnée disponible</p>;

  return (
    <ResponsiveContainer width="100%" height={200}>
      <BarChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 4 }}>
        <XAxis dataKey="name" tick={{ fontSize: 11 }} />
        <YAxis domain={[0, 20]} tick={{ fontSize: 11 }} />
        <Tooltip formatter={(v) => [`${v}/20`, "Moyenne"]} />
        <Bar dataKey="avg" radius={[4, 4, 0, 0]}>
          {data.map((entry, i) => <Cell key={i} fill={getColor(entry.avg)} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}