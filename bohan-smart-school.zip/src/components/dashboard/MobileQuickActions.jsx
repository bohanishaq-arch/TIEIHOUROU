import { useNavigate } from "react-router-dom";
import { UserPlus, School, ClipboardList, FileText, UserX, Send } from "lucide-react";
import { motion } from "framer-motion";

const ACTIONS = [
  { label: "Ajouter élève",    icon: UserPlus,      path: "/students",        color: "#2563EB", bg: "#EFF6FF" },
  { label: "Ajouter classe",   icon: School,        path: "/classes",         color: "#7C3AED", bg: "#F5F3FF" },
  { label: "Saisir notes",     icon: ClipboardList, path: "/grades",          color: "#059669", bg: "#ECFDF5" },
  { label: "Bulletins",        icon: FileText,      path: "/reports",         color: "#D97706", bg: "#FFFBEB" },
  { label: "Absences",         icon: UserX,         path: "/students",        color: "#EF4444", bg: "#FEF2F2" },
  { label: "Rapport",          icon: Send,          path: "/teacher-reports", color: "#DB2777", bg: "#FDF2F8" },
];

export default function MobileQuickActions() {
  const navigate = useNavigate();

  return (
    <div
      className="bg-white rounded-2xl p-4"
      style={{ boxShadow: "0 1px 8px rgba(15,23,42,0.06)" }}
    >
      <p className="text-sm font-bold text-slate-800 mb-4">Actions rapides</p>
      <div className="grid grid-cols-3 gap-3">
        {ACTIONS.map(({ label, icon: Icon, path, color, bg }, i) => (
          <motion.button
            key={label}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04, duration: 0.25 }}
            onClick={() => navigate(path)}
            className="flex flex-col items-center gap-2 active:scale-95 transition-transform"
          >
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center"
              style={{ background: bg }}
            >
              <Icon size={20} style={{ color }} />
            </div>
            <span className="text-[10px] font-semibold text-center leading-tight" style={{ color: "#64748B" }}>
              {label}
            </span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}