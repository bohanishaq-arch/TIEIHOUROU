import { useNavigate } from "react-router-dom";
import { UserPlus, School, ClipboardList, FileText, UserX, Send } from "lucide-react";

const ACTIONS = [
  { label: "Ajouter élève",    icon: UserPlus,     path: "/students",     bg: "bg-blue-50 hover:bg-blue-100",    text: "text-blue-600",    border: "border-blue-100" },
  { label: "Ajouter classe",   icon: School,        path: "/classes",      bg: "bg-violet-50 hover:bg-violet-100",text: "text-violet-600",  border: "border-violet-100" },
  { label: "Saisir notes",     icon: ClipboardList, path: "/grades",       bg: "bg-emerald-50 hover:bg-emerald-100",text: "text-emerald-600",border: "border-emerald-100" },
  { label: "Générer bulletin", icon: FileText,      path: "/reports",      bg: "bg-orange-50 hover:bg-orange-100",text: "text-orange-600",  border: "border-orange-100" },
  { label: "Gérer absences",   icon: UserX,         path: "/students",     bg: "bg-red-50 hover:bg-red-100",      text: "text-red-600",     border: "border-red-100" },
  { label: "Envoyer message",  icon: Send,          path: "/teacher-reports", bg: "bg-pink-50 hover:bg-pink-100", text: "text-pink-600",    border: "border-pink-100" },
];

export default function QuickActions() {
  const navigate = useNavigate();

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <h3 className="text-sm font-bold text-gray-900 mb-4">Actions rapides</h3>
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-3">
        {ACTIONS.map(({ label, icon: Icon, path, bg, text, border }) => (
          <button
            key={label}
            onClick={() => navigate(path)}
            className={`flex flex-col items-center justify-center gap-1.5 p-2.5 sm:p-3 rounded-xl border ${bg} ${border} transition-all hover:shadow-sm group active:scale-95`}
          >
            <div className={`w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform`}>
              <Icon className={`h-5 w-5 ${text}`} />
            </div>
            <span className={`text-[10px] font-semibold ${text} text-center leading-tight`}>{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}