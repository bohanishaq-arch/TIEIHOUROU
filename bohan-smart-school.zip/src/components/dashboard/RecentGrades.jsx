import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { ClipboardList } from "lucide-react";
import moment from "moment";

export default function RecentGrades() {
  const [grades, setGrades] = useState([]);
  const [students, setStudents] = useState({});
  const [subjects, setSubjects] = useState({});

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      const gradeList = await base44.entities.Grade.filter(filter, "-created_date", 10);
      const studentList = await base44.entities.Student.filter(filter);
      const subjectList = await base44.entities.Subject.filter(filter);

      const sMap = {};
      studentList.forEach((s) => (sMap[s.id] = `${s.first_name} ${s.last_name}`));
      const subMap = {};
      subjectList.forEach((s) => (subMap[s.id] = s.name));

      setStudents(sMap);
      setSubjects(subMap);
      setGrades(gradeList);
    }
    load();
  }, []);

  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <ClipboardList className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Notes récentes</h3>
      </div>
      {grades.length === 0 ? (
        <p className="text-sm text-muted-foreground">Aucune note saisie</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 px-3 text-xs font-medium text-muted-foreground uppercase">Élève</th>
                <th className="text-left py-2 px-3 text-xs font-medium text-muted-foreground uppercase">Matière</th>
                <th className="text-left py-2 px-3 text-xs font-medium text-muted-foreground uppercase">Note</th>
                <th className="text-left py-2 px-3 text-xs font-medium text-muted-foreground uppercase">Type</th>
                <th className="text-left py-2 px-3 text-xs font-medium text-muted-foreground uppercase">Date</th>
              </tr>
            </thead>
            <tbody>
              {grades.map((g) => (
                <tr key={g.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-2.5 px-3 font-medium">{students[g.student_id] || "—"}</td>
                  <td className="py-2.5 px-3 text-muted-foreground">{subjects[g.subject_id] || "—"}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${
                        g.score >= 14
                          ? "bg-green-100 text-green-700"
                          : g.score >= 10
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-red-100 text-red-700"
                      }`}
                    >
                      {g.score}/{g.max_score || 20}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-muted-foreground">{g.exam_type}</td>
                  <td className="py-2.5 px-3 text-muted-foreground">{moment(g.created_date).fromNow()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}