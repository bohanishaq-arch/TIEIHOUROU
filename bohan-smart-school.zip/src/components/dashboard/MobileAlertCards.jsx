import { AlertTriangle, TrendingDown, UserX, ChevronRight, Bell } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

export default function MobileAlertCards({ stats }) {
  const navigate = useNavigate();

  const alerts = [
    {
      icon: AlertTriangle,
      label: "Élèves en difficulté",
      sub: "Moyenne < 10",
      count: stats?.weakStudents || 0,
      path: "/averages",
      color: "#f87171",
    },
    {
      icon: TrendingDown,
      label: "Classes en baisse",
      sub: "Ce mois",
      count: stats?.decliningClasses || 0,
      path: "/statistics",
      color: "#fbbf24",
    },
    {
      icon: UserX,
      label: "Absences injustifiées",
      sub: "À vérifier",
      count: stats?.unjustifiedAbsences || 0,
      path: "/students",
      color: "#60a5fa",
    },
  ];

  const totalAlerts = alerts.reduce((s, a) => s + a.count, 0);

  return (
    <div className="space-y-2">
      {/* Needs Attention banner */}
      <motion.button
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={() => navigate("/averages")}
        className="w-full flex items-center gap-3 rounded-2xl px-4 py-3.5 active:scale-[0.98] transition-transform"
        style={{
          background: "rgba(255,255,255,0.95)",
          boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
        }}
      >
        <div className="w-9 h-9 rounded-xl bg-purple-100 flex items-center justify-center shrink-0">
          <Bell className="h-4 w-4 text-purple-600" />
        </div>
        <div className="flex-1 text-left">
          <p className="text-sm font-bold text-slate-800">
            Nécessite attention{" "}
            <span className="text-purple-600">({totalAlerts})</span>
          </p>
        </div>
        <ChevronRight className="h-4 w-4 text-slate-400 shrink-0" />
      </motion.button>

      {/* Individual alert rows */}
      {alerts.map((alert, i) => {
        const Icon = alert.icon;
        const hasAlert = alert.count > 0;

        return (
          <motion.button
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 + i * 0.06, duration: 0.3 }}
            onClick={() => navigate(alert.path)}
            className="w-full flex items-center gap-3 rounded-2xl px-4 py-3.5 text-left active:scale-[0.98] transition-transform"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: `${alert.color}22` }}
            >
              <Icon size={16} style={{ color: alert.color }} />
            </div>

            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white leading-tight">{alert.label}</p>
              <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>{alert.sub}</p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span
                className="text-xs font-bold px-2 py-0.5 rounded-full"
                style={{
                  background: hasAlert ? `${alert.color}22` : "rgba(255,255,255,0.08)",
                  color: hasAlert ? alert.color : "rgba(255,255,255,0.3)",
                }}
              >
                {alert.count}
              </span>
              <ChevronRight className="h-3.5 w-3.5" style={{ color: "rgba(255,255,255,0.25)" }} />
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}