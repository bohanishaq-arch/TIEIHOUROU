import { AlertTriangle, TrendingDown, UserX, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function AlertCards({ stats }) {
  const navigate = useNavigate();

  const alerts = [
    {
      icon: AlertTriangle,
      title: "élèves en difficulté",
      subtitle: "Moyenne < 10 cette période",
      count: stats?.weakStudents || 0,
      color: "bg-red-50 border-red-200",
      iconBg: "bg-red-100",
      iconColor: "text-red-600",
      textColor: "text-red-700",
      path: "/averages",
    },
    {
      icon: TrendingDown,
      title: "classe(s) en baisse",
      subtitle: "Performances en baisse ce mois-ci",
      count: stats?.decliningClasses || 0,
      color: "bg-orange-50 border-orange-200",
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      textColor: "text-orange-700",
      path: "/statistics",
    },
    {
      icon: UserX,
      title: "absences non justifiées",
      subtitle: "À vérifier rapidement",
      count: stats?.unjustifiedAbsences || 0,
      color: "bg-blue-50 border-blue-200",
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      textColor: "text-blue-700",
      path: "/students",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
      {alerts.map((alert, i) => {
        const Icon = alert.icon;
        return (
          <button
            key={i}
            onClick={() => navigate(alert.path)}
            className={`flex items-center gap-3 p-3 sm:p-4 rounded-2xl border ${alert.color} hover:shadow-md transition-all text-left group active:scale-95`}
          >
            <div className={`w-10 h-10 rounded-xl ${alert.iconBg} flex items-center justify-center shrink-0`}>
              <Icon className={`h-5 w-5 ${alert.iconColor}`} />
            </div>
            <div className="flex-1 min-w-0">
              <p className={`font-bold text-sm ${alert.textColor}`}>
                {alert.count} {alert.title}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">{alert.subtitle}</p>
            </div>
            <ChevronRight className={`h-4 w-4 ${alert.iconColor} opacity-50 group-hover:opacity-100 shrink-0`} />
          </button>
        );
      })}
    </div>
  );
}