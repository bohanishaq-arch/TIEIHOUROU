import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { Trophy, AlertTriangle, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

function avg(scores) {
  if (!scores.length) return null;
  return scores.reduce((a, b) => a + b, 0) / scores.length;
}

export default function StudentRankings() {
  const [top, setTop] = useState([]);
  const [weak, setWeak] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      const [students, grades] = await Promise.all([
        base44.entities.Student.filter(filter),
        base44.entities.Grade.filter(filter),
      ]);

      const byStudent = {};
      grades.forEach(g => {
        if (!byStudent[g.student_id]) byStudent[g.student_id] = [];
        byStudent[g.student_id].push(g.score);
      });

      const ranked = students
        .map(s => ({ ...s, avg: avg(byStudent[s.id] || []) }))
        .filter(s => s.avg !== null)
        .sort((a, b) => b.avg - a.avg);

      setTop(ranked.slice(0, 3));
      setWeak(ranked.filter(s => s.avg < 10).slice(-3).reverse());
    }
    load();
  }, []);

  const MEDALS = ["🥇", "🥈", "🥉"];

  return (
    <div className="space-y-4">
      {/* Top students */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-yellow-100 rounded-xl flex items-center justify-center">
              <Trophy className="h-4 w-4 text-yellow-600" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-900">Meilleurs élèves</h3>
              <p className="text-[10px] text-gray-400">Ce trimestre</p>
            </div>
          </div>
          <button onClick={() => navigate("/averages")} className="text-[10px] text-blue-600 hover:underline font-medium flex items-center gap-0.5">
            Classement <ChevronRight className="h-3 w-3" />
          </button>
        </div>
        <div className="space-y-2.5">
          {top.length === 0 ? (
            <p className="text-xs text-gray-400 text-center py-3">Aucune donnée</p>
          ) : top.map((s, i) => (
            <div key={s.id} className="flex items-center gap-3">
              <span className="text-lg w-6 shrink-0">{MEDALS[i]}</span>
              <p className="flex-1 text-sm font-medium text-gray-700 truncate">{s.last_name} {s.first_name}</p>
              <span className="text-sm font-bold text-emerald-600">{s.avg?.toFixed(1)}/20</span>
            </div>
          ))}
        </div>
      </div>

      {/* Weak students */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 bg-red-100 rounded-xl flex items-center justify-center">
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Élèves en difficulté</h3>
            <p className="text-[10px] text-gray-400">Moyenne {"<"} 10</p>
          </div>
        </div>
        <div className="space-y-2.5">
          {weak.length === 0 ? (
            <p className="text-xs text-gray-400 text-center py-3">Aucun élève en difficulté 🎉</p>
          ) : weak.map((s, i) => (
            <div key={s.id} className="flex items-center gap-3">
              <span className="w-5 h-5 rounded-full bg-red-100 text-red-600 text-[10px] font-bold flex items-center justify-center shrink-0">{i + 1}</span>
              <p className="flex-1 text-sm font-medium text-gray-700 truncate">{s.last_name} {s.first_name}</p>
              <span className="text-sm font-bold text-red-500">{s.avg?.toFixed(1)}/20</span>
            </div>
          ))}
        </div>
        {weak.length > 0 && (
          <button onClick={() => navigate("/averages")} className="w-full mt-3 text-xs text-red-500 hover:underline font-medium">
            Voir tous →
          </button>
        )}
      </div>
    </div>
  );
}