import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function SubjectPerformance() {
  const [best, setBest] = useState([]);
  const [worst, setWorst] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    Promise.all([
      base44.entities.Grade.filter(filter),
      base44.entities.Subject.filter(filter),
    ]).then(([grades, subjects]) => {
      const subjectMap = {};
      subjects.forEach((s) => (subjectMap[s.id] = s));

      const subjectIds = [...new Set(grades.map((g) => g.subject_id))];
      const subjectAvgs = subjectIds.map((sid) => {
        const sGrades = grades.filter((g) => g.subject_id === sid);
        const avg = sGrades.reduce((a, g) => a + g.score, 0) / sGrades.length;
        return { name: subjectMap[sid]?.name || "—", avg: Math.round(avg * 100) / 100 };
      }).sort((a, b) => b.avg - a.avg);

      setBest(subjectAvgs.slice(0, 5));
      setWorst(subjectAvgs.slice(-5).reverse());
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="h-32 flex items-center justify-center"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <p className="text-xs font-semibold text-green-600 uppercase tracking-wide mb-2 flex items-center gap-1">
          <TrendingUp className="h-3.5 w-3.5" /> Matières les plus réussies
        </p>
        <div className="space-y-2">
          {best.map((s, i) => (
            <div key={i} className="flex items-center justify-between p-2 bg-green-50 rounded-lg">
              <span className="text-sm font-medium text-foreground">{s.name}</span>
              <span className="text-sm font-bold text-green-600">{s.avg}/20</span>
            </div>
          ))}
          {!best.length && <p className="text-sm text-muted-foreground italic">Aucune donnée</p>}
        </div>
      </div>
      <div>
        <p className="text-xs font-semibold text-red-500 uppercase tracking-wide mb-2 flex items-center gap-1">
          <TrendingDown className="h-3.5 w-3.5" /> Matières les plus faibles
        </p>
        <div className="space-y-2">
          {worst.map((s, i) => (
            <div key={i} className="flex items-center justify-between p-2 bg-red-50 rounded-lg">
              <span className="text-sm font-medium text-foreground">{s.name}</span>
              <span className="text-sm font-bold text-red-500">{s.avg}/20</span>
            </div>
          ))}
          {!worst.length && <p className="text-sm text-muted-foreground italic">Aucune donnée</p>}
        </div>
      </div>
    </div>
  );
}