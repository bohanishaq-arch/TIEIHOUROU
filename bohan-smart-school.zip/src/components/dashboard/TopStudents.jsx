import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { Award } from "lucide-react";

export default function TopStudents() {
  const [topStudents, setTopStudents] = useState([]);

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      const [grades, students] = await Promise.all([
        base44.entities.Grade.filter(filter),
        base44.entities.Student.filter(filter),
      ]);

      const studentMap = {};
      students.forEach((s) => {
        studentMap[s.id] = `${s.first_name} ${s.last_name}`;
      });

      const avgByStudent = {};
      grades.forEach((g) => {
        if (!avgByStudent[g.student_id]) avgByStudent[g.student_id] = { total: 0, count: 0 };
        avgByStudent[g.student_id].total += g.score;
        avgByStudent[g.student_id].count += 1;
      });

      const ranked = Object.entries(avgByStudent)
        .map(([id, vals]) => ({
          name: studentMap[id] || "Inconnu",
          moyenne: Math.round((vals.total / vals.count) * 100) / 100,
        }))
        .sort((a, b) => b.moyenne - a.moyenne)
        .slice(0, 5);

      setTopStudents(ranked);
    }
    load();
  }, []);

  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Award className="h-4 w-4 text-secondary" />
        <h3 className="text-sm font-semibold text-foreground">Meilleurs élèves</h3>
      </div>
      {topStudents.length === 0 ? (
        <p className="text-sm text-muted-foreground">Aucune donnée</p>
      ) : (
        <div className="space-y-3">
          {topStudents.map((s, i) => (
            <div key={i} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    i === 0
                      ? "bg-secondary text-secondary-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {i + 1}
                </span>
                <span className="text-sm font-medium text-foreground">{s.name}</span>
              </div>
              <span className="text-sm font-semibold text-primary">{s.moyenne}/20</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}