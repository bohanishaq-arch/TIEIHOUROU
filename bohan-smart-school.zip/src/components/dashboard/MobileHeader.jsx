import { Search, Bell } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolName } from "../../hooks/useSchool";
import { getDisplayName } from "../../hooks/useDisplayName";

export default function MobileHeader({ onNotifClick }) {
  const { user } = useAuth();
  const schoolName = getSchoolName();

  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? "Bonjour" : hour < 18 ? "Bon après-midi" : "Bonsoir";
  const displayName = getDisplayName(user?.full_name);
  const firstName = displayName?.split(" ")[0] || "Administrateur";
  const dateStr = now.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "2-digit" });

  return (
    <div
      className="lg:hidden px-4 pt-4 pb-5 relative overflow-hidden"
      style={{ background: "linear-gradient(135deg, #1a2340 0%, #0f172a 60%, #1e3a5f 100%)" }}
    >
      {/* Decorative circles */}
      <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full opacity-10" style={{ background: "radial-gradient(circle, #60a5fa, transparent)" }} />
      <div className="absolute -bottom-4 -left-4 w-24 h-24 rounded-full opacity-10" style={{ background: "radial-gradient(circle, #34d399, transparent)" }} />

      {/* Row 1 — Logo + actions */}
      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="flex items-center gap-2.5">
          <img
            src="https://media.base44.com/images/public/69d451f34dcd67ebe250192e/239e74618_generated_image.png"
            alt="BOHAN"
            className="h-8 w-8 rounded-xl object-contain bg-white/10 p-0.5"
          />
          <span className="font-black text-lg text-white tracking-widest" style={{ letterSpacing: "0.15em" }}>
            BOHAN
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onNotifClick}
            className="relative w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center active:scale-95 transition-transform"
          >
            <Search className="h-4 w-4 text-white/80" />
          </button>
          <button
            onClick={onNotifClick}
            className="relative w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center active:scale-95 transition-transform"
          >
            <Bell className="h-4 w-4 text-white/80" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white/30" />
          </button>
        </div>
      </div>

      {/* Row 2 — Greeting */}
      <div className="relative z-10">
        <h1 className="text-xl font-bold text-white leading-tight">
          {greeting}, <span className="text-blue-300">{firstName}</span>
        </h1>
        <div className="flex items-center gap-1.5 mt-1">
          <span className="text-white/40 text-xs">🕐</span>
          <p className="text-xs text-white/50 font-medium">
            Mis à jour {dateStr} {schoolName ? `· ${schoolName}` : ""}
          </p>
        </div>
      </div>
    </div>
  );
}