import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Users, School, BookOpen, UserCog, ClipboardList, TrendingUp, ArrowUpRight } from "lucide-react";
import { LineChart, Line, ResponsiveContainer } from "recharts";

const SPARKLINE_DATA = [
  [4,7,5,9,8,10,12],
  [6,8,7,11,10,9,11],
  [3,5,8,6,9,10,9],
  [5,7,6,8,9,8,10],
  [2,4,6,8,7,9,11],
];

const CARDS = [
  { key: "students",  label: "Élèves inscrits",  icon: Users,        path: "/students",  color: "from-blue-500 to-blue-600",    bg: "bg-blue-50",    text: "text-blue-600",    trend: "+12% ce mois",  sparkColor: "#3b82f6" },
  { key: "classes",   label: "Classes",           icon: School,       path: "/classes",   color: "from-violet-500 to-purple-600",bg: "bg-violet-50",  text: "text-violet-600",  trend: "+2 nouvelles",  sparkColor: "#7c3aed" },
  { key: "subjects",  label: "Matières",          icon: BookOpen,     path: "/subjects",  color: "from-emerald-500 to-teal-600", bg: "bg-emerald-50", text: "text-emerald-600", trend: "Stable",        sparkColor: "#10b981" },
  { key: "teachers",  label: "Professeurs",       icon: UserCog,      path: "/teachers",  color: "from-orange-500 to-amber-500", bg: "bg-orange-50",  text: "text-orange-600",  trend: "Actif",         sparkColor: "#f59e0b" },
  { key: "grades",    label: "Notes saisies",     icon: ClipboardList,path: "/grades",    color: "from-rose-500 to-pink-600",    bg: "bg-rose-50",    text: "text-rose-600",    trend: "+1 aujourd'hui",sparkColor: "#f43f5e" },
];

export default function KpiCards({ stats }) {
  const navigate = useNavigate();

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
      {CARDS.map((card, i) => {
        const Icon = card.icon;
        const sparkData = SPARKLINE_DATA[i].map(v => ({ v }));
        return (
          <motion.div
            key={card.key}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07, duration: 0.4, ease: "easeOut" }}
            onClick={() => navigate(card.path)}
            className="group cursor-pointer bg-white rounded-2xl border border-gray-100 p-3 sm:p-4 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 shadow-sm active:scale-95"
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl ${card.bg} flex items-center justify-center`}>
                <Icon className={`h-5 w-5 ${card.text}`} />
              </div>
              <ArrowUpRight className={`h-4 w-4 ${card.text} opacity-0 group-hover:opacity-60 transition-opacity`} />
            </div>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-1 truncate">{card.label}</p>
            <p className="text-2xl sm:text-3xl font-bold text-gray-900">{(stats?.[card.key] || 0).toLocaleString()}</p>
            <div className="flex items-center justify-between mt-2">
              <p className="text-[11px] text-gray-400 flex items-center gap-1">
                <TrendingUp className="h-3 w-3 text-emerald-500" />
                {card.trend}
              </p>
            </div>
            <div className="mt-3" style={{ width: "100%", height: 32 }}>
              <ResponsiveContainer width="100%" height={32}>
                <LineChart data={sparkData}>
                  <Line type="monotone" dataKey="v" stroke={card.sparkColor} strokeWidth={1.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}