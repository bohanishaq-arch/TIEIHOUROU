import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function PerformanceChart() {
  const [data, setData] = useState([]);

  useEffect(() => {
    async function loadData() {
      const grades = await base44.entities.Grade.list();
      const classes = await base44.entities.Class.list();

      const classMap = {};
      classes.forEach((c) => {
        classMap[c.id] = c.name;
      });

      const avgByClass = {};
      grades.forEach((g) => {
        const className = classMap[g.class_id] || "Autre";
        if (!avgByClass[className]) avgByClass[className] = { total: 0, count: 0 };
        avgByClass[className].total += g.score;
        avgByClass[className].count += 1;
      });

      const chartData = Object.entries(avgByClass).map(([name, vals]) => ({
        name,
        moyenne: Math.round((vals.total / vals.count) * 100) / 100,
      }));

      setData(chartData);
    }
    loadData();
  }, []);

  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <h3 className="text-sm font-semibold text-foreground mb-4">Moyenne par classe</h3>
      {data.length === 0 ? (
        <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">
          Aucune donnée disponible
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="name" fontSize={12} tick={{ fill: "hsl(var(--muted-foreground))" }} />
            <YAxis domain={[0, 20]} fontSize={12} tick={{ fill: "hsl(var(--muted-foreground))" }} />
            <Tooltip
              contentStyle={{
                background: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                fontSize: "12px",
              }}
            />
            <Bar dataKey="moyenne" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}