import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

const TRIMESTERS = ["Trimestre 1", "Trimestre 2", "Trimestre 3"];
const COLORS = ["#1e4078", "#c4a020", "#16a34a", "#9333ea", "#dc2626"];

export default function EvolutionChart() {
  const [data, setData] = useState([]);
  const [classNames, setClassNames] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    Promise.all([
      base44.entities.Grade.filter(filter),
      base44.entities.Class.filter(filter),
      base44.entities.Subject.filter(filter),
    ]).then(([grades, classes, subjects]) => {
      const subjectMap = {};
      subjects.forEach((s) => (subjectMap[s.id] = s));

      // Top 5 classes by student count approximation
      const top5 = classes.slice(0, 5);
      setClassNames(top5.map((c) => c.name));

      const chartData = TRIMESTERS.map((t) => {
        const row = { trimester: t.replace("Trimestre ", "T") };
        top5.forEach((cls) => {
          const classGrades = grades.filter((g) => g.class_id === cls.id && g.trimester === t);
          const subIds = [...new Set(classGrades.map((g) => g.subject_id))];
          const scores = subIds.map((sid) => {
            const sg = classGrades.filter((g) => g.subject_id === sid);
            const coef = subjectMap[sid]?.coefficient || 1;
            const avg = sg.reduce((a, g) => a + g.score, 0) / sg.length;
            return { avg, coef };
          });
          const totalCoef = scores.reduce((a, s) => a + s.coef, 0);
          row[cls.name] = totalCoef > 0
            ? Math.round(scores.reduce((a, s) => a + s.avg * s.coef, 0) / totalCoef * 100) / 100
            : null;
        });
        return row;
      });

      setData(chartData);
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="h-48 flex items-center justify-center"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div style={{ width: "100%", height: 220 }}>
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data} margin={{ top: 4, right: 12, left: -16, bottom: 4 }}>
        <XAxis dataKey="trimester" tick={{ fontSize: 12 }} />
        <YAxis domain={[0, 20]} tick={{ fontSize: 11 }} />
        <Tooltip formatter={(v) => v ? [`${v}/20`] : ["—"]} />
        <Legend wrapperStyle={{ fontSize: 11 }} />
        {classNames.map((name, i) => (
          <Line key={name} type="monotone" dataKey={name} stroke={COLORS[i % COLORS.length]} strokeWidth={2} dot={{ r: 4 }} connectNulls />
        ))}
      </LineChart>
    </ResponsiveContainer>
    </div>
  );
}