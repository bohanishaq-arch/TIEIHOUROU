import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { BookOpen, UserPlus, School, FileText, ClipboardList, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

function timeAgo(date) {
  if (!date) return "—";
  const d = new Date(date);
  const now = new Date();
  const diff = Math.floor((now - d) / 1000);
  if (diff < 60) return "À l'instant";
  if (diff < 3600) return `Il y a ${Math.floor(diff / 60)} min`;
  if (diff < 86400) return `Aujourd'hui, ${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
  return `Hier, ${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
}

export default function RecentActivities() {
  const [activities, setActivities] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      const [grades, students, classes] = await Promise.all([
        base44.entities.Grade.filter(filter, "-created_date", 5),
        base44.entities.Student.filter(filter, "-created_date", 3),
        base44.entities.Class.filter(filter, "-updated_date", 2),
      ]);

      const acts = [
        ...grades.map(g => ({
          icon: ClipboardList,
          bg: "bg-blue-100",
          color: "text-blue-600",
          text: `Note saisie pour un élève en ${g.trimester || ""}`,
          time: g.created_date,
          path: "/grades",
        })),
        ...students.map(s => ({
          icon: UserPlus,
          bg: "bg-emerald-100",
          color: "text-emerald-600",
          text: `Nouvel élève inscrit : ${s.first_name} ${s.last_name}`,
          time: s.created_date,
          path: "/students",
        })),
        ...classes.map(c => ({
          icon: School,
          bg: "bg-violet-100",
          color: "text-violet-600",
          text: `Classe ${c.name} modifiée`,
          time: c.updated_date,
          path: "/classes",
        })),
      ].sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 6);

      setActivities(acts);
    }
    load();
  }, []);

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-bold text-gray-900">Activités récentes</h3>
          <p className="text-xs text-gray-400 mt-0.5">Dernières actions</p>
        </div>
        <button onClick={() => navigate("/grades")} className="text-xs text-blue-600 hover:underline font-medium flex items-center gap-1">
          Voir tout <ChevronRight className="h-3 w-3" />
        </button>
      </div>
      <div className="space-y-3">
        {activities.length === 0 ? (
          <p className="text-sm text-gray-400 text-center py-4">Aucune activité récente</p>
        ) : activities.map((act, i) => {
          const Icon = act.icon;
          return (
            <button key={i} onClick={() => navigate(act.path)} className="w-full flex items-center gap-3 hover:bg-gray-50 rounded-xl p-2 -mx-2 transition-colors text-left">
              <div className={`w-8 h-8 rounded-xl ${act.bg} flex items-center justify-center shrink-0`}>
                <Icon className={`h-4 w-4 ${act.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-gray-700 truncate">{act.text}</p>
                <p className="text-[10px] text-gray-400 mt-0.5">{timeAgo(act.time)}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}