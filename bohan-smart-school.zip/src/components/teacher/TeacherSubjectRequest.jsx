import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { Send, CheckCircle, Clock, XCircle, PlusCircle, Loader2 } from "lucide-react";

const STATUS_CONFIG = {
  en_attente: { label: "En attente", icon: Clock, color: "bg-yellow-100 text-yellow-700 border-yellow-200" },
  approuvee: { label: "Approuvée", icon: CheckCircle, color: "bg-green-100 text-green-700 border-green-200" },
  rejetee: { label: "Rejetée", icon: XCircle, color: "bg-red-100 text-red-700 border-red-200" },
};

export default function TeacherSubjectRequest({ myAssignments }) {
  const { user } = useAuth();
  const [subjects, setSubjects] = useState([]);
  const [classes, setClasses] = useState([]);
  const [myRequests, setMyRequests] = useState([]);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ class_id: "", subject_id: "", motivation: "" });
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      const email = user?.email?.toLowerCase();

      const [subs, cls, reqs, accesses] = await Promise.all([
        base44.entities.Subject.filter(filter),
        base44.entities.Class.filter(filter),
        base44.entities.SubjectRequest.filter({ teacher_email: email }),
        base44.entities.AppAccess.filter({ user_email: email }),
      ]);

      setSubjects(subs);
      setClasses(cls);
      setMyRequests(reqs.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
      const p = accesses.find((a) => a.role === "teacher" && a.is_active !== false);
      setProfile(p || null);
      setLoading(false);
    }
    load();
  }, [user]);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    const schoolId = getSchoolId();
    const cls = classes.find((c) => c.id === form.class_id);
    const sub = subjects.find((s) => s.id === form.subject_id);

    await base44.entities.SubjectRequest.create({
      school_id: schoolId,
      teacher_email: user?.email?.toLowerCase(),
      teacher_name: profile?.full_name || user?.full_name || user?.email,
      teacher_access_id: profile?.access_id || "",
      class_id: form.class_id,
      class_name: cls?.name || "",
      subject_id: form.subject_id,
      subject_name: sub?.name || "",
      motivation: form.motivation,
      status: "en_attente",
    });

    const updated = await base44.entities.SubjectRequest.filter({ teacher_email: user?.email?.toLowerCase() });
    setMyRequests(updated.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
    setForm({ class_id: "", subject_id: "", motivation: "" });
    setShowForm(false);
    setSuccess(true);
    setSaving(false);
    setTimeout(() => setSuccess(false), 4000);
  }

  // Already assigned combinations
  const assignedPairs = new Set(myAssignments.map((a) => `${a.class_id}|${a.subject_id}`));
  const pendingPairs = new Set(myRequests.filter(r => r.status === "en_attente").map((r) => `${r.class_id}|${r.subject_id}`));

  if (loading) return (
    <div className="flex items-center justify-center h-40">
      <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
    </div>
  );

  return (
    <div className="space-y-6">
      {success && (
        <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-xl px-4 py-3 text-green-700 text-sm">
          <CheckCircle className="h-5 w-5 shrink-0" />
          Votre demande a été envoyée avec succès. Elle sera examinée par l'administration.
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-bold text-foreground">Mes demandes d'enseignement</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Soumettez une demande pour enseigner une matière dans une classe.</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors"
        >
          <PlusCircle className="h-4 w-4" />
          Nouvelle demande
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-card border-2 border-primary/20 rounded-2xl p-5 space-y-4">
          <h4 className="font-semibold text-foreground">Nouvelle demande d'enseignement</h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-1.5">Classe *</label>
              <select
                value={form.class_id}
                onChange={(e) => setForm((f) => ({ ...f, class_id: e.target.value, subject_id: "" }))}
                required
                className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="">-- Choisir une classe --</option>
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>{c.name} ({c.level})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground block mb-1.5">Matière *</label>
              {form.class_id && (() => {
                const availableSubjects = subjects.filter(s => !assignedPairs.has(`${form.class_id}|${s.id}`) && !pendingPairs.has(`${form.class_id}|${s.id}`));
                return (
                  <>
                    {availableSubjects.length > 0 && (
                      <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-xs font-semibold text-blue-900 mb-2">📚 Matières disponibles pour cette classe:</p>
                        <div className="flex flex-wrap gap-2">
                          {availableSubjects.map(s => (
                            <button
                              key={s.id}
                              type="button"
                              onClick={() => setForm((f) => ({ ...f, subject_id: s.id }))}
                              className={`text-xs px-3 py-1.5 rounded-lg border-2 font-medium transition-all ${
                                form.subject_id === s.id
                                  ? "bg-primary text-primary-foreground border-primary"
                                  : "bg-white border-blue-300 text-blue-700 hover:bg-blue-100"
                              }`}
                            >
                              {s.name}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    <select
                      value={form.subject_id}
                      onChange={(e) => setForm((f) => ({ ...f, subject_id: e.target.value }))}
                      required
                      className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      <option value="">-- Choisir une matière --</option>
                      {subjects.map((s) => {
                        const alreadyAssigned = assignedPairs.has(`${form.class_id}|${s.id}`);
                        const alreadyPending = pendingPairs.has(`${form.class_id}|${s.id}`);
                        return (
                          <option key={s.id} value={s.id} disabled={alreadyAssigned || alreadyPending}>
                            {s.name} (Coeff. {s.coefficient}){alreadyAssigned ? " — déjà assigné" : alreadyPending ? " — demande en cours" : ""}
                          </option>
                        );
                      })}
                    </select>
                  </>
                );
              })()}
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Motivation (optionnel)</label>
            <textarea
              value={form.motivation}
              onChange={(e) => setForm((f) => ({ ...f, motivation: e.target.value }))}
              placeholder="Expliquez pourquoi vous souhaitez enseigner cette matière..."
              rows={3}
              className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={() => setShowForm(false)} className="flex-1 px-4 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-muted transition-colors">
              Annuler
            </button>
            <button
              type="submit"
              disabled={saving || !form.class_id || !form.subject_id}
              className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl px-4 py-2.5 text-sm font-semibold disabled:opacity-60 hover:bg-primary/90 transition-colors"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              {saving ? "Envoi…" : "Envoyer la demande"}
            </button>
          </div>
        </form>
      )}

      {/* List of requests */}
      {myRequests.length === 0 ? (
        <div className="bg-muted/40 rounded-xl border border-border p-8 text-center">
          <Send className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
          <p className="font-semibold text-foreground">Aucune demande soumise</p>
          <p className="text-sm text-muted-foreground mt-1">Cliquez sur "Nouvelle demande" pour soumettre votre première demande d'enseignement.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {myRequests.map((req) => {
            const sc = STATUS_CONFIG[req.status] || STATUS_CONFIG.en_attente;
            const Icon = sc.icon;
            return (
              <div key={req.id} className="bg-card rounded-xl border border-border p-4 flex items-start gap-4">
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold text-foreground">{req.subject_name}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">Classe : {req.class_name}</p>
                      {req.motivation && (
                        <p className="text-xs text-muted-foreground mt-1 italic">"{req.motivation}"</p>
                      )}
                      {req.admin_note && (
                        <p className="text-xs mt-1 bg-muted rounded px-2 py-1">Note admin : {req.admin_note}</p>
                      )}
                    </div>
                    <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border shrink-0 ${sc.color}`}>
                      <Icon className="h-3.5 w-3.5" />
                      {sc.label}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Soumise le {new Date(req.created_date).toLocaleDateString("fr-FR")}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}