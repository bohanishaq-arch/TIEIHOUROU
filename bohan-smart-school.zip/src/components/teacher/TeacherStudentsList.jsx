import { useState } from "react";
import { Users, TrendingUp, Search } from "lucide-react";

function avg(arr) {
  if (!arr.length) return null;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function scoreColor(v) {
  if (v === null || v === undefined) return "text-muted-foreground";
  if (v >= 14) return "text-green-600";
  if (v >= 10) return "text-yellow-600";
  return "text-red-600";
}

function scoreBg(v) {
  if (v === null || v === undefined) return "bg-muted text-muted-foreground";
  if (v >= 14) return "bg-green-100 text-green-700";
  if (v >= 10) return "bg-yellow-100 text-yellow-700";
  return "bg-red-100 text-red-700";
}

export default function TeacherStudentsList({ myClasses, myStudents, myGrades, mySubjects }) {
  const [search, setSearch] = useState("");
  const [selectedClass, setSelectedClass] = useState("all");

  const filtered = myStudents.filter((s) => {
    const matchClass = selectedClass === "all" || s.class_id === selectedClass;
    const matchSearch = !search || `${s.first_name} ${s.last_name}`.toLowerCase().includes(search.toLowerCase());
    return matchClass && matchSearch;
  });

  function getStudentAvg(studentId) {
    const g = myGrades.filter((g) => g.student_id === studentId);
    if (!g.length) return null;
    return avg(g.map((x) => x.score));
  }

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un élève…"
            className="w-full pl-9 pr-4 py-2 border border-input rounded-lg text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <select
          value={selectedClass}
          onChange={(e) => setSelectedClass(e.target.value)}
          className="border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="all">Toutes les classes ({myStudents.length} élèves)</option>
          {myClasses.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} ({myStudents.filter((s) => s.class_id === c.id).length} élèves)
            </option>
          ))}
        </select>
      </div>

      {/* Students */}
      {filtered.length === 0 ? (
        <div className="text-center py-12">
          <Users className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">Aucun élève trouvé</p>
        </div>
      ) : (
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/50 border-b border-border">
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Élève</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground">Classe</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground">Notes</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground">Moyenne</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => {
                const a = getStudentAvg(s.id);
                const cls = myClasses.find((c) => c.id === s.class_id);
                const nbGrades = myGrades.filter((g) => g.student_id === s.id).length;
                return (
                  <tr key={s.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-xs shrink-0">
                          {s.first_name?.[0]?.toUpperCase()}
                        </div>
                        <div>
                          <p className="font-semibold">{s.last_name} {s.first_name}</p>
                          <p className="text-xs text-muted-foreground font-mono">{s.student_number}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full font-medium">{cls?.name || "—"}</span>
                    </td>
                    <td className="py-3 px-4 text-center text-muted-foreground text-xs">{nbGrades} note{nbGrades !== 1 ? "s" : ""}</td>
                    <td className="py-3 px-4 text-center">
                      {a !== null ? (
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-sm font-bold ${scoreBg(a)}`}>
                          {a.toFixed(2)}/20
                        </span>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}