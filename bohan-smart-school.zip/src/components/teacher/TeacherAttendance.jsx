import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { CheckCircle2, XCircle, Clock, Users, Send, ChevronLeft, BookOpen, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const STATUS_CONFIG = {
  present: { label: "Présent",   icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-100 border-emerald-300" },
  absent:  { label: "Absent",    icon: XCircle,      color: "text-red-500",     bg: "bg-red-100 border-red-300" },
  retard:  { label: "Retard",    icon: Clock,        color: "text-amber-500",   bg: "bg-amber-100 border-amber-300" },
};

// View: list of past sessions
function SessionHistory({ sessions, classes, subjects, onNew }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-foreground">Historique des pointages</h3>
        <Button onClick={onNew} size="sm" className="gap-2">
          <Users className="h-4 w-4" /> Nouveau pointage
        </Button>
      </div>
      {sessions.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Users className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p className="font-semibold">Aucun pointage effectué</p>
          <p className="text-sm mt-1">Cliquez sur "Nouveau pointage" pour commencer.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {sessions.map(s => {
            const presentCount = s.records?.filter(r => r.status === "present").length || 0;
            const absentCount = s.records?.filter(r => r.status === "absent").length || 0;
            const total = s.records?.length || 0;
            return (
              <div key={s.id} className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground text-sm">{s.class_name} — {s.subject_name}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      📅 {s.date ? new Date(s.date).toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long" }) : "—"}
                      {s.time_slot ? ` · ${s.time_slot}` : ""}
                    </p>
                  </div>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                    s.status === "traité" ? "bg-green-100 text-green-700" :
                    s.status === "soumis" ? "bg-blue-100 text-blue-700" :
                    "bg-muted text-muted-foreground"
                  }`}>
                    {s.status === "traité" ? "✓ Traité" : s.status === "soumis" ? "📨 Envoyé" : "Brouillon"}
                  </span>
                </div>
                <div className="flex gap-3 mt-2 text-xs">
                  <span className="text-emerald-700 font-semibold">{presentCount} présents</span>
                  <span className="text-red-600 font-semibold">{absentCount} absents</span>
                  <span className="text-muted-foreground">{total} élèves</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function TeacherAttendance({ myClasses, myStudents, myAssignments }) {
  const { user } = useAuth();
  const [view, setView] = useState("history"); // "history" | "form"
  const [sessions, setSessions] = useState([]);
  const [loadingSessions, setLoadingSessions] = useState(true);
  const [subjects, setSubjects] = useState([]);
  const [educators, setEducators] = useState([]);

  // Form state
  const [selectedClass, setSelectedClass] = useState(myClasses[0]?.id || "");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [timeSlot, setTimeSlot] = useState("");
  const [duration, setDuration] = useState(60);
  const [attendance, setAttendance] = useState({});
  const [retardTimes, setRetardTimes] = useState({});
  const [saving, setSaving] = useState(false);

  const schoolId = getSchoolId();

  async function loadData() {
    const f = schoolId ? { school_id: schoolId } : {};
    const [subs, sesses, accesses] = await Promise.all([
      base44.entities.Subject.filter(f),
      base44.entities.AttendanceSession.filter(
        { teacher_email: user?.email?.toLowerCase() }, "-date", 100
      ),
      base44.entities.AppAccess.filter({ role: "educator" }),
    ]);
    setSubjects(subs);
    setSessions(sesses);
    setEducators(accesses.filter(a => a.is_active !== false));
    setLoadingSessions(false);
  }

  useEffect(() => { loadData(); }, []);

  // Subjects for selected class via assignments
  const classAssignments = myAssignments?.filter(a => a.class_id === selectedClass) || [];
  const classSubjectIds = new Set(classAssignments.map(a => a.subject_id));
  const classSubjects = subjects.filter(s => classSubjectIds.has(s.id));

  const classStudents = myStudents.filter(s => s.class_id === selectedClass)
    .sort((a, b) => a.last_name.localeCompare(b.last_name));

  function setStatus(studentId, status) {
    setAttendance(prev => ({ ...prev, [studentId]: status }));
  }

  const presentCount = Object.values(attendance).filter(v => v === "present").length;
  const absentCount = Object.values(attendance).filter(v => v === "absent").length;
  const retardCount = Object.values(attendance).filter(v => v === "retard").length;
  const filledCount = classStudents.filter(s => attendance[s.id]).length;

  async function handleSubmit() {
    if (filledCount < classStudents.length) {
      toast.error("Veuillez pointer tous les élèves avant de valider.");
      return;
    }
    setSaving(true);

    const cls = myClasses.find(c => c.id === selectedClass);
    const subj = subjects.find(s => s.id === selectedSubject);
    const educatorAccess = educators.find(e => e.school_id === schoolId) || educators[0];

    const records = classStudents.map(s => ({
      student_id: s.id,
      student_name: `${s.last_name} ${s.first_name}`,
      status: attendance[s.id],
      arrival_time: retardTimes[s.id] || "",
      note: "",
    }));

    // Save session
    const session = await base44.entities.AttendanceSession.create({
      school_id: schoolId,
      class_id: selectedClass,
      class_name: cls?.name || "",
      subject_id: selectedSubject,
      subject_name: subj?.name || "",
      teacher_email: user?.email?.toLowerCase(),
      teacher_name: user?.full_name || user?.email,
      date,
      time_slot: timeSlot,
      duration_minutes: duration,
      academic_year: cls?.academic_year || new Date().getFullYear() + "-" + (new Date().getFullYear() + 1),
      records,
      status: "soumis",
      educator_email: educatorAccess?.user_email || "",
    });

    // Also create Absence records for absent/late students so AbsenceManager can see them
    const absentsAndLate = records.filter(r => r.status === "absent" || r.status === "retard");
    for (const rec of absentsAndLate) {
      const student = classStudents.find(s => s.id === rec.student_id);
      await base44.entities.Absence.create({
        school_id: schoolId,
        student_id: rec.student_id,
        student_name: rec.student_name,
        class_id: selectedClass,
        class_name: cls?.name || "",
        date,
        type: rec.status === "retard" ? "retard" : "absent",
        arrival_time: rec.arrival_time || "",
        period: subj?.name || "",
        educator_email: educatorAccess?.user_email || "",
        educator_name: educatorAccess?.full_name || "",
        notes: `Pointage prof: ${user?.full_name || user?.email}`,
        notified_parent: false,
      });
    }

    toast.success(`✅ Pointage validé et envoyé à l'éducateur ! (${absentCount} absent(s), ${retardCount} retard(s))`);
    setSaving(false);
    setView("history");
    setAttendance({});
    setRetardTimes({});
    loadData();
  }

  if (loadingSessions) {
    return <div className="flex justify-center py-10"><div className="w-7 h-7 border-4 border-orange-200 border-t-orange-600 rounded-full animate-spin" /></div>;
  }

  if (view === "history") {
    return <SessionHistory sessions={sessions} classes={myClasses} subjects={subjects} onNew={() => setView("form")} />;
  }

  return (
    <div className="space-y-4">
      {/* Back button */}
      <button onClick={() => setView("history")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ChevronLeft className="h-4 w-4" /> Retour à l'historique
      </button>

      {/* Header config */}
      <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
        <h3 className="font-bold text-foreground flex items-center gap-2">
          <Users className="h-4 w-4 text-orange-500" /> Nouveau pointage de présences
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Classe *</label>
            <select value={selectedClass}
              onChange={e => { setSelectedClass(e.target.value); setSelectedSubject(""); setAttendance({}); }}
              className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm">
              {myClasses.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Matière *</label>
            <select value={selectedSubject} onChange={e => setSelectedSubject(e.target.value)}
              className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm">
              <option value="">— Sélectionner —</option>
              {classSubjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)}
              className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Créneau (ex: 08:00-10:00)</label>
            <input type="text" value={timeSlot} onChange={e => setTimeSlot(e.target.value)}
              placeholder="08:00-10:00"
              className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
          </div>
        </div>
      </div>

      {/* Summary badges */}
      <div className="flex gap-3 flex-wrap">
        <span className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-emerald-700">
          <CheckCircle2 className="h-3.5 w-3.5" /> {presentCount} présents
        </span>
        <span className="flex items-center gap-1.5 bg-red-50 border border-red-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-red-600">
          <XCircle className="h-3.5 w-3.5" /> {absentCount} absents
        </span>
        <span className="flex items-center gap-1.5 bg-amber-50 border border-amber-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-amber-600">
          <Clock className="h-3.5 w-3.5" /> {retardCount} retards
        </span>
        <span className="ml-auto text-xs text-muted-foreground self-center">{filledCount}/{classStudents.length} pointés</span>
      </div>

      {/* Progress bar */}
      {classStudents.length > 0 && (
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-orange-500 to-amber-500 rounded-full transition-all duration-500"
            style={{ width: `${classStudents.length ? (filledCount / classStudents.length) * 100 : 0}%` }} />
        </div>
      )}

      {/* Student list */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        {classStudents.length === 0 ? (
          <div className="py-16 text-center text-sm text-muted-foreground">Aucun élève dans cette classe</div>
        ) : (
          <>
            {/* Mark all present shortcut */}
            <div className="px-4 py-2.5 border-b border-border bg-muted/30 flex items-center justify-between">
              <p className="text-xs font-semibold text-muted-foreground">{classStudents.length} élèves</p>
              <button
                onClick={() => {
                  const all = {};
                  classStudents.forEach(s => { all[s.id] = "present"; });
                  setAttendance(all);
                }}
                className="text-xs text-emerald-700 bg-emerald-100 hover:bg-emerald-200 px-2.5 py-1 rounded-lg font-semibold transition-colors"
              >
                ✓ Tous présents
              </button>
            </div>
            <div className="divide-y divide-border/30">
              {classStudents.map((student, i) => {
                const status = attendance[student.id];
                return (
                  <div key={student.id} className={`flex items-center gap-3 px-4 py-3 transition-colors ${status === "present" ? "bg-emerald-50/30" : status === "absent" ? "bg-red-50/30" : status === "retard" ? "bg-amber-50/30" : ""}`}>
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                      {i + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{student.last_name} {student.first_name}</p>
                      {status === "retard" && (
                        <input
                          type="time"
                          value={retardTimes[student.id] || ""}
                          onChange={e => setRetardTimes(prev => ({ ...prev, [student.id]: e.target.value }))}
                          placeholder="Heure d'arrivée"
                          className="mt-1 h-7 rounded border border-amber-300 bg-background px-2 text-xs w-28"
                        />
                      )}
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      {Object.entries(STATUS_CONFIG).map(([key, cfg]) => {
                        const Icon = cfg.icon;
                        const isSelected = status === key;
                        return (
                          <button key={key} onClick={() => setStatus(student.id, key)}
                            className={`flex items-center gap-1 px-2 py-1.5 rounded-lg border text-xs font-medium transition-all ${isSelected ? `${cfg.bg} ${cfg.color} shadow-sm scale-105` : "border-border text-muted-foreground hover:bg-muted"}`}>
                            <Icon className="h-3.5 w-3.5" />
                            <span className="hidden sm:inline">{cfg.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="p-4 border-t border-border/30 bg-muted/20 space-y-2">
              {filledCount < classStudents.length && (
                <p className="text-xs text-amber-700 text-center bg-amber-50 border border-amber-200 rounded-lg py-2">
                  ⚠️ {classStudents.length - filledCount} élève(s) non pointé(s) — pointez tous les élèves pour valider.
                </p>
              )}
              <Button
                onClick={handleSubmit}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white gap-2"
                disabled={!selectedSubject || filledCount === 0 || saving}
              >
                <Send className="h-4 w-4" />
                {saving ? "Envoi en cours…" : `Valider & Envoyer à l'éducateur (${absentCount + retardCount} absence(s))`}
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}