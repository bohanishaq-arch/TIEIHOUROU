import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle2, BookOpen, ClipboardList, FlaskConical, History, CheckCircle } from "lucide-react";

const TYPE_OPTIONS = [
  { value: "cours", label: "📖 Cours du jour", icon: BookOpen, color: "bg-blue-50 border-blue-200 text-blue-700" },
  { value: "devoir", label: "📝 Devoir donné", icon: ClipboardList, color: "bg-amber-50 border-amber-200 text-amber-700" },
  { value: "examen", label: "🧪 Examen / Évaluation", icon: FlaskConical, color: "bg-purple-50 border-purple-200 text-purple-700" },
];

export default function TeacherReportForm({ myClasses, mySubjects, myAssignments, onClose }) {
  const { user } = useAuth();
  const [view, setView] = useState("form"); // "form" | "history"
  const [history, setHistory] = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [form, setForm] = useState({
    report_type: "cours",
    date: new Date().toISOString().slice(0, 10),
    class_id: "",
    subject_id: "",
    title: "",
    objectives: "",
    content: "",
    activities: "",
    remarks: "",
    due_date: "",
    duration: "",
    competencies: "",
    grading_scale: "",
  });
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  // Filter subjects based on selected class
  const availableSubjects = form.class_id
    ? mySubjects.filter(s => myAssignments.some(a => a.class_id === form.class_id && a.subject_id === s.id))
    : mySubjects;

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    const cls = myClasses.find(c => c.id === form.class_id);
    const sub = mySubjects.find(s => s.id === form.subject_id);
    await base44.entities.TeacherReport.create({
      ...form,
      school_id: getSchoolId(),
      teacher_email: user?.email,
      teacher_name: user?.full_name,
      class_name: cls?.name || "",
      subject_name: sub?.name || "",
      status: "envoyé",
    });
    setSaving(false);
    setDone(true);
  }

  useEffect(() => {
    if (view === "history") {
      setLoadingHistory(true);
      base44.entities.TeacherReport.filter({ teacher_email: user?.email }, "-date", 100)
        .then(r => { setHistory(r); setLoadingHistory(false); });
    }
  }, [view, user?.email]);

  if (done) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
          <CheckCircle2 className="h-8 w-8 text-green-600" />
        </div>
        <h3 className="text-lg font-bold text-foreground">Rapport envoyé à l'administration !</h3>
        <p className="text-sm text-muted-foreground text-center max-w-sm">
          Votre rapport a été transmis avec succès. L'administration peut le consulter dans son tableau de bord.
        </p>
        <div className="flex gap-3 mt-2">
          <Button variant="outline" onClick={() => setDone(false)}>Nouveau rapport</Button>
          <Button variant="outline" onClick={() => { setDone(false); setView("history"); }}><History className="h-4 w-4 mr-1" /> Voir l'historique</Button>
          <Button onClick={onClose}>Fermer</Button>
        </div>
      </div>
    );
  }

  if (view === "history") {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-foreground flex items-center gap-2"><History className="h-5 w-5" /> Historique de mes rapports</h3>
          <Button variant="outline" size="sm" onClick={() => setView("form")}>+ Nouveau rapport</Button>
        </div>
        {loadingHistory ? (
          <div className="p-10 text-center"><div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" /></div>
        ) : history.length === 0 ? (
          <p className="text-muted-foreground text-sm text-center py-10">Aucun rapport envoyé pour l'instant.</p>
        ) : (
          <div className="space-y-3">
            {history.map(r => (
              <div key={r.id} className={`relative rounded-xl border p-4 overflow-hidden ${
                r.status === "approuvé" ? "border-green-300 bg-green-50/30" : "border-border bg-card"
              }`}>
                {r.status === "approuvé" && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none" style={{zIndex:0}}>
                    <span className="text-green-200 font-black text-6xl tracking-widest rotate-[-25deg] opacity-40">VALIDÉ</span>
                  </div>
                )}
                <div className="relative z-10">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                        r.report_type === "cours" ? "bg-blue-100 text-blue-700" :
                        r.report_type === "devoir" ? "bg-amber-100 text-amber-700" : "bg-purple-100 text-purple-700"
                      }`}>{r.report_type === "cours" ? "📖 Cours" : r.report_type === "devoir" ? "📝 Devoir" : "🧪 Examen"}</span>
                      <p className="font-semibold text-foreground mt-1">{r.title}</p>
                      <p className="text-xs text-muted-foreground">{r.class_name} · {r.subject_name} · {r.date && new Date(r.date).toLocaleDateString("fr-FR")}</p>
                    </div>
                    <div className="shrink-0">
                      {r.status === "approuvé" ? (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-green-700 bg-green-100 border border-green-300 px-2 py-1 rounded-full">
                          <CheckCircle className="h-3.5 w-3.5" /> Validé
                        </span>
                      ) : (
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          r.status === "lu" ? "bg-blue-100 text-blue-700" : "bg-amber-100 text-amber-700"
                        }`}>{r.status}</span>
                      )}
                    </div>
                  </div>
                  {r.status === "approuvé" && r.approved_by && (
                    <p className="text-xs text-green-600 mt-2">✓ Approuvé par {r.approved_by}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Tabs */}
      <div className="flex gap-2 border-b border-border pb-3">
        <button type="button" onClick={() => setView("form")} className="text-sm font-medium text-primary border-b-2 border-primary pb-1 px-1">Nouveau rapport</button>
        <button type="button" onClick={() => setView("history")} className="text-sm font-medium text-muted-foreground hover:text-foreground px-1 flex items-center gap-1"><History className="h-3.5 w-3.5" /> Historique</button>
      </div>
      {/* Type selector */}
      <div>
        <Label className="text-sm font-semibold mb-2 block">Type de rapport *</Label>
        <div className="grid grid-cols-3 gap-3">
          {TYPE_OPTIONS.map(t => (
            <button
              key={t.value}
              type="button"
              onClick={() => setForm(f => ({ ...f, report_type: t.value }))}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 text-sm font-medium transition-all ${
                form.report_type === t.value ? t.color + " border-current shadow-sm" : "bg-card border-border hover:border-muted-foreground"
              }`}
            >
              <t.icon className="h-5 w-5" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Date, Class, Subject */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <Label>Date *</Label>
          <Input type="date" className="mt-1" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} required />
        </div>
        <div>
          <Label>Classe *</Label>
          <Select value={form.class_id} onValueChange={v => setForm(f => ({ ...f, class_id: v, subject_id: "" }))}>
            <SelectTrigger className="mt-1"><SelectValue placeholder="Choisir une classe" /></SelectTrigger>
            <SelectContent>
              {myClasses.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Matière *</Label>
          <Select value={form.subject_id} onValueChange={v => setForm(f => ({ ...f, subject_id: v }))}>
            <SelectTrigger className="mt-1"><SelectValue placeholder="Choisir une matière" /></SelectTrigger>
            <SelectContent>
              {availableSubjects.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Title */}
      <div>
        <Label>Titre / Chapitre *</Label>
        <Input className="mt-1" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Ex: Chapitre 3 – Les équations du premier degré" required />
      </div>

      {/* COURS fields */}
      {form.report_type === "cours" && (
        <>
          <div>
            <Label>Objectifs du cours</Label>
            <textarea className="mt-1 w-full min-h-[80px] rounded-md border border-input bg-transparent px-3 py-2 text-sm resize-y focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Ce que les élèves doivent retenir…" value={form.objectives} onChange={e => setForm(f => ({ ...f, objectives: e.target.value }))} />
          </div>
          <div>
            <Label>Contenu détaillé du cours</Label>
            <textarea className="mt-1 w-full min-h-[120px] rounded-md border border-input bg-transparent px-3 py-2 text-sm resize-y focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Plan du cours, notions abordées, étapes…" value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} />
          </div>
          <div>
            <Label>Activités réalisées</Label>
            <textarea className="mt-1 w-full min-h-[80px] rounded-md border border-input bg-transparent px-3 py-2 text-sm resize-y focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Exercices, travaux de groupe, exposés…" value={form.activities} onChange={e => setForm(f => ({ ...f, activities: e.target.value }))} />
          </div>
        </>
      )}

      {/* DEVOIR fields */}
      {form.report_type === "devoir" && (
        <>
          <div>
            <Label>Consignes du devoir</Label>
            <textarea className="mt-1 w-full min-h-[100px] rounded-md border border-input bg-transparent px-3 py-2 text-sm resize-y focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Détail du devoir donné aux élèves…" value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Date de rendu</Label>
              <Input type="date" className="mt-1" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} />
            </div>
            <div>
              <Label>Durée estimée</Label>
              <Input className="mt-1" value={form.duration} onChange={e => setForm(f => ({ ...f, duration: e.target.value }))} placeholder="Ex: 1h30" />
            </div>
          </div>
        </>
      )}

      {/* EXAMEN fields */}
      {form.report_type === "examen" && (
        <>
          <div>
            <Label>Chapitres / Contenu évalué</Label>
            <textarea className="mt-1 w-full min-h-[80px] rounded-md border border-input bg-transparent px-3 py-2 text-sm resize-y focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Chapitres concernés par l'évaluation…" value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Date de l'examen</Label>
              <Input type="date" className="mt-1" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} />
            </div>
            <div>
              <Label>Durée</Label>
              <Input className="mt-1" value={form.duration} onChange={e => setForm(f => ({ ...f, duration: e.target.value }))} placeholder="Ex: 2h00" />
            </div>
          </div>
          <div>
            <Label>Compétences évaluées</Label>
            <textarea className="mt-1 w-full min-h-[80px] rounded-md border border-input bg-transparent px-3 py-2 text-sm resize-y focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Lister les compétences visées…" value={form.competencies} onChange={e => setForm(f => ({ ...f, competencies: e.target.value }))} />
          </div>
          <div>
            <Label>Barème (optionnel)</Label>
            <Input className="mt-1" value={form.grading_scale} onChange={e => setForm(f => ({ ...f, grading_scale: e.target.value }))} placeholder="Ex: 10 pts rédaction / 10 pts calcul" />
          </div>
        </>
      )}

      {/* Remarks always */}
      <div>
        <Label>Remarques générales</Label>
        <textarea className="mt-1 w-full min-h-[70px] rounded-md border border-input bg-transparent px-3 py-2 text-sm resize-y focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Observations, difficultés rencontrées…" value={form.remarks} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} />
      </div>

      <div className="flex justify-end gap-3 pt-2 border-t border-border">
        <Button type="button" variant="outline" onClick={onClose}>Annuler</Button>
        <Button type="submit" disabled={saving || !form.class_id || !form.subject_id} className="gap-2">
          {saving ? "Envoi…" : "📤 Envoyer à l'administration"}
        </Button>
      </div>
    </form>
  );
}