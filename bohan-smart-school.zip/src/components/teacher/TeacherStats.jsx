import { useMemo } from "react";
import { Link } from "react-router-dom";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadialBarChart, RadialBar, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, Users, BookOpen, Award, PenLine, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

const COLORS = ["#6366f1", "#8b5cf6", "#ec4899", "#f59e0b", "#10b981", "#3b82f6"];

function avg(grades) {
  if (!grades.length) return null;
  return grades.reduce((s, g) => s + g.score, 0) / grades.length;
}

function scoreColor(v) {
  if (v >= 14) return "text-emerald-600";
  if (v >= 10) return "text-amber-500";
  return "text-red-500";
}

function scoreBg(v) {
  if (v >= 14) return "from-emerald-500 to-green-400";
  if (v >= 10) return "from-amber-500 to-yellow-400";
  return "from-red-500 to-orange-400";
}

export default function TeacherStats({ myClasses, mySubjects, myStudents, myGrades, myAssignments }) {
  const globalAvg = avg(myGrades);
  const passCount = myGrades.filter((g) => g.score >= 10).length;
  const passRate = myGrades.length ? Math.round((passCount / myGrades.length) * 100) : 0;

  // Per-class averages for bar chart
  const classData = useMemo(() => myClasses.map((cls) => {
    const g = myGrades.filter((gr) => gr.class_id === cls.id);
    return { name: cls.name, avg: avg(g) ? parseFloat(avg(g).toFixed(2)) : 0, count: g.length };
  }), [myClasses, myGrades]);

  // Per-subject averages
  const subjectData = useMemo(() => mySubjects.map((sub, i) => {
    const g = myGrades.filter((gr) => gr.subject_id === sub.id);
    return { name: sub.name, avg: avg(g) ? parseFloat(avg(g).toFixed(2)) : 0, fill: COLORS[i % COLORS.length] };
  }), [mySubjects, myGrades]);

  // Grade distribution
  const distribution = useMemo(() => {
    const ranges = [
      { name: "0–5", min: 0, max: 5 },
      { name: "6–9", min: 6, max: 9 },
      { name: "10–12", min: 10, max: 12 },
      { name: "13–15", min: 13, max: 15 },
      { name: "16–20", min: 16, max: 20 },
    ];
    return ranges.map((r) => ({
      name: r.name,
      value: myGrades.filter((g) => g.score >= r.min && g.score <= r.max).length,
    }));
  }, [myGrades]);

  const statCards = [
    { label: "Élèves", value: myStudents.length, icon: Users, gradient: "from-blue-500 to-indigo-500", light: "bg-blue-50 text-blue-600" },
    { label: "Notes saisies", value: myGrades.length, icon: BookOpen, gradient: "from-violet-500 to-purple-500", light: "bg-violet-50 text-violet-600" },
    { label: "Taux de réussite", value: `${passRate}%`, icon: Award, gradient: "from-emerald-500 to-green-500", light: "bg-emerald-50 text-emerald-600" },
    { label: "Moyenne générale", value: globalAvg ? globalAvg.toFixed(2) : "—", icon: TrendingUp, gradient: globalAvg ? `${scoreBg(globalAvg)}` : "from-slate-400 to-slate-500", light: "bg-indigo-50 text-indigo-600" },
  ];

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="bg-white rounded-2xl shadow-md border border-border/40 overflow-hidden">
              <div className={`h-1.5 bg-gradient-to-r ${card.gradient}`} />
              <div className="p-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${card.light}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <p className="text-2xl font-bold text-foreground">{card.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{card.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Bar chart par classe */}
        <div className="bg-white rounded-2xl shadow-md border border-border/40 p-5">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-500" />
            Moyenne par classe
          </h3>
          {classData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={classData} barSize={32}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis domain={[0, 20]} tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v) => [`${v}/20`, "Moyenne"]} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
                <Bar dataKey="avg" radius={[6, 6, 0, 0]}>
                  {classData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">Aucune donnée disponible</div>
          )}
        </div>

        {/* Distribution des notes */}
        <div className="bg-white rounded-2xl shadow-md border border-border/40 p-5">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-purple-500" />
            Distribution des notes
          </h3>
          {myGrades.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={distribution} barSize={36}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
                <Bar dataKey="value" name="Élèves" radius={[6, 6, 0, 0]}>
                  {distribution.map((_, i) => (
                    <Cell key={i} fill={["#ef4444", "#f97316", "#f59e0b", "#10b981", "#6366f1"][i]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">Aucune note saisie</div>
          )}
        </div>
      </div>

      {/* Classes overview */}
      <div className="bg-white rounded-2xl shadow-md border border-border/40 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-pink-500" />
            Mes classes
          </h3>
          <Link to="/grades">
            <Button size="sm" className="gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white">
              <PenLine className="h-3.5 w-3.5" /> Saisir des notes
            </Button>
          </Link>
        </div>
        {myClasses.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-10 text-muted-foreground">
            <AlertTriangle className="h-8 w-8 text-amber-400" />
            <p className="text-sm">Aucune classe assignée. Contactez l'administrateur.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {myClasses.map((cls, i) => {
              const clsGrades = myGrades.filter((g) => g.class_id === cls.id);
              const clsStudents = myStudents.filter((s) => s.class_id === cls.id);
              const clsAvg = avg(clsGrades);
              return (
                <div key={cls.id} className="rounded-xl border border-border/60 p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold" style={{ background: COLORS[i % COLORS.length] }}>
                      {cls.name?.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{cls.name}</p>
                      <p className="text-xs text-muted-foreground">{cls.level}</p>
                    </div>
                  </div>
                  <div className="flex justify-between mt-3 text-xs text-muted-foreground">
                    <span>{clsStudents.length} élèves</span>
                    <span>{clsGrades.length} notes</span>
                    {clsAvg !== null && (
                      <span className={`font-bold ${scoreColor(clsAvg)}`}>{clsAvg.toFixed(1)}/20</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}