import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { Calendar, Clock, MapPin, BookOpen } from "lucide-react";

const DAYS = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

const DAY_HEADER_COLORS = {
  "Lundi":    "bg-gradient-to-r from-blue-600 to-blue-700",
  "Mardi":    "bg-gradient-to-r from-violet-600 to-purple-700",
  "Mercredi": "bg-gradient-to-r from-emerald-600 to-teal-700",
  "Jeudi":    "bg-gradient-to-r from-orange-500 to-amber-600",
  "Vendredi": "bg-gradient-to-r from-rose-600 to-pink-700",
  "Samedi":   "bg-gradient-to-r from-slate-600 to-gray-700",
};

const PALETTE_MATIN = [
  "bg-sky-100 border-sky-300 text-sky-900",
  "bg-blue-100 border-blue-300 text-blue-900",
  "bg-indigo-100 border-indigo-300 text-indigo-900",
  "bg-violet-100 border-violet-300 text-violet-900",
  "bg-cyan-100 border-cyan-300 text-cyan-900",
  "bg-teal-100 border-teal-300 text-teal-900",
  "bg-purple-100 border-purple-300 text-purple-900",
];
const PALETTE_APMIDI = [
  "bg-amber-100 border-amber-300 text-amber-900",
  "bg-orange-100 border-orange-300 text-orange-900",
  "bg-rose-100 border-rose-300 text-rose-900",
  "bg-pink-100 border-pink-300 text-pink-900",
  "bg-red-100 border-red-300 text-red-900",
  "bg-yellow-100 border-yellow-300 text-yellow-900",
  "bg-fuchsia-100 border-fuchsia-300 text-fuchsia-900",
];

function getSlotColor(start_time, idx) {
  const [h] = start_time.split(":").map(Number);
  const palette = h >= 13 ? PALETTE_APMIDI : PALETTE_MATIN;
  return palette[idx % palette.length];
}

export default function TeacherSchedule({ myClasses, mySubjects, myAssignments }) {
  const { user } = useAuth();
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const f = schoolId ? { school_id: schoolId } : {};
      const all = await base44.entities.Schedule.filter(f, "day", 500);
      // Filter to this teacher's slots
      const mine = all.filter(s =>
        s.teacher_email?.toLowerCase() === user?.email?.toLowerCase() ||
        myAssignments.some(a => a.class_id === s.class_id && a.subject_id === s.subject_id)
      );
      setSchedules(mine);
      setLoading(false);
    }
    load();
  }, [user?.email]);

  const today = new Date().toLocaleDateString("fr-FR", { weekday: "long" });
  const todayKey = DAYS.find(d => d.toLowerCase() === today.toLowerCase());

  const byDay = DAYS.reduce((acc, d) => {
    acc[d] = schedules.filter(s => s.day === d).sort((a, b) => a.start_time.localeCompare(b.start_time));
    return acc;
  }, {});

  const subjectIndexMap = {};
  mySubjects.forEach((s, i) => { subjectIndexMap[s.id] = i; });

  if (loading) return (
    <div className="flex items-center justify-center h-32">
      <div className="w-6 h-6 border-4 border-orange-200 border-t-orange-500 rounded-full animate-spin" />
    </div>
  );

  if (schedules.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground space-y-2">
        <Calendar className="h-10 w-10 mx-auto opacity-40" />
        <p className="font-medium">Aucun emploi du temps disponible</p>
        <p className="text-sm">Le directeur des études n'a pas encore publié votre planning.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Today highlight */}
      {todayKey && byDay[todayKey].length > 0 && (
        <div className="bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-200 rounded-2xl p-4">
          <p className="text-sm font-bold text-orange-800 mb-3 flex items-center gap-2">
            <Clock className="h-4 w-4" /> Aujourd'hui — {todayKey}
          </p>
          <div className="space-y-2">
            {byDay[todayKey].map(slot => (
              <div key={slot.id} className="flex items-center gap-3 bg-white rounded-xl border border-orange-200 px-4 py-3">
                <div className="text-center min-w-[60px]">
                  <p className="text-xs font-bold text-orange-700">{slot.start_time}</p>
                  <p className="text-xs text-orange-400">↓</p>
                  <p className="text-xs font-bold text-orange-700">{slot.end_time}</p>
                </div>
                <div className="w-px h-10 bg-orange-200" />
                <div>
                  <p className="font-bold text-sm text-foreground">{slot.subject_name}</p>
                  <p className="text-xs text-muted-foreground">{slot.class_name}</p>
                  {slot.room && <p className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="h-3 w-3" />{slot.room}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Week view */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {DAYS.map(day => {
          const isToday = day.toLowerCase() === today.toLowerCase();
          const sessions = byDay[day];
          if (sessions.length === 0 && !isToday) return null;
          return (
            <div key={day} className={`rounded-2xl border overflow-hidden shadow-sm ${isToday ? "border-2 border-white shadow-lg" : "border-border/50"}`}>
              <div className={`px-4 py-3 ${DAY_HEADER_COLORS[day]}`}>
                <p className="text-sm font-bold text-white">{day}{isToday && <span className="ml-2 text-[10px] bg-white/20 px-1.5 py-0.5 rounded-full">Aujourd'hui</span>}</p>
                <p className="text-xs text-white/70">{sessions.length} cours</p>
              </div>
              <div className="bg-white p-3 space-y-2 min-h-[80px]">
                {sessions.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-2">Libre</p>
                ) : sessions.map(slot => (
                  <div key={slot.id} className={`rounded-xl border p-2.5 ${getSlotColor(slot.start_time, subjectIndexMap[slot.subject_id] ?? 0)}`}>
                    <p className="text-xs font-bold truncate">{slot.subject_name}</p>
                    <p className="text-xs opacity-75 truncate">{slot.class_name}</p>
                    <p className="text-xs font-semibold">{slot.start_time} – {slot.end_time}</p>
                    {slot.room && <p className="text-xs opacity-60">🏫 {slot.room}</p>}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}