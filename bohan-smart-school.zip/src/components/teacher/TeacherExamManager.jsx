import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Calendar, Plus, Trash2, Loader2, CheckCircle, BookOpen, Upload, FileText, Eye, EyeOff, CheckCircle2, X } from "lucide-react";
import { usePeriodType } from "@/hooks/usePeriodType";

const EXAM_TYPES = ["Devoir", "Interrogation", "Examen trimestriel", "TP", "Oral"];

export default function TeacherExamManager({ myClasses, mySubjects, myAssignments }) {
  const { periods } = usePeriodType();
  const { user } = useAuth();
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    class_id: "",
    subject_id: "",
    title: "",
    date: "",
    exam_type: "Devoir",
    trimester: "Trimestre 1",
    academic_year: `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`,
    max_score: 20,
    description: "",
  });

  // Sync default period once periods load
  useEffect(() => {
    if (periods.length > 0) setForm(f => ({ ...f, trimester: f.trimester === "Trimestre 1" ? periods[0] : f.trimester }));
  }, [periods[0]]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [correctionModal, setCorrectionModal] = useState(null); // exam object
  const [correctionText, setCorrectionText] = useState("");
  const [correctionFile, setCorrectionFile] = useState(null);
  const [uploadingCorrection, setUploadingCorrection] = useState(false);
  const [correctionSaved, setCorrectionSaved] = useState(false);

  const myClassIds = new Set(myAssignments.map((a) => a.class_id));

  useEffect(() => {
    async function load() {
      const all = await Promise.all(
        [...myClassIds].map((cid) => base44.entities.Exam.filter({ class_id: cid }))
      );
      setExams(all.flat().sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0)));
      setLoading(false);
    }
    if (myClassIds.size > 0) load();
    else setLoading(false);
  }, []);

  // Filter subjects available for selected class
  const availableSubjects = form.class_id
    ? myAssignments
        .filter((a) => a.class_id === form.class_id)
        .map((a) => mySubjects.find((s) => s.id === a.subject_id))
        .filter(Boolean)
    : mySubjects;

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    const schoolId = myClasses[0]?.school_id || null;
    const created = await base44.entities.Exam.create({
      ...form,
      school_id: schoolId,
      max_score: Number(form.max_score),
    });
    setExams((prev) => [created, ...prev]);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    setShowForm(false);
    setForm({ class_id: "", subject_id: "", title: "", date: "", exam_type: "Devoir", trimester: periods[0] || "Trimestre 1", academic_year: `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`, max_score: 20, description: "" });
  }

  async function handleDelete(id) {
    if (!confirm("Supprimer cet examen/devoir ?")) return;
    await base44.entities.Exam.delete(id);
    setExams((prev) => prev.filter((e) => e.id !== id));
  }

  async function handleSaveCorrection(exam) {
    setUploadingCorrection(true);
    let fileUrl = exam.correction_file_url || null;
    if (correctionFile) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: correctionFile });
      fileUrl = file_url;
    }
    const updated = await base44.entities.Exam.update(exam.id, {
      correction_file_url: fileUrl,
      correction_text: correctionText,
      correction_published: true,
    });
    setExams((prev) => prev.map((e) => e.id === exam.id ? { ...e, ...updated } : e));
    setUploadingCorrection(false);
    setCorrectionSaved(true);
    setTimeout(() => { setCorrectionSaved(false); setCorrectionModal(null); }, 1500);
  }

  async function handleToggleCorrection(exam) {
    const updated = await base44.entities.Exam.update(exam.id, {
      correction_published: !exam.correction_published,
    });
    setExams((prev) => prev.map((e) => e.id === exam.id ? { ...e, ...updated } : e));
  }

  function getClassName(classId) {
    return myClasses.find((c) => c.id === classId)?.name || "—";
  }
  function getSubjectName(subjectId) {
    return mySubjects.find((s) => s.id === subjectId)?.name || "—";
  }

  const typeColors = {
    "Devoir": "bg-blue-100 text-blue-700",
    "Interrogation": "bg-purple-100 text-purple-700",
    "Examen trimestriel": "bg-red-100 text-red-700",
    "TP": "bg-green-100 text-green-700",
    "Oral": "bg-orange-100 text-orange-700",
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Les devoirs/examens créés ici sont <span className="font-semibold text-foreground">visibles immédiatement</span> dans le portail élève.
        </p>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-indigo-600 text-white rounded-lg px-4 py-2 text-sm font-semibold hover:bg-indigo-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          Nouveau devoir
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-5">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-indigo-600" />
            Créer un devoir / examen
          </h3>
          <form onSubmit={handleSave} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Classe *</label>
              <select
                value={form.class_id}
                onChange={(e) => setForm({ ...form, class_id: e.target.value, subject_id: "" })}
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
                required
              >
                <option value="">Sélectionner une classe</option>
                {myClasses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Matière *</label>
              <select
                value={form.subject_id}
                onChange={(e) => setForm({ ...form, subject_id: e.target.value })}
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
                required
              >
                <option value="">Sélectionner une matière</option>
                {availableSubjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="text-xs font-medium text-foreground block mb-1">Titre *</label>
              <input
                type="text"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Ex: Devoir n°1 – Les fractions"
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
                required
              />
            </div>

            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Type</label>
              <select
                value={form.exam_type}
                onChange={(e) => setForm({ ...form, exam_type: e.target.value })}
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {EXAM_TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Période</label>
              <select
                value={form.trimester}
                onChange={(e) => setForm({ ...form, trimester: e.target.value })}
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {periods.map((t) => <option key={t}>{t}</option>)}
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Date</label>
              <input
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-foreground block mb-1">Barème</label>
              <input
                type="number"
                min={1} max={100}
                value={form.max_score}
                onChange={(e) => setForm({ ...form, max_score: e.target.value })}
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="text-xs font-medium text-foreground block mb-1">Instructions / Description</label>
              <textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={3}
                placeholder="Instructions pour les élèves…"
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring resize-none"
              />
            </div>

            <div className="sm:col-span-2 flex justify-end gap-3">
              <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-input text-sm font-medium hover:bg-muted transition-colors">Annuler</button>
              <button type="submit" disabled={saving} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-60">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <CheckCircle className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                {saving ? "Enregistrement…" : "Publier"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Exam list */}
      {loading ? (
        <div className="flex items-center justify-center h-32">
          <div className="w-6 h-6 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin" />
        </div>
      ) : exams.length === 0 ? (
        <div className="text-center py-12">
          <Calendar className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground font-medium">Aucun devoir ou examen créé</p>
          <p className="text-sm text-muted-foreground mt-1">Cliquez sur "Nouveau devoir" pour en créer un.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {exams.map((exam) => (
            <div key={exam.id} className="bg-card border border-border rounded-xl p-4 flex items-start justify-between gap-3 hover:shadow-sm transition-shadow">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center shrink-0">
                  <BookOpen className="h-5 w-5 text-indigo-600" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">{exam.title}</p>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    <span className="text-xs bg-muted px-2 py-0.5 rounded-full">{getClassName(exam.class_id)}</span>
                    <span className="text-xs bg-muted px-2 py-0.5 rounded-full">{getSubjectName(exam.subject_id)}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${typeColors[exam.exam_type] || "bg-muted"}`}>{exam.exam_type}</span>
                    <span className="text-xs text-muted-foreground">{exam.trimester}</span>
                    {exam.date && <span className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" />{new Date(exam.date).toLocaleDateString("fr-FR")}</span>}
                  </div>
                  {exam.description && <p className="text-xs text-muted-foreground mt-1 italic">{exam.description}</p>}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {/* Publier / masquer correction */}
                {(exam.correction_file_url || exam.correction_text) && (
                  <button
                    onClick={() => handleToggleCorrection(exam)}
                    title={exam.correction_published ? "Masquer la correction aux élèves" : "Publier la correction"}
                    className={`p-1.5 rounded-lg transition-colors ${exam.correction_published ? "bg-emerald-100 text-emerald-600 hover:bg-emerald-200" : "bg-gray-100 text-gray-400 hover:bg-gray-200"}`}
                  >
                    {exam.correction_published ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                  </button>
                )}
                {/* Ajouter / modifier correction */}
                <button
                  onClick={() => { setCorrectionModal(exam); setCorrectionText(exam.correction_text || ""); setCorrectionFile(null); setCorrectionSaved(false); }}
                  title="Ajouter une correction"
                  className={`p-1.5 rounded-lg transition-colors ${exam.correction_file_url || exam.correction_text ? "bg-blue-100 text-blue-600 hover:bg-blue-200" : "bg-gray-100 text-gray-400 hover:bg-gray-200"}`}
                >
                  <FileText className="h-4 w-4" />
                </button>
                <button onClick={() => handleDelete(exam.id)} className="p-1.5 rounded-lg text-muted-foreground hover:bg-red-50 hover:text-destructive transition-colors">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Correction Modal */}
      {correctionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={() => setCorrectionModal(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <h3 className="font-bold text-gray-900">Correction du devoir</h3>
                <p className="text-xs text-gray-400 mt-0.5">{correctionModal.title}</p>
              </div>
              <button onClick={() => setCorrectionModal(null)} className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center">
                <X className="h-4 w-4 text-gray-500" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              {/* Texte de correction */}
              <div>
                <label className="text-xs font-semibold text-gray-600 block mb-1">Correction écrite (optionnel)</label>
                <textarea
                  value={correctionText}
                  onChange={e => setCorrectionText(e.target.value)}
                  rows={4}
                  placeholder="Rédigez ici les éléments de correction, les réponses attendues…"
                  className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              {/* Fichier PDF/image */}
              <div>
                <label className="text-xs font-semibold text-gray-600 block mb-1">Fichier de correction (PDF, image…)</label>
                {correctionModal.correction_file_url && !correctionFile && (
                  <a href={correctionModal.correction_file_url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-2 text-xs text-blue-600 hover:underline mb-2">
                    <FileText className="h-3 w-3" /> Fichier actuel — cliquer pour voir
                  </a>
                )}
                <label className="flex items-center gap-2 cursor-pointer border-2 border-dashed border-gray-200 hover:border-blue-400 rounded-xl px-4 py-3 transition-colors">
                  <input type="file" accept=".pdf,.png,.jpg,.jpeg,.webp" className="hidden" onChange={e => setCorrectionFile(e.target.files?.[0] || null)} />
                  <Upload className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-500">{correctionFile ? correctionFile.name : "Choisir un fichier…"}</span>
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setCorrectionModal(null)} className="px-4 py-2 text-sm rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors">Annuler</button>
                <button
                  onClick={() => handleSaveCorrection(correctionModal)}
                  disabled={uploadingCorrection || correctionSaved}
                  className="flex items-center gap-2 px-5 py-2 text-sm font-semibold rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors disabled:opacity-60"
                >
                  {uploadingCorrection ? <Loader2 className="h-4 w-4 animate-spin" /> : correctionSaved ? <CheckCircle2 className="h-4 w-4" /> : <Upload className="h-4 w-4" />}
                  {uploadingCorrection ? "Envoi…" : correctionSaved ? "Publié !" : "Publier la correction"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}