import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../../hooks/useSchool";
import { ClipboardList, UserX, BookOpen, FileText, Send, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

function timeAgo(date) {
  if (!date) return "—";
  const d = new Date(date);
  const now = new Date();
  const diff = Math.floor((now - d) / 1000);
  if (diff < 60) return "À l'instant";
  if (diff < 3600) return `Il y a ${Math.floor(diff / 60)} min`;
  if (diff < 86400) return `Aujourd'hui, ${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
  return `Hier, ${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
}

export default function TeacherRecentActivities({ teacherEmail, mySubjectIds, myClassIds, onOpenModal }) {
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      const [grades, absences, exams, reports] = await Promise.all([
        base44.entities.Grade.filter(filter, "-created_date", 8),
        base44.entities.Absence.filter(filter, "-created_date", 4),
        base44.entities.Exam.filter({ ...filter, teacher_email: teacherEmail }, "-created_date", 3),
        base44.entities.TeacherReport.filter({ teacher_email: teacherEmail }, "-created_date", 3),
      ]);

      const acts = [
        ...grades
          .filter(g => mySubjectIds.has(g.subject_id) && myClassIds.has(g.class_id))
          .slice(0, 4)
          .map(g => ({
            icon: ClipboardList, bg: "bg-blue-100", color: "text-blue-600",
            text: `Notes ajoutées en ${g.subject_id || ""}`, time: g.created_date,
          })),
        ...absences
          .filter(a => myClassIds.has(a.class_id))
          .slice(0, 2)
          .map(a => ({
            icon: UserX, bg: "bg-red-100", color: "text-red-600",
            text: `Absence enregistrée — ${a.class_name || ""}`, time: a.created_date,
          })),
        ...exams.map(e => ({
          icon: BookOpen, bg: "bg-orange-100", color: "text-orange-600",
          text: `Devoir publié en ${e.subject_id || ""}`, time: e.created_date,
        })),
        ...reports.map(r => ({
          icon: Send, bg: "bg-violet-100", color: "text-violet-600",
          text: `Rapport envoyé : ${r.title || ""}`, time: r.created_date,
        })),
      ].sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 6);

      setActivities(acts);
    }
    load();
  }, [teacherEmail]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5"
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-bold text-gray-900">Activités récentes</h3>
          <p className="text-[10px] text-gray-400">Vos dernières actions</p>
        </div>
        <button onClick={() => onOpenModal("historique")} className="text-xs text-blue-600 hover:underline font-medium flex items-center gap-1">
          Voir tout <ChevronRight className="h-3 w-3" />
        </button>
      </div>

      <div className="space-y-3">
        {activities.length === 0 ? (
          <p className="text-xs text-gray-400 italic text-center py-4">Aucune activité récente</p>
        ) : activities.map((act, i) => {
          const Icon = act.icon;
          return (
            <div key={i} className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-xl ${act.bg} flex items-center justify-center shrink-0`}>
                <Icon className={`h-4 w-4 ${act.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-gray-700 truncate">{act.text}</p>
                <p className="text-[10px] text-gray-400">{timeAgo(act.time)}</p>
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}