import { Users, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

const CLASS_COLORS = [
  "from-blue-500 to-blue-600",
  "from-violet-500 to-purple-600",
  "from-emerald-500 to-teal-600",
  "from-orange-500 to-amber-500",
  "from-rose-500 to-pink-600",
];

function avgColor(avg) {
  if (!avg) return "text-gray-400";
  if (avg >= 14) return "text-emerald-600";
  if (avg >= 10) return "text-orange-500";
  return "text-red-500";
}

export default function TeacherClassCards({ myClasses, myStudents, myGrades, myAssignments, onOpenModal }) {
  const classData = myClasses.map((cls) => {
    const students = myStudents.filter((s) => s.class_id === cls.id);
    const grades = myGrades.filter((g) => g.class_id === cls.id);
    const avg = grades.length
      ? Math.round((grades.reduce((a, g) => a + g.score, 0) / grades.length) * 10) / 10
      : null;
    return { ...cls, studentCount: students.length, avg };
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.25 }}
      className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5"
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-bold text-gray-900">Mes classes</h3>
          <p className="text-[10px] text-gray-400">{myClasses.length} classe(s) assignée(s)</p>
        </div>
        <button onClick={() => onOpenModal("students")} className="text-xs text-blue-600 hover:underline font-medium flex items-center gap-1">
          Voir tout <ChevronRight className="h-3 w-3" />
        </button>
      </div>

      {classData.length === 0 ? (
        <p className="text-xs text-gray-400 italic text-center py-4">Aucune classe assignée</p>
      ) : (
        <div className="space-y-3">
          {classData.map((cls, i) => (
            <button
              key={cls.id}
              onClick={() => onOpenModal("students")}
              className="w-full flex items-center gap-3 hover:bg-gray-50 rounded-xl p-2 -mx-2 transition-colors text-left"
            >
              <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${CLASS_COLORS[i % CLASS_COLORS.length]} flex items-center justify-center shrink-0`}>
                <Users className="h-4 w-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-800">{cls.name}</p>
                <p className="text-[10px] text-gray-400">{cls.studentCount} élève{cls.studentCount !== 1 ? "s" : ""}</p>
              </div>
              <div className="text-right shrink-0">
                <p className={`text-sm font-bold ${avgColor(cls.avg)}`}>
                  {cls.avg != null ? `${cls.avg}/20` : "—"}
                </p>
                <p className="text-[9px] text-gray-400">Moyenne</p>
              </div>
            </button>
          ))}
        </div>
      )}
    </motion.div>
  );
}