import { motion } from "framer-motion";
import { School, Users, ClipboardList, BarChart3, TrendingUp, ArrowUpRight } from "lucide-react";
import { LineChart, Line, ResponsiveContainer } from "recharts";

const SPARKLINE = [
  [4, 7, 5, 9, 8, 10, 12],
  [6, 8, 7, 11, 10, 9, 11],
  [3, 5, 8, 6, 9, 10, 9],
  [5, 7, 6, 8, 9, 8, 10],
];

export default function TeacherKpiCards({ classesCount, studentsCount, examsCount, generalAvg }) {
  const cards = [
    { label: "Classes", value: classesCount, trend: "+1 ce mois", icon: School, color: "text-blue-600", bg: "bg-blue-50", spark: "#3b82f6" },
    { label: "Élèves", value: studentsCount, trend: "+8 ce mois", icon: Users, color: "text-emerald-600", bg: "bg-emerald-50", spark: "#10b981" },
    { label: "Devoirs", value: examsCount, trend: "-2 ce mois", icon: ClipboardList, color: "text-orange-600", bg: "bg-orange-50", spark: "#f97316" },
    { label: "Moyenne générale", value: generalAvg ? `${generalAvg}/20` : "—", trend: "+1.2 ce mois", icon: BarChart3, color: "text-violet-600", bg: "bg-violet-50", spark: "#7c3aed" },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card, i) => {
        const Icon = card.icon;
        const sparkData = SPARKLINE[i].map(v => ({ v }));
        return (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07 }}
            className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 hover:shadow-md transition-all group cursor-default"
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl ${card.bg} flex items-center justify-center`}>
                <Icon className={`h-5 w-5 ${card.color}`} />
              </div>
              <ArrowUpRight className={`h-4 w-4 ${card.color} opacity-0 group-hover:opacity-60 transition-opacity`} />
            </div>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400 mb-1">{card.label}</p>
            <p className="text-2xl font-bold text-gray-900">{card.value}</p>
            <div className="flex items-center justify-between mt-1">
              <p className="text-[11px] text-gray-400 flex items-center gap-1">
                <TrendingUp className="h-3 w-3 text-emerald-500" /> {card.trend}
              </p>
            </div>
            <div className="mt-2 h-8">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sparkData}>
                  <Line type="monotone" dataKey="v" stroke={card.spark} strokeWidth={1.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}