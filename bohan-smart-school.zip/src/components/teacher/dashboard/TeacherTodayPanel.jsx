import { Clock, CheckSquare, Square } from "lucide-react";
import { motion } from "framer-motion";

const SUBJECT_COLORS = ["bg-blue-100 text-blue-700", "bg-violet-100 text-violet-700", "bg-emerald-100 text-emerald-700", "bg-orange-100 text-orange-700", "bg-rose-100 text-rose-700"];

export default function TeacherTodayPanel({ todaySchedule, todos }) {
  const days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  const today = days[new Date().getDay()];

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5"
    >
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 bg-blue-100 rounded-xl flex items-center justify-center">
          <Clock className="h-4 w-4 text-blue-600" />
        </div>
        <div>
          <h3 className="text-sm font-bold text-gray-900">Aujourd'hui</h3>
          <p className="text-[10px] text-gray-400">{today}</p>
        </div>
      </div>

      {/* Schedule */}
      <div className="mb-4">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Emploi du temps</p>
        {todaySchedule.length === 0 ? (
          <p className="text-xs text-gray-400 italic">Aucun cours aujourd'hui 🎉</p>
        ) : (
          <div className="space-y-2">
            {todaySchedule.map((s, i) => (
              <div key={i} className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-400">{s.start_time} — {s.end_time}</p>
                  <p className="text-sm font-medium text-gray-700">{s.subject_name}</p>
                </div>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-lg ${SUBJECT_COLORS[i % SUBJECT_COLORS.length]}`}>
                  {s.class_name}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* To-do */}
      <div>
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">À faire</p>
        {todos.length === 0 ? (
          <p className="text-xs text-gray-400 italic">Tout est à jour ✅</p>
        ) : (
          <div className="space-y-2">
            {todos.map((t, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Square className="h-4 w-4 text-gray-300 shrink-0" />
                  <p className="text-sm text-gray-700">{t.label}</p>
                </div>
                {t.count != null && (
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg ${t.urgent ? "bg-red-100 text-red-600" : "bg-orange-100 text-orange-600"}`}>
                    {t.count}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}