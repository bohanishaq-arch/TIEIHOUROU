import { ClipboardList, FileText, Send, BookOpen, UserCheck } from "lucide-react";
import { motion } from "framer-motion";

const ACTIONS = [
  { label: "Saisir des notes",    icon: ClipboardList, modal: "grades",          bg: "bg-blue-50 hover:bg-blue-100",    text: "text-blue-600",    border: "border-blue-100",    iconBg: "bg-blue-100" },
  { label: "Générer un bulletin", icon: FileText,      modal: "overview",        bg: "bg-violet-50 hover:bg-violet-100",text: "text-violet-600",  border: "border-violet-100",  iconBg: "bg-violet-100" },
  { label: "Envoyer un message",  icon: Send,          modal: "report",          bg: "bg-emerald-50 hover:bg-emerald-100",text: "text-emerald-600",border: "border-emerald-100", iconBg: "bg-emerald-100" },
  { label: "Créer un devoir",     icon: BookOpen,      modal: "exams",           bg: "bg-orange-50 hover:bg-orange-100",text: "text-orange-600",  border: "border-orange-100",  iconBg: "bg-orange-100" },
  { label: "Gérer les présences", icon: UserCheck,     modal: "attendance-new",  bg: "bg-rose-50 hover:bg-rose-100",    text: "text-rose-600",    border: "border-rose-100",    iconBg: "bg-rose-100" },
];

export default function TeacherQuickActions({ onOpenModal }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5"
    >
      <h3 className="text-sm font-bold text-gray-900 mb-4">Actions rapides</h3>
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {ACTIONS.map(({ label, icon: Icon, modal, bg, text, border, iconBg }) => (
          <button
            key={modal}
            onClick={() => onOpenModal(modal)}
            className={`flex flex-col items-center justify-center gap-2 p-4 rounded-xl border ${bg} ${border} transition-all hover:shadow-sm group`}
          >
            <div className={`w-10 h-10 rounded-xl ${iconBg} flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm`}>
              <Icon className={`h-5 w-5 ${text}`} />
            </div>
            <span className={`text-[11px] font-semibold ${text} text-center leading-tight`}>{label}</span>
          </button>
        ))}
      </div>
    </motion.div>
  );
}