import { Calendar, Clock, BookOpen, UserX, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export default function TeacherHeroCard({ teacherName, todayCourses, devoirsCount, absencesCount, onViewSchedule }) {
  const now = new Date();
  const days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  const months = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
  const dateStr = `${days[now.getDay()]}, ${String(now.getDate()).padStart(2, "0")} ${months[now.getMonth()]} ${now.getFullYear()}`;
  const timeStr = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;

  const stats = [
    { icon: BookOpen, label: "Cours aujourd'hui", value: todayCourses, color: "bg-white/20" },
    { icon: BookOpen, label: "Devoir à corriger", value: devoirsCount, color: "bg-white/20" },
    { icon: UserX, label: "Absences à traiter", value: absencesCount, color: "bg-white/20" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-2xl p-6 text-white shadow-xl"
      style={{ background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 40%, #f97316 100%)" }}
    >
      {/* Decorative blobs */}
      <div className="absolute -top-10 -right-10 w-48 h-48 bg-white/10 rounded-full blur-2xl" />
      <div className="absolute -bottom-8 -left-8 w-36 h-36 bg-white/10 rounded-full blur-2xl" />

      <div className="relative flex flex-col lg:flex-row lg:items-center gap-6">
        {/* Left: Avatar + message */}
        <div className="flex items-center gap-4 flex-1">
          <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center text-2xl font-bold shadow-lg shrink-0">
            {(teacherName || "P")[0].toUpperCase()}
          </div>
          <div>
            <p className="text-white/70 text-sm font-medium">Bon retour, Professeur !</p>
            <h2 className="text-xl font-bold">{teacherName || "Professeur"}</h2>
            <p className="text-white/60 text-xs mt-0.5">Voici votre résumé pour aujourd'hui.</p>
          </div>
        </div>

        {/* Center: stats */}
        <div className="flex items-center gap-4 flex-wrap">
          {stats.map((s, i) => {
            const Icon = s.icon;
            return (
              <div key={i} className="flex items-center gap-2 bg-white/15 backdrop-blur rounded-xl px-4 py-2.5">
                <Icon className="h-5 w-5 text-white/80" />
                <div>
                  <p className="text-xl font-bold leading-none">{s.value}</p>
                  <p className="text-white/60 text-[10px] mt-0.5">{s.label}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: date + button */}
        <div className="flex flex-col items-end gap-3 shrink-0">
          <div className="text-right">
            <div className="flex items-center justify-end gap-1.5 text-white/80 text-sm">
              <Calendar className="h-4 w-4" /> {dateStr}
            </div>
            <div className="flex items-center justify-end gap-1.5 text-white/60 text-xs mt-0.5">
              <Clock className="h-3 w-3" /> {timeStr}
            </div>
          </div>
          <button
            onClick={onViewSchedule}
            className="flex items-center gap-2 bg-white text-purple-700 font-semibold text-sm px-4 py-2 rounded-xl hover:bg-white/90 transition-all shadow-md"
          >
            Voir mon emploi du temps <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}