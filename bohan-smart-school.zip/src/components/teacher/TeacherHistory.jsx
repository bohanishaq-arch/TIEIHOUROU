import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { CheckCircle, Clock, Eye, BookOpen, ClipboardList, FlaskConical, Filter } from "lucide-react";

const TYPE_CONFIG = {
  cours: { label: "Cours", icon: BookOpen, color: "bg-blue-100 text-blue-700", emoji: "📖" },
  devoir: { label: "Devoir", icon: ClipboardList, color: "bg-amber-100 text-amber-700", emoji: "📝" },
  examen: { label: "Examen", icon: FlaskConical, color: "bg-purple-100 text-purple-700", emoji: "🧪" },
};

export default function TeacherHistory() {
  const { user } = useAuth();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all"); // all | approuvé | en_attente
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    async function load() {
      const list = await base44.entities.TeacherReport.filter({ teacher_email: user?.email }, "-date", 200);
      setReports(list);
      setLoading(false);
    }
    if (user?.email) load();
  }, [user?.email]);

  const filtered = reports.filter(r => {
    if (filter === "approuvé") return r.status === "approuvé";
    if (filter === "en_attente") return r.status !== "approuvé";
    return true;
  });

  const approvedCount = reports.filter(r => r.status === "approuvé").length;
  const pendingCount = reports.filter(r => r.status !== "approuvé").length;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-orange-200 border-t-orange-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-muted/50 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-foreground">{reports.length}</p>
          <p className="text-xs text-muted-foreground mt-0.5">Total envoyés</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{approvedCount}</p>
          <p className="text-xs text-green-600 mt-0.5">Validés</p>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-amber-700">{pendingCount}</p>
          <p className="text-xs text-amber-600 mt-0.5">En attente</p>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 border-b border-border pb-3">
        {[
          { key: "all", label: "Tous" },
          { key: "approuvé", label: "✅ Validés" },
          { key: "en_attente", label: "⏳ En attente" },
        ].map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
              filter === f.key
                ? "bg-orange-100 text-orange-700"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <BookOpen className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">Aucun rapport trouvé.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(r => {
            const cfg = TYPE_CONFIG[r.report_type] || TYPE_CONFIG.cours;
            const isApproved = r.status === "approuvé";
            return (
              <div
                key={r.id}
                className={`relative rounded-xl border p-4 cursor-pointer overflow-hidden transition-shadow hover:shadow-md ${
                  isApproved ? "border-green-300 bg-green-50/40" : "border-border bg-card"
                }`}
                onClick={() => setSelected(selected?.id === r.id ? null : r)}
              >
                {/* Watermark VALIDÉ */}
                {isApproved && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
                    <span className="text-green-200 font-black text-5xl tracking-widest rotate-[-20deg] opacity-50">
                      VALIDÉ
                    </span>
                  </div>
                )}

                <div className="relative z-10">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 text-base ${cfg.color}`}>
                        {cfg.emoji}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-foreground truncate">{r.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {r.class_name || "—"} · {r.subject_name || "—"} · {r.date ? new Date(r.date).toLocaleDateString("fr-FR") : ""}
                        </p>
                      </div>
                    </div>
                    <div className="shrink-0">
                      {isApproved ? (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-green-700 bg-green-100 border border-green-300 px-2.5 py-1 rounded-full">
                          <CheckCircle className="h-3.5 w-3.5" /> Validé
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700 bg-amber-100 px-2.5 py-1 rounded-full">
                          <Clock className="h-3.5 w-3.5" /> {r.status === "lu" ? "Lu" : "En attente"}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Expanded detail */}
                  {selected?.id === r.id && (
                    <div className="mt-4 pt-4 border-t border-border/60 space-y-3">
                      {r.objectives && <Detail label="Objectifs" value={r.objectives} />}
                      {r.content && <Detail label="Contenu" value={r.content} />}
                      {r.activities && <Detail label="Activités" value={r.activities} />}
                      {r.remarks && <Detail label="Remarques" value={r.remarks} />}
                      {r.due_date && <Detail label="Date de rendu/examen" value={new Date(r.due_date).toLocaleDateString("fr-FR")} />}
                      {isApproved && r.approved_by && (
                        <div className="flex items-center gap-2 bg-green-100 border border-green-300 rounded-lg px-3 py-2">
                          <CheckCircle className="h-4 w-4 text-green-600 shrink-0" />
                          <p className="text-sm text-green-700 font-medium">
                            Approuvé par <strong>{r.approved_by}</strong>
                            {r.approved_date && ` le ${new Date(r.approved_date).toLocaleDateString("fr-FR")}`}
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Detail({ label, value }) {
  return (
    <div>
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">{label}</p>
      <p className="text-sm text-foreground bg-muted/40 rounded-lg px-3 py-2 whitespace-pre-line">{value}</p>
    </div>
  );
}