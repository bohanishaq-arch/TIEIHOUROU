import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { CheckCircle2, XCircle, Clock, AlertCircle, Save, Loader2, Users } from "lucide-react";
import MobileSelect from "@/components/MobileSelect";

const STATUS_CONFIG = {
  présent:         { label: "Présent",           color: "bg-emerald-100 text-emerald-700 border-emerald-300", icon: CheckCircle2, dot: "bg-emerald-500" },
  absent:          { label: "Absent",            color: "bg-red-100 text-red-700 border-red-300",             icon: XCircle,      dot: "bg-red-500" },
  retard:          { label: "Retard",            color: "bg-amber-100 text-amber-700 border-amber-300",       icon: Clock,        dot: "bg-amber-500" },
  absent_justifié: { label: "Absent justifié",   color: "bg-blue-100 text-blue-700 border-blue-300",          icon: AlertCircle,  dot: "bg-blue-500" },
};

function calcDuration(start, end) {
  if (!start || !end) return 1;
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  const diff = (eh * 60 + em - sh * 60 - sm) / 60;
  return diff > 0 ? parseFloat(diff.toFixed(2)) : 1;
}

export default function TeacherAttendanceManager({ teacherEmail, schoolId }) {
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [students, setStudents] = useState([]);
  const [schedules, setSchedules] = useState([]);

  const [selectedClass, setSelectedClass] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [startTime, setStartTime] = useState("08:00");
  const [endTime, setEndTime] = useState("09:00");
  const [academicYear, setAcademicYear] = useState("");

  const [attendanceMap, setAttendanceMap] = useState({}); // studentId -> status
  const [reasonMap, setReasonMap] = useState({});          // studentId -> reason
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [existingMap, setExistingMap] = useState({});      // studentId -> session id (already saved)
  const [pendingSet, setPendingSet] = useState(new Set()); // optimistic: students being saved in bg

  useEffect(() => {
    async function load() {
      const f = schoolId ? { school_id: schoolId } : {};
      const [cls, subs, assigns, scheds] = await Promise.all([
        base44.entities.Class.filter(f),
        base44.entities.Subject.filter(f),
        base44.entities.TeacherAssignment.filter({ teacher_email: teacherEmail, ...f }),
        base44.entities.Schedule.filter({ teacher_email: teacherEmail, ...f }),
      ]);
      setClasses(cls);
      setSubjects(subs);
      setAssignments(assigns);
      setSchedules(scheds);

      // Auto-detect academic year from classes
      const yr = cls[0]?.academic_year || `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`;
      setAcademicYear(yr);
    }
    if (teacherEmail) load();
  }, [teacherEmail, schoolId]);

  // Load students when class selected
  useEffect(() => {
    if (!selectedClass) { setStudents([]); return; }
    const f = schoolId ? { class_id: selectedClass, school_id: schoolId } : { class_id: selectedClass };
    base44.entities.Student.filter(f).then(s =>
      setStudents(s.filter(st => st.status === "Actif" || !st.status).sort((a, b) => a.last_name.localeCompare(b.last_name)))
    );
  }, [selectedClass, schoolId]);

  // Load existing sessions for this slot
  useEffect(() => {
    if (!selectedClass || !selectedSubject || !selectedDate) return;
    base44.entities.AttendanceSession.filter({
      class_id: selectedClass,
      subject_id: selectedSubject,
      date: selectedDate,
    }).then(sessions => {
      const map = {};
      const reasons = {};
      const existing = {};
      sessions.forEach(s => {
        map[s.student_id] = s.status;
        reasons[s.student_id] = s.reason || "";
        existing[s.student_id] = s.id;
      });
      setAttendanceMap(map);
      setReasonMap(reasons);
      setExistingMap(existing);
    });
  }, [selectedClass, selectedSubject, selectedDate]);

  // Auto-fill from schedule
  useEffect(() => {
    if (!selectedClass || !selectedSubject) return;
    const DAYS = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
    const dayName = DAYS[new Date(selectedDate + "T12:00:00").getDay()];
    const slot = schedules.find(s => s.class_id === selectedClass && s.subject_id === selectedSubject && s.day === dayName);
    if (slot) {
      setStartTime(slot.start_time || "08:00");
      setEndTime(slot.end_time || "09:00");
    }
  }, [selectedClass, selectedSubject, selectedDate, schedules]);

  // My classes & subjects from assignments
  const myClasses = useMemo(() => {
    const ids = [...new Set(assignments.map(a => a.class_id))];
    return classes.filter(c => ids.includes(c.id));
  }, [classes, assignments]);

  const mySubjects = useMemo(() => {
    if (!selectedClass) return [];
    const ids = assignments.filter(a => a.class_id === selectedClass).map(a => a.subject_id);
    return subjects.filter(s => ids.includes(s.id));
  }, [subjects, assignments, selectedClass]);

  async function setStatus(studentId, status) {
    // Optimistic: update UI immediately
    setAttendanceMap(prev => ({ ...prev, [studentId]: status }));
    setPendingSet(prev => new Set(prev).add(studentId));

    // Background save for this single student
    if (selectedClass && selectedSubject && selectedDate) {
      const duration = calcDuration(startTime, endTime);
      const subjectObj = subjects.find(s => s.id === selectedSubject);
      const classObj = classes.find(c => c.id === selectedClass);
      const student = students.find(s => s.id === studentId);
      if (student) {
        const payload = {
          school_id: schoolId, student_id: student.id,
          student_name: `${student.last_name} ${student.first_name}`,
          class_id: selectedClass, class_name: classObj?.name || "",
          subject_id: selectedSubject, subject_name: subjectObj?.name || "",
          teacher_email: teacherEmail, date: selectedDate,
          start_time: startTime, end_time: endTime, duration_hours: duration,
          status, reason: reasonMap[student.id] || "", academic_year: academicYear,
        };
        if (existingMap[studentId]) {
          await base44.entities.AttendanceSession.update(existingMap[studentId], payload);
        } else {
          const created = await base44.entities.AttendanceSession.create(payload);
          setExistingMap(prev => ({ ...prev, [studentId]: created.id }));
        }
      }
    }

    setPendingSet(prev => { const s = new Set(prev); s.delete(studentId); return s; });
  }

  function markAll(status) {
    const map = {};
    students.forEach(s => { map[s.id] = status; });
    setAttendanceMap(map);
  }

  async function handleSave() {
    if (!selectedClass || !selectedSubject || !selectedDate) return;
    setSaving(true);
    const duration = calcDuration(startTime, endTime);
    const subjectObj = subjects.find(s => s.id === selectedSubject);
    const classObj = classes.find(c => c.id === selectedClass);

    const ops = students.map(async student => {
      const status = attendanceMap[student.id] || "présent";
      const payload = {
        school_id: schoolId,
        student_id: student.id,
        student_name: `${student.last_name} ${student.first_name}`,
        class_id: selectedClass,
        class_name: classObj?.name || "",
        subject_id: selectedSubject,
        subject_name: subjectObj?.name || "",
        teacher_email: teacherEmail,
        date: selectedDate,
        start_time: startTime,
        end_time: endTime,
        duration_hours: duration,
        status,
        reason: reasonMap[student.id] || "",
        academic_year: academicYear,
      };
      if (existingMap[student.id]) {
        return base44.entities.AttendanceSession.update(existingMap[student.id], payload);
      } else {
        return base44.entities.AttendanceSession.create(payload);
      }
    });

    await Promise.all(ops);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  const stats = useMemo(() => {
    const présents = students.filter(s => (attendanceMap[s.id] || "présent") === "présent").length;
    const absents  = students.filter(s => attendanceMap[s.id] === "absent").length;
    const retards  = students.filter(s => attendanceMap[s.id] === "retard").length;
    const justif   = students.filter(s => attendanceMap[s.id] === "absent_justifié").length;
    return { présents, absents, retards, justif };
  }, [attendanceMap, students]);

  return (
    <div className="space-y-5">
      {/* Config row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div>
          <label className="text-xs font-semibold text-muted-foreground mb-1 block">Classe</label>
          <MobileSelect
            value={selectedClass}
            onChange={v => { setSelectedClass(v); setSelectedSubject(""); }}
            options={myClasses.map(c => ({ value: c.id, label: c.name }))}
            placeholder="-- Choisir --"
          />
        </div>
        <div>
          <label className="text-xs font-semibold text-muted-foreground mb-1 block">Matière</label>
          <MobileSelect
            value={selectedSubject}
            onChange={v => setSelectedSubject(v)}
            options={mySubjects.map(s => ({ value: s.id, label: s.name }))}
            placeholder="-- Choisir --"
            disabled={!selectedClass}
          />
        </div>
        <div>
          <label className="text-xs font-semibold text-muted-foreground mb-1 block">Date</label>
          <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)}
            className="w-full h-9 rounded-lg border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <div className="flex gap-2">
          <div className="flex-1">
            <label className="text-xs font-semibold text-muted-foreground mb-1 block">Début</label>
            <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)}
              className="w-full h-9 rounded-lg border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div className="flex-1">
            <label className="text-xs font-semibold text-muted-foreground mb-1 block">Fin</label>
            <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)}
              className="w-full h-9 rounded-lg border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
        </div>
      </div>

      {/* Stats bar */}
      {students.length > 0 && (
        <div className="flex flex-wrap gap-3 items-center">
          {[
            { label: "Présents", count: stats.présents, color: "bg-emerald-100 text-emerald-700" },
            { label: "Absents",  count: stats.absents,  color: "bg-red-100 text-red-700" },
            { label: "Retards",  count: stats.retards,  color: "bg-amber-100 text-amber-700" },
            { label: "Justifiés",count: stats.justif,   color: "bg-blue-100 text-blue-700" },
          ].map(s => (
            <span key={s.label} className={`text-xs font-bold px-3 py-1.5 rounded-full ${s.color}`}>
              {s.count} {s.label}
            </span>
          ))}
          <div className="ml-auto flex gap-2">
            <button onClick={() => markAll("présent")} className="text-xs px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold hover:bg-emerald-100 transition-colors">
              Tous présents
            </button>
            <button onClick={() => markAll("absent")} className="text-xs px-3 py-1.5 rounded-lg bg-red-50 text-red-700 border border-red-200 font-semibold hover:bg-red-100 transition-colors">
              Tous absents
            </button>
          </div>
        </div>
      )}

      {/* Student list */}
      {!selectedClass || !selectedSubject ? (
        <div className="text-center py-10 text-muted-foreground text-sm">
          <Users className="h-10 w-10 mx-auto mb-2 opacity-30" />
          Sélectionnez une classe et une matière pour commencer.
        </div>
      ) : students.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground text-sm">Aucun élève actif dans cette classe.</div>
      ) : (
        <div className="space-y-2">
          {students.map((student, idx) => {
            const status = attendanceMap[student.id] || "présent";
            const cfg = STATUS_CONFIG[status];
            const needsReason = status === "absent" || status === "absent_justifié" || status === "retard";
            const isPending = pendingSet.has(student.id);
            return (
              <div key={student.id} className={`rounded-xl border p-3 transition-all ${cfg.color} ${isPending ? "opacity-80 ring-1 ring-current" : ""}`}>
                <div className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-full bg-white/60 flex items-center justify-center text-xs font-bold shrink-0">{idx + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="font-semibold text-sm">{student.last_name} {student.first_name}</p>
                      {isPending && <Loader2 className="h-3 w-3 animate-spin shrink-0" />}
                    </div>
                    <p className="text-xs opacity-70 font-mono">{student.student_number}</p>
                  </div>
                  {/* Status buttons */}
                  <div className="flex gap-1 shrink-0">
                    {Object.entries(STATUS_CONFIG).map(([key, conf]) => (
                      <button key={key} onClick={() => setStatus(student.id, key)}
                        title={conf.label}
                        className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center transition-all ${
                          status === key ? "border-current shadow-sm scale-110" : "border-transparent bg-white/40 hover:bg-white/60"
                        }`}>
                        <conf.icon className="h-4 w-4" />
                      </button>
                    ))}
                  </div>
                </div>
                {needsReason && (
                  <input
                    type="text"
                    value={reasonMap[student.id] || ""}
                    onChange={e => setReasonMap(prev => ({ ...prev, [student.id]: e.target.value }))}
                    placeholder="Motif (optionnel)…"
                    className="mt-2 w-full h-8 rounded-lg border border-white/50 bg-white/60 px-3 text-xs focus:outline-none focus:ring-2 focus:ring-ring placeholder:text-current/40"
                  />
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Save button */}
      {students.length > 0 && selectedSubject && (
        <button onClick={handleSave} disabled={saving}
          className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl py-3 font-bold text-sm disabled:opacity-60 hover:bg-primary/90 transition-colors shadow-md">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <CheckCircle2 className="h-4 w-4" /> : <Save className="h-4 w-4" />}
          {saving ? "Enregistrement…" : saved ? "✅ Présences enregistrées !" : "Enregistrer les présences"}
        </button>
      )}
    </div>
  );
}