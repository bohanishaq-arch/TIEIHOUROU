import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { PenLine, Search, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const TRIMESTERS = ["Tous", "Trimestre 1", "Trimestre 2", "Trimestre 3"];

function avg(grades) {
  if (!grades.length) return null;
  return grades.reduce((s, g) => s + g.score, 0) / grades.length;
}

function ScoreBadge({ score }) {
  const color =
    score >= 14 ? "bg-emerald-100 text-emerald-700 border-emerald-200"
    : score >= 10 ? "bg-amber-100 text-amber-700 border-amber-200"
    : "bg-red-100 text-red-700 border-red-200";
  return (
    <span className={`px-2 py-0.5 rounded-lg border text-xs font-bold ${color}`}>
      {score}/20
    </span>
  );
}

export default function TeacherGradesList({ myClasses, mySubjects, myStudents, myGrades }) {
  const [search, setSearch] = useState("");
  const [selectedClass, setSelectedClass] = useState("all");
  const [selectedTrimester, setSelectedTrimester] = useState("Tous");
  const [sortDir, setSortDir] = useState("desc");

  const filtered = useMemo(() => {
    return myGrades.filter((g) => {
      const student = myStudents.find((s) => s.id === g.student_id);
      const name = `${student?.last_name} ${student?.first_name}`.toLowerCase();
      const matchSearch = !search || name.includes(search.toLowerCase());
      const matchClass = selectedClass === "all" || g.class_id === selectedClass;
      const matchTrimester = selectedTrimester === "Tous" || g.trimester === selectedTrimester;
      return matchSearch && matchClass && matchTrimester;
    }).sort((a, b) => sortDir === "desc" ? b.score - a.score : a.score - b.score);
  }, [myGrades, search, selectedClass, selectedTrimester, sortDir, myStudents]);

  const globalAvg = avg(filtered);

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-md border border-border/40 p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Rechercher un élève…" className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="h-9 rounded-md border border-input bg-transparent px-3 text-sm"
          >
            <option value="all">Toutes les classes</option>
            {myClasses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select
            value={selectedTrimester}
            onChange={(e) => setSelectedTrimester(e.target.value)}
            className="h-9 rounded-md border border-input bg-transparent px-3 text-sm"
          >
            {TRIMESTERS.map((t) => <option key={t}>{t}</option>)}
          </select>
        </div>
      </div>

      {/* Summary bar */}
      <div className="flex items-center gap-4 bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-100 rounded-2xl px-5 py-3">
        <span className="text-sm text-muted-foreground">{filtered.length} notes trouvées</span>
        {globalAvg !== null && (
          <span className="text-sm font-bold text-indigo-700">Moyenne : {globalAvg.toFixed(2)}/20</span>
        )}
        <div className="ml-auto flex gap-2">
          <button
            onClick={() => setSortDir(sortDir === "desc" ? "asc" : "desc")}
            className="flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-800 font-medium"
          >
            {sortDir === "desc" ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronUp className="h-3.5 w-3.5" />}
            Trier par note
          </button>
          <Link to="/grades">
            <Button size="sm" className="gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white h-7 text-xs">
              <PenLine className="h-3 w-3" /> Saisir
            </Button>
          </Link>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-md border border-border/40 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-16 text-center text-muted-foreground text-sm">Aucune note trouvée</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gradient-to-r from-indigo-50 to-purple-50 border-b border-border/40">
                  <th className="text-left py-3 px-4 text-xs font-semibold text-indigo-700 uppercase tracking-wide">Élève</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-indigo-700 uppercase tracking-wide">Classe</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-indigo-700 uppercase tracking-wide">Matière</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-indigo-700 uppercase tracking-wide">Type</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-indigo-700 uppercase tracking-wide">Trimestre</th>
                  <th className="text-right py-3 px-4 text-xs font-semibold text-indigo-700 uppercase tracking-wide">Note</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((g, i) => {
                  const student = myStudents.find((s) => s.id === g.student_id);
                  const cls = myClasses.find((c) => c.id === g.class_id);
                  const sub = myClasses.find((c) => c.id === g.class_id);
                  return (
                    <tr key={g.id} className={`border-b border-border/30 hover:bg-indigo-50/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-400 to-purple-400 flex items-center justify-center text-white text-xs font-bold shrink-0">
                            {student?.last_name?.charAt(0) || "?"}
                          </div>
                          <span className="text-sm font-medium">{student ? `${student.last_name} ${student.first_name}` : "—"}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-sm text-muted-foreground">{cls?.name || "—"}</td>
                      <td className="py-3 px-4 text-sm text-muted-foreground">{g.subject_id ? "—" : "—"}</td>
                      <td className="py-3 px-4">
                        <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md">{g.exam_type}</span>
                      </td>
                      <td className="py-3 px-4 text-xs text-muted-foreground">{g.trimester}</td>
                      <td className="py-3 px-4 text-right">
                        <ScoreBadge score={g.score} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}