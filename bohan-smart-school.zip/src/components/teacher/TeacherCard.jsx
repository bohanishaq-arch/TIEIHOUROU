import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { GraduationCap, Search, Loader2, AlertCircle, BookOpen, Users, School } from "lucide-react";

export default function TeacherCard({ myClasses, mySubjects, myAssignments, onProfileLinked }) {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null); // AppAccess record
  const [schoolSettings, setSchoolSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [accessIdInput, setAccessIdInput] = useState("");
  const [linkLoading, setLinkLoading] = useState(false);
  const [linkError, setLinkError] = useState("");

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const filter = schoolId ? { school_id: schoolId } : {};
      const [accesses, settings] = await Promise.all([
        base44.entities.AppAccess.filter({ user_email: user?.email?.toLowerCase() }),
        base44.entities.SchoolSettings.filter(filter),
      ]);
      const teacherAccess = accesses.find((a) => a.role === "teacher" && a.is_active);
      setProfile(teacherAccess || null);
      setSchoolSettings(settings[0] || null);
      setLoading(false);
    }
    if (user?.email) load();
  }, [user]);

  async function handleLink(e) {
    e.preventDefault();
    setLinkError("");
    setLinkLoading(true);
    const schoolId = getSchoolId();
    const filter = schoolId ? { school_id: schoolId } : {};
    const allAccesses = await base44.entities.AppAccess.filter(filter);
    const match = allAccesses.find(
      (a) =>
        a.access_id?.trim().toLowerCase() === accessIdInput.trim().toLowerCase() &&
        a.role === "teacher" &&
        a.is_active !== false
    );
    if (!match) {
      setLinkError("Aucun profil professeur trouvé avec cet identifiant.");
      setLinkLoading(false);
      return;
    }
    // Link this google email to the AppAccess record
    await base44.entities.AppAccess.update(match.id, { user_email: user.email.toLowerCase() });
    const linked = { ...match, user_email: user.email.toLowerCase() };
    setProfile(linked);
    setLinkLoading(false);
    if (onProfileLinked) onProfileLinked(linked);
  }

  if (loading) return (
    <div className="flex items-center justify-center h-40">
      <div className="w-6 h-6 border-4 border-green-200 border-t-green-600 rounded-full animate-spin" />
    </div>
  );

  // Not linked yet — show form
  if (!profile) return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] p-4">
      <div className="w-full max-w-md bg-card border border-border rounded-2xl shadow-lg overflow-hidden">
        <div className="p-6 text-center" style={{ background: "linear-gradient(135deg, #16a34a 0%, #15803d 100%)" }}>
          <div className="w-14 h-14 bg-white/15 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <GraduationCap className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-lg font-bold text-white">Lier mon profil professeur</h2>
          <p className="text-white/70 text-xs mt-1">Saisissez votre identifiant d'accès</p>
        </div>

        <div className="p-6 space-y-5">
          <div className="flex items-center gap-2 bg-muted rounded-lg px-3 py-2">
            <div className="w-7 h-7 rounded-full bg-green-100 flex items-center justify-center text-green-700 font-bold text-xs shrink-0">
              {(user?.email || "?")[0].toUpperCase()}
            </div>
            <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          </div>

          <form onSubmit={handleLink} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-1.5">Identifiant d'accès</label>
              <input
                type="text"
                value={accessIdInput}
                onChange={(e) => { setAccessIdInput(e.target.value); setLinkError(""); }}
                placeholder="Ex : PROF-AB-2024-001"
                className="w-full border border-input rounded-lg px-3 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-green-500 bg-background"
                required
                autoFocus
              />
            </div>

            {linkError && (
              <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2.5 text-sm text-red-700">
                <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                {linkError}
              </div>
            )}

            <button
              type="submit"
              disabled={linkLoading || !accessIdInput.trim()}
              className="w-full flex items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60 transition-colors"
              style={{ background: "#16a34a" }}
            >
              {linkLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              {linkLoading ? "Recherche en cours…" : "Lier mon profil"}
            </button>
          </form>

          <p className="text-center text-xs text-muted-foreground">
            Cet identifiant vous a été remis par l'administrateur.<br />
            En cas de difficulté, contactez l'administration.
          </p>
        </div>
      </div>
    </div>
  );

  // Linked — show green teacher ID card
  const mySubjectNames = myAssignments
    .map((a) => mySubjects.find((s) => s.id === a.subject_id)?.name)
    .filter(Boolean);
  const uniqueSubjects = [...new Set(mySubjectNames)];

  return (
    <div className="flex flex-col items-center gap-6">
      {/* Green ID Card */}
      <div className="w-full max-w-md rounded-3xl shadow-2xl overflow-hidden text-white"
        style={{ background: "linear-gradient(135deg, #16a34a 0%, #15803d 60%, #166534 100%)" }}>
        {/* Header band */}
        <div className="px-6 pt-5 pb-3 flex items-center justify-between border-b border-white/20">
          <div>
            <p className="text-[10px] uppercase tracking-widest opacity-70">
              {schoolSettings?.republic_name || "RÉPUBLIQUE"}
            </p>
            <p className="text-xs font-bold opacity-90">{schoolSettings?.school_name || "Établissement"}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center">
            <GraduationCap className="h-6 w-6 text-white" />
          </div>
        </div>

        {/* Body */}
        <div className="px-6 py-5 flex gap-5 items-start">
          {/* Avatar */}
          <div className="w-20 h-24 rounded-xl bg-white/15 border-2 border-white/30 overflow-hidden shrink-0 flex items-center justify-center">
            <span className="text-4xl font-bold opacity-60">
              {(profile.full_name || user?.email || "P")[0].toUpperCase()}
            </span>
          </div>
          {/* Info */}
          <div className="flex-1 space-y-1.5">
            <p className="text-lg font-bold leading-tight">{profile.full_name || user?.full_name || "Professeur"}</p>
            <div className="space-y-1 text-xs opacity-85">
              <div className="flex gap-2">
                <span className="opacity-60 w-20 shrink-0">Identifiant</span>
                <span className="font-mono font-semibold">{profile.access_id}</span>
              </div>
              <div className="flex gap-2">
                <span className="opacity-60 w-20 shrink-0">Rôle</span>
                <span className="font-semibold">Professeur</span>
              </div>
              <div className="flex gap-2">
                <span className="opacity-60 w-20 shrink-0">Classes</span>
                <span>{myClasses.length > 0 ? myClasses.map((c) => c.name).join(", ") : "Non assigné"}</span>
              </div>
              {profile.school_name && (
                <div className="flex gap-2">
                  <span className="opacity-60 w-20 shrink-0">École</span>
                  <span>{profile.school_name}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-black/20 flex items-center justify-between">
          <p className="text-[10px] uppercase tracking-widest opacity-60">Carte d'identité professeur</p>
          <span className="text-xs px-2 py-0.5 rounded-full font-semibold bg-green-300/20 text-green-100">
            ● Actif
          </span>
        </div>
      </div>

      {/* Sync notice */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground bg-card border border-border rounded-xl px-4 py-2.5">
        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shrink-0" />
        Profil lié — vos classes et matières sont synchronisées automatiquement.
      </div>

      {/* Summary cards */}
      <div className="w-full max-w-md grid grid-cols-2 gap-3">
        <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
            <School className="h-5 w-5 text-green-700" />
          </div>
          <div>
            <p className="text-2xl font-bold text-foreground">{myClasses.length}</p>
            <p className="text-xs text-muted-foreground">Classe{myClasses.length !== 1 ? "s" : ""}</p>
          </div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
            <BookOpen className="h-5 w-5 text-green-700" />
          </div>
          <div>
            <p className="text-2xl font-bold text-foreground">{uniqueSubjects.length}</p>
            <p className="text-xs text-muted-foreground">Matière{uniqueSubjects.length !== 1 ? "s" : ""}</p>
          </div>
        </div>
      </div>

      {/* Subjects list */}
      {uniqueSubjects.length > 0 && (
        <div className="w-full max-w-md bg-card border border-border rounded-xl p-4 space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Matières enseignées</p>
          {uniqueSubjects.map((s) => (
            <div key={s} className="flex items-center gap-2 py-1.5 border-b border-border/50 last:border-0">
              <div className="w-2 h-2 rounded-full bg-green-500 shrink-0" />
              <span className="text-sm font-medium">{s}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}