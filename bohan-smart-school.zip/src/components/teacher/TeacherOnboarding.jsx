import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { GraduationCap, User, Phone, BookOpen, Send, Clock, CheckCircle, XCircle } from "lucide-react";

export default function TeacherOnboarding({ accessRecord, existingRequest, onCompleted }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    first_name: accessRecord?.full_name?.split(" ")[0] || "",
    last_name: accessRecord?.full_name?.split(" ").slice(1).join(" ") || "",
    phone: "",
    subjects_taught: "",
    message: "",
  });
  const [availableSubjects, setAvailableSubjects] = useState([]);
  const [selectedSubjects, setSelectedSubjects] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(!!existingRequest);
  const [request, setRequest] = useState(existingRequest || null);

  useEffect(() => {
    async function loadSubjects() {
      const schoolId = getSchoolId() || accessRecord?.school_id;
      const filter = schoolId ? { school_id: schoolId } : {};

      // Load all subjects for the school
      const [subs, assignments] = await Promise.all([
        base44.entities.Subject.filter(filter),
        base44.entities.TeacherAssignment.filter({
          ...filter,
          teacher_email: user?.email?.toLowerCase(),
        }),
      ]);

      setAvailableSubjects(subs);

      // Pre-select subjects already assigned to this teacher
      if (assignments.length > 0) {
        const assignedSubjectIds = new Set(assignments.map(a => a.subject_id));
        const preSelected = subs
          .filter(s => assignedSubjectIds.has(s.id))
          .map(s => s.name);
        if (preSelected.length > 0) setSelectedSubjects(preSelected);
      }
    }
    loadSubjects();
  }, []);

  function toggleSubject(name) {
    setSelectedSubjects(prev =>
      prev.includes(name) ? prev.filter(s => s !== name) : [...prev, name]
    );
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    const schoolId = getSchoolId() || accessRecord?.school_id;
    const full_name = `${form.first_name.trim()} ${form.last_name.trim()}`.trim();

    // Update AppAccess with full name & phone
    if (accessRecord?.id) {
      await base44.entities.AppAccess.update(accessRecord.id, {
        full_name,
        school_name: accessRecord.school_name,
      });
    }

    const subjectsList = selectedSubjects.length > 0
      ? selectedSubjects.join(", ")
      : form.subjects_taught.trim();

    // Create AccessRequest for admin review
    const req = await base44.entities.AccessRequest.create({
      school_id: schoolId,
      school_name: accessRecord?.school_name || "",
      email: user?.email || accessRecord?.user_email,
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      full_name,
      role_requested: "teacher",
      subjects_taught: subjectsList,
      message: `Téléphone: ${form.phone.trim()}${form.message ? "\n" + form.message : ""}`,
      status: "en_attente",
    });

    setRequest(req);
    setDone(true);
    setSubmitting(false);
  }

  const statusConfig = {
    en_attente: { icon: Clock, color: "text-amber-500", bg: "bg-amber-50 border-amber-200", label: "En attente d'approbation", desc: "L'administration va examiner votre demande et vous contacter." },
    approuvee: { icon: CheckCircle, color: "text-green-500", bg: "bg-green-50 border-green-200", label: "Demande approuvée !", desc: "Vous êtes maintenant autorisé à enseigner dans cet établissement." },
    rejetee: { icon: XCircle, color: "text-red-500", bg: "bg-red-50 border-red-200", label: "Demande rejetée", desc: request?.admin_note || "Contactez l'administration pour plus d'informations." },
  };

  if (done && request) {
    const status = statusConfig[request.status] || statusConfig.en_attente;
    const Icon = status.icon;

    if (request.status === "approuvee") {
      // Approved — let parent know to proceed
      setTimeout(() => onCompleted?.(), 1500);
    }

    return (
      <div className="min-h-[60vh] flex items-center justify-center p-6">
        <div className={`max-w-md w-full rounded-2xl border-2 p-8 text-center space-y-4 ${status.bg}`}>
          <Icon className={`h-16 w-16 mx-auto ${status.color}`} />
          <h2 className="text-xl font-bold text-foreground">{status.label}</h2>
          <p className="text-muted-foreground text-sm">{status.desc}</p>
          {request.status === "en_attente" && (
            <div className="bg-white rounded-xl p-4 text-left space-y-2 text-sm border border-border">
              <p><span className="text-muted-foreground">Nom :</span> <strong>{request.full_name}</strong></p>
              <p><span className="text-muted-foreground">Email :</span> <strong>{request.email}</strong></p>
              <p><span className="text-muted-foreground">Matières :</span> <strong>{request.subjects_taught || "—"}</strong></p>
            </div>
          )}
          <p className="text-xs text-muted-foreground">Actualisez la page pour voir les mises à jour de votre demande.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[60vh] flex items-center justify-center p-6">
      <div className="max-w-lg w-full space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center mx-auto">
            <GraduationCap className="h-8 w-8 text-orange-600" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Complétez votre inscription</h1>
          <p className="text-sm text-muted-foreground">
            Renseignez vos informations pour rejoindre l'établissement{accessRecord?.school_name ? ` ${accessRecord.school_name}` : ""}.
          </p>
        </div>

        {/* Info card */}
        {accessRecord && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-sm space-y-1">
            <p className="font-semibold text-blue-800">Vos identifiants d'accès</p>
            <p className="text-blue-700">Code permanent : <span className="font-mono font-bold">{accessRecord.access_id}</span></p>
            {accessRecord.school_name && <p className="text-blue-600">École : {accessRecord.school_name}</p>}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-card border border-border rounded-2xl p-6 space-y-4 shadow-sm">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-1.5">
                <User className="h-3.5 w-3.5 inline mr-1" />Prénom *
              </label>
              <input
                type="text"
                value={form.first_name}
                onChange={e => setForm(f => ({ ...f, first_name: e.target.value }))}
                placeholder="Ex: YAHAYA"
                className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
                required
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-1.5">Nom *</label>
              <input
                type="text"
                value={form.last_name}
                onChange={e => setForm(f => ({ ...f, last_name: e.target.value }))}
                placeholder="Ex: KONE"
                className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring uppercase"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">
              <Phone className="h-3.5 w-3.5 inline mr-1" />Téléphone
            </label>
            <input
              type="tel"
              value={form.phone}
              onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
              placeholder="+225 07 XX XX XX XX"
              className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">
              <BookOpen className="h-3.5 w-3.5 inline mr-1" />Matière(s) souhaitée(s) *
            </label>
            {availableSubjects.length === 0 && (
              <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-2">
                ⚠️ Aucune matière n'est encore configurée dans votre établissement. Contactez l'administrateur pour qu'il génère les matières depuis la page "Matières".
              </p>
            )}
            {availableSubjects.length > 0 ? (
              <div className="border border-input rounded-lg p-3 bg-background max-h-48 overflow-y-auto space-y-1">
                {availableSubjects.map(s => (
                  <label key={s.id} className={`flex items-center gap-2.5 px-2 py-1.5 rounded-lg cursor-pointer transition-colors ${selectedSubjects.includes(s.name) ? 'bg-orange-50 border border-orange-200' : 'hover:bg-muted/50'}`}>
                    <input
                      type="checkbox"
                      checked={selectedSubjects.includes(s.name)}
                      onChange={() => toggleSubject(s.name)}
                      className="accent-orange-600 w-4 h-4 shrink-0"
                    />
                    <span className="text-sm font-medium text-foreground">{s.name}</span>
                    
                  </label>
                ))}
              </div>
            ) : (
              <input
                type="text"
                value={form.subjects_taught}
                onChange={e => setForm(f => ({ ...f, subjects_taught: e.target.value }))}
                placeholder="Ex: Mathématiques, Physique-Chimie"
                className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
              />
            )}
            {selectedSubjects.length > 0 && (
              <p className="text-xs text-orange-700 mt-1.5 font-medium">
                ✓ {selectedSubjects.length} matière{selectedSubjects.length > 1 ? "s" : ""} sélectionnée{selectedSubjects.length > 1 ? "s" : ""} : {selectedSubjects.join(", ")}
              </p>
            )}
          </div>

          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Message (optionnel)</label>
            <textarea
              value={form.message}
              onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
              placeholder="Informations supplémentaires à transmettre à l'administration..."
              rows={3}
              className="w-full border border-input rounded-lg px-3 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={submitting || !form.first_name || !form.last_name || (availableSubjects.length > 0 ? selectedSubjects.length === 0 : !form.subjects_taught)}
            className="w-full flex items-center justify-center gap-2 bg-orange-600 text-white rounded-xl px-4 py-3 font-semibold hover:bg-orange-700 transition-colors disabled:opacity-60"
          >
            {submitting ? "Envoi en cours…" : (
              <><Send className="h-4 w-4" /> Soumettre ma demande</>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}