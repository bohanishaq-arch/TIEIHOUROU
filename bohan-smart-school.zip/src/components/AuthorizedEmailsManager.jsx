import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Mail, Globe, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function AuthorizedEmailsManager({ school, onUpdated }) {
  const [emails, setEmails] = useState(school.authorized_emails || []);
  const [domain, setDomain] = useState(school.authorized_domain || "");
  const [newEmail, setNewEmail] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function addEmail() {
    const email = newEmail.trim().toLowerCase();
    if (!email) return;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Adresse email invalide");
      return;
    }
    if (emails.includes(email)) {
      setError("Cet email est déjà dans la liste");
      return;
    }
    setEmails([...emails, email]);
    setNewEmail("");
    setError("");
  }

  function removeEmail(email) {
    setEmails(emails.filter((e) => e !== email));
  }

  async function handleSave() {
    setSaving(true);
    const cleanDomain = domain.trim().toLowerCase();
    await base44.entities.School.update(school.id, {
      authorized_emails: emails,
      authorized_domain: cleanDomain,
    });
    setSaving(false);
    onUpdated?.();
  }

  return (
    <div className="bg-card rounded-xl border border-border p-5 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <Mail className="h-4 w-4 text-primary" />
            Accès par email — {school.name}
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Seuls les emails enregistrés ou du domaine autorisé pourront se connecter.
          </p>
        </div>
        <Button onClick={handleSave} disabled={saving} size="sm" className="gap-1.5">
          <Save className="h-3.5 w-3.5" />
          {saving ? "Enregistrement…" : "Enregistrer"}
        </Button>
      </div>

      {/* Domain */}
      <div className="space-y-2">
        <Label className="flex items-center gap-1.5">
          <Globe className="h-3.5 w-3.5 text-muted-foreground" />
          Domaine autorisé (optionnel)
        </Label>
        <Input
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          placeholder="@lycee-abc.com"
          className="max-w-sm"
        />
        <p className="text-[11px] text-muted-foreground">
          Tous les emails se terminant par ce domaine seront automatiquement autorisés.
        </p>
      </div>

      {/* Email list */}
      <div className="space-y-2">
        <Label className="flex items-center gap-1.5">
          <Mail className="h-3.5 w-3.5 text-muted-foreground" />
          Emails individuels autorisés ({emails.length})
        </Label>

        <div className="flex gap-2">
          <Input
            value={newEmail}
            onChange={(e) => { setNewEmail(e.target.value); setError(""); }}
            placeholder="prof@ecole.com"
            className="flex-1"
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addEmail(); } }}
          />
          <Button type="button" variant="outline" size="sm" onClick={addEmail} className="gap-1.5 shrink-0">
            <Plus className="h-3.5 w-3.5" /> Ajouter
          </Button>
        </div>

        {error && <p className="text-xs text-red-600">{error}</p>}

        {emails.length > 0 ? (
          <div className="max-h-52 overflow-y-auto border border-border rounded-lg divide-y divide-border">
            {emails.map((email) => (
              <div key={email} className="flex items-center justify-between px-3 py-2 hover:bg-muted/30">
                <span className="text-sm text-foreground">{email}</span>
                <button
                  onClick={() => removeEmail(email)}
                  className="text-muted-foreground hover:text-destructive transition-colors"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground italic py-2">
            Aucun email individuel ajouté. Utilisez le domaine ou ajoutez des emails ci-dessus.
          </p>
        )}
      </div>
    </div>
  );
}