import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { hashPin, verifyPin } from "@/lib/pinHash";
import { setDisplayName, clearDisplayName } from "@/hooks/useDisplayName";
import {
  GraduationCap, Eye, EyeOff, LogOut, ArrowRight, CheckCircle2,
  KeyRound, Lock, AlertCircle, Loader2, ShieldCheck, ShieldAlert,
  RefreshCw
} from "lucide-react";

const SESSION_KEY = "scolaris_access_verified";
const ROLE_KEY = "scolaris_verified_role";
const MAX_ATTEMPTS = 5;
const LOCK_MINUTES = 10;

export function isAccessVerified() {
  return sessionStorage.getItem(SESSION_KEY) === "true";
}

export function getVerifiedRole() {
  return sessionStorage.getItem(ROLE_KEY) || null;
}

export function clearAccessVerified() {
  sessionStorage.removeItem(SESSION_KEY);
  sessionStorage.removeItem(ROLE_KEY);
  clearDisplayName();
}

const ROLE_LABELS = {
  teacher: "Professeur", student: "Élève", user: "Directeur",
  educator: "Éducateur", accountant: "Comptable", admin: "Administrateur",
  it_manager: "Informaticien",
};

// ── Étape 1 : Identifiant + mot de passe temporaire ──────────────────────────
function StepCredentials({ user, onMatch, emailBlocked }) {
  const [accessId, setAccessId] = useState("");
  const [password, setPassword] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (emailBlocked) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden">
        <div className="bg-red-500 p-8 text-center">
          <AlertCircle className="h-10 w-10 text-white mx-auto mb-3" />
          <h1 className="text-xl font-bold text-white">Accès refusé</h1>
          <p className="text-white/70 text-xs mt-1">Email non autorisé sur cette plateforme</p>
        </div>
        <div className="p-6 text-center space-y-4">
          <p className="text-sm text-slate-600">L'adresse <strong>{user.email}</strong> n'a pas accès à BOHAN.</p>
          <p className="text-xs text-slate-400">Contactez l'administrateur de votre établissement.</p>
          <button onClick={() => { clearAccessVerified(); base44.auth.logout(); }}
            className="flex items-center gap-2 text-sm text-slate-400 hover:text-slate-600 mx-auto">
            <LogOut className="h-4 w-4" /> Changer de compte
          </button>
        </div>
      </div>
    </div>
  );

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);

    const googleEmail = user.email.trim().toLowerCase();
    const idTrimmed = accessId.trim();
    const pwdTrimmed = password.trim();

    const allRecords = await base44.entities.AppAccess.list();

    // Vérifier verrouillage
    const candidate = allRecords.find(r => r.access_id?.trim() === idTrimmed);
    if (candidate?.locked_until) {
      const lockDate = new Date(candidate.locked_until);
      if (lockDate > new Date()) {
        const mins = Math.ceil((lockDate - new Date()) / 60000);
        setError(`Compte verrouillé. Réessayez dans ${mins} minute${mins > 1 ? "s" : ""}.`);
        setLoading(false);
        return;
      }
    }

    // Stratégie 1 : email + id + password
    let match = allRecords.find(r =>
      r.user_email?.trim().toLowerCase() === googleEmail &&
      r.access_id?.trim() === idTrimmed &&
      r.access_password?.trim() === pwdTrimmed
    );

    // Stratégie 2 : id + password seulement (première connexion — uniquement si aucun email n'est encore lié)
    if (!match) {
      const byIdPwd = allRecords.find(r =>
        r.access_id?.trim() === idTrimmed &&
        r.access_password?.trim() === pwdTrimmed
      );
      if (byIdPwd) {
        // Si un email est déjà lié à ce compte mais ne correspond pas → accès refusé
        if (byIdPwd.user_email && byIdPwd.user_email.trim().toLowerCase() !== googleEmail) {
          setError("Ce compte est déjà lié à une autre adresse email. Connectez-vous avec le bon compte Google.");
          setLoading(false);
          return;
        }
        // Première connexion : lier l'email Google au compte
        await base44.entities.AppAccess.update(byIdPwd.id, { user_email: googleEmail, failed_attempts: 0, locked_until: null });
        match = { ...byIdPwd, user_email: googleEmail };
      }
    }

    if (!match) {
      // Incrémenter les tentatives si on a trouvé un compte par access_id
      if (candidate) {
        const newAttempts = (candidate.failed_attempts || 0) + 1;
        const updateData = { failed_attempts: newAttempts };
        if (newAttempts >= MAX_ATTEMPTS) {
          const lockUntil = new Date(Date.now() + LOCK_MINUTES * 60 * 1000).toISOString();
          updateData.locked_until = lockUntil;
          setError(`Trop de tentatives. Compte verrouillé ${LOCK_MINUTES} minutes.`);
        } else {
          setError(`Identifiant ou mot de passe incorrect. ${MAX_ATTEMPTS - newAttempts} tentative${MAX_ATTEMPTS - newAttempts > 1 ? "s" : ""} restante${MAX_ATTEMPTS - newAttempts > 1 ? "s" : ""}.`);
        }
        await base44.entities.AppAccess.update(candidate.id, updateData);
      } else {
        setError("Identifiant ou mot de passe incorrect.");
      }
      setLoading(false);
      return;
    }

    // Réinitialiser les tentatives après succès
    if ((match.failed_attempts || 0) > 0) {
      await base44.entities.AppAccess.update(match.id, { failed_attempts: 0, locked_until: null });
    }

    setLoading(false);
    onMatch(match);
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-emerald-600/10 rounded-full blur-3xl" />
      </div>
      <div className="relative w-full max-w-md">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
          <div className="px-8 pt-8 pb-6 text-center border-b border-slate-800">
            <img src="https://media.base44.com/images/public/69d451f34dcd67ebe250192e/239e74618_generated_image.png" alt="BOHAN" className="h-20 w-20 rounded-2xl object-contain bg-white p-1 shadow-xl mx-auto mb-4" />
            <h1 className="text-3xl font-black text-white tracking-widest">BOHAN</h1>
            <p className="text-slate-400 text-xs uppercase tracking-widest mt-1">Plateforme scolaire numérique</p>
          </div>

          <div className="p-8 space-y-6">
            <div className="flex items-center gap-3 bg-slate-800/60 border border-slate-700 rounded-2xl px-4 py-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center text-white font-bold text-sm shrink-0">
                {(user.full_name || user.email || "?")[0].toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-white text-sm font-semibold truncate">{user.full_name || user.email}</p>
                <p className="text-slate-400 text-xs truncate">{user.email}</p>
              </div>
              <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
            </div>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs font-bold flex items-center justify-center">1</span>
                <h2 className="text-white font-bold text-lg">Vérification d'identité</h2>
              </div>
              <p className="text-slate-400 text-sm">Saisissez vos identifiants remis par l'administrateur.</p>
            </div>

            {error && (
              <div className="flex items-start gap-3 bg-red-500/10 border border-red-500/30 rounded-2xl px-4 py-3">
                <AlertCircle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
                <p className="text-red-300 text-sm">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                  <KeyRound className="h-3.5 w-3.5 text-slate-400" /> Code d'accès permanent
                </label>
                <input
                  value={accessId}
                  onChange={e => { setAccessId(e.target.value); setError(""); }}
                  placeholder="Ex: PROF-CIB-26KON-150492-03"
                  required autoComplete="off"
                  className="w-full bg-slate-800 border border-slate-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 text-sm font-mono outline-none transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                  <Lock className="h-3.5 w-3.5 text-slate-400" /> Mot de passe initial
                </label>
                <div className="relative">
                  <input
                    type={showPwd ? "text" : "password"}
                    value={password}
                    onChange={e => { setPassword(e.target.value); setError(""); }}
                    placeholder="••••••••••"
                    required autoComplete="off"
                    className="w-full bg-slate-800 border border-slate-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 pr-12 text-sm font-mono outline-none transition-all"
                  />
                  <button type="button" onClick={() => setShowPwd(p => !p)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1">
                    {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <button type="submit" disabled={loading || !accessId.trim() || !password.trim()}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 disabled:opacity-50 text-white font-bold rounded-xl py-3.5 transition-all shadow-lg shadow-blue-600/25">
                {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Vérification…</> : <><ArrowRight className="h-4 w-4" /> Continuer</>}
              </button>
            </form>

            <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-4 space-y-1.5 text-xs text-slate-500">
              <p className="font-semibold text-slate-400 uppercase tracking-wide text-[10px]">Comment ça marche ?</p>
              <p>① L'admin crée votre compte et vous remet un code + mot de passe initial.</p>
              <p>② Lors de votre première connexion, vous créerez votre propre code PIN secret.</p>
              <p>③ Ce PIN est connu de vous seul — même l'admin ne peut pas y accéder.</p>
            </div>

            <div className="text-center">
              <button onClick={() => { clearAccessVerified(); base44.auth.logout(); }}
                className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-1.5 mx-auto transition-colors">
                <LogOut className="h-3.5 w-3.5" /> Changer de compte Google
              </button>
            </div>
          </div>
        </div>
        <p className="text-center text-slate-600 text-xs mt-4">BOHAN — Gestion scolaire numérique · {new Date().getFullYear()}</p>
      </div>
    </div>
  );
}

// ── Étape 2 : Création du PIN (première connexion) ───────────────────────────
function StepCreatePin({ user, match, onPinCreated }) {
  const [pin, setPin] = useState("");
  const [pinConfirm, setPinConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (pin.length < 5 || pin.length > 6 || !/^\d+$/.test(pin)) {
      setError("Le code PIN doit contenir exactement 5 ou 6 chiffres.");
      return;
    }
    if (pin !== pinConfirm) {
      setError("Les deux codes ne correspondent pas.");
      return;
    }
    setLoading(true);
    const pinHash = await hashPin(pin);
    await base44.entities.AppAccess.update(match.id, { pin_hash: pinHash, pin_set: true, failed_attempts: 0, locked_until: null });
    // Stocker le nom officiel de l'AppAccess
    if (match.full_name) setDisplayName(match.full_name);
    setLoading(false);
    onPinCreated({ ...match, pin_hash: pinHash, pin_set: true });
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="relative w-full max-w-md">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
          <div className="px-8 pt-8 pb-6 text-center border-b border-slate-800">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center mx-auto mb-4 shadow-lg">
              <ShieldCheck className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-xl font-black text-white">Créez votre code PIN</h1>
            <p className="text-slate-400 text-xs mt-1">Première connexion — Ce PIN vous appartiendra uniquement</p>
          </div>

          <div className="p-8 space-y-6">
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 space-y-2">
              <p className="text-amber-300 text-sm font-bold flex items-center gap-2">
                <ShieldAlert className="h-4 w-4" /> Important — Lisez attentivement
              </p>
              <ul className="text-xs text-amber-200/70 space-y-1 list-disc list-inside">
                <li>Ce code PIN est <strong className="text-amber-200">personnel et secret</strong>.</li>
                <li>Il sera nécessaire à <strong className="text-amber-200">chaque connexion</strong>.</li>
                <li>Même l'administrateur <strong className="text-amber-200">ne peut pas le voir</strong>.</li>
                <li>En cas d'oubli, l'admin devra <strong className="text-amber-200">réinitialiser</strong> votre compte.</li>
              </ul>
            </div>

            {error && (
              <div className="flex items-start gap-3 bg-red-500/10 border border-red-500/30 rounded-2xl px-4 py-3">
                <AlertCircle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
                <p className="text-red-300 text-sm">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                  <Lock className="h-3.5 w-3.5 text-slate-400" /> Code PIN (5 ou 6 chiffres)
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  value={pin}
                  onChange={e => { setPin(e.target.value.replace(/\D/g, "")); setError(""); }}
                  placeholder="•••••"
                  required
                  className="w-full bg-slate-800 border border-slate-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 text-center text-2xl font-mono tracking-[0.5em] outline-none transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                  <Lock className="h-3.5 w-3.5 text-slate-400" /> Confirmez le code PIN
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  value={pinConfirm}
                  onChange={e => { setPinConfirm(e.target.value.replace(/\D/g, "")); setError(""); }}
                  placeholder="•••••"
                  required
                  className="w-full bg-slate-800 border border-slate-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 text-center text-2xl font-mono tracking-[0.5em] outline-none transition-all"
                />
              </div>

              <button type="submit" disabled={loading || pin.length < 5 || pinConfirm.length < 5}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:opacity-90 disabled:opacity-50 text-white font-bold rounded-xl py-3.5 transition-all shadow-lg">
                {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Enregistrement…</> : <><ShieldCheck className="h-4 w-4" /> Activer mon PIN</>}
              </button>
            </form>

            <div className="text-center">
              <button onClick={() => { clearAccessVerified(); base44.auth.logout(); }}
                className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-1.5 mx-auto transition-colors">
                <LogOut className="h-3.5 w-3.5" /> Annuler et se déconnecter
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Étape 3 : Saisie du PIN (connexions suivantes) ───────────────────────────
function StepEnterPin({ user, match, onVerified }) {
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [locked, setLocked] = useState(false);
  const [lockMins, setLockMins] = useState(0);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);

    // Vérifier verrouillage frais (re-fetch)
    const records = await base44.entities.AppAccess.filter({ access_id: match.access_id });
    const fresh = records[0] || match;
    if (fresh.locked_until) {
      const lockDate = new Date(fresh.locked_until);
      if (lockDate > new Date()) {
        const mins = Math.ceil((lockDate - new Date()) / 60000);
        setLocked(true);
        setLockMins(mins);
        setLoading(false);
        return;
      }
    }

    const ok = await verifyPin(pin, fresh.pin_hash);

    if (!ok) {
      const newAttempts = (fresh.failed_attempts || 0) + 1;
      const updateData = { failed_attempts: newAttempts };
      let errMsg = "";
      if (newAttempts >= MAX_ATTEMPTS) {
        const lockUntil = new Date(Date.now() + LOCK_MINUTES * 60 * 1000).toISOString();
        updateData.locked_until = lockUntil;
        errMsg = `Trop de tentatives. Compte verrouillé ${LOCK_MINUTES} minutes.`;
        setLocked(true);
        setLockMins(LOCK_MINUTES);
      } else {
        errMsg = `Code PIN incorrect. ${MAX_ATTEMPTS - newAttempts} tentative${MAX_ATTEMPTS - newAttempts > 1 ? "s" : ""} restante${MAX_ATTEMPTS - newAttempts > 1 ? "s" : ""}.`;
      }
      await base44.entities.AppAccess.update(fresh.id, updateData);
      setError(errMsg);
      setPin("");
      setLoading(false);
      return;
    }

    // Succès — réinitialiser compteur + activer + stocker école
    const updateData = { failed_attempts: 0, locked_until: null };
    if (!fresh.is_active) updateData.is_active = true;
    await base44.entities.AppAccess.update(fresh.id, updateData);

    if (fresh.school_id) {
      const { setSchool } = await import('../hooks/useSchool');
      let schoolName = fresh.school_name || "";
      if (!schoolName) {
        const schools = await base44.entities.School.filter({ id: fresh.school_id });
        if (schools[0]) schoolName = schools[0].name;
      }
      setSchool(fresh.school_id, schoolName);
    }

    sessionStorage.setItem(SESSION_KEY, "true");
    sessionStorage.setItem(ROLE_KEY, fresh.role || "user");
    // Stocker le nom officiel de l'AppAccess (pas le nom Google)
    if (fresh.full_name) setDisplayName(fresh.full_name);
    setLoading(false);
    onVerified();
  }

  if (locked) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-8 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mx-auto">
          <ShieldAlert className="h-8 w-8 text-red-400" />
        </div>
        <h2 className="text-white font-bold text-xl">Compte verrouillé</h2>
        <p className="text-slate-400 text-sm">Trop de tentatives incorrectes. Compte bloqué <strong className="text-white">{lockMins} minute{lockMins > 1 ? "s" : ""}</strong>.</p>
        <p className="text-xs text-slate-500">Contactez l'administrateur si vous ne vous souvenez plus de votre PIN.</p>
        <button onClick={() => { clearAccessVerified(); base44.auth.logout(); }}
          className="flex items-center gap-2 text-sm text-slate-400 hover:text-slate-200 mx-auto mt-4 transition-colors">
          <LogOut className="h-4 w-4" /> Se déconnecter
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-80 h-80 bg-emerald-600/8 rounded-full blur-3xl" />
      </div>
      <div className="relative w-full max-w-sm">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
          <div className="px-8 pt-8 pb-6 text-center border-b border-slate-800">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center mx-auto mb-4 shadow-lg">
              <ShieldCheck className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-xl font-black text-white">Code PIN</h1>
            <p className="text-slate-400 text-xs mt-1">2e niveau de sécurité</p>
          </div>

          <div className="p-8 space-y-6">
            <div className="flex items-center gap-3 bg-slate-800/60 border border-slate-700 rounded-2xl px-4 py-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center text-white font-bold text-sm shrink-0">
                {(user.full_name || user.email || "?")[0].toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-white text-sm font-semibold truncate">{user.full_name || user.email}</p>
                <p className="text-slate-400 text-xs">{ROLE_LABELS[match.role] || match.role}</p>
              </div>
              <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
            </div>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="w-6 h-6 rounded-full bg-emerald-500 text-white text-xs font-bold flex items-center justify-center">2</span>
                <h2 className="text-white font-bold text-lg">Entrez votre PIN</h2>
              </div>
              <p className="text-slate-400 text-sm">Votre code PIN personnel (5 ou 6 chiffres).</p>
            </div>

            {error && (
              <div className="flex items-start gap-3 bg-red-500/10 border border-red-500/30 rounded-2xl px-4 py-3">
                <AlertCircle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
                <p className="text-red-300 text-sm">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <input
                  type={showPin ? "text" : "password"}
                  inputMode="numeric"
                  maxLength={6}
                  value={pin}
                  onChange={e => { setPin(e.target.value.replace(/\D/g, "")); setError(""); }}
                  placeholder="•••••"
                  required autoFocus
                  className="w-full bg-slate-800 border border-slate-700 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-white placeholder:text-slate-500 rounded-xl px-4 py-4 pr-12 text-center text-3xl font-mono tracking-[0.6em] outline-none transition-all"
                />
                <button type="button" onClick={() => setShowPin(p => !p)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1">
                  {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>

              <button type="submit" disabled={loading || pin.length < 5}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:opacity-90 disabled:opacity-50 text-white font-bold rounded-xl py-3.5 transition-all shadow-lg shadow-emerald-600/20">
                {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Vérification…</> : <><ShieldCheck className="h-4 w-4" /> Accéder</>}
              </button>
            </form>

            <div className="text-center">
              <button onClick={() => { clearAccessVerified(); base44.auth.logout(); }}
                className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-1.5 mx-auto transition-colors">
                <LogOut className="h-3.5 w-3.5" /> Se déconnecter
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Orchestrateur principal ──────────────────────────────────────────────────
export default function AccessGate({ user, onVerified }) {
  const [step, setStep] = useState("credentials"); // credentials | create_pin | enter_pin | success
  const [matchedRecord, setMatchedRecord] = useState(null);
  const [checking, setChecking] = useState(true);
  const [emailBlocked, setEmailBlocked] = useState(false);

  useEffect(() => {
    async function checkAccess() {
      const email = user.email.toLowerCase();
      const [records, allSchools] = await Promise.all([
        base44.entities.AppAccess.filter({ user_email: email }),
        base44.entities.School.list(),
      ]);

      if (records.length > 0) { setChecking(false); return; }

      const emailDomain = "@" + email.split("@")[1];
      const isAuthorized = allSchools.some(school => {
        const hasRestrictions = (school.authorized_emails?.length > 0) || school.authorized_domain;
        if (!hasRestrictions) return true;
        if (school.authorized_emails?.map(e => e.toLowerCase()).includes(email)) return true;
        if (school.authorized_domain && emailDomain === school.authorized_domain.toLowerCase()) return true;
        if (school.admin_email?.toLowerCase() === email) return true;
        return false;
      });

      if (!isAuthorized) setEmailBlocked(true);
      setChecking(false);
    }
    checkAccess();
  }, [user.email]);

  async function handleSuccess() {
    setStep("success");
    setTimeout(() => onVerified(), 1400);
  }

  function handleMatch(record) {
    setMatchedRecord(record);
    // Si PIN jamais défini → créer PIN
    if (!record.pin_set || !record.pin_hash) {
      setStep("create_pin");
    } else {
      setStep("enter_pin");
    }
  }

  if (checking) return (
    <div className="fixed inset-0 flex flex-col items-center justify-center gap-3 bg-background">
    <img src="https://media.base44.com/images/public/69d451f34dcd67ebe250192e/239e74618_generated_image.png" alt="BOHAN" className="h-14 w-14 rounded-2xl object-contain bg-white shadow-lg" />
      <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      <p className="text-xs text-muted-foreground">Vérification en cours…</p>
    </div>
  );

  if (step === "success") return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm text-center space-y-4">
        <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/30">
          <CheckCircle2 className="h-10 w-10 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-white">Accès validé !</h2>
        <p className="text-slate-400 text-sm">Bienvenue, <span className="text-white font-semibold">{matchedRecord?.full_name || user.full_name || user.email}</span></p>
        {matchedRecord?.role && (
          <span className="inline-block bg-emerald-500/20 text-emerald-400 text-xs font-bold px-3 py-1 rounded-full border border-emerald-500/30">
            {ROLE_LABELS[matchedRecord.role] || matchedRecord.role}
          </span>
        )}
        <p className="text-slate-500 text-xs">Redirection vers votre espace…</p>
      </div>
    </div>
  );

  if (step === "credentials") return (
    <StepCredentials user={user} onMatch={handleMatch} emailBlocked={emailBlocked} />
  );

  if (step === "create_pin") return (
    <StepCreatePin user={user} match={matchedRecord} onPinCreated={(updated) => {
      setMatchedRecord(updated);
      setStep("success");
      setTimeout(() => onVerified(), 1400);
    }} />
  );

  if (step === "enter_pin") return (
    <StepEnterPin user={user} match={matchedRecord} onVerified={handleSuccess} />
  );

  return null;
}