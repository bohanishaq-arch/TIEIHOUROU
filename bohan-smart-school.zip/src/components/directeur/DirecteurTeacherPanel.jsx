import { UserCog, BookOpen, ClipboardList, Clock, ChevronRight, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";

export default function DirecteurTeacherPanel({ teachers, assignments, grades, reports }) {
  // Build enriched teacher list
  const enriched = teachers.map(email => {
    const myAssignments = assignments.filter(a => a.teacher_email === email);
    const subjects = [...new Set(myAssignments.map(a => a.subject_name).filter(Boolean))];
    const classes  = [...new Set(myAssignments.map(a => a.class_name).filter(Boolean))];
    const myGrades = grades.filter(g => g.teacher_email === email);
    const myReports = reports.filter(r => r.teacher_email === email);
    const pendingReports = myReports.filter(r => r.status === "envoyé" || r.status === "lu");
    const name = myAssignments[0]?.teacher_name || email;

    return { email, name, subjects, classes, gradeCount: myGrades.length, pendingReports: pendingReports.length };
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <UserCog size={16} className="text-amber-600" />
          <h3 className="text-sm font-bold text-slate-900">Tableau des enseignants</h3>
        </div>
        <Link to="/teachers" className="text-xs font-semibold text-blue-600 flex items-center gap-1 hover:underline">
          Voir tous <ChevronRight size={14} />
        </Link>
      </div>

      {enriched.length === 0 ? (
        <p className="text-sm text-slate-400 text-center py-6">Aucun enseignant assigné.</p>
      ) : (
        <div className="space-y-2">
          {enriched.slice(0, 8).map((t, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors">
              <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center shrink-0">
                <span className="text-sm font-bold text-amber-700">{t.name[0]?.toUpperCase() || "?"}</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 truncate">{t.name}</p>
                <p className="text-[11px] text-slate-400 truncate">
                  {t.subjects.slice(0, 3).join(", ") || "Aucune matière"}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {/* Notes saisies */}
                <span className="flex items-center gap-1 text-[10px] font-medium text-slate-500 bg-slate-200 px-2 py-0.5 rounded-full">
                  <ClipboardList size={10} />
                  {t.gradeCount} notes
                </span>
                {/* Rapports en attente */}
                {t.pendingReports > 0 ? (
                  <span className="flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                    <Clock size={10} />
                    {t.pendingReports} att.
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[10px] font-medium text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                    <CheckCircle size={10} />
                    À jour
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}