import { useState } from "react";
import { Sparkles, RefreshCw, AlertTriangle, TrendingDown, TrendingUp, Users } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function DirecteurAIInsights({ grades, students, classes, subjects }) {
  const [insights, setInsights] = useState([]);
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);

  async function generate() {
    setLoading(true);
    try {
      // Build a concise summary for the LLM
      const classAvgs = classes.map(cls => {
        const cg = grades.filter(g => g.class_id === cls.id);
        if (!cg.length) return null;
        const avg = cg.reduce((s, g) => s + g.score, 0) / cg.length;
        const successRate = Math.round((cg.filter(g => g.score >= 10).length / cg.length) * 100);
        return { name: cls.name, avg: avg.toFixed(1), successRate };
      }).filter(Boolean);

      const weakStudents = students.filter(s => {
        const sg = grades.filter(g => g.student_id === s.id);
        if (!sg.length) return false;
        return sg.reduce((a, g) => a + g.score, 0) / sg.length < 10;
      }).length;

      const subjectAvgs = subjects.slice(0, 10).map(sub => {
        const sg = grades.filter(g => g.subject_id === sub.id);
        if (!sg.length) return null;
        const avg = sg.reduce((s, g) => s + g.score, 0) / sg.length;
        return { name: sub.name, avg: avg.toFixed(1) };
      }).filter(Boolean).sort((a, b) => a.avg - b.avg);

      const prompt = `Tu es un conseiller pédagogique expert pour une école africaine (Côte d'Ivoire).
Voici les données académiques actuelles :
- ${students.length} élèves, ${classes.length} classes
- ${weakStudents} élèves en difficulté (moyenne < 10)
- Moyennes par classe : ${classAvgs.map(c => `${c.name}: ${c.avg}/20 (${c.successRate}% réussite)`).join(', ')}
- Matières les plus faibles : ${subjectAvgs.slice(0, 3).map(s => `${s.name}: ${s.avg}/20`).join(', ')}
- Matières les plus fortes : ${subjectAvgs.slice(-3).map(s => `${s.name}: ${s.avg}/20`).join(', ')}

Génère exactement 4 insights pédagogiques courts, précis et actionnables. Sois direct et concis (max 2 phrases chacun).
Chaque insight doit avoir: type (danger/warning/info/success), title (court, < 10 mots), description (analyse précise avec chiffres).`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            insights: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  title: { type: "string" },
                  description: { type: "string" },
                },
              },
            },
          },
        },
      });

      setInsights(result.insights || []);
      setGenerated(true);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  }

  const TYPE_CONFIG = {
    danger:  { icon: AlertTriangle, color: "#DC2626", bg: "#FEF2F2", border: "#FECACA" },
    warning: { icon: TrendingDown,  color: "#D97706", bg: "#FFFBEB", border: "#FDE68A" },
    info:    { icon: Users,         color: "#2563EB", bg: "#EFF6FF", border: "#BFDBFE" },
    success: { icon: TrendingUp,    color: "#059669", bg: "#ECFDF5", border: "#A7F3D0" },
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-blue-600 flex items-center justify-center">
            <Sparkles size={14} className="text-white" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">IA Pédagogique</h3>
            <p className="text-[10px] text-slate-400">Analyse intelligente des performances</p>
          </div>
        </div>
        <button
          onClick={generate}
          disabled={loading}
          className="flex items-center gap-1.5 text-xs font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100 px-3 py-1.5 rounded-xl transition-colors disabled:opacity-50"
        >
          <RefreshCw size={12} className={loading ? "animate-spin" : ""} />
          {generated ? "Actualiser" : "Analyser"}
        </button>
      </div>

      {!generated && !loading && (
        <div className="text-center py-8 text-slate-400">
          <Sparkles size={32} className="mx-auto mb-3 text-violet-300" />
          <p className="text-sm font-medium">Cliquez sur "Analyser" pour obtenir</p>
          <p className="text-xs mt-1">des recommandations pédagogiques intelligentes basées sur vos données</p>
        </div>
      )}

      {loading && (
        <div className="flex flex-col items-center py-8 gap-3 text-slate-400">
          <div className="w-8 h-8 border-2 border-violet-200 border-t-violet-500 rounded-full animate-spin" />
          <p className="text-sm">Analyse des performances en cours…</p>
        </div>
      )}

      {!loading && generated && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {insights.map((ins, i) => {
            const cfg = TYPE_CONFIG[ins.type] || TYPE_CONFIG.info;
            const Icon = cfg.icon;
            return (
              <div
                key={i}
                className="flex items-start gap-3 p-3.5 rounded-xl border"
                style={{ background: cfg.bg, borderColor: cfg.border }}
              >
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                  style={{ background: `${cfg.color}20` }}
                >
                  <Icon size={14} style={{ color: cfg.color }} />
                </div>
                <div>
                  <p className="text-xs font-bold" style={{ color: cfg.color }}>{ins.title}</p>
                  <p className="text-[11px] mt-0.5 leading-relaxed" style={{ color: `${cfg.color}bb` }}>
                    {ins.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}