import { Link } from "react-router-dom";
import {
  Users, School, BookOpen, UserCog, ClipboardList, FileText,
  Calendar, BarChart3, Send, ShieldCheck, CheckCircle2, ClipboardCheck
} from "lucide-react";

const ACTIONS = [
  { label: "Élèves",        icon: Users,          to: "/students",          color: "#2563EB", bg: "#EFF6FF" },
  { label: "Classes",       icon: School,         to: "/classes",           color: "#7C3AED", bg: "#F5F3FF" },
  { label: "Matières",      icon: BookOpen,       to: "/subjects",          color: "#0891B2", bg: "#ECFEFF" },
  { label: "Enseignants",   icon: UserCog,        to: "/teachers",          color: "#D97706", bg: "#FFFBEB" },
  { label: "Notes",         icon: ClipboardList,  to: "/grades",            color: "#DB2777", bg: "#FDF2F8" },
  { label: "Moyennes",      icon: ClipboardCheck, to: "/averages",          color: "#059669", bg: "#ECFDF5" },
  { label: "Bulletins",     icon: FileText,       to: "/reports",           color: "#6366F1", bg: "#EEF2FF" },
  { label: "Emploi du tps", icon: Calendar,       to: "/schedule",          color: "#0D9488", bg: "#F0FDFA" },
  { label: "Statistiques",  icon: BarChart3,      to: "/statistics",        color: "#9333EA", bg: "#FDF4FF" },
  { label: "Rapports",      icon: Send,           to: "/teacher-reports",   color: "#EA580C", bg: "#FFF7ED" },
  { label: "Demandes",      icon: CheckCircle2,   to: "/directeur-requests",color: "#7C3AED", bg: "#F5F3FF" },
  { label: "Identifiants",  icon: ShieldCheck,    to: "/manage-access",     color: "#475569", bg: "#F8FAFC" },
];

export default function DirecteurQuickNav() {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
      <h3 className="text-sm font-bold text-slate-900 mb-4">Navigation rapide</h3>
      <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        {ACTIONS.map(({ label, icon: Icon, to, color, bg }) => (
          <Link
            key={to}
            to={to}
            className="flex flex-col items-center gap-2 p-3 rounded-2xl hover:scale-105 active:scale-95 transition-transform"
            style={{ background: bg }}
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: `${color}18` }}
            >
              <Icon size={18} style={{ color }} />
            </div>
            <span className="text-[10px] font-semibold text-center leading-tight" style={{ color }}>
              {label}
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}