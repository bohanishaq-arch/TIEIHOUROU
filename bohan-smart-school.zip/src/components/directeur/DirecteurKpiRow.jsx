import { Users, School, UserCog, TrendingUp, UserX, AlertTriangle, ShieldAlert, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const CARDS = [
  { key: "students",    label: "Élèves inscrits",     icon: Users,        color: "#2563EB", bg: "#EFF6FF", to: "/students" },
  { key: "classes",     label: "Classes actives",     icon: School,       color: "#7C3AED", bg: "#F5F3FF", to: "/classes" },
  { key: "teachers",    label: "Enseignants",          icon: UserCog,      color: "#D97706", bg: "#FFFBEB", to: "/teachers" },
  { key: "avgGeneral",  label: "Moyenne générale",    icon: TrendingUp,   color: "#059669", bg: "#ECFDF5", to: "/averages", suffix: "/20" },
  { key: "successRate", label: "Taux de réussite",    icon: TrendingUp,   color: "#0891B2", bg: "#ECFEFF", to: "/statistics", suffix: "%" },
  { key: "absences",    label: "Absences globales",   icon: UserX,        color: "#DC2626", bg: "#FEF2F2", to: "/students" },
  { key: "incidents",   label: "Incidents signalés",  icon: ShieldAlert,  color: "#B45309", bg: "#FEF3C7", to: "/students" },
  { key: "pendingNotes",label: "Notes en attente",    icon: Clock,        color: "#7C3AED", bg: "#F5F3FF", to: "/grades" },
];

export default function DirecteurKpiRow({ stats }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
      {CARDS.map((card, i) => {
        const Icon = card.icon;
        const raw = stats?.[card.key] ?? 0;
        const val = typeof raw === "number" ? (Number.isInteger(raw) ? raw : raw.toFixed(1)) : raw;

        return (
          <motion.div
            key={card.key}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05, duration: 0.3 }}
          >
            <Link
              to={card.to}
              className="flex flex-col gap-2 p-3 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 active:scale-[0.97] block"
            >
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center"
                style={{ background: card.bg }}
              >
                <Icon size={16} style={{ color: card.color }} />
              </div>
              <p className="text-lg font-bold text-slate-900 leading-none">
                {val}{card.suffix || ""}
              </p>
              <p className="text-[10px] font-semibold text-slate-400 leading-tight uppercase tracking-wide">
                {card.label}
              </p>
            </Link>
          </motion.div>
        );
      })}
    </div>
  );
}