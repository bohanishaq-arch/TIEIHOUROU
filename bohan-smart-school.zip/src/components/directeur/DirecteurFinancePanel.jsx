import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { DollarSign, AlertTriangle, CheckCircle, TrendingUp, Users, Eye } from "lucide-react";
import { motion } from "framer-motion";
import PaymentTracker from "@/components/accountant/PaymentTracker";
import FinancialChart from "@/components/accountant/FinancialChart";

export default function DirecteurFinancePanel({ schoolId }) {
  const [enrollments, setEnrollments] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeView, setActiveView] = useState(null); // "payments" | "chart"

  useEffect(() => {
    if (!schoolId) { setLoading(false); return; }
    const f = { school_id: schoolId };
    Promise.all([
      base44.entities.Enrollment.filter(f, "-enrollment_date", 200),
      base44.entities.Payment.filter(f, "-payment_date", 500),
    ]).then(([enrs, pays]) => {
      setEnrollments(enrs);
      setPayments(pays);
      setLoading(false);
    });
  }, [schoolId]);

  if (loading) return null;

  const totalCollected = payments.reduce((s, p) => s + (p.amount || 0), 0);
  const fullPaid = enrollments.filter(e => e.payment_status === "complet").length;
  const partial = enrollments.filter(e => e.payment_status === "partiel").length;
  const pending = enrollments.filter(e => e.payment_status === "en_attente").length;
  const total = enrollments.length;
  const paidPct = total > 0 ? Math.round((fullPaid / total) * 100) : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="bg-white border border-border rounded-2xl p-5 shadow-sm"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-100 flex items-center justify-center">
            <DollarSign className="h-4 w-4 text-emerald-700" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-foreground">Supervision financière</h3>
            <p className="text-xs text-muted-foreground">Vue lecture seule — données comptabilité</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setActiveView("payments")}
            className="text-xs font-semibold text-primary border border-primary/30 bg-primary/5 hover:bg-primary/10 px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors"
          >
            <Eye className="h-3 w-3" /> Détails paiements
          </button>
          <button
            onClick={() => setActiveView("chart")}
            className="text-xs font-semibold text-emerald-700 border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors"
          >
            <TrendingUp className="h-3 w-3" /> Rapport
          </button>
        </div>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3">
          <p className="text-xs text-emerald-600 font-semibold">Encaissé total</p>
          <p className="text-lg font-bold text-emerald-800">{totalCollected.toLocaleString("fr-FR")}</p>
          <p className="text-[10px] text-emerald-600">XOF</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
          <p className="text-xs text-blue-600 font-semibold">Inscriptions</p>
          <p className="text-lg font-bold text-blue-800">{total}</p>
          <p className="text-[10px] text-blue-600">élèves</p>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
          <p className="text-xs text-amber-600 font-semibold">Impayés / Partiels</p>
          <p className="text-lg font-bold text-amber-800">{pending + partial}</p>
          <p className="text-[10px] text-amber-600">élèves</p>
        </div>
        <div className={`${paidPct >= 70 ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200"} border rounded-xl p-3`}>
          <p className={`text-xs font-semibold ${paidPct >= 70 ? "text-emerald-600" : "text-red-600"}`}>Taux recouvrement</p>
          <p className={`text-lg font-bold ${paidPct >= 70 ? "text-emerald-800" : "text-red-800"}`}>{paidPct}%</p>
          <p className={`text-[10px] ${paidPct >= 70 ? "text-emerald-600" : "text-red-600"}`}>{fullPaid} payés complet</p>
        </div>
      </div>

      {/* Progress bar */}
      <div className="space-y-1">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Payés complets</span>
          <span>{fullPaid} / {total}</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div className="h-full flex">
            <div className="bg-emerald-500 transition-all" style={{ width: `${total > 0 ? (fullPaid/total)*100 : 0}%` }} />
            <div className="bg-amber-400 transition-all" style={{ width: `${total > 0 ? (partial/total)*100 : 0}%` }} />
            <div className="bg-red-400 transition-all" style={{ width: `${total > 0 ? (pending/total)*100 : 0}%` }} />
          </div>
        </div>
        <div className="flex items-center gap-4 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" /> Complets</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-400 inline-block" /> Partiels</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-400 inline-block" /> En attente</span>
        </div>
      </div>

      {/* Modal viewer */}
      {activeView && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={() => setActiveView(null)}>
          <div className="bg-background w-full max-w-3xl rounded-2xl shadow-2xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-card shrink-0">
              <h2 className="text-base font-bold flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-emerald-600" />
                {activeView === "payments" ? "Suivi des paiements" : "Rapport financier"}
                <span className="text-xs font-normal text-muted-foreground bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">Lecture seule</span>
              </h2>
              <button onClick={() => setActiveView(null)} className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center">
                ✕
              </button>
            </div>
            <div className="overflow-y-auto flex-1 p-4 sm:p-6">
              {activeView === "payments" && <PaymentTracker schoolId={schoolId} readOnly />}
              {activeView === "chart" && <FinancialChart payments={payments} enrollments={enrollments} />}
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}