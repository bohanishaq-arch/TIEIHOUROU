import { ClipboardCheck, CheckCircle, Clock, ChevronRight, Send } from "lucide-react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useState } from "react";

export default function DirecteurReportsPanel({ reports }) {
  const [approving, setApproving] = useState(null);

  async function approve(id) {
    setApproving(id);
    await base44.entities.TeacherReport.update(id, { status: "approuvé" });
    setApproving(null);
  }

  const pending = reports.filter(r => r.status === "envoyé" || r.status === "lu");
  const recent  = reports.slice(0, 6);

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <ClipboardCheck size={16} className="text-indigo-500" />
          <h3 className="text-sm font-bold text-slate-900">Rapports des professeurs</h3>
          {pending.length > 0 && (
            <span className="text-[10px] font-bold bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">
              {pending.length} en attente
            </span>
          )}
        </div>
        <Link to="/teacher-reports" className="text-xs font-semibold text-blue-600 flex items-center gap-1 hover:underline">
          Tous <ChevronRight size={14} />
        </Link>
      </div>

      {recent.length === 0 ? (
        <p className="text-sm text-slate-400 text-center py-6">Aucun rapport reçu.</p>
      ) : (
        <div className="space-y-2">
          {recent.map(r => {
            const isPending = r.status === "envoyé" || r.status === "lu";
            const typeEmoji = r.report_type === "cours" ? "📖" : r.report_type === "devoir" ? "📝" : "🧪";
            return (
              <div key={r.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors">
                <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0 text-base">
                  {typeEmoji}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800 truncate">{r.title}</p>
                  <p className="text-[11px] text-slate-400 truncate">{r.teacher_name} · {r.class_name} · {r.subject_name}</p>
                </div>
                {isPending ? (
                  <button
                    onClick={() => approve(r.id)}
                    disabled={approving === r.id}
                    className="shrink-0 flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100 hover:bg-emerald-200 px-2.5 py-1 rounded-full transition-colors disabled:opacity-50"
                  >
                    <CheckCircle size={11} />
                    {approving === r.id ? "…" : "Valider"}
                  </button>
                ) : (
                  <span className="shrink-0 flex items-center gap-1 text-[10px] font-medium text-slate-400 bg-slate-200 px-2 py-0.5 rounded-full">
                    <CheckCircle size={10} className="text-emerald-500" />
                    Validé
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}