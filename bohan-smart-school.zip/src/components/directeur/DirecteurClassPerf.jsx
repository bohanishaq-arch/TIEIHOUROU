import { School, TrendingUp, TrendingDown, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

function getColor(avg) {
  if (avg >= 14) return { bar: "#10B981", text: "#065F46", bg: "#D1FAE5" };
  if (avg >= 10) return { bar: "#F59E0B", text: "#92400E", bg: "#FEF3C7" };
  return { bar: "#EF4444", text: "#991B1B", bg: "#FEE2E2" };
}

export default function DirecteurClassPerf({ classes, grades, subjects }) {
  const classData = classes.map(cls => {
    const cGrades = grades.filter(g => g.class_id === cls.id);
    if (!cGrades.length) return { ...cls, avg: null, count: 0, successRate: 0 };

    // Weighted average
    let totalW = 0, totalScore = 0;
    cGrades.forEach(g => {
      const sub = subjects.find(s => s.id === g.subject_id);
      const coef = sub?.coefficient || 1;
      totalScore += g.score * coef;
      totalW += coef;
    });
    const avg = totalW ? totalScore / totalW : 0;
    const successRate = Math.round((cGrades.filter(g => g.score >= 10).length / cGrades.length) * 100);

    return { ...cls, avg, count: cGrades.length, successRate };
  })
  .filter(c => c.avg !== null)
  .sort((a, b) => b.avg - a.avg);

  if (!classData.length) return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
      <p className="text-sm text-slate-400 text-center py-6">Aucune donnée de performance disponible.</p>
    </div>
  );

  const maxAvg = Math.max(...classData.map(c => c.avg));

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <School size={16} className="text-violet-600" />
          <h3 className="text-sm font-bold text-slate-900">Performance par classe</h3>
        </div>
        <Link to="/averages" className="text-xs font-semibold text-blue-600 flex items-center gap-1 hover:underline">
          Détails <ChevronRight size={14} />
        </Link>
      </div>

      <div className="space-y-3">
        {classData.map((cls, i) => {
          const c = getColor(cls.avg);
          const pct = (cls.avg / maxAvg) * 100;
          const isUp = i < Math.ceil(classData.length / 2);

          return (
            <div key={cls.id} className="space-y-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isUp
                    ? <TrendingUp size={13} className="text-emerald-500" />
                    : <TrendingDown size={13} className="text-red-400" />
                  }
                  <span className="text-sm font-semibold text-slate-700">{cls.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-medium text-slate-400">{cls.successRate}% réussite</span>
                  <span
                    className="text-xs font-bold px-2 py-0.5 rounded-full"
                    style={{ color: c.text, background: c.bg }}
                  >
                    {cls.avg.toFixed(1)}/20
                  </span>
                </div>
              </div>
              <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${pct}%`, background: c.bar }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}