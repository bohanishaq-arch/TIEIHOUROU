import { AlertTriangle, TrendingDown, Clock, BookOpen, ChevronRight, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

export default function DirecteurAlerts({ alerts }) {
  if (!alerts || alerts.length === 0) return null;

  const ICONS = {
    danger:  { icon: AlertTriangle, color: "#DC2626", bg: "#FEF2F2", border: "#FECACA" },
    warning: { icon: TrendingDown,  color: "#D97706", bg: "#FFFBEB", border: "#FDE68A" },
    info:    { icon: Clock,         color: "#2563EB", bg: "#EFF6FF", border: "#BFDBFE" },
    success: { icon: CheckCircle2,  color: "#059669", bg: "#ECFDF5", border: "#A7F3D0" },
  };

  return (
    <div className="space-y-2">
      <p className="text-[11px] font-bold uppercase tracking-widest text-slate-400 px-1">Alertes intelligentes</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {alerts.map((alert, i) => {
          const cfg = ICONS[alert.type] || ICONS.info;
          const Icon = cfg.icon;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.06 }}
              className="flex items-start gap-3 p-4 rounded-2xl border"
              style={{ background: cfg.bg, borderColor: cfg.border }}
            >
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5"
                style={{ background: `${cfg.color}18` }}
              >
                <Icon size={16} style={{ color: cfg.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold leading-tight" style={{ color: cfg.color }}>
                  {alert.title}
                </p>
                <p className="text-xs mt-0.5 leading-relaxed" style={{ color: `${cfg.color}cc` }}>
                  {alert.description}
                </p>
              </div>
              {alert.to && (
                <Link to={alert.to} className="shrink-0 mt-0.5">
                  <ChevronRight size={16} style={{ color: cfg.color }} />
                </Link>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}