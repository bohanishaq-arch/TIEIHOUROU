import { Outlet, useLocation, useNavigate, Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/lib/AuthContext";
import { getVerifiedRole, clearAccessVerified } from "./AccessGate";
import { getSchoolId, getSchoolName } from "../hooks/useSchool";
import { getDisplayName } from "../hooks/useDisplayName";
import SchoolSelector from "./SchoolSelector";
import HelpGuide from "./HelpGuide";
import ProfileSettings from "./ProfileSettings";
import MobileBottomNav from "./MobileBottomNav";
import PullToRefresh from "./PullToRefresh";
import { useDarkMode } from "../hooks/useDarkMode";
import { base44 } from "@/api/base44Client";
import {
  LayoutDashboard, Users, School, BookOpen, ClipboardList, FileText,
  BarChart3, GraduationCap, TrendingUp, UserCog, Settings, ShieldAlert,
  ShieldCheck, UserPlus, Send, Shield, Calendar, DollarSign, Building2,
  LogOut, Menu, X, Bell, ArrowLeft, HelpCircle,
} from "lucide-react";

const pageVariants = {
  initial: { opacity: 0, y: 12 },
  in:      { opacity: 1, y: 0 },
  out:     { opacity: 0, y: -6 },
};
const pageTransition = { type: "spring", stiffness: 300, damping: 28 };

const ADMIN_NAV = [
  { group: "Principal", items: [
    { label: "Tableau de bord", icon: LayoutDashboard, path: "/" },
    { label: "Documentation", icon: BookOpen, path: "/documentation" },
    { label: "Financements BOHAN", icon: DollarSign, path: "/bohan-finances" },
  ]},
  { group: "Élèves & Classes", items: [
    { label: "Élèves", icon: Users, path: "/students" },
    { label: "Classes", icon: School, path: "/classes" },
    { label: "Matières", icon: BookOpen, path: "/subjects" },
    { label: "Professeurs", icon: UserCog, path: "/teachers" },
  ]},
  { group: "Enseignement", items: [
    { label: "Notes", icon: ClipboardList, path: "/grades" },
    { label: "Moyennes", icon: TrendingUp, path: "/averages" },
    { label: "Bulletins", icon: FileText, path: "/reports" },
    { label: "Emploi du temps", icon: Calendar, path: "/schedule" },
  ]},
  { group: "Rapports", items: [
    { label: "Statistiques", icon: BarChart3, path: "/statistics" },
    { label: "Rapports Profs", icon: Send, path: "/teacher-reports" },
  ]},
  { group: "Administration", items: [
    { label: "Accès & Invitations", icon: ShieldAlert, path: "/access-requests" },
    { label: "Identifiants d'accès", icon: ShieldCheck, path: "/manage-access" },
    { label: "Inscription", icon: UserPlus, path: "/inscription" },
    { label: "Demandes", icon: BookOpen, path: "/subject-requests" },
    { label: "Proviseurs", icon: Building2, path: "/directeur-requests" },
    { label: "Configuration", icon: Settings, path: "/config" },
  ]},
];

const TEACHER_NAV = [
  { group: "Espace Enseignant", items: [
    { label: "Tableau de bord", icon: LayoutDashboard, path: "/teacher" },
    { label: "Emploi du temps", icon: Calendar, path: "/schedule" },
    { label: "Notes", icon: ClipboardList, path: "/grades" },
    { label: "Bulletins", icon: FileText, path: "/reports" },
  ]},
];

const STUDENT_NAV = [
  { group: "Mon portail", items: [
    { label: "Ma carte", icon: GraduationCap, path: "/portal?tab=card" },
    { label: "Emploi du temps", icon: Calendar, path: "/portal?tab=schedule" },
    { label: "Examens", icon: ClipboardList, path: "/portal?tab=exams" },
    { label: "Mes notes", icon: BookOpen, path: "/portal?tab=grades" },
    { label: "Moyennes", icon: TrendingUp, path: "/portal?tab=averages" },
    { label: "Bulletins", icon: FileText, path: "/portal?tab=bulletin" },
  ]},
];

const DIRECTEUR_NAV = [
  { group: "Principal", items: [
    { label: "Tableau de bord", icon: LayoutDashboard, path: "/directeur" },
  ]},
  { group: "Gestion", items: [
    { label: "Élèves", icon: Users, path: "/students" },
    { label: "Classes", icon: School, path: "/classes" },
    { label: "Matières", icon: BookOpen, path: "/subjects" },
    { label: "Professeurs", icon: UserCog, path: "/teachers" },
    { label: "Notes", icon: ClipboardList, path: "/grades" },
    { label: "Moyennes", icon: TrendingUp, path: "/averages" },
    { label: "Bulletins", icon: FileText, path: "/reports" },
    { label: "Emploi du temps", icon: Calendar, path: "/schedule" },
  ]},
  { group: "Rapports", items: [
    { label: "Statistiques", icon: BarChart3, path: "/statistics" },
    { label: "Rapports Profs", icon: Send, path: "/teacher-reports" },
    { label: "Éducateurs", icon: Shield, path: "/directeur-requests" },
    { label: "Identifiants", icon: ShieldCheck, path: "/manage-access" },
  ]},
];

const EDUCATOR_NAV = [
  { group: "Mon espace", items: [
    { label: "Tableau de bord", icon: Shield, path: "/educateur" },
  ]},
];

const ACCOUNTANT_NAV = [
  { group: "Comptabilité", items: [
    { label: "Comptabilité", icon: DollarSign, path: "/comptable" },
  ]},
];

const IT_MANAGER_NAV = [
  { group: "Gestion des accès", items: [
    { label: "Identifiants d'accès", icon: ShieldCheck, path: "/manage-access" },
    { label: "Inscription élèves", icon: UserPlus, path: "/inscription" },
    { label: "Classes", icon: School, path: "/classes" },
    { label: "Matières", icon: BookOpen, path: "/subjects" },
    { label: "Professeurs", icon: UserCog, path: "/teachers" },
  ]},
];

const SUPER_ADMIN_NAV = [
  { group: "Super Admin", items: [
    { label: "Super Admin", icon: Building2, path: "/super-admin" },
  ]},
];

const ROLE_LABEL = {
  admin: "Administrateur", teacher: "Professeur", student: "Élève",
  user: "Direction", educator: "Éducateur", accountant: "Comptable", it_manager: "Informaticien"
};

function NavItem({ item, onClose, location }) {
  const isActive = item.path.includes("?")
    ? location.pathname + location.search === item.path
    : location.pathname === item.path && !location.search;

  return (
    <Link
      to={item.path}
      onClick={onClose}
      className={`relative flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200 group ${
        isActive
          ? "bg-sidebar-primary text-white shadow-md shadow-black/20"
          : "text-sidebar-foreground/65 hover:bg-white/10 hover:text-white"
      }`}
    >
      {isActive && (
        <motion.div
          layoutId="activeNav"
          className="absolute inset-0 bg-sidebar-primary rounded-xl"
          style={{ zIndex: -1 }}
          transition={{ type: "spring", stiffness: 380, damping: 32 }}
        />
      )}
      <item.icon className={`h-4 w-4 shrink-0 transition-transform duration-200 ${isActive ? "scale-110" : "group-hover:scale-110"}`} />
      <span>{item.label}</span>
    </Link>
  );
}

function Sidebar({ onClose }) {
  const location = useLocation();
  const { user } = useAuth();
  const effectiveRole = user?.role === 'admin' ? 'admin' : (getVerifiedRole() || user?.role);
  const isStudent = effectiveRole === "student";
  const isTeacher = effectiveRole === "teacher";
  const isEducator = effectiveRole === "educator";
  const isSuperAdmin = user?.role === "admin";
  const isDirecteur = effectiveRole === 'user';
  const isAccountant = effectiveRole === 'accountant';
  const isITManager = effectiveRole === 'it_manager';
  const hasSchool = !!getSchoolId();

  let navGroups;
  if (isStudent) navGroups = STUDENT_NAV;
  else if (isTeacher) navGroups = TEACHER_NAV;
  else if (isEducator) navGroups = EDUCATOR_NAV;
  else if (isAccountant) navGroups = ACCOUNTANT_NAV;
  else if (isITManager) navGroups = IT_MANAGER_NAV;
  else if (isDirecteur) navGroups = DIRECTEUR_NAV;
  else if (isSuperAdmin) navGroups = hasSchool ? [...SUPER_ADMIN_NAV, ...ADMIN_NAV] : SUPER_ADMIN_NAV;
  else navGroups = ADMIN_NAV;

  return (
    <div className="h-full flex flex-col bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className="flex items-center justify-between h-16 px-5 border-b border-sidebar-border"
        style={{ background: 'linear-gradient(135deg, hsl(222,60%,10%) 0%, hsl(222,55%,18%) 100%)' }}>
        <div className="flex items-center gap-2.5">
          <motion.div
            animate={{ y: [0, -3, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
            <img src="https://media.base44.com/images/public/69d451f34dcd67ebe250192e/239e74618_generated_image.png" alt="BOHAN" className="h-10 w-10 rounded-xl object-contain bg-white p-0.5 shadow-lg" />
          </motion.div>
          <div>
            <h1 className="font-display text-lg font-extrabold text-white tracking-widest" style={{ letterSpacing: '0.15em' }}>BOHAN</h1>
            <p className="text-[9px] uppercase tracking-widest text-white/40">Gestion scolaire numérique</p>
          </div>
        </div>
        <button onClick={onClose} className="lg:hidden p-1 rounded hover:bg-sidebar-accent">
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* School selector */}
      <div className="pt-3">
        <SchoolSelector />
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-3 overflow-y-auto space-y-4">
        {navGroups.map((group, gi) => (
          <div key={gi}>
            <p className="text-[10px] font-bold uppercase tracking-widest text-sidebar-foreground/30 px-3 mb-1.5">{group.group}</p>
            <div className="space-y-0.5">
              {group.items.map((item, i) => (
                <motion.div
                  key={item.path}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 + gi * 0.05, duration: 0.18 }}
                >
                  <NavItem item={item} onClose={onClose} location={location} />
                </motion.div>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer user */}
      <div className="px-3 py-4 border-t border-sidebar-border space-y-1">
        {user && (
          <div className="flex items-center gap-3 px-3 py-2 mb-2 rounded-xl bg-white/5">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
              {(getDisplayName(user.full_name) || user.email || "?")[0].toUpperCase()}
            </div>
            <div className="overflow-hidden flex-1">
              <p className="text-xs font-semibold text-white truncate">{getDisplayName(user.full_name) || user.email}</p>
              <p className="text-[10px] text-sidebar-foreground/50">{ROLE_LABEL[effectiveRole] || effectiveRole}</p>
            </div>
          </div>
        )}
        <button
          onClick={() => { clearAccessVerified(); base44.auth.logout(); }}
          className="flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium text-sidebar-foreground/50 hover:bg-white/10 hover:text-white w-full transition-all duration-200"
        >
          <LogOut className="h-4 w-4" />
          Déconnexion
        </button>
      </div>
    </div>
  );
}

const ADMIN_QUICK_TABS = [
  { label: "Tableau de bord", icon: LayoutDashboard, path: "/" },
  { label: "Élèves", icon: Users, path: "/students" },
  { label: "Classes", icon: School, path: "/classes" },
  { label: "Notes", icon: ClipboardList, path: "/grades" },
  { label: "Bulletins", icon: FileText, path: "/reports" },
];
const TEACHER_QUICK_TABS = [
  { label: "Mon espace", icon: UserCog, path: "/teacher" },
  { label: "Notes", icon: ClipboardList, path: "/grades" },
  { label: "Bulletins", icon: FileText, path: "/reports" },
];
const DIRECTEUR_QUICK_TABS = [
  { label: "Tableau de bord", icon: LayoutDashboard, path: "/directeur" },
  { label: "Élèves", icon: Users, path: "/students" },
  { label: "Notes", icon: ClipboardList, path: "/grades" },
  { label: "Bulletins", icon: FileText, path: "/reports" },
];

const ROOT_PATHS = ["/", "/teacher", "/portal", "/directeur", "/educateur", "/comptable", "/super-admin"];

function TopBar({ onMenuOpen }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [profileOpen, setProfileOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const effectiveRole = user?.role === 'admin' ? 'admin' : (getVerifiedRole() || user?.role);
  const dropdownRef = useRef(null);

  const showBack = !ROOT_PATHS.includes(location.pathname);

  useEffect(() => {
    function handleClick(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setProfileOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  let quickTabs = [];
  if (effectiveRole === 'admin') quickTabs = ADMIN_QUICK_TABS;
  else if (effectiveRole === 'teacher') quickTabs = TEACHER_QUICK_TABS;
  else if (effectiveRole === 'user') quickTabs = DIRECTEUR_QUICK_TABS;

  return (
    <>
      <header className="h-14 bg-card border-b border-border flex items-center px-4 gap-2 shrink-0 z-30">
        {/* Mobile: back button OR menu button */}
        {showBack ? (
          <button onClick={() => navigate(-1)} className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors">
            <ArrowLeft className="h-5 w-5 text-muted-foreground" />
          </button>
        ) : (
          <button onClick={onMenuOpen} className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors">
            <Menu className="h-5 w-5 text-muted-foreground" />
          </button>
        )}

        {/* Mobile logo */}
        <Link to="/" className="lg:hidden flex items-center gap-2">
          <img src="https://media.base44.com/images/public/69d451f34dcd67ebe250192e/239e74618_generated_image.png" alt="BOHAN" className="h-7 w-7 rounded-lg object-contain bg-white shadow-sm" />
          <span className="font-display text-base font-bold text-primary">BOHAN</span>
        </Link>



        {/* Quick tabs - desktop */}
        {quickTabs.length > 0 && (
          <nav className="hidden lg:flex items-center gap-1">
            {quickTabs.map((tab) => {
              const isActive = location.pathname === tab.path && !location.search;
              return (
                <Link
                  key={tab.path}
                  to={tab.path}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                >
                  <tab.icon className="h-3.5 w-3.5" />
                  {tab.label}
                </Link>
              );
            })}
          </nav>
        )}

        <div className="flex-1" />

        {/* Right actions */}
        <div className="flex items-center gap-1.5">
          {/* Settings */}
          <button onClick={() => setShowSettings(true)} className="p-2 rounded-xl hover:bg-muted transition-colors" title="Paramètres du compte">
            <Settings className="h-4 w-4 text-muted-foreground" style={{ width: 16, height: 16 }} />
          </button>

          {/* Notifications */}
          <button onClick={() => setShowHelp(true)} className="relative p-2 rounded-xl hover:bg-muted transition-colors" title="Guide d'utilisation">
            <Bell className="h-4 w-4 text-muted-foreground" style={{ width: 16, height: 16 }} />
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-red-500 rounded-full" />
          </button>

          {/* Profile avatar */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setProfileOpen(!profileOpen)}
              className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center text-white text-xs font-bold hover:ring-2 hover:ring-primary/30 transition-all"
            >
              {(getDisplayName(user?.full_name) || user?.email || "?")[0].toUpperCase()}
            </button>

            <AnimatePresence>
              {profileOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -8, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -8, scale: 0.96 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 top-full mt-2 w-52 bg-popover border border-border rounded-2xl shadow-xl z-50 overflow-hidden"
                >
                  <div className="px-4 py-3 border-b border-border bg-muted/30">
                    <p className="text-sm font-semibold text-foreground truncate">{getDisplayName(user?.full_name) || user?.email}</p>
                    <p className="text-xs text-muted-foreground">{ROLE_LABEL[effectiveRole] || effectiveRole}</p>
                  </div>
                  <div className="p-1.5 space-y-0.5">
                    <button
                      onClick={() => { setProfileOpen(false); setShowSettings(true); }}
                      className="flex items-center gap-2.5 w-full px-3 py-2 text-sm rounded-lg hover:bg-muted transition-colors text-left"
                    >
                      <Settings className="h-4 w-4 text-muted-foreground" />
                      Paramètres du compte
                    </button>
                    <button
                      onClick={() => { setProfileOpen(false); setShowHelp(true); }}
                      className="flex items-center gap-2.5 w-full px-3 py-2 text-sm rounded-lg hover:bg-muted transition-colors text-left"
                    >
                      <HelpCircle className="h-4 w-4 text-muted-foreground" />
                      Guide d'utilisation
                    </button>
                    <button
                      onClick={() => { setProfileOpen(false); clearAccessVerified(); base44.auth.logout(); }}
                      className="flex items-center gap-2.5 w-full px-3 py-2 text-sm rounded-lg hover:bg-red-50 hover:text-red-600 transition-colors text-left text-muted-foreground"
                    >
                      <LogOut className="h-4 w-4" />
                      Déconnexion
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </header>

      {showSettings && <ProfileSettings onClose={() => setShowSettings(false)} />}
      <HelpGuide role={effectiveRole} open={showHelp} onClose={() => setShowHelp(false)} />
    </>
  );
}

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showProfileSettings, setShowProfileSettings] = useState(false);
  const location = useLocation();
  const verifiedRole = getVerifiedRole();

  // Auto dark mode sync with OS preference
  useDarkMode();

  const handleRefresh = async () => {
    window.location.reload();
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background" style={{ paddingTop: "env(safe-area-inset-top)" }}>
      {/* Mobile overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-64 transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
        style={{ paddingTop: "env(safe-area-inset-top)" }}
      >
        <Sidebar onClose={() => setSidebarOpen(false)} />
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        <TopBar onMenuOpen={() => setSidebarOpen(true)} />

        <PullToRefresh onRefresh={handleRefresh}>
          <main className="bg-background overflow-x-hidden" style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 4.5rem)" }}>
            <div className="p-3 sm:p-4 md:p-6 lg:p-8 max-w-[1600px] mx-auto lg:pb-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={location.pathname}
                  initial="initial"
                  animate="in"
                  exit="out"
                  variants={pageVariants}
                  transition={pageTransition}
                >
                  <Outlet />
                </motion.div>
              </AnimatePresence>
            </div>
          </main>
        </PullToRefresh>


      </div>

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav onProfileClick={() => setShowProfileSettings(true)} />

      {/* Profile settings triggered from mobile nav */}
      {showProfileSettings && <ProfileSettings onClose={() => setShowProfileSettings(false)} />}
    </div>
  );
}