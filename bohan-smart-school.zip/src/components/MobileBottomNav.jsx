import { useLocation, useNavigate } from "react-router-dom";
import { LayoutDashboard, ClipboardList, UserCircle, FileText, Users, Calendar, DollarSign, Shield } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { getVerifiedRole } from "./AccessGate";

const NAV_ITEMS_ADMIN = [
  { label: "Accueil", icon: LayoutDashboard, path: "/" },
  { label: "Élèves", icon: Users, path: "/students" },
  { label: "Notes", icon: ClipboardList, path: "/grades" },
  { label: "Bulletins", icon: FileText, path: "/reports" },
  { label: "Profil", icon: UserCircle, path: null, isProfile: true },
];

const NAV_ITEMS_TEACHER = [
  { label: "Accueil", icon: LayoutDashboard, path: "/teacher" },
  { label: "Notes", icon: ClipboardList, path: "/grades" },
  { label: "Emploi", icon: Calendar, path: "/schedule" },
  { label: "Bulletins", icon: FileText, path: "/reports" },
  { label: "Profil", icon: UserCircle, path: null, isProfile: true },
];

const NAV_ITEMS_STUDENT = [
  { label: "Accueil", icon: LayoutDashboard, path: "/portal?tab=dashboard" },
  { label: "Notes", icon: ClipboardList, path: "/portal?tab=grades" },
  { label: "Emploi", icon: Calendar, path: "/portal?tab=schedule" },
  { label: "Frais", icon: DollarSign, path: "/portal?tab=fees" },
  { label: "Carte", icon: UserCircle, path: "/portal?tab=card" },
];

const NAV_ITEMS_DIRECTEUR = [
  { label: "Accueil", icon: LayoutDashboard, path: "/directeur" },
  { label: "Élèves", icon: Users, path: "/students" },
  { label: "Notes", icon: ClipboardList, path: "/grades" },
  { label: "Bulletins", icon: FileText, path: "/reports" },
  { label: "Profil", icon: UserCircle, path: null, isProfile: true },
];

const NAV_ITEMS_ACCOUNTANT = [
  { label: "Comptabilité", icon: DollarSign, path: "/comptable" },
  { label: "Profil", icon: UserCircle, path: null, isProfile: true },
];

const NAV_ITEMS_EDUCATOR = [
  { label: "Accueil", icon: Shield, path: "/educateur" },
  { label: "Profil", icon: UserCircle, path: null, isProfile: true },
];

export default function MobileBottomNav({ onProfileClick }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const role = user?.role === "admin" ? "admin" : (getVerifiedRole() || user?.role);

  let items = NAV_ITEMS_ADMIN;
  if (role === "teacher") items = NAV_ITEMS_TEACHER;
  else if (role === "student") items = NAV_ITEMS_STUDENT;
  else if (role === "user") items = NAV_ITEMS_DIRECTEUR;
  else if (role === "accountant") items = NAV_ITEMS_ACCOUNTANT;
  else if (role === "educator") items = NAV_ITEMS_EDUCATOR;

  function isActive(item) {
    if (!item.path) return false;
    const rootPath = item.path.split("?")[0];
    const currentFull = location.pathname + location.search;
    return (
      currentFull === item.path ||
      (item.path === "/" && location.pathname === "/" && !location.search) ||
      (item.path !== "/" && location.pathname === rootPath && !item.path.includes("?"))
    );
  }

  function handleTabPress(item) {
    if (!item.path) return;
    navigate(item.path, { replace: isActive(item) });
  }

  return (
    <nav
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 flex items-stretch"
      style={{
        background: "linear-gradient(180deg, #1a2340 0%, #0f172a 100%)",
        paddingBottom: "env(safe-area-inset-bottom)",
        borderTop: "1px solid rgba(255,255,255,0.08)",
        boxShadow: "0 -8px 32px rgba(0,0,0,0.4)",
      }}
    >
      {items.map((item) => {
        const Icon = item.icon;
        const active = isActive(item);

        if (item.isProfile) {
          return (
            <button
              key="profile"
              onClick={onProfileClick}
              className="flex-1 flex flex-col items-center justify-center gap-1 py-3 min-h-[60px] transition-all select-none active:scale-90"
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center shadow-md">
                <Icon className="h-3.5 w-3.5 text-white" />
              </div>
              <span className="text-[10px] font-semibold text-white/40">{item.label}</span>
            </button>
          );
        }

        return (
          <button
            key={item.path}
            onClick={() => handleTabPress(item)}
            className="flex-1 flex flex-col items-center justify-center gap-1 py-3 min-h-[60px] transition-all select-none active:scale-90 relative"
          >
            {/* Active indicator dot at top */}
            {active && (
              <span
                className="absolute top-0 left-1/2 -translate-x-1/2 w-6 h-0.5 rounded-full"
                style={{ background: "linear-gradient(90deg, #60a5fa, #34d399)" }}
              />
            )}

            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center transition-all"
              style={active ? {
                background: "linear-gradient(135deg, rgba(96,165,250,0.25), rgba(52,211,153,0.15))",
                boxShadow: "0 0 16px rgba(96,165,250,0.2)",
              } : {}}
            >
              <Icon
                className="h-5 w-5 transition-all"
                style={{ color: active ? "#60a5fa" : "rgba(255,255,255,0.35)" }}
              />
            </div>
            <span
              className="text-[10px] font-semibold leading-tight"
              style={{ color: active ? "#60a5fa" : "rgba(255,255,255,0.35)" }}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}