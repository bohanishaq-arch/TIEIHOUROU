import { useState } from "react";
import {
  HelpCircle, X, ChevronRight, GraduationCap, Calendar, ClipboardList,
  TrendingUp, FileText, DollarSign, Bell, LayoutDashboard, Users, School,
  BookOpen, UserCog, Settings, BarChart3, ShieldCheck, Receipt, UserCheck,
  AlertTriangle, BookMarked, Megaphone, CreditCard, UserPlus, Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";

// ─── SECTION PRÉSENTATION BOHAN ─────────────────────────────────────────────

const GUIDE_ABOUT = {
  icon: Sparkles,
  title: "À propos de BOHAN",
  color: "bg-gradient-to-br from-blue-500 to-emerald-500 text-white",
  desc: "BOHAN — Base Opérationnelle d'Harmonisation Académique et Numérique — est une plateforme digitale complète conçue pour moderniser et centraliser la gestion des établissements scolaires en Côte d'Ivoire et en Afrique.",
  mission: "Notre mission est de connecter tous les acteurs de l'éducation — directeurs, professeurs, éducateurs, comptables et élèves — sur une seule plateforme intelligente, fluide et accessible.",
  values: [
    { emoji: "🎓", label: "Pour les élèves", text: "Accès immédiat à leurs notes, bulletins, emploi du temps et frais de scolarité depuis n'importe quel appareil." },
    { emoji: "👨‍🏫", label: "Pour les professeurs", text: "Gestion simplifiée des examens, saisie rapide des notes et suivi en temps réel des performances de chaque classe." },
    { emoji: "💰", label: "Pour la comptabilité", text: "Inscription, suivi des paiements, émission de reçus officiels et tableau de bord financier complet." },
    { emoji: "🏫", label: "Pour la direction", text: "Vision globale de l'établissement : performances académiques, présences, incidents et validation des bulletins." },
    { emoji: "🛡️", label: "Pour les éducateurs", text: "Gestion des absences, signalement des incidents et communication directe avec la direction." },
    { emoji: "⚡", label: "Technologie moderne", text: "Interface fluide, animations naturelles, données en temps réel et accès sécurisé via code d'accès permanent." },
  ],
  slogan: "\"L'école de demain, numérique aujourd'hui.\"",
};

// ─── GUIDES PAR RÔLE ────────────────────────────────────────────────────────

const GUIDE_STUDENT = [
  {
    icon: GraduationCap,
    title: "Ma carte scolaire",
    color: "bg-blue-100 text-blue-700",
    desc: "Votre carte d'identité scolaire officielle avec votre photo, matricule, classe et année scolaire. Ces informations sont mises à jour en temps réel par l'administration.",
    tips: [
      "Votre photo est ajoutée par l'administration — contactez-la si elle est absente.",
      "Votre matricule est unique et sert à vous identifier dans tout l'établissement.",
      "La synchronisation en temps réel garantit que vos informations sont toujours à jour.",
    ],
  },
  {
    icon: Calendar,
    title: "Emploi du temps",
    color: "bg-purple-100 text-purple-700",
    desc: "Votre planning hebdomadaire par matière, avec les horaires, salles et professeurs. Les cours du jour sont mis en avant automatiquement.",
    tips: [
      "L'emploi du temps est mis à jour par l'administration — actualisez la page si nécessaire.",
      "Les cours du jour apparaissent en haut pour un accès rapide.",
      "Consultez les horaires la veille pour vous organiser.",
    ],
  },
  {
    icon: ClipboardList,
    title: "Devoirs & Examens",
    color: "bg-orange-100 text-orange-700",
    desc: "Liste de tous vos devoirs et examens passés, avec vos notes et les commentaires du professeur par trimestre.",
    tips: [
      "Filtrez par trimestre pour retrouver une note précise.",
      "Le commentaire du professeur vous indique vos points à améliorer.",
      "Les notes en rouge (moins de 10) nécessitent une attention particulière.",
    ],
  },
  {
    icon: TrendingUp,
    title: "Mes moyennes",
    color: "bg-teal-100 text-teal-700",
    desc: "Vos moyennes par matière, par trimestre et votre moyenne annuelle générale pondérée par les coefficients.",
    tips: [
      "La moyenne annuelle est la moyenne de vos trois trimestres.",
      "Les matières à fort coefficient ont plus d'impact sur votre moyenne générale.",
      "Une moyenne sous 10 dans une matière nécessite un effort particulier.",
    ],
  },
  {
    icon: DollarSign,
    title: "Frais de scolarité",
    color: "bg-emerald-100 text-emerald-700",
    desc: "État de votre dossier financier : montant total dû, montant payé, reste à régler, historique des versements et informations sur votre mode de paiement.",
    tips: [
      "Consultez cette section régulièrement pour suivre l'état de vos paiements.",
      "En cas de solde restant, rapprochez-vous du bureau de la comptabilité.",
      "Conservez vos numéros de reçus comme preuve de paiement.",
    ],
  },
  {
    icon: FileText,
    title: "Bulletin scolaire",
    color: "bg-indigo-100 text-indigo-700",
    desc: "Votre bulletin officiel par trimestre avec toutes vos moyennes, coefficients, appréciations du conseil de classe et distinctions éventuelles.",
    tips: [
      "Le bulletin est publié par l'administration après le conseil de classe.",
      "Les distinctions (Félicitations, Tableau d'honneur) récompensent les meilleurs élèves.",
      "En cas de désaccord, adressez-vous à votre professeur principal.",
    ],
  },
  {
    icon: Bell,
    title: "Messages & Alertes",
    color: "bg-red-100 text-red-700",
    desc: "Boîte de réception de vos notifications : examens à venir, devoirs urgents et alertes importantes. Un badge rouge vous signale les messages non lus.",
    tips: [
      "Un badge rouge sur l'onglet indique des examens dans les 7 prochains jours.",
      "Les alertes en rouge signalent un examen dans moins de 3 jours.",
      "Cliquez sur un message pour le marquer comme lu.",
    ],
  },
];

const GUIDE_TEACHER = [
  {
    icon: LayoutDashboard,
    title: "Mon tableau de bord",
    color: "bg-blue-100 text-blue-700",
    desc: "Vue d'ensemble de vos activités : classes assignées, matières enseignées, examens créés et taux de saisie des notes. Accès rapide à toutes vos fonctions.",
    tips: [
      "Vérifiez votre taux de saisie pour savoir quelles notes sont encore à compléter.",
      "Les statistiques affichées concernent uniquement vos classes assignées.",
      "Utilisez les boutons d'action pour accéder rapidement aux fonctions fréquentes.",
    ],
  },
  {
    icon: ClipboardList,
    title: "Gestion des examens",
    color: "bg-red-100 text-red-700",
    desc: "Créez et gérez vos examens (Devoirs, Interrogations, TP, Oral…) pour vos classes. Définissez la date, le barème, le chapitre et les instructions.",
    tips: [
      "Créez l'examen avant de saisir les notes — les deux étapes sont liées.",
      "Indiquez le chapitre pour que les élèves puissent réviser précisément.",
      "Soumettez l'examen à validation du proviseur si nécessaire.",
    ],
  },
  {
    icon: BookMarked,
    title: "Saisie des notes",
    color: "bg-orange-100 text-orange-700",
    desc: "Saisissez les notes de vos élèves pour chaque examen créé. Ajoutez des commentaires individuels pour chaque élève.",
    tips: [
      "Saisissez toutes les notes d'un examen en une seule session pour plus d'efficacité.",
      "Les commentaires personnalisés sont très appréciés des élèves et parents.",
      "Les notes verrouillées ne peuvent plus être modifiées sans demande de correction.",
    ],
  },
  {
    icon: Users,
    title: "Liste des élèves",
    color: "bg-green-100 text-green-700",
    desc: "Consultez la liste des élèves de vos classes avec leurs informations essentielles et leurs performances académiques.",
    tips: [
      "Filtrez par classe pour voir uniquement vos élèves.",
      "Identifiez rapidement les élèves en difficulté grâce aux indicateurs de couleur.",
      "Contactez l'administration pour toute mise à jour des informations d'un élève.",
    ],
  },
  {
    icon: Calendar,
    title: "Mon emploi du temps",
    color: "bg-purple-100 text-purple-700",
    desc: "Votre planning hebdomadaire de cours : horaires, salles et classes. Les cours du jour sont mis en avant.",
    tips: [
      "Votre emploi du temps est défini par l'administration.",
      "En cas d'erreur, signalez-le au responsable des emplois du temps.",
      "Les cours d'aujourd'hui apparaissent en priorité.",
    ],
  },
  {
    icon: FileText,
    title: "Rapports pédagogiques",
    color: "bg-indigo-100 text-indigo-700",
    desc: "Rédigez et envoyez des rapports de cours, de devoirs ou d'examens à l'administration. Suivez le statut de vos soumissions.",
    tips: [
      "Les rapports sont visibles par le directeur et l'administrateur.",
      "Un rapport approuvé confirme que l'administration a pris connaissance.",
      "Utilisez les rapports pour signaler les difficultés pédagogiques d'une classe.",
    ],
  },
  {
    icon: TrendingUp,
    title: "Statistiques de classe",
    color: "bg-teal-100 text-teal-700",
    desc: "Analyses de performance de vos classes : distribution des notes, taux de réussite, comparaison par matière et évolution trimestrielle.",
    tips: [
      "Comparez les résultats entre trimestres pour mesurer la progression.",
      "Un taux de réussite faible peut indiquer un besoin de revoir la méthode pédagogique.",
      "Partagez ces données lors des conseils de classe.",
    ],
  },
];

const GUIDE_EDUCATOR = [
  {
    icon: LayoutDashboard,
    title: "Mon tableau de bord",
    color: "bg-blue-100 text-blue-700",
    desc: "Vue d'ensemble de votre activité quotidienne : absences récentes, incidents signalés, rapports envoyés et statistiques de présence de l'établissement.",
    tips: [
      "Consultez le tableau de bord chaque matin pour un état des lieux rapide.",
      "Les alertes d'absence importante apparaissent en priorité.",
      "Suivez l'évolution des incidents pour identifier les tendances comportementales.",
    ],
  },
  {
    icon: UserCheck,
    title: "Gestion des absences",
    color: "bg-orange-100 text-orange-700",
    desc: "Enregistrez les absences et retards des élèves. Spécifiez le type (absent, retard, justifié), la période et le motif. Notifiez les parents si nécessaire.",
    tips: [
      "Saisissez les absences dès le début du cours pour plus de précision.",
      "Indiquez toujours la période (cours, demi-journée) pour un suivi exact.",
      "Activez la notification parent pour les absences importantes.",
    ],
  },
  {
    icon: AlertTriangle,
    title: "Gestion des incidents",
    color: "bg-red-100 text-red-700",
    desc: "Signalez les incidents disciplinaires avec leur niveau de gravité (léger, moyen, grave), description et sanction proposée. L'incident est transmis au directeur.",
    tips: [
      "Soyez précis dans la description — elle sert de base à la décision du directeur.",
      "Proposez une sanction adaptée à la gravité de l'incident.",
      "Suivez l'état de traitement pour connaître la décision finale.",
    ],
  },
  {
    icon: Megaphone,
    title: "Rapports éducateurs",
    color: "bg-indigo-100 text-indigo-700",
    desc: "Rédigez et envoyez des rapports quotidiens, d'incident ou d'alerte à l'administration et au directeur. Consultez les réponses reçues.",
    tips: [
      "Un rapport quotidien permet un suivi régulier de la vie scolaire.",
      "Les rapports de type 'alerte' sont traités en priorité par le directeur.",
      "Vérifiez les réponses du proviseur pour connaître les suites données.",
    ],
  },
];

const GUIDE_ACCOUNTANT = [
  {
    icon: LayoutDashboard,
    title: "Tableau de bord financier",
    color: "bg-emerald-100 text-emerald-700",
    desc: "Vue d'ensemble de la santé financière de l'établissement : total collecté, inscriptions en attente, paiements partiels et statistiques globales.",
    tips: [
      "Consultez les alertes en haut du tableau pour identifier les impayés prioritaires.",
      "Le total XOF collecté est mis à jour en temps réel après chaque saisie.",
      "Utilisez les filtres pour cibler les dossiers à traiter en urgence.",
    ],
  },
  {
    icon: UserPlus,
    title: "Nouvelle inscription",
    color: "bg-blue-100 text-blue-700",
    desc: "Enregistrez l'inscription d'un nouvel élève : informations personnelles, classe, frais calculés automatiquement selon les tarifs de son niveau, et premier paiement.",
    tips: [
      "Vérifiez que les tarifs du niveau sont configurés avant de créer une inscription.",
      "Le total est calculé automatiquement selon l'inscription (affecté ou non).",
      "Imprimez le reçu immédiatement après validation du premier paiement.",
    ],
  },
  {
    icon: CreditCard,
    title: "Suivi des paiements",
    color: "bg-teal-100 text-teal-700",
    desc: "Consultez et mettez à jour l'état des paiements de chaque élève. Enregistrez de nouveaux versements et suivez les soldes restants.",
    tips: [
      "Filtrez par statut (en attente, partiel, complet) pour prioriser votre travail.",
      "Chaque versement génère automatiquement un numéro de reçu unique.",
      "Réimprimez un reçu à tout moment depuis l'historique des versements.",
    ],
  },
  {
    icon: Receipt,
    title: "Historique des reçus",
    color: "bg-purple-100 text-purple-700",
    desc: "Recherchez et réimprimez tous les reçus de paiement émis. Chaque reçu contient les informations complètes de l'élève et du paiement.",
    tips: [
      "Recherchez par nom d'élève, numéro de reçu ou classe.",
      "Les reçus sont conformes aux standards officiels avec en-tête et signatures.",
      "Conservez une copie numérique pour vos archives comptables.",
    ],
  },
  {
    icon: BarChart3,
    title: "Graphique financier",
    color: "bg-indigo-100 text-indigo-700",
    desc: "Visualisez l'évolution des encaissements, la répartition des paiements par type et les tendances mensuelles.",
    tips: [
      "Utilisez les graphiques pour votre rapport financier trimestriel.",
      "Identifiez les pics d'encaissement liés aux échéances scolaires.",
      "Partagez ces données avec le directeur lors des réunions de pilotage.",
    ],
  },
  {
    icon: Settings,
    title: "Tarifs scolaires",
    color: "bg-gray-100 text-gray-700",
    desc: "Configurez les frais par niveau : droit d'inscription, frais de scolarité, frais plateforme, avance initiale et paramètres de paiement échelonné.",
    tips: [
      "Configurez les tarifs au début de chaque année scolaire.",
      "Différenciez les tarifs affecté / non-affecté selon les règles de l'établissement.",
      "Le nombre d'échéances maximum encadre les paiements échelonnés.",
    ],
  },
];

const GUIDE_ADMIN = [
  {
    icon: LayoutDashboard,
    title: "Tableau de bord",
    color: "bg-blue-100 text-blue-700",
    desc: "Vue d'ensemble de l'établissement : statistiques globales, performances académiques, taux de saisie des notes par professeur et évolution trimestrielle.",
    tips: [
      "Consultez les graphiques dès la connexion pour un état des lieux rapide.",
      "Les performances sont calculées automatiquement à partir des notes saisies.",
      "Le taux de saisie des professeurs vous alerte sur les notes manquantes.",
    ],
  },
  {
    icon: Users,
    title: "Élèves",
    color: "bg-green-100 text-green-700",
    desc: "Gestion complète des élèves : inscription, modification, recherche, affectation à une classe, informations des parents et historique scolaire.",
    tips: [
      "Attribuez toujours une classe à chaque élève avant de saisir des notes.",
      "Renseignez l'email parent pour les notifications et bulletins.",
      "L'historique scolaire retrace le parcours de l'élève sur plusieurs années.",
    ],
  },
  {
    icon: School,
    title: "Classes",
    color: "bg-purple-100 text-purple-700",
    desc: "Création et gestion des classes par niveau et série. Chaque classe peut avoir une division, une salle et un professeur principal.",
    tips: [
      "Créez une classe par série et division : ex. Tle A1, Tle C2.",
      "Renseignez la salle pour faciliter la gestion des salles d'examen.",
      "Le professeur principal apparaîtra sur les bulletins officiels.",
    ],
  },
  {
    icon: BookOpen,
    title: "Matières",
    color: "bg-yellow-100 text-yellow-700",
    desc: "Gestion des matières enseignées : nom, code, coefficient, niveaux cibles et professeur responsable. Le coefficient détermine le poids dans les moyennes.",
    tips: [
      "Le coefficient est crucial : vérifiez-le soigneusement avant de valider.",
      "Associez chaque matière à plusieurs niveaux pour un meilleur filtrage.",
      "Le code matière (ex: MATH, SVT) facilite l'identification rapide.",
    ],
  },
  {
    icon: UserCog,
    title: "Professeurs & Accès",
    color: "bg-orange-100 text-orange-700",
    desc: "Gestion des comptes professeurs, éducateurs, directeurs et comptables. Création des codes d'accès permanents, attribution des matières et classes.",
    tips: [
      "Chaque membre du personnel reçoit un code permanent unique généré automatiquement.",
      "Imprimez la fiche d'identifiants pour la remettre à la personne concernée.",
      "Désactivez un compte immédiatement en cas de départ du personnel.",
    ],
  },
  {
    icon: ClipboardList,
    title: "Notes & Examens",
    color: "bg-red-100 text-red-700",
    desc: "Supervision de tous les examens et notes de l'établissement. Validation des demandes de correction avec workflow éducateur → directeur → admin.",
    tips: [
      "Les notes verrouillées garantissent l'intégrité des résultats officiels.",
      "Le workflow de correction assure une traçabilité complète des modifications.",
      "Approuvez ou rejetez les demandes de correction depuis l'onglet Corrections.",
    ],
  },
  {
    icon: TrendingUp,
    title: "Moyennes & Classements",
    color: "bg-teal-100 text-teal-700",
    desc: "Calcul automatique des moyennes pondérées, classement des élèves par classe ou par niveau, avec comparatifs inter-classes.",
    tips: [
      "Les moyennes sont recalculées en temps réel après chaque saisie de note.",
      "Filtrez par trimestre pour le classement d'une période précise.",
      "Le classement par niveau permet une comparaison équitable entre classes.",
    ],
  },
  {
    icon: FileText,
    title: "Bulletins officiels",
    color: "bg-indigo-100 text-indigo-700",
    desc: "Génération et publication des bulletins trimestriels officiels : en-tête institutionnel, tableau des matières avec coefficients, rang, absences et signature.",
    tips: [
      "Configurez d'abord les paramètres de l'établissement (menu Configuration).",
      "Remplissez les données du bulletin avant de le publier.",
      "Publiez le bulletin pour le rendre visible aux élèves dans leur portail.",
    ],
  },
  {
    icon: BarChart3,
    title: "Statistiques",
    color: "bg-pink-100 text-pink-700",
    desc: "Analyses avancées de performance globale : taux de réussite, répartition des mentions, comparaisons inter-classes et suivi longitudinal.",
    tips: [
      "Analysez les tendances pour ajuster les stratégies pédagogiques.",
      "Comparez les performances entre classes du même niveau.",
      "Exportez les données pour vos rapports de fin de trimestre.",
    ],
  },
  {
    icon: Settings,
    title: "Configuration",
    color: "bg-gray-100 text-gray-700",
    desc: "Paramétrage de l'établissement : nom, adresse, logo, devise, nom du proviseur et organisation de l'année (trimestres/semestres).",
    tips: [
      "Renseignez ces informations une seule fois — elles s'appliquent à tous les bulletins.",
      "Le nom du proviseur apparaît dans la zone de signature des documents officiels.",
      "La devise (ex: Union - Discipline - Travail) figure en en-tête des documents.",
    ],
  },
];

// Les directeurs voient le même guide étendu que les admins
const GUIDE_DIRECTOR = GUIDE_ADMIN;

// ─── MAPPING RÔLE → GUIDE ────────────────────────────────────────────────────

function getGuideForRole(role) {
  switch (role) {
    case "student":   return { guide: GUIDE_STUDENT,    label: "Guide Élève",      accent: "bg-blue-600" };
    case "teacher":   return { guide: GUIDE_TEACHER,    label: "Guide Professeur", accent: "bg-primary" };
    case "educator":  return { guide: GUIDE_EDUCATOR,   label: "Guide Éducateur",  accent: "bg-teal-600" };
    case "accountant":return { guide: GUIDE_ACCOUNTANT, label: "Guide Comptable",  accent: "bg-emerald-600" };
    case "user":      return { guide: GUIDE_DIRECTOR,   label: "Guide Directeur",  accent: "bg-purple-600" };
    default:          return { guide: GUIDE_ADMIN,      label: "Guide Administrateur", accent: "bg-primary" };
  }
}

// ─── COMPOSANT ───────────────────────────────────────────────────────────────

export default function HelpGuide({ role, open, onClose }) {
  const [selected, setSelected] = useState(null);

  const { guide, label, accent } = getGuideForRole(role);

  if (!open) return null;

  return (
    <>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
          <div className="relative bg-card w-full sm:max-w-2xl sm:rounded-2xl rounded-t-3xl border border-border shadow-2xl max-h-[90vh] sm:max-h-[85vh] flex flex-col overflow-hidden">

            {/* Drag handle mobile */}
            <div className="flex justify-center pt-3 sm:hidden">
              <div className="w-10 h-1 bg-muted-foreground/20 rounded-full" />
            </div>

            {/* Header */}
            <div className={`flex items-center justify-between px-5 py-4 border-b border-border ${accent} text-white shrink-0`}>
              <div>
                <h2 className="text-base font-bold">{label}</h2>
                <p className="text-[11px] opacity-80">
                  {selected === null ? "Sélectionnez une section" : "Détail de la section"}
                </p>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 active:bg-white/40"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-4">
              {selected === null ? (
                <div className="space-y-3">
                  {/* BOHAN About Card */}
                  <button
                    onClick={() => setSelected("about")}
                    className="w-full flex items-center gap-3 p-4 rounded-2xl border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-emerald-50 hover:from-blue-100 hover:to-emerald-100 active:scale-98 transition-all text-left group shadow-sm"
                  >
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-emerald-500 flex items-center justify-center shrink-0 shadow-md">
                      <Sparkles className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm text-blue-800">🎯 À propos de BOHAN</p>
                      <p className="text-xs text-blue-600 mt-0.5">Mission, vision et objectifs de la plateforme</p>
                    </div>
                    <ChevronRight className="h-4 w-4 text-blue-400 group-hover:text-blue-700 shrink-0" />
                  </button>

                  <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold px-1 pt-1">Fonctionnalités</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {guide.map((item, i) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={i}
                        onClick={() => setSelected(i)}
                        className="flex items-center gap-3 p-3.5 rounded-xl border border-border bg-card hover:bg-accent/30 active:bg-accent/50 transition-colors text-left group"
                      >
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${item.color}`}>
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm text-foreground">{item.title}</p>
                          <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{item.desc}</p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground shrink-0" />
                      </button>
                    );
                  })}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <button
                    onClick={() => setSelected(null)}
                    className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors"
                  >
                    ← Retour au guide
                  </button>

                  {selected === "about" ? (
                    <div className="space-y-4">
                      {/* Hero about */}
                      <div className="rounded-2xl overflow-hidden" style={{background:'linear-gradient(135deg,#1d4ed8 0%,#059669 100%)'}}>
                        <div className="p-5 text-white">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                              <Sparkles className="h-6 w-6 text-white" />
                            </div>
                            <div>
                              <h3 className="text-lg font-extrabold tracking-wider">BOHAN</h3>
                              <p className="text-white/70 text-[10px] uppercase tracking-widest">Base Opérationnelle d'Harmonisation Académique et Numérique</p>
                            </div>
                          </div>
                          <p className="text-sm text-white/90 leading-relaxed">{GUIDE_ABOUT.desc}</p>
                          <p className="mt-3 text-sm font-semibold italic text-white/80">{GUIDE_ABOUT.slogan}</p>
                        </div>
                      </div>

                      {/* Mission */}
                      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                        <p className="text-xs font-bold uppercase tracking-wide text-blue-700 mb-2">🎯 Notre mission</p>
                        <p className="text-sm text-blue-800 leading-relaxed">{GUIDE_ABOUT.mission}</p>
                      </div>

                      {/* Values grid */}
                      <div>
                        <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2 px-1">👥 Pour chaque acteur</p>
                        <div className="space-y-2">
                          {GUIDE_ABOUT.values.map((v, i) => (
                            <div key={i} className="flex items-start gap-3 bg-card border border-border rounded-xl p-3">
                              <span className="text-xl shrink-0">{v.emoji}</span>
                              <div>
                                <p className="text-sm font-semibold text-foreground">{v.label}</p>
                                <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{v.text}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    (() => {
                      const item = guide[selected];
                      const Icon = item.icon;
                      return (
                        <div className="space-y-4">
                          <div className="flex items-center gap-3">
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${item.color}`}>
                              <Icon className="h-6 w-6" />
                            </div>
                            <h3 className="text-xl font-bold text-foreground">{item.title}</h3>
                          </div>
                          <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>

                          <div className="bg-accent/30 rounded-xl p-4 border border-border">
                            <p className="text-xs font-semibold text-foreground mb-2">💡 Conseils pratiques</p>
                            <ul className="text-xs text-muted-foreground space-y-1.5">
                              {item.tips.map((tip, i) => (
                                <li key={i} className="flex items-start gap-1.5">
                                  <span className="text-primary mt-0.5 shrink-0">•</span>
                                  <span>{tip}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          <div className="flex justify-between pt-1">
                            <Button variant="outline" size="sm" onClick={() => setSelected((selected - 1 + guide.length) % guide.length)}>
                              ← Précédent
                            </Button>
                            <Button size="sm" onClick={() => setSelected((selected + 1) % guide.length)}>
                              Suivant →
                            </Button>
                          </div>
                        </div>
                      );
                    })()
                  )}
                </div>
              )}
            </div>

            {/* Footer */}
            {selected === null && (
              <div className="px-5 py-3 border-t border-border bg-muted/20 text-center shrink-0">
                <div className="space-y-0.5">
                  <p className="text-xs font-semibold text-foreground">BOHAN — Base Opérationnelle d'Harmonisation Académique et Numérique</p>
                  <p className="text-xs text-muted-foreground">Une solution digitale conçue pour moderniser la gestion des établissements scolaires en connectant tous les acteurs de l'éducation sur une seule plateforme.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}