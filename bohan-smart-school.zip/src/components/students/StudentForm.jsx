import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Plus, Trash2 } from "lucide-react";

export default function StudentForm({ student, classes, onSave, onCancel, totalStudents }) {
  const generateStudentNumber = () => {
    const year = new Date().getFullYear();
    const num = String(totalStudents + 1).padStart(4, "0");
    return `SCO-${year}-${num}`;
  };

  const [form, setForm] = useState({
    student_number: student?.student_number || generateStudentNumber(),
    first_name: student?.first_name || "",
    last_name: student?.last_name || "",
    date_of_birth: student?.date_of_birth || "",
    gender: student?.gender || "",
    address: student?.address || "",
    class_id: student?.class_id || "",
    parent_name: student?.parent_name || "",
    parent_email: student?.parent_email || "",
    parent_phone: student?.parent_phone || "",
    status: student?.status || "Actif",
    school_history: student?.school_history || [],
  });

  const [showHistory, setShowHistory] = useState(false);

  function addHistoryEntry() {
    setForm({
      ...form,
      school_history: [
        ...form.school_history,
        { academic_year: "", class_name: "", average: "", result: "Admis", observations: "" },
      ],
    });
  }

  function updateHistory(index, field, value) {
    const updated = [...form.school_history];
    updated[index] = { ...updated[index], [field]: value };
    setForm({ ...form, school_history: updated });
  }

  function removeHistory(index) {
    setForm({ ...form, school_history: form.school_history.filter((_, i) => i !== index) });
  }

  function handleSubmit(e) {
    e.preventDefault();
    onSave(form);
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-foreground">
          {student ? "Modifier l'élève" : "Inscrire un nouvel élève"}
        </h3>
        <Button variant="ghost" size="icon" onClick={onCancel}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Informations personnelles */}
        <div>
          <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Informations personnelles</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <Label>N° Étudiant</Label>
              <Input value={form.student_number} readOnly className="bg-muted/50 font-mono" />
            </div>
            <div>
              <Label>Prénom *</Label>
              <Input value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} required />
            </div>
            <div>
              <Label>Nom *</Label>
              <Input value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })} required />
            </div>
            <div>
              <Label>Date de naissance</Label>
              <Input type="date" value={form.date_of_birth} onChange={(e) => setForm({ ...form, date_of_birth: e.target.value })} />
            </div>
            <div>
              <Label>Sexe</Label>
              <Select value={form.gender} onValueChange={(v) => setForm({ ...form, gender: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Masculin">Masculin</SelectItem>
                  <SelectItem value="Féminin">Féminin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Statut</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Actif">Actif</SelectItem>
                  <SelectItem value="Inactif">Inactif</SelectItem>
                  <SelectItem value="Transféré">Transféré</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2">
              <Label>Adresse</Label>
              <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Rue, ville, pays" />
            </div>
            <div>
              <Label>Classe *</Label>
              <Select value={form.class_id} onValueChange={(v) => setForm({ ...form, class_id: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                <SelectContent>
                  {classes.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Contact parent */}
        <div>
          <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Contact parent / tuteur</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Nom du parent</Label>
              <Input value={form.parent_name} onChange={(e) => setForm({ ...form, parent_name: e.target.value })} />
            </div>
            <div>
              <Label>Email du parent</Label>
              <Input type="email" value={form.parent_email} onChange={(e) => setForm({ ...form, parent_email: e.target.value })} />
            </div>
            <div>
              <Label>Téléphone du parent</Label>
              <Input value={form.parent_phone} onChange={(e) => setForm({ ...form, parent_phone: e.target.value })} />
            </div>
          </div>
        </div>

        {/* Historique scolaire */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Historique scolaire</h4>
            <Button type="button" variant="outline" size="sm" onClick={addHistoryEntry}>
              <Plus className="h-3.5 w-3.5 mr-1" /> Ajouter une année
            </Button>
          </div>
          {form.school_history.length === 0 ? (
            <p className="text-sm text-muted-foreground italic">Aucun historique enregistré</p>
          ) : (
            <div className="space-y-3">
              {form.school_history.map((entry, index) => (
                <div key={index} className="grid grid-cols-2 md:grid-cols-5 gap-3 p-3 bg-muted/30 rounded-lg items-end">
                  <div>
                    <Label className="text-xs">Année scolaire</Label>
                    <Input placeholder="2024-2025" value={entry.academic_year} onChange={(e) => updateHistory(index, "academic_year", e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-xs">Classe</Label>
                    <Input placeholder="Ex: 5ème A" value={entry.class_name} onChange={(e) => updateHistory(index, "class_name", e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-xs">Moyenne</Label>
                    <Input type="number" min="0" max="20" step="0.01" placeholder="0-20" value={entry.average} onChange={(e) => updateHistory(index, "average", e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-xs">Résultat</Label>
                    <Select value={entry.result} onValueChange={(v) => updateHistory(index, "result", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Admis">Admis</SelectItem>
                        <SelectItem value="Redoublant">Redoublant</SelectItem>
                        <SelectItem value="Transféré">Transféré</SelectItem>
                        <SelectItem value="Exclu">Exclu</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2 items-end">
                    <div className="flex-1">
                      <Label className="text-xs">Observations</Label>
                      <Input placeholder="Optionnel" value={entry.observations} onChange={(e) => updateHistory(index, "observations", e.target.value)} />
                    </div>
                    <Button type="button" variant="ghost" size="icon" className="h-9 w-9 text-destructive shrink-0" onClick={() => removeHistory(index)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-end gap-3 pt-2 border-t border-border">
          <Button type="button" variant="outline" onClick={onCancel}>Annuler</Button>
          <Button type="submit">{student ? "Enregistrer" : "Inscrire l'élève"}</Button>
        </div>
      </form>
    </div>
  );
}