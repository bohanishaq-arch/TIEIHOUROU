import { Pencil, Trash2, User, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function StudentTable({ students, classes, onEdit, onDelete, onView }) {
  const classMap = {};
  classes.forEach((c) => (classMap[c.id] = c.name));

  if (students.length === 0) {
    return (
      <div className="bg-card rounded-xl border border-border p-12 text-center">
        <User className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
        <p className="text-muted-foreground">Aucun élève trouvé</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted/50 border-b border-border">
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Photo</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">N° Étudiant</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Nom complet</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Classe</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Sexe</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Statut</th>
              <th className="text-right py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Actions</th>
            </tr>
          </thead>
          <tbody>
            {students.map((s) => (
              <tr key={s.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                <td className="py-3 px-4">
                  {s.photo_url
                    ? <img src={s.photo_url} alt="" className="w-9 h-9 rounded-lg object-cover border border-border" />
                    : <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">{s.first_name?.[0]}{s.last_name?.[0]}</div>
                  }
                </td>
                <td className="py-3 px-4 font-mono text-xs font-medium text-primary">{s.student_number}</td>
                <td className="py-3 px-4 font-medium">{s.first_name} {s.last_name}</td>
                <td className="py-3 px-4 text-muted-foreground">{classMap[s.class_id] || "—"}</td>
                <td className="py-3 px-4 text-muted-foreground">{s.gender || "—"}</td>
                <td className="py-3 px-4">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                    s.status === "Actif" ? "bg-green-100 text-green-700" :
                    s.status === "Inactif" ? "bg-gray-100 text-gray-600" :
                    "bg-orange-100 text-orange-700"
                  }`}>
                    {s.status || "Actif"}
                  </span>
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-1">
                    {onView && (
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onView(s)}>
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(s)}>
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => onDelete(s.id)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}