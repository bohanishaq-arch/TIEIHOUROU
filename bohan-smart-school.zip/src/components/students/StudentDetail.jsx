import { X, User, Phone, Mail, MapPin, BookOpen, Calendar, School } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function StudentDetail({ student, classes, onClose, onEdit }) {
  const classMap = {};
  classes.forEach((c) => (classMap[c.id] = c.name));

  const age = student.date_of_birth
    ? Math.floor((new Date() - new Date(student.date_of_birth)) / (365.25 * 24 * 3600 * 1000))
    : null;

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-2xl border border-border w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-accent flex items-center justify-center text-2xl font-bold text-primary">
              {student.first_name?.[0]}{student.last_name?.[0]}
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">{student.first_name} {student.last_name}</h2>
              <p className="text-sm font-mono text-primary">{student.student_number}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => onEdit(student)}>Modifier</Button>
            <Button variant="ghost" size="icon" onClick={onClose}><X className="h-4 w-4" /></Button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Infos personnelles */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Informations personnelles</h3>
            <div className="grid grid-cols-2 gap-3">
              <InfoRow icon={User} label="Sexe" value={student.gender || "—"} />
              <InfoRow icon={Calendar} label="Date de naissance" value={student.date_of_birth ? `${student.date_of_birth}${age ? ` (${age} ans)` : ""}` : "—"} />
              <InfoRow icon={School} label="Classe" value={classMap[student.class_id] || "—"} />
              <InfoRow icon={BookOpen} label="Statut" value={student.status || "Actif"} />
              {student.address && (
                <div className="col-span-2">
                  <InfoRow icon={MapPin} label="Adresse" value={student.address} />
                </div>
              )}
            </div>
          </div>

          {/* Contact parent */}
          {(student.parent_name || student.parent_email || student.parent_phone) && (
            <div>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Contact parent / tuteur</h3>
              <div className="grid grid-cols-2 gap-3">
                {student.parent_name && <InfoRow icon={User} label="Nom" value={student.parent_name} />}
                {student.parent_phone && <InfoRow icon={Phone} label="Téléphone" value={student.parent_phone} />}
                {student.parent_email && (
                  <div className="col-span-2">
                    <InfoRow icon={Mail} label="Email" value={student.parent_email} />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Historique scolaire */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Historique scolaire</h3>
            {(!student.school_history || student.school_history.length === 0) ? (
              <p className="text-sm text-muted-foreground italic">Aucun historique enregistré</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/50">
                      <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Année</th>
                      <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Classe</th>
                      <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Moyenne</th>
                      <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Résultat</th>
                      <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Observations</th>
                    </tr>
                  </thead>
                  <tbody>
                    {student.school_history.map((entry, i) => (
                      <tr key={i} className="border-t border-border/50">
                        <td className="py-2 px-3 font-medium">{entry.academic_year}</td>
                        <td className="py-2 px-3">{entry.class_name}</td>
                        <td className="py-2 px-3">
                          <span className={`font-semibold ${
                            entry.average >= 10 ? "text-green-600" : "text-red-500"
                          }`}>{entry.average !== "" ? `${entry.average}/20` : "—"}</span>
                        </td>
                        <td className="py-2 px-3">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            entry.result === "Admis" ? "bg-green-100 text-green-700" :
                            entry.result === "Redoublant" ? "bg-orange-100 text-orange-700" :
                            "bg-gray-100 text-gray-600"
                          }`}>{entry.result}</span>
                        </td>
                        <td className="py-2 px-3 text-muted-foreground">{entry.observations || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-2">
      <Icon className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium text-foreground">{value}</p>
      </div>
    </div>
  );
}