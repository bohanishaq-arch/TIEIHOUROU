import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { UserPlus, Trash2, User, BookOpen, School, Loader2 } from "lucide-react";

export default function TeacherClassAssignment() {
  const [assignments, setAssignments] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ teacher_id: "", class_id: "", subject_id: "" });

  async function load() {
    const schoolId = getSchoolId();
    const f = schoolId ? { school_id: schoolId } : {};
    const [asgns, tchs, cls, subs] = await Promise.all([
      base44.entities.TeacherAssignment.filter(f),
      base44.entities.AppAccess.filter({ role: "teacher" }),
      base44.entities.Class.filter(f),
      base44.entities.Subject.filter(f),
    ]);
    setAssignments(asgns);
    setTeachers(tchs.filter(t => t.is_active !== false));
    setClasses(cls);
    setSubjects(subs);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    setSaving(true);
    const schoolId = getSchoolId();
    const teacher = teachers.find(t => t.id === form.teacher_id);
    const cls = classes.find(c => c.id === form.class_id);
    const subject = subjects.find(s => s.id === form.subject_id);

    // Check duplicate
    const exists = assignments.find(
      a => a.teacher_email === teacher?.user_email && a.class_id === form.class_id && a.subject_id === form.subject_id
    );
    if (exists) {
      alert("Cette assignation existe déjà.");
      setSaving(false);
      return;
    }

    await base44.entities.TeacherAssignment.create({
      school_id: schoolId,
      teacher_email: teacher?.user_email || "",
      teacher_name: teacher?.full_name || "",
      class_id: form.class_id,
      class_name: cls?.name || "",
      subject_id: form.subject_id,
      subject_name: subject?.name || "",
    });

    setForm({ teacher_id: "", class_id: "", subject_id: "" });
    await load();
    setSaving(false);
  }

  async function handleDelete(id) {
    await base44.entities.TeacherAssignment.delete(id);
    await load();
  }

  if (loading) return (
    <div className="flex justify-center py-8">
      <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
    </div>
  );

  // Group assignments by teacher
  const grouped = assignments.reduce((acc, a) => {
    const key = a.teacher_email || "—";
    if (!acc[key]) acc[key] = { name: a.teacher_name, email: a.teacher_email, items: [] };
    acc[key].items.push(a);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {/* Form */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
          <UserPlus className="h-5 w-5 text-primary" /> Nouvelle assignation
        </h3>
        <form onSubmit={handleAdd} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Professeur *</label>
            <select
              value={form.teacher_id}
              onChange={e => setForm(f => ({ ...f, teacher_id: e.target.value }))}
              required
              className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="">-- Choisir un professeur --</option>
              {teachers.map(t => (
                <option key={t.id} value={t.id}>{t.full_name} ({t.access_id})</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Classe *</label>
            <select
              value={form.class_id}
              onChange={e => setForm(f => ({ ...f, class_id: e.target.value }))}
              required
              className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="">-- Choisir une classe --</option>
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name} ({c.level})</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Matière *</label>
            <select
              value={form.subject_id}
              onChange={e => setForm(f => ({ ...f, subject_id: e.target.value }))}
              required
              className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="">-- Choisir une matière --</option>
              {subjects.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
          <div className="sm:col-span-3 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 bg-primary text-primary-foreground rounded-lg px-4 py-2 text-sm font-semibold hover:bg-primary/90 disabled:opacity-60"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
              {saving ? "Enregistrement…" : "Assigner"}
            </button>
          </div>
        </form>
      </div>

      {/* Existing assignments grouped by teacher */}
      <div>
        <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
          <User className="h-5 w-5 text-muted-foreground" /> Professeurs assignés ({assignments.length} assignation{assignments.length !== 1 ? "s" : ""})
        </h3>
        {Object.keys(grouped).length === 0 ? (
          <div className="bg-muted/40 rounded-xl border border-border p-8 text-center text-sm text-muted-foreground">
            Aucune assignation enregistrée.
          </div>
        ) : (
          <div className="space-y-4">
            {Object.values(grouped).map(group => (
              <div key={group.email} className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="bg-muted/40 px-4 py-2.5 flex items-center gap-2 border-b border-border">
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{group.name || "—"}</p>
                    <p className="text-xs text-muted-foreground font-mono">{group.email}</p>
                  </div>
                  <span className="ml-auto text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">
                    {group.items.length} classe{group.items.length !== 1 ? "s" : ""}
                  </span>
                </div>
                <div className="divide-y divide-border/50">
                  {group.items.map(a => (
                    <div key={a.id} className="flex items-center gap-3 px-4 py-2.5 hover:bg-muted/20">
                      <div className="flex items-center gap-1.5 text-sm flex-1">
                        <School className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                        <span className="font-medium">{a.class_name}</span>
                        <span className="text-muted-foreground mx-1">→</span>
                        <BookOpen className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                        <span>{a.subject_name}</span>
                      </div>
                      <button
                        onClick={() => handleDelete(a.id)}
                        className="text-destructive hover:bg-destructive/10 rounded p-1 transition-colors"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}