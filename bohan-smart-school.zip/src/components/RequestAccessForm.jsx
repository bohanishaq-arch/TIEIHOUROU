import { useState } from "react";
import { GraduationCap, Eye, EyeOff, Loader2, AlertCircle, ArrowRight, KeyRound, Lock, CheckCircle2, LogOut } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { clearAccessVerified } from "./AccessGate";

const SESSION_KEY = "scolaris_access_verified";
const ROLE_KEY = "scolaris_verified_role";

const ROLE_LABELS = {
  teacher: "Professeur",
  student: "Élève",
  user: "Directeur",
  educator: "Éducateur",
  accountant: "Comptable",
  admin: "Administrateur",
};

export default function RequestAccessForm({ user }) {
  const [accessId, setAccessId] = useState("");
  const [password, setPassword] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [matchedRole, setMatchedRole] = useState(null);

  // If no user is logged in, redirect to login
  if (!user) {
    base44.auth.redirectToLogin();
    return null;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);

    const googleEmail = user.email.trim().toLowerCase();
    const accessIdTrimmed = accessId.trim();
    const passwordTrimmed = password.trim();

    if (!accessIdTrimmed || !passwordTrimmed) {
      setError("Veuillez remplir tous les champs.");
      setLoading(false);
      return;
    }

    const allRecords = await base44.entities.AppAccess.list();

    // Strategy 1: email + id + password
    let match = allRecords.find(
      (r) =>
        r.user_email?.trim().toLowerCase() === googleEmail &&
        r.access_id?.trim() === accessIdTrimmed &&
        r.access_password?.trim() === passwordTrimmed
    );

    // Strategy 2: id + password only (first-time — auto-link email)
    if (!match) {
      match = allRecords.find(
        (r) =>
          r.access_id?.trim() === accessIdTrimmed &&
          r.access_password?.trim() === passwordTrimmed
      );
      if (match) {
        await base44.entities.AppAccess.update(match.id, { user_email: googleEmail });
        match = { ...match, user_email: googleEmail };
      }
    }

    if (!match) {
      setError("Code d'accès ou mot de passe incorrect. Vérifiez les identifiants remis par votre administrateur.");
      setLoading(false);
      return;
    }

    // Activate if needed
    if (match.is_active === false) {
      await base44.entities.AppAccess.update(match.id, { is_active: true });
    }

    // Store school
    if (match.school_id) {
      const { setSchool } = await import('../hooks/useSchool');
      let schoolName = match.school_name || "";
      if (!schoolName) {
        try {
          const schools = await base44.entities.School.filter({ id: match.school_id });
          if (schools[0]) schoolName = schools[0].name;
        } catch {}
      }
      setSchool(match.school_id, schoolName);
    }

    // Update display name if available
    if (match.full_name) {
      try { await base44.auth.updateMe({ full_name: match.full_name }); } catch {}
    }

    sessionStorage.setItem(SESSION_KEY, "true");
    sessionStorage.setItem(ROLE_KEY, match.role || "user");
    setMatchedRole(match.role || "user");
    setSuccess(true);
    setLoading(false);

    setTimeout(() => window.location.reload(), 1400);
  }

  // Success screen
  if (success) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="w-full max-w-sm text-center space-y-4">
          <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/30">
            <CheckCircle2 className="h-10 w-10 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Accès validé !</h2>
            <p className="text-slate-400 text-sm mt-1">
              Bienvenue, <span className="text-white font-semibold">{user.full_name || user.email}</span>
            </p>
            {matchedRole && (
              <span className="inline-block mt-2 bg-emerald-500/20 text-emerald-400 text-xs font-bold px-3 py-1 rounded-full border border-emerald-500/30">
                {ROLE_LABELS[matchedRole] || matchedRole}
              </span>
            )}
          </div>
          <p className="text-slate-500 text-xs">Redirection vers votre espace…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-emerald-600/10 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">

          {/* Header */}
          <div className="px-8 pt-8 pb-6 text-center border-b border-slate-800">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/20">
              <GraduationCap className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-black text-white tracking-widest">BOHAN</h1>
            <p className="text-slate-400 text-xs uppercase tracking-widest mt-1">Plateforme scolaire numérique</p>
          </div>

          {/* Body */}
          <div className="p-8 space-y-6">

            {/* Connected user badge */}
            <div className="flex items-center gap-3 bg-slate-800/60 border border-slate-700 rounded-2xl px-4 py-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center text-white font-bold text-sm shrink-0">
                {(user.full_name || user.email || "?")[0].toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-white text-sm font-semibold truncate">{user.full_name || user.email}</p>
                <p className="text-slate-400 text-xs truncate">{user.email}</p>
              </div>
              <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
            </div>

            <div className="space-y-1">
              <h2 className="text-white font-bold text-lg">Validation des accès</h2>
              <p className="text-slate-400 text-sm">Saisissez les identifiants remis par votre administrateur d'établissement.</p>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-start gap-3 bg-red-500/10 border border-red-500/30 rounded-2xl px-4 py-3">
                <AlertCircle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
                <p className="text-red-300 text-sm">{error}</p>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                  <KeyRound className="h-3.5 w-3.5 text-slate-400" />
                  Code d'accès permanent
                </label>
                <input
                  value={accessId}
                  onChange={(e) => { setAccessId(e.target.value); setError(""); }}
                  placeholder="Ex: PROF-CIB-26KON-150492-03"
                  required
                  autoComplete="off"
                  className="w-full bg-slate-800 border border-slate-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 text-sm font-mono outline-none transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                  <Lock className="h-3.5 w-3.5 text-slate-400" />
                  Mot de passe initial
                </label>
                <div className="relative">
                  <input
                    type={showPwd ? "text" : "password"}
                    value={password}
                    onChange={(e) => { setPassword(e.target.value); setError(""); }}
                    placeholder="••••••••••"
                    required
                    autoComplete="off"
                    className="w-full bg-slate-800 border border-slate-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 pr-12 text-sm font-mono outline-none transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPwd(p => !p)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors p-1"
                  >
                    {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || !accessId.trim() || !password.trim()}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-xl py-3.5 transition-all shadow-lg shadow-blue-600/25"
              >
                {loading ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Vérification…</>
                ) : (
                  <><ArrowRight className="h-4 w-4" /> Se connecter</>
                )}
              </button>
            </form>

            {/* Help */}
            <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-4 space-y-2">
              <p className="text-slate-400 text-xs font-semibold uppercase tracking-wide">Comment obtenir vos identifiants ?</p>
              <div className="space-y-1.5 text-xs text-slate-500">
                <p>① Votre administrateur crée votre compte depuis la page <strong className="text-slate-400">Inscription</strong>.</p>
                <p>② Il vous remet une fiche avec votre <strong className="text-slate-400">code d'accès</strong> et votre <strong className="text-slate-400">mot de passe initial</strong>.</p>
                <p>③ Saisissez ces informations ici pour activer votre accès.</p>
              </div>
            </div>

            <div className="text-center">
              <button
                onClick={() => { clearAccessVerified(); base44.auth.logout(); }}
                className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-1.5 mx-auto transition-colors"
              >
                <LogOut className="h-3.5 w-3.5" /> Changer de compte Google
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-slate-600 text-xs mt-4">
          BOHAN — Gestion scolaire numérique · {new Date().getFullYear()}
        </p>
      </div>
    </div>
  );
}