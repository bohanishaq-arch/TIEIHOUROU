import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { GraduationCap, AlertCircle, Loader2, CheckCircle, X } from "lucide-react";
import { getSchoolId, getSchoolName } from "../hooks/useSchool";

export default function TeacherRegistrationForm() {
  const [form, setForm] = useState({
    first_name: "",
    last_name: "",
    email: "",
    subjects_taught: "",
    message: "",
    school_license: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [schoolSubjects, setSchoolSubjects] = useState([]);
  const [selectedSubjects, setSelectedSubjects] = useState([]);

  // Auto-load subjects when school license is entered
  useEffect(() => {
    async function loadSubjects() {
      try {
        const schools = await base44.entities.School.filter({ license_key: form.school_license.trim() });
        if (schools[0]) {
          const subjects = await base44.entities.Subject.filter({ school_id: schools[0].id });
          setSchoolSubjects(subjects || []);
        }
      } catch {
        setSchoolSubjects([]);
      }
    }
    if (form.school_license.trim().length >= 3) {
      loadSubjects();
    } else {
      setSchoolSubjects([]);
      setSelectedSubjects([]);
    }
  }, [form.school_license]);

  function toggleSubject(subId, subName) {
    setSelectedSubjects(prev => {
      const isSelected = prev.some(s => s.id === subId);
      let newSelected;
      if (isSelected) {
        newSelected = prev.filter(s => s.id !== subId);
      } else {
        newSelected = [...prev, { id: subId, name: subName }];
      }
      setForm(f => ({...f, subjects_taught: newSelected.map(s => s.name).join(", ")}));
      return newSelected;
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      // Verify school license key
      const schools = await base44.entities.School.filter({ license_key: form.school_license.trim() });
      const school = schools[0];
      if (!school) {
        setError("Code d'établissement invalide.");
        setLoading(false);
        return;
      }

      // Generate access credentials
      function generateAccessId() {
        return `PROF-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
      }
      function generatePassword() {
        return Math.random().toString(36).substr(2, 12);
      }
      
      const accessId = generateAccessId();
      const password = generatePassword();
      const fullName = `${form.first_name.trim()} ${form.last_name.trim()}`;
      
      // Create AppAccess for immediate access
      await base44.entities.AppAccess.create({
        user_email: form.email.toLowerCase().trim(),
        full_name: fullName,
        access_id: accessId,
        access_password: password,
        role: "teacher",
        is_active: true,
        school_id: school.id,
        school_name: school.name,
      });

      setSuccess(true);
      setForm({ first_name: "", last_name: "", email: "", subjects_taught: "", message: "", school_license: "" });
      setSelectedSubjects([]);
    } catch (e) {
      setError(`Erreur : ${e?.message || "Impossible de créer la demande"}`);
    } finally {
      setLoading(false);
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl border-2 border-green-300 shadow-xl w-full max-w-md overflow-hidden">
          <div className="bg-green-600 p-6 text-center">
            <CheckCircle className="h-12 w-12 text-white mx-auto mb-3" />
            <h2 className="text-lg font-bold text-white">Bienvenue!</h2>
          </div>
          <div className="p-6 space-y-4">
            <p className="text-foreground font-medium">Votre compte est activé.</p>
            <p className="text-sm text-muted-foreground">
              Vous pouvez maintenant accéder à votre espace professeur. En attente de vos classes et emploi du temps de la part de l'administration.
            </p>
            <p className="text-xs text-muted-foreground font-semibold mt-3">Vos identifiants ont été envoyés à votre email.</p>
            <button onClick={() => window.location.href = "https://verinote.app"} className="w-full mt-4 bg-green-600 text-white rounded-lg px-4 py-2.5 text-sm font-semibold hover:bg-green-700">
              Accéder à l'application
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-amber-600 p-6 text-center">
          <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <GraduationCap className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-xl font-bold text-white">Inscription Professeur</h1>
          <p className="text-white/80 text-xs mt-1">Plateforme VeriNote</p>
        </div>

        <div className="p-6 space-y-5">
          {error && (
            <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2.5 text-sm text-red-700">
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-foreground block mb-1">Prénom *</label>
                <input
                  type="text"
                  value={form.first_name}
                  onChange={(e) => setForm({ ...form, first_name: e.target.value })}
                  placeholder="Ex: Moustapha"
                  className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-orange-500"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-foreground block mb-1">Nom *</label>
                <input
                  type="text"
                  value={form.last_name}
                  onChange={(e) => setForm({ ...form, last_name: e.target.value })}
                  placeholder="Ex: Kone"
                  className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-orange-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-foreground block mb-1">Email *</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="votre.email@gmail.com"
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-foreground block mb-1">Code d'établissement *</label>
              <input
                type="text"
                value={form.school_license}
                onChange={(e) => setForm({ ...form, school_license: e.target.value })}
                placeholder="Code fourni par l'admin de votre école"
                className="w-full border border-input rounded-lg px-3 py-2 text-sm font-mono bg-background focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-foreground block mb-1">Matière(s) à enseigner *</label>
              {schoolSubjects.length === 0 && form.school_license && (
                <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded px-2 py-1.5 mb-2">Chargement des matières...</p>
              )}
              {schoolSubjects.length > 0 ? (
                <div className="space-y-2">
                  <div className="flex flex-wrap gap-2">
                    {schoolSubjects.map(s => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => toggleSubject(s.id, s.name)}
                        className={`text-xs px-3 py-2 rounded-lg border-2 font-medium transition-all ${
                          selectedSubjects.some(sel => sel.id === s.id)
                            ? "bg-orange-600 text-white border-orange-600"
                            : "bg-white border-orange-300 text-orange-700 hover:bg-orange-100"
                        }`}
                      >
                        {s.name}
                      </button>
                    ))}
                  </div>
                  {selectedSubjects.length > 0 && (
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-2.5">
                      <p className="text-xs font-semibold text-orange-900 mb-2">Sélectionnée(s):</p>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedSubjects.map(s => (
                          <span key={s.id} className="inline-flex items-center gap-1 bg-orange-100 text-orange-700 px-2.5 py-1 rounded-lg text-xs font-medium">
                            {s.name}
                            <button type="button" onClick={() => toggleSubject(s.id, s.name)} className="hover:text-orange-900">
                              <X className="h-3 w-3" />
                            </button>
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <input
                  type="text"
                  value={form.subjects_taught}
                  onChange={(e) => setForm({ ...form, subjects_taught: e.target.value })}
                  placeholder="Saisissez vos matières (ex: Français, Histoire)"
                  className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              )}
            </div>



            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-orange-600 text-white rounded-lg px-4 py-2.5 text-sm font-semibold hover:bg-orange-700 transition-colors disabled:opacity-60"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <GraduationCap className="h-4 w-4" />}
              {loading ? "Inscription en cours…" : "S'inscrire"}
            </button>
          </form>

          <p className="text-center text-xs text-muted-foreground">
            Un administrateur validera votre inscription. Vous recevrez vos identifiants par email.
          </p>
        </div>
      </div>
    </div>
  );
}