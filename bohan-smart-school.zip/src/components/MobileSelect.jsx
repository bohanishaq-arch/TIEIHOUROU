/**
 * MobileSelect — renders a native <select> on desktop and a Vaul Bottom Sheet on mobile.
 * Props match a standard <select>:
 *   value, onChange(value), options: [{value, label}], placeholder, disabled, label
 */
import { useState } from "react";
import { Drawer } from "vaul";
import { Check, ChevronDown } from "lucide-react";

export default function MobileSelect({ value, onChange, options = [], placeholder = "Choisir…", disabled = false, className = "" }) {
  const [open, setOpen] = useState(false);
  const selected = options.find(o => o.value === value);

  // Desktop: plain native select
  return (
    <>
      {/* Desktop select — hidden on mobile */}
      <select
        value={value}
        onChange={e => onChange(e.target.value)}
        disabled={disabled}
        className={`hidden sm:block w-full h-9 rounded-lg border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50 ${className}`}
      >
        <option value="">{placeholder}</option>
        {options.map(o => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>

      {/* Mobile trigger — visible only on mobile */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => !disabled && setOpen(true)}
        className={`sm:hidden flex items-center justify-between w-full h-11 rounded-lg border border-input bg-background px-3 text-sm disabled:opacity-50 ${className}`}
      >
        <span className={selected ? "text-foreground" : "text-muted-foreground"}>
          {selected ? selected.label : placeholder}
        </span>
        <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
      </button>

      {/* Vaul Drawer — mobile only */}
      <Drawer.Root open={open} onOpenChange={setOpen}>
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 bg-black/40 z-50" />
          <Drawer.Content className="fixed bottom-0 left-0 right-0 z-50 flex flex-col bg-background rounded-t-2xl max-h-[70vh]"
            style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
            {/* Handle */}
            <div className="mx-auto mt-3 mb-2 w-10 h-1 rounded-full bg-border shrink-0" />

            <div className="overflow-y-auto px-2 pb-4">
              {/* Placeholder/cancel row */}
              <button
                onClick={() => { onChange(""); setOpen(false); }}
                className="flex items-center justify-between w-full px-4 py-3.5 rounded-xl text-sm text-muted-foreground hover:bg-muted transition-colors"
              >
                <span>{placeholder}</span>
              </button>

              {options.map(o => (
                <button
                  key={o.value}
                  onClick={() => { onChange(o.value); setOpen(false); }}
                  className={`flex items-center justify-between w-full px-4 py-3.5 rounded-xl text-sm font-medium transition-colors ${
                    value === o.value ? "bg-primary/10 text-primary" : "hover:bg-muted text-foreground"
                  }`}
                >
                  <span>{o.label}</span>
                  {value === o.value && <Check className="h-4 w-4 shrink-0" />}
                </button>
              ))}
            </div>
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
    </>
  );
}