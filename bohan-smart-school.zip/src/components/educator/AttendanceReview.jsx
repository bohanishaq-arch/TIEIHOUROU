import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { CheckCircle2, XCircle, Clock, Edit2, Save, X, Star, ChevronDown, ChevronRight, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

// Conduire note: 18/20 pour 0 heure d'absence, diminue proportionnellement
// Formule: note = max(0, 18 - (totalAbsenceHours / maxAbsenceHours) * 18)
// maxAbsenceHours = nombre total d'heures de cours dans l'année
function computeConductScore(absenceHours, totalCourseHours) {
  if (!totalCourseHours || totalCourseHours <= 0) return 18;
  const ratio = Math.min(1, absenceHours / totalCourseHours);
  return Math.max(0, Math.round((18 * (1 - ratio)) * 10) / 10);
}

function scoreBg(v) {
  if (v >= 14) return "bg-green-100 text-green-700 border-green-300";
  if (v >= 10) return "bg-amber-100 text-amber-700 border-amber-300";
  return "bg-red-100 text-red-700 border-red-300";
}

export default function AttendanceReview() {
  const { user } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [students, setStudents] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState("soumis");
  const [expandedSession, setExpandedSession] = useState(null);
  const [editingRecord, setEditingRecord] = useState(null); // { sessionId, studentId, field, value }
  const [conductTab, setConductTab] = useState(null); // classId for conduct view

  const schoolId = getSchoolId();

  async function load() {
    const f = schoolId ? { school_id: schoolId } : {};
    const [sess, stud, cls] = await Promise.all([
      base44.entities.AttendanceSession.filter(f, "-date", 200),
      base44.entities.Student.filter(f),
      base44.entities.Class.filter(f),
    ]);
    setSessions(sess);
    setStudents(stud);
    setClasses(cls);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function markTreated(sessionId) {
    await base44.entities.AttendanceSession.update(sessionId, { status: "traité" });
    setSessions(prev => prev.map(s => s.id === sessionId ? { ...s, status: "traité" } : s));
    toast.success("Rapport marqué comme traité.");
  }

  async function justifyAbsence(sessionId, studentId, newStatus, arrivalTime) {
    const session = sessions.find(s => s.id === sessionId);
    if (!session) return;
    const updatedRecords = session.records.map(r =>
      r.student_id === studentId
        ? { ...r, status: newStatus, arrival_time: arrivalTime || r.arrival_time, note: "Justifié par éducateur" }
        : r
    );
    await base44.entities.AttendanceSession.update(sessionId, { records: updatedRecords });

    // Also update the Absence record in the main Absence entity
    const absences = await base44.entities.Absence.filter({ student_id: studentId });
    const targetDate = session.date;
    const abs = absences.find(a => a.date === targetDate && a.period === session.subject_name);
    if (abs) {
      await base44.entities.Absence.update(abs.id, {
        type: newStatus === "present" ? "justifié" : newStatus === "retard" ? "retard" : "absent",
        arrival_time: arrivalTime || abs.arrival_time,
      });
    }

    setSessions(prev => prev.map(s => s.id === sessionId ? { ...s, records: updatedRecords } : s));
    setEditingRecord(null);
    toast.success("Présence mise à jour.");
  }

  // Compute conduct data per class
  function computeClassConduct(classId) {
    const classStudents = students.filter(s => s.class_id === classId);
    const classSessions = sessions.filter(s => s.class_id === classId && s.status !== "brouillon");
    const totalCourseHours = classSessions.reduce((sum, s) => sum + (s.duration_minutes || 60), 0) / 60;

    return classStudents.map(student => {
      let absenceHours = 0;
      let lateCount = 0;
      classSessions.forEach(sess => {
        const rec = sess.records?.find(r => r.student_id === student.id);
        if (!rec) return;
        if (rec.status === "absent") absenceHours += (sess.duration_minutes || 60) / 60;
        if (rec.status === "retard") lateCount++;
      });
      const conductScore = computeConductScore(absenceHours, totalCourseHours);
      return {
        student,
        absenceHours: Math.round(absenceHours * 10) / 10,
        lateCount,
        totalCourseHours: Math.round(totalCourseHours * 10) / 10,
        conductScore,
      };
    }).sort((a, b) => b.conductScore - a.conductScore);
  }

  const filteredSessions = sessions.filter(s => filterStatus === "all" || s.status === filterStatus);
  const newCount = sessions.filter(s => s.status === "soumis").length;

  if (loading) return <div className="flex justify-center py-10"><div className="w-7 h-7 border-4 border-teal-200 border-t-teal-600 rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      {/* Tabs: Reports | Conduct */}
      <div className="flex gap-2 border-b border-border">
        <button onClick={() => setConductTab(null)}
          className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${!conductTab ? "border-teal-600 text-teal-700" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
          Rapports de présence {newCount > 0 && <span className="ml-1.5 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{newCount}</span>}
        </button>
        <button onClick={() => setConductTab("select")}
          className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${conductTab ? "border-teal-600 text-teal-700" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
          Note de conduite
        </button>
      </div>

      {/* CONDUCT TAB */}
      {conductTab && (
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Sélectionner une classe</label>
            <select value={conductTab === "select" ? "" : conductTab}
              onChange={e => setConductTab(e.target.value)}
              className="h-9 rounded-md border border-input bg-background px-3 text-sm">
              <option value="">— Choisir une classe —</option>
              {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          {conductTab && conductTab !== "select" && (() => {
            const conductData = computeClassConduct(conductTab);
            const cls = classes.find(c => c.id === conductTab);
            return (
              <div className="space-y-3">
                <div className="bg-teal-50 border border-teal-200 rounded-xl p-3 text-sm text-teal-800">
                  <p className="font-bold mb-1">📊 Algorithme de conduite — {cls?.name}</p>
                  <p className="text-xs">Élève présent toute l'année = <strong>18/20</strong>. La note diminue proportionnellement aux heures d'absence.</p>
                  <p className="text-xs mt-0.5">Formule : <code className="bg-teal-100 px-1 rounded">note = 18 × (1 − absences_h / total_heures_cours)</code></p>
                </div>

                {conductData.length === 0 ? (
                  <p className="text-center text-sm text-muted-foreground py-8">Aucun élève dans cette classe.</p>
                ) : (
                  <div className="space-y-2">
                    {conductData.map(({ student, absenceHours, lateCount, totalCourseHours, conductScore }, idx) => (
                      <div key={student.id} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center text-teal-700 font-bold text-sm shrink-0">
                          {idx + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-foreground text-sm">{student.last_name} {student.first_name}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {absenceHours}h d'absence · {lateCount} retard(s) · {totalCourseHours}h de cours au total
                          </p>
                        </div>
                        <div className={`text-center border rounded-xl px-4 py-2 min-w-[80px] shrink-0 ${scoreBg(conductScore)}`}>
                          <p className="text-lg font-bold">{conductScore}</p>
                          <p className="text-[10px] font-medium">/20</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      )}

      {/* REPORTS TAB */}
      {!conductTab && (
        <div className="space-y-4">
          {/* Filter */}
          <div className="flex gap-2 flex-wrap">
            {[
              { v: "soumis", label: `Nouveaux (${sessions.filter(s=>s.status==="soumis").length})` },
              { v: "traité", label: `Traités (${sessions.filter(s=>s.status==="traité").length})` },
              { v: "all", label: `Tous (${sessions.length})` },
            ].map(({ v, label }) => (
              <button key={v} onClick={() => setFilterStatus(v)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filterStatus === v ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}>
                {label}
              </button>
            ))}
          </div>

          {filteredSessions.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="h-10 w-10 mx-auto mb-2 opacity-30" />
              <p>Aucun rapport pour ce filtre.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredSessions.map(session => {
                const isExpanded = expandedSession === session.id;
                const absent = session.records?.filter(r => r.status === "absent") || [];
                const retard = session.records?.filter(r => r.status === "retard") || [];
                const present = session.records?.filter(r => r.status === "present") || [];

                return (
                  <div key={session.id} className="bg-card border border-border rounded-2xl overflow-hidden">
                    {/* Session header */}
                    <button
                      onClick={() => setExpandedSession(isExpanded ? null : session.id)}
                      className="w-full flex items-center gap-4 px-5 py-4 hover:bg-muted/20 transition-colors text-left"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-bold text-foreground text-sm">{session.class_name} — {session.subject_name}</p>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${session.status === "traité" ? "bg-green-100 text-green-700" : "bg-blue-100 text-blue-700"}`}>
                            {session.status === "traité" ? "✓ Traité" : "📨 Nouveau"}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Prof : {session.teacher_name} · {session.date ? new Date(session.date).toLocaleDateString("fr-FR", { weekday: "short", day: "2-digit", month: "short" }) : "—"}
                          {session.time_slot ? ` · ${session.time_slot}` : ""}
                        </p>
                        <div className="flex gap-3 mt-1 text-xs">
                          <span className="text-emerald-700 font-semibold">{present.length} présents</span>
                          {absent.length > 0 && <span className="text-red-600 font-semibold">{absent.length} absents</span>}
                          {retard.length > 0 && <span className="text-amber-600 font-semibold">{retard.length} retards</span>}
                        </div>
                      </div>
                      {isExpanded ? <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" /> : <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />}
                    </button>

                    {/* Expanded detail */}
                    {isExpanded && (
                      <div className="border-t border-border px-5 pb-5 space-y-3 pt-3">
                        {/* Absent/late list with edit capability */}
                        {(absent.length > 0 || retard.length > 0) && (
                          <div>
                            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
                              Absents & Retards ({absent.length + retard.length})
                            </p>
                            <div className="space-y-2">
                              {[...absent, ...retard].map(rec => {
                                const isEditing = editingRecord?.sessionId === session.id && editingRecord?.studentId === rec.student_id;
                                return (
                                  <div key={rec.student_id} className={`rounded-xl border p-3 ${rec.status === "absent" ? "bg-red-50 border-red-200" : "bg-amber-50 border-amber-200"}`}>
                                    <div className="flex items-center gap-3">
                                      <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${rec.status === "absent" ? "bg-red-500" : "bg-amber-500"}`} />
                                      <p className="text-sm font-semibold text-foreground flex-1">{rec.student_name}</p>
                                      <span className={`text-xs font-bold ${rec.status === "absent" ? "text-red-700" : "text-amber-700"}`}>
                                        {rec.status === "absent" ? "Absent" : "Retard"}{rec.arrival_time ? ` (${rec.arrival_time})` : ""}
                                      </span>
                                      {!isEditing && session.status !== "traité" && (
                                        <button onClick={() => setEditingRecord({ sessionId: session.id, studentId: rec.student_id, status: rec.status, arrivalTime: rec.arrival_time || "" })}
                                          className="ml-1 p-1 rounded-lg hover:bg-white text-muted-foreground hover:text-foreground transition-colors">
                                          <Edit2 className="h-3.5 w-3.5" />
                                        </button>
                                      )}
                                    </div>
                                    {rec.note && <p className="text-xs text-muted-foreground mt-1 italic">{rec.note}</p>}

                                    {/* Edit form */}
                                    {isEditing && (
                                      <div className="mt-3 space-y-2 border-t border-dashed pt-3">
                                        <p className="text-xs font-semibold text-muted-foreground">Modifier le statut (justification éducateur)</p>
                                        <div className="flex gap-2 flex-wrap">
                                          {[
                                            { v: "present", label: "✅ Présent (justifié)", color: "bg-emerald-100 border-emerald-300 text-emerald-700" },
                                            { v: "retard", label: "🟡 Retard", color: "bg-amber-100 border-amber-300 text-amber-700" },
                                            { v: "absent", label: "🔴 Absent", color: "bg-red-100 border-red-300 text-red-700" },
                                          ].map(opt => (
                                            <button key={opt.v} onClick={() => setEditingRecord(prev => ({ ...prev, status: opt.v }))}
                                              className={`px-2.5 py-1 rounded-lg border text-xs font-medium transition-all ${editingRecord.status === opt.v ? opt.color + " shadow-sm" : "border-border text-muted-foreground hover:bg-muted"}`}>
                                              {opt.label}
                                            </button>
                                          ))}
                                        </div>
                                        {editingRecord.status === "retard" && (
                                          <input type="time" value={editingRecord.arrivalTime}
                                            onChange={e => setEditingRecord(prev => ({ ...prev, arrivalTime: e.target.value }))}
                                            className="h-8 rounded-md border border-input bg-background px-3 text-sm" />
                                        )}
                                        <div className="flex gap-2">
                                          <button onClick={() => justifyAbsence(session.id, rec.student_id, editingRecord.status, editingRecord.arrivalTime)}
                                            className="flex items-center gap-1 bg-teal-600 text-white text-xs font-semibold px-3 py-1.5 rounded-lg hover:bg-teal-700 transition-colors">
                                            <Save className="h-3.5 w-3.5" /> Enregistrer
                                          </button>
                                          <button onClick={() => setEditingRecord(null)}
                                            className="flex items-center gap-1 border border-border text-xs font-medium px-3 py-1.5 rounded-lg hover:bg-muted transition-colors">
                                            <X className="h-3.5 w-3.5" /> Annuler
                                          </button>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        {absent.length === 0 && retard.length === 0 && (
                          <p className="text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center">
                            ✅ Tous les élèves étaient présents.
                          </p>
                        )}

                        {/* Mark as treated */}
                        {session.status === "soumis" && (
                          <Button onClick={() => markTreated(session.id)} size="sm" className="w-full gap-2 bg-teal-600 hover:bg-teal-700">
                            <CheckCircle2 className="h-4 w-4" /> Marquer comme traité
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}