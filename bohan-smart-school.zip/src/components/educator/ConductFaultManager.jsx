import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { Plus, Trash2, Edit2, Check, X, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";

const SEVERITY_COLORS = {
  léger: "bg-yellow-100 text-yellow-700 border-yellow-200",
  moyen: "bg-orange-100 text-orange-700 border-orange-200",
  grave: "bg-red-100 text-red-700 border-red-200",
};

const DEFAULT_FAULTS = [
  { label: "Bavardage en classe", points_deducted: 0.5, severity: "léger", description: "Perturbation légère du cours" },
  { label: "Retard répété", points_deducted: 1, severity: "léger", description: "Plus de 3 retards non justifiés" },
  { label: "Insolence envers un professeur", points_deducted: 2, severity: "moyen", description: "Manque de respect verbal" },
  { label: "Utilisation téléphone interdit", points_deducted: 1, severity: "léger", description: "Usage du téléphone pendant les cours" },
  { label: "Triche ou tentative de triche", points_deducted: 5, severity: "grave", description: "Fraude lors d'un examen ou devoir" },
  { label: "Violence verbale", points_deducted: 3, severity: "moyen", description: "Insultes ou propos agressifs" },
  { label: "Violence physique", points_deducted: 10, severity: "grave", description: "Bagarre ou agression physique" },
  { label: "Dégradation de matériel", points_deducted: 4, severity: "moyen", description: "Détérioration volontaire du matériel scolaire" },
  { label: "Absence injustifiée prolongée", points_deducted: 2, severity: "moyen", description: "Plus de 2 jours d'absence sans justificatif" },
  { label: "Comportement irrespectueux", points_deducted: 1.5, severity: "léger", description: "Attitude déplacée envers les autres élèves" },
];

export default function ConductFaultManager() {
  const [faults, setFaults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ label: "", description: "", points_deducted: 1, severity: "léger" });
  const [saving, setSaving] = useState(false);
  const [seeding, setSeeding] = useState(false);

  async function load() {
    const schoolId = getSchoolId();
    const list = await base44.entities.ConductFault.filter(schoolId ? { school_id: schoolId } : {});
    setFaults(list);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleSeed() {
    setSeeding(true);
    const schoolId = getSchoolId();
    await Promise.all(DEFAULT_FAULTS.map(f =>
      base44.entities.ConductFault.create({ ...f, school_id: schoolId, is_active: true })
    ));
    setSeeding(false);
    load();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    const schoolId = getSchoolId();
    if (editId) {
      await base44.entities.ConductFault.update(editId, { ...form });
    } else {
      await base44.entities.ConductFault.create({ ...form, school_id: schoolId, is_active: true });
    }
    setSaving(false);
    setShowForm(false);
    setEditId(null);
    setForm({ label: "", description: "", points_deducted: 1, severity: "léger" });
    load();
  }

  function startEdit(fault) {
    setEditId(fault.id);
    setForm({ label: fault.label, description: fault.description || "", points_deducted: fault.points_deducted, severity: fault.severity });
    setShowForm(true);
  }

  async function handleDelete(id) {
    if (!confirm("Supprimer cette faute ?")) return;
    await base44.entities.ConductFault.delete(id);
    load();
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-bold text-foreground flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-orange-500" /> Liste des fautes disciplinaires
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">Ces fautes sont utilisées lors de la confirmation d'indiscipline pour déduire les points de conduite.</p>
        </div>
        <div className="flex gap-2">
          {faults.length === 0 && (
            <Button variant="outline" size="sm" onClick={handleSeed} disabled={seeding}>
              {seeding ? "Chargement…" : "Charger fautes par défaut"}
            </Button>
          )}
          <Button size="sm" onClick={() => { setShowForm(!showForm); setEditId(null); setForm({ label: "", description: "", points_deducted: 1, severity: "léger" }); }} className="gap-2">
            <Plus className="h-4 w-4" /> Ajouter
          </Button>
        </div>
      </div>

      {/* Info règle */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-700 space-y-1">
        <p className="font-semibold">📋 Règle de calcul de la note de conduite</p>
        <p>• Note de base : <strong>20/20</strong></p>
        <p>• Absences (non justifiées) : <strong>24h = −5 pts</strong> × 40% de pondération</p>
        <p>• Indiscipline confirmée : <strong>−points faute</strong> × 60% de pondération</p>
        <p className="font-mono bg-blue-100 rounded px-2 py-1 mt-1">Note finale = 20 − (h÷24×5)×0.4 − Σ(pts_fautes)×0.6</p>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-card border border-border rounded-xl p-5 space-y-4">
          <h4 className="font-semibold text-sm">{editId ? "Modifier la faute" : "Nouvelle faute"}</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2">
              <label className="text-xs font-medium text-muted-foreground block mb-1">Intitulé de la faute *</label>
              <input value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} required
                placeholder="Ex: Violence verbale, Triche…"
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Points retirés (0.5 – 10) *</label>
              <input type="number" min="0.5" max="10" step="0.5" value={form.points_deducted}
                onChange={e => setForm(f => ({ ...f, points_deducted: parseFloat(e.target.value) }))} required
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Gravité *</label>
              <select value={form.severity} onChange={e => setForm(f => ({ ...f, severity: e.target.value }))}
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm">
                <option value="léger">🟡 Léger</option>
                <option value="moyen">🟠 Moyen</option>
                <option value="grave">🔴 Grave</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-medium text-muted-foreground block mb-1">Description</label>
              <input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="Description optionnelle…"
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" size="sm" onClick={() => { setShowForm(false); setEditId(null); }}>Annuler</Button>
            <Button type="submit" size="sm" disabled={saving}>{saving ? "Enregistrement…" : editId ? "Modifier" : "Ajouter"}</Button>
          </div>
        </form>
      )}

      {loading ? (
        <div className="p-8 text-center"><div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" /></div>
      ) : faults.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground text-sm">
          Aucune faute enregistrée. Cliquez sur "Charger fautes par défaut" pour démarrer.
        </div>
      ) : (
        <div className="space-y-2">
          {faults.map(fault => (
            <div key={fault.id} className={`flex items-center gap-3 p-3 rounded-xl border ${SEVERITY_COLORS[fault.severity] || SEVERITY_COLORS.léger}`}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-sm">{fault.label}</p>
                  <span className="text-xs font-bold bg-white/60 rounded-full px-2 py-0.5">−{fault.points_deducted} pt{fault.points_deducted > 1 ? "s" : ""}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-white/40">{fault.severity}</span>
                </div>
                {fault.description && <p className="text-xs mt-0.5 opacity-70">{fault.description}</p>}
              </div>
              <div className="flex gap-1 shrink-0">
                <button onClick={() => startEdit(fault)} className="p-1.5 rounded-lg hover:bg-white/50 transition-colors">
                  <Edit2 className="h-3.5 w-3.5" />
                </button>
                <button onClick={() => handleDelete(fault.id)} className="p-1.5 rounded-lg hover:bg-red-100 transition-colors">
                  <Trash2 className="h-3.5 w-3.5 text-red-600" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}