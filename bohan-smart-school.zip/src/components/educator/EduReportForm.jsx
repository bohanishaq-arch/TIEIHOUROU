import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { Send, History, CheckCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const TYPE_OPTIONS = [
  { value: "quotidien", label: "📋 Rapport quotidien" },
  { value: "incident", label: "⚠️ Rapport d'incident" },
  { value: "alerte", label: "🚨 Alerte urgente" },
  { value: "autre", label: "📄 Autre" },
];

export default function EduReportForm({ onClose }) {
  const { user } = useAuth();
  const [view, setView] = useState("form");
  const [history, setHistory] = useState([]);
  const [loadingHist, setLoadingHist] = useState(false);
  const [form, setForm] = useState({
    report_type: "quotidien",
    title: "",
    content: "",
    date: new Date().toISOString().slice(0, 10),
  });
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (view === "history") {
      setLoadingHist(true);
      base44.entities.EducatorReport.filter({ educator_email: user?.email }, "-date", 100)
        .then(r => { setHistory(r); setLoadingHist(false); });
    }
  }, [view, user?.email]);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    await base44.entities.EducatorReport.create({
      ...form,
      school_id: getSchoolId(),
      educator_email: user?.email,
      educator_name: user?.full_name || user?.email,
      status: "envoyé",
    });
    setSaving(false);
    setDone(true);
  }

  if (done) {
    return (
      <div className="flex flex-col items-center gap-4 py-12">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
          <CheckCircle className="h-8 w-8 text-green-600" />
        </div>
        <h3 className="font-bold text-foreground">Rapport envoyé au proviseur !</h3>
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => { setDone(false); setForm({ report_type: "quotidien", title: "", content: "", date: new Date().toISOString().slice(0, 10) }); }}>Nouveau rapport</Button>
          <Button variant="outline" onClick={() => { setDone(false); setView("history"); }}><History className="h-4 w-4 mr-1" /> Historique</Button>
          <Button onClick={onClose}>Fermer</Button>
        </div>
      </div>
    );
  }

  if (view === "history") {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold flex items-center gap-2"><History className="h-5 w-5" /> Mes rapports</h3>
          <Button size="sm" variant="outline" onClick={() => setView("form")}>+ Nouveau</Button>
        </div>
        {loadingHist ? (
          <div className="p-10 text-center"><div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" /></div>
        ) : history.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-10">Aucun rapport envoyé.</p>
        ) : (
          <div className="space-y-3">
            {history.map(r => (
              <div key={r.id} className={`rounded-xl border p-4 ${r.status === "traité" ? "border-green-200 bg-green-50/20" : "border-border bg-card"}`}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold text-foreground">{r.title}</p>
                    <p className="text-xs text-muted-foreground">{r.report_type} · {r.date && new Date(r.date).toLocaleDateString("fr-FR")}</p>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{r.content}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium shrink-0 ${r.status === "traité" ? "bg-green-100 text-green-700" : r.status === "lu" ? "bg-blue-100 text-blue-700" : "bg-amber-100 text-amber-700"}`}>
                    {r.status}
                  </span>
                </div>
                {r.director_response && (
                  <div className="mt-3 pt-3 border-t border-border">
                    <p className="text-xs font-semibold text-muted-foreground mb-1">Réponse du proviseur :</p>
                    <p className="text-sm text-foreground bg-muted/40 rounded-lg px-3 py-2">{r.director_response}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="flex gap-2 border-b border-border pb-3">
        <button type="button" onClick={() => setView("form")} className="text-sm font-medium text-primary border-b-2 border-primary pb-1 px-1">Nouveau rapport</button>
        <button type="button" onClick={() => setView("history")} className="text-sm font-medium text-muted-foreground hover:text-foreground px-1"><History className="h-3.5 w-3.5 inline mr-1" />Historique</button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="text-sm font-medium text-foreground block mb-1">Type de rapport</label>
          <Select value={form.report_type} onValueChange={v => setForm(f => ({ ...f, report_type: v }))}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{TYPE_OPTIONS.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-sm font-medium text-foreground block mb-1">Date</label>
          <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
            className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
        </div>
        <div>
          <label className="text-sm font-medium text-foreground block mb-1">Titre *</label>
          <input type="text" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required
            placeholder="Titre du rapport…" className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
        </div>
      </div>

      <div>
        <label className="text-sm font-medium text-foreground block mb-1">Contenu *</label>
        <textarea value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} required
          className="w-full min-h-[140px] rounded-md border border-input bg-background px-3 py-2 text-sm resize-y"
          placeholder="Décrivez les événements, observations, situations du jour…" />
      </div>

      <div className="flex justify-end gap-3 pt-2 border-t border-border">
        <Button type="button" variant="outline" onClick={onClose}>Annuler</Button>
        <Button type="submit" disabled={saving || !form.title || !form.content} className="gap-2">
          <Send className="h-4 w-4" /> {saving ? "Envoi…" : "Envoyer au proviseur"}
        </Button>
      </div>
    </form>
  );
}