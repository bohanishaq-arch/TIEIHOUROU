import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { Star, TrendingDown, Users, Filter } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

function getScoreColor(score) {
  if (score >= 16) return { bg: "bg-green-100", text: "text-green-700", bar: "bg-green-500" };
  if (score >= 12) return { bg: "bg-yellow-100", text: "text-yellow-700", bar: "bg-yellow-500" };
  if (score >= 8)  return { bg: "bg-orange-100", text: "text-orange-700", bar: "bg-orange-500" };
  return { bg: "bg-red-100", text: "text-red-700", bar: "bg-red-500" };
}

export default function ConductScoreViewer({ students, classes }) {
  const [scores, setScores] = useState([]);
  const [absences, setAbsences] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterClass, setFilterClass] = useState("all");

  useEffect(() => {
    const schoolId = getSchoolId();
    const f = schoolId ? { school_id: schoolId } : {};
    Promise.all([
      base44.entities.ConductScore.filter(f),
      base44.entities.Absence.filter(f),
    ]).then(([sc, abs]) => {
      setScores(sc);
      setAbsences(abs);
      setLoading(false);
    });
  }, []);

  // Compute real-time scores combining DB scores + live absence hours
  const computedScores = students.map(student => {
    const dbScore = scores.find(s => s.student_id === student.id);

    // Count unjustified absence hours (each absence = 1h by default, or use duration_hours if set)
    const studentAbsences = absences.filter(a => a.student_id === student.id && a.type === "absent");
    const absenceHours = studentAbsences.reduce((sum, a) => sum + (a.duration_hours || 1), 0);

    // Absence deduction: 24h = 5 pts, weighted 40%
    const absenceRaw = (absenceHours / 24) * 5;
    const absenceDeduction = absenceRaw * 0.4;

    // Discipline deduction from DB (weighted 60% already applied when saved)
    const disciplineDeduction = dbScore?.discipline_deduction || 0;

    const finalScore = Math.max(0, 20 - absenceDeduction - disciplineDeduction);

    return {
      student,
      absenceHours,
      absenceDeduction: Math.round(absenceDeduction * 100) / 100,
      disciplineDeduction: Math.round(disciplineDeduction * 100) / 100,
      finalScore: Math.round(finalScore * 100) / 100,
      incidents: dbScore?.incidents || [],
    };
  });

  const displayed = filterClass === "all"
    ? computedScores
    : computedScores.filter(s => s.student.class_id === filterClass);

  const avgScore = displayed.length > 0
    ? Math.round(displayed.reduce((s, x) => s + x.finalScore, 0) / displayed.length * 100) / 100
    : 20;

  const atRisk = displayed.filter(s => s.finalScore < 10).length;

  if (loading) return <div className="p-8 text-center"><div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" /></div>;

  return (
    <div className="space-y-5">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-blue-700">{displayed.length}</p>
          <p className="text-xs text-blue-600 mt-0.5">Élèves</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-700">{avgScore}</p>
          <p className="text-xs text-green-600 mt-0.5">Moyenne conduite</p>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-red-700">{atRisk}</p>
          <p className="text-xs text-red-600 mt-0.5">En dessous de 10</p>
        </div>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-3">
        <Filter className="h-4 w-4 text-muted-foreground" />
        <Select value={filterClass} onValueChange={setFilterClass}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Toutes les classes" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes les classes</SelectItem>
            {classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <span className="text-xs text-muted-foreground ml-auto">{displayed.length} élève(s)</span>
      </div>

      {/* Table */}
      {displayed.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground text-sm">Aucun élève trouvé.</div>
      ) : (
        <div className="space-y-2">
          {displayed
            .sort((a, b) => a.finalScore - b.finalScore)
            .map(({ student, absenceHours, absenceDeduction, disciplineDeduction, finalScore, incidents }) => {
              const colors = getScoreColor(finalScore);
              const cls = classes.find(c => c.id === student.class_id);
              return (
                <div key={student.id} className={`rounded-xl border p-3 ${colors.bg}`}>
                  <div className="flex items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold text-sm text-foreground">{student.first_name} {student.last_name}</p>
                        <span className="text-xs text-muted-foreground">{cls?.name || student.class_id}</span>
                      </div>
                      <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                        <span className="text-xs text-muted-foreground">Absences : <strong>{absenceHours}h</strong> (−{absenceDeduction} pts)</span>
                        {disciplineDeduction > 0 && (
                          <span className="text-xs text-red-600">Indiscipline : −{disciplineDeduction} pts</span>
                        )}
                      </div>
                      {/* Progress bar */}
                      <div className="mt-2 h-1.5 bg-white/60 rounded-full overflow-hidden w-full max-w-xs">
                        <div className={`h-full rounded-full transition-all ${colors.bar}`} style={{ width: `${(finalScore / 20) * 100}%` }} />
                      </div>
                    </div>
                    <div className={`shrink-0 text-center ${colors.text}`}>
                      <p className="text-xl font-bold">{finalScore}</p>
                      <p className="text-xs">/20</p>
                    </div>
                  </div>
                  {incidents.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-white/40">
                      <p className="text-xs font-semibold text-muted-foreground mb-1">Incidents confirmés :</p>
                      <div className="flex flex-wrap gap-1">
                        {incidents.map((inc, i) => (
                          <span key={i} className="text-xs bg-white/50 border border-white/40 rounded-full px-2 py-0.5">
                            {inc.fault_label} (−{inc.points_deducted} pts)
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      )}
    </div>
  );
}