import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { AlertTriangle, Plus, ShieldX, CheckCircle, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const SEVERITY_CONFIG = {
  léger: { color: "bg-yellow-100 text-yellow-700 border-yellow-200", dot: "bg-yellow-400" },
  moyen: { color: "bg-orange-100 text-orange-700 border-orange-200", dot: "bg-orange-500" },
  grave: { color: "bg-red-100 text-red-700 border-red-200", dot: "bg-red-600" },
};

const STATUS_CONFIG = {
  signalé:       { label: "Signalé",       color: "bg-amber-100 text-amber-700" },
  en_traitement: { label: "En traitement", color: "bg-blue-100 text-blue-700" },
  résolu:        { label: "Résolu",        color: "bg-green-100 text-green-700" },
  confirmé:      { label: "Confirmé ✓",   color: "bg-red-100 text-red-700" },
};

export default function IncidentManager({ students, classes }) {
  const { user } = useAuth();
  const [incidents, setIncidents] = useState([]);
  const [faults, setFaults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [expanded, setExpanded] = useState(null);
  const [confirmModal, setConfirmModal] = useState(null); // incident being confirmed
  const [selectedFaultId, setSelectedFaultId] = useState("");
  const [confirming, setConfirming] = useState(false);
  const [form, setForm] = useState({
    student_id: "", class_id: "", date: new Date().toISOString().slice(0, 10),
    description: "", severity: "léger", proposed_sanction: "",
  });
  const [saving, setSaving] = useState(false);

  async function load() {
    const schoolId = getSchoolId();
    const f = schoolId ? { school_id: schoolId } : {};
    const [list, faultList] = await Promise.all([
      base44.entities.Incident.filter(f, "-date", 200),
      base44.entities.ConductFault.filter(f),
    ]);
    setIncidents(list);
    setFaults(faultList);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const filteredStudents = form.class_id ? students.filter(s => s.class_id === form.class_id) : students;

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    const schoolId = getSchoolId();
    const student = students.find(s => s.id === form.student_id);
    const cls = classes.find(c => c.id === form.class_id);
    await base44.entities.Incident.create({
      ...form,
      school_id: schoolId,
      student_name: student ? `${student.first_name} ${student.last_name}` : "",
      class_name: cls?.name || "",
      educator_email: user?.email,
      educator_name: user?.full_name || user?.email,
      status: "signalé",
    });
    setSaving(false);
    setShowForm(false);
    setForm({ student_id: "", class_id: "", date: new Date().toISOString().slice(0, 10), description: "", severity: "léger", proposed_sanction: "" });
    load();
  }

  // ── Confirmation d'indiscipline ──────────────────────────────────────────
  async function handleConfirmIndiscipline() {
    if (!selectedFaultId || !confirmModal) return;
    setConfirming(true);

    const fault = faults.find(f => f.id === selectedFaultId);
    if (!fault) { setConfirming(false); return; }

    const schoolId = getSchoolId();
    const today = new Date().toISOString().slice(0, 10);

    // 1. Mettre à jour le statut de l'incident
    await base44.entities.Incident.update(confirmModal.id, {
      status: "confirmé",
      director_decision: `Indiscipline confirmée : ${fault.label} (−${fault.points_deducted} pts)`,
    });

    // 2. Récupérer ou créer le ConductScore de l'élève
    const existing = await base44.entities.ConductScore.filter({
      student_id: confirmModal.student_id,
      school_id: schoolId,
    });

    const newIncidentEntry = {
      incident_id: confirmModal.id,
      fault_label: fault.label,
      points_deducted: fault.points_deducted,
      date: confirmModal.date || today,
      educator_name: user?.full_name || user?.email,
    };

    if (existing.length > 0) {
      const sc = existing[0];
      const prevIncidents = sc.incidents || [];
      // Check not already confirmed
      if (prevIncidents.some(i => i.incident_id === confirmModal.id)) {
        setConfirming(false);
        setConfirmModal(null);
        return;
      }
      const newDisciplineRaw = prevIncidents.reduce((s, i) => s + i.points_deducted, 0) + fault.points_deducted;
      const newDisciplineDeduction = newDisciplineRaw * 0.6;
      // Recalculate absence deduction from existing
      const absenceDeduction = sc.absence_deduction || 0;
      const finalScore = Math.max(0, 20 - absenceDeduction - newDisciplineDeduction);

      await base44.entities.ConductScore.update(sc.id, {
        discipline_deduction: Math.round(newDisciplineDeduction * 100) / 100,
        final_score: Math.round(finalScore * 100) / 100,
        incidents: [...prevIncidents, newIncidentEntry],
      });
    } else {
      // Create new conduct score
      const student = students.find(s => s.id === confirmModal.student_id);
      const cls = classes.find(c => c.id === confirmModal.class_id);
      const newDisciplineDeduction = fault.points_deducted * 0.6;
      const finalScore = Math.max(0, 20 - newDisciplineDeduction);

      await base44.entities.ConductScore.create({
        school_id: schoolId,
        student_id: confirmModal.student_id,
        student_name: confirmModal.student_name,
        class_id: confirmModal.class_id,
        class_name: cls?.name || confirmModal.class_name || "",
        base_score: 20,
        absence_hours: 0,
        absence_deduction: 0,
        discipline_deduction: Math.round(newDisciplineDeduction * 100) / 100,
        final_score: Math.round(finalScore * 100) / 100,
        incidents: [newIncidentEntry],
      });
    }

    setConfirming(false);
    setConfirmModal(null);
    setSelectedFaultId("");
    load();
  }

  return (
    <div className="space-y-5">
      {/* Stats */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex gap-3 flex-wrap">
          {["signalé", "confirmé", "résolu"].map(s => {
            const cnt = incidents.filter(i => i.status === s).length;
            const cfg = STATUS_CONFIG[s];
            return (
              <div key={s} className={`rounded-xl px-4 py-3 text-center border ${cfg.color}`}>
                <p className="text-lg font-bold">{cnt}</p>
                <p className="text-xs mt-0.5">{cfg.label}</p>
              </div>
            );
          })}
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus className="h-4 w-4" /> Signaler incident
        </Button>
      </div>

      {/* No faults warning */}
      {faults.length === 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-700">
          ⚠️ Aucune faute configurée. Allez dans l'onglet <strong>Fautes disciplinaires</strong> pour créer la liste des fautes avant de confirmer un incident.
        </div>
      )}

      {/* Form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="bg-card border border-border rounded-xl p-5 space-y-4">
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-orange-500" /> Signaler un incident
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Classe</label>
              <Select value={form.class_id} onValueChange={v => setForm(f => ({ ...f, class_id: v, student_id: "" }))}>
                <SelectTrigger><SelectValue placeholder="Classe" /></SelectTrigger>
                <SelectContent>{classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Élève *</label>
              <Select value={form.student_id} onValueChange={v => setForm(f => ({ ...f, student_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Choisir" /></SelectTrigger>
                <SelectContent>{filteredStudents.map(s => <SelectItem key={s.id} value={s.id}>{s.first_name} {s.last_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Gravité *</label>
              <Select value={form.severity} onValueChange={v => setForm(f => ({ ...f, severity: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="léger">🟡 Léger</SelectItem>
                  <SelectItem value="moyen">🟠 Moyen</SelectItem>
                  <SelectItem value="grave">🔴 Grave</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Date</label>
              <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-medium text-muted-foreground block mb-1">Sanction proposée</label>
              <input type="text" value={form.proposed_sanction} onChange={e => setForm(f => ({ ...f, proposed_sanction: e.target.value }))}
                placeholder="Ex: Convocation, avertissement…"
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1">Description *</label>
            <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} required
              className="w-full min-h-[80px] rounded-md border border-input bg-background px-3 py-2 text-sm resize-y"
              placeholder="Décrivez l'incident…" />
          </div>
          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Annuler</Button>
            <Button type="submit" disabled={saving || !form.student_id || !form.description}>
              {saving ? "Envoi…" : "Signaler"}
            </Button>
          </div>
        </form>
      )}

      {/* List */}
      {loading ? (
        <div className="p-10 text-center"><div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" /></div>
      ) : incidents.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">Aucun incident enregistré.</div>
      ) : (
        <div className="space-y-3">
          {incidents.map(inc => {
            const sev = SEVERITY_CONFIG[inc.severity] || SEVERITY_CONFIG.léger;
            const sta = STATUS_CONFIG[inc.status] || STATUS_CONFIG.signalé;
            const isExpanded = expanded === inc.id;
            const isConfirmed = inc.status === "confirmé";

            return (
              <div key={inc.id} className={`rounded-xl border overflow-hidden ${sev.color}`}>
                <div
                  className="flex items-start gap-3 p-4 cursor-pointer"
                  onClick={() => setExpanded(isExpanded ? null : inc.id)}
                >
                  <div className={`w-3 h-3 rounded-full mt-1 shrink-0 ${sev.dot}`} />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground text-sm">{inc.student_name}</p>
                    <p className="text-xs text-muted-foreground">{inc.class_name} · {inc.date ? new Date(inc.date).toLocaleDateString("fr-FR") : ""}</p>
                    <p className="text-sm mt-1 line-clamp-2">{inc.description}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${sta.color}`}>{sta.label}</span>
                    <span className="text-xs text-muted-foreground">{inc.severity}</span>
                    {isExpanded ? <ChevronUp className="h-3.5 w-3.5 mt-1" /> : <ChevronDown className="h-3.5 w-3.5 mt-1" />}
                  </div>
                </div>

                {isExpanded && (
                  <div className="px-4 pb-4 space-y-3 border-t border-current/10 pt-3">
                    {inc.proposed_sanction && (
                      <p className="text-xs"><span className="font-semibold">Sanction proposée :</span> {inc.proposed_sanction}</p>
                    )}
                    {inc.director_decision && (
                      <p className="text-xs bg-white/50 rounded-lg px-3 py-2">
                        <span className="font-semibold">Décision :</span> {inc.director_decision}
                      </p>
                    )}

                    {/* Confirm discipline button — only if not already confirmed */}
                    {!isConfirmed && (
                      <div className="bg-white/60 rounded-xl p-3 border border-white/40">
                        <p className="text-xs font-bold text-red-700 mb-2 flex items-center gap-1.5">
                          <ShieldX className="h-3.5 w-3.5" /> Confirmer l'indiscipline
                        </p>
                        <p className="text-xs text-muted-foreground mb-2">
                          Choisissez la faute commise. Les points seront automatiquement déduits de la note de conduite de l'élève (pondération 60%).
                        </p>
                        {faults.length === 0 ? (
                          <p className="text-xs text-amber-600">⚠️ Aucune faute configurée. Créez d'abord la liste des fautes.</p>
                        ) : (
                          <div className="flex gap-2 flex-wrap">
                            <Select
                              value={confirmModal?.id === inc.id ? selectedFaultId : ""}
                              onValueChange={v => { setConfirmModal(inc); setSelectedFaultId(v); }}
                            >
                              <SelectTrigger className="flex-1 min-w-[200px] bg-white">
                                <SelectValue placeholder="Sélectionner la faute…" />
                              </SelectTrigger>
                              <SelectContent>
                                {faults.map(f => (
                                  <SelectItem key={f.id} value={f.id}>
                                    {f.label} — −{f.points_deducted} pt{f.points_deducted > 1 ? "s" : ""}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Button
                              size="sm"
                              variant="destructive"
                              disabled={confirming || !selectedFaultId || confirmModal?.id !== inc.id}
                              onClick={() => { setConfirmModal(inc); handleConfirmIndiscipline(); }}
                              className="gap-1.5"
                            >
                              <CheckCircle className="h-3.5 w-3.5" />
                              {confirming && confirmModal?.id === inc.id ? "Traitement…" : "Confirmer"}
                            </Button>
                          </div>
                        )}
                      </div>
                    )}

                    {isConfirmed && (
                      <div className="flex items-center gap-2 text-xs text-green-700 bg-green-50 rounded-lg px-3 py-2">
                        <CheckCircle className="h-3.5 w-3.5" />
                        Indiscipline confirmée — note de conduite mise à jour
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}