import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { getSchoolId } from "../../hooks/useSchool";
import { UserCheck, UserX, Clock, Plus, CheckCircle, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const TYPE_CONFIG = {
  absent:   { label: "Absent",   icon: UserX,     color: "bg-red-100 text-red-700 border-red-200",    dot: "bg-red-500" },
  retard:   { label: "Retard",   icon: Clock,     color: "bg-amber-100 text-amber-700 border-amber-200", dot: "bg-amber-500" },
  "justifié": { label: "Justifié", icon: UserCheck, color: "bg-green-100 text-green-700 border-green-200", dot: "bg-green-500" },
};

export default function AbsenceManager({ students, classes }) {
  const { user } = useAuth();
  const [absences, setAbsences] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [filterClass, setFilterClass] = useState("all");
  const [filterDate, setFilterDate] = useState(new Date().toISOString().slice(0, 10));
  const [form, setForm] = useState({
    student_id: "", class_id: "", date: new Date().toISOString().slice(0, 10),
    type: "absent", arrival_time: "", reason: "", period: "", notes: "",
  });
  const [saving, setSaving] = useState(false);

  async function load() {
    const schoolId = getSchoolId();
    const list = await base44.entities.Absence.filter(schoolId ? { school_id: schoolId } : {}, "-date", 500);
    setAbsences(list);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    const schoolId = getSchoolId();
    const student = students.find(s => s.id === form.student_id);
    const cls = classes.find(c => c.id === form.class_id);
    await base44.entities.Absence.create({
      ...form,
      school_id: schoolId,
      student_name: student ? `${student.first_name} ${student.last_name}` : "",
      class_name: cls?.name || "",
      educator_email: user?.email,
      educator_name: user?.full_name || user?.email,
    });
    setSaving(false);
    setShowForm(false);
    setForm(f => ({ ...f, student_id: "", type: "absent", arrival_time: "", reason: "", notes: "" }));
    load();
  }

  const filteredStudents = filterClass !== "all" ? students.filter(s => s.class_id === filterClass) : students;

  const displayed = absences.filter(a => {
    if (filterClass !== "all" && a.class_id !== filterClass) return false;
    if (filterDate && a.date !== filterDate) return false;
    return true;
  });

  const todayAbsences = absences.filter(a => a.date === new Date().toISOString().slice(0, 10));
  const absentCount = todayAbsences.filter(a => a.type === "absent").length;
  const retardCount = todayAbsences.filter(a => a.type === "retard").length;

  return (
    <div className="space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-red-700">{absentCount}</p>
          <p className="text-xs text-red-600 mt-0.5">Absents aujourd'hui</p>
        </div>
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-amber-700">{retardCount}</p>
          <p className="text-xs text-amber-600 mt-0.5">Retards aujourd'hui</p>
        </div>
        <div className="bg-muted/50 rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-foreground">{absences.length}</p>
          <p className="text-xs text-muted-foreground mt-0.5">Total enregistrés</p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-3 items-center">
        <Select value={filterClass} onValueChange={setFilterClass}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Toutes les classes" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes les classes</SelectItem>
            {classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <input
          type="date"
          value={filterDate}
          onChange={e => setFilterDate(e.target.value)}
          className="h-9 rounded-md border border-input bg-background px-3 text-sm"
        />
        <Button onClick={() => setShowForm(!showForm)} className="gap-2 ml-auto">
          <Plus className="h-4 w-4" /> Enregistrer
        </Button>
      </div>

      {/* Form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="bg-card border border-border rounded-xl p-5 space-y-4">
          <h3 className="font-semibold text-foreground">Nouvel enregistrement</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Classe</label>
              <Select value={form.class_id} onValueChange={v => setForm(f => ({ ...f, class_id: v, student_id: "" }))}>
                <SelectTrigger><SelectValue placeholder="Classe" /></SelectTrigger>
                <SelectContent>{classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Élève *</label>
              <Select value={form.student_id} onValueChange={v => setForm(f => ({ ...f, student_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Choisir élève" /></SelectTrigger>
                <SelectContent>
                  {filteredStudents.map(s => <SelectItem key={s.id} value={s.id}>{s.first_name} {s.last_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Type *</label>
              <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="absent">🔴 Absent</SelectItem>
                  <SelectItem value="retard">🟡 Retard</SelectItem>
                  <SelectItem value="justifié">🟢 Justifié</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Date</label>
              <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
            </div>
            {form.type === "retard" && (
              <div>
                <label className="text-xs font-medium text-muted-foreground block mb-1">Heure d'arrivée</label>
                <input type="time" value={form.arrival_time} onChange={e => setForm(f => ({ ...f, arrival_time: e.target.value }))}
                  className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
              </div>
            )}
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Motif</label>
              <input type="text" value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))}
                placeholder="Motif de l'absence…" className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Annuler</Button>
            <Button type="submit" disabled={saving || !form.student_id}>{saving ? "Enregistrement…" : "Enregistrer"}</Button>
          </div>
        </form>
      )}

      {/* List */}
      {loading ? (
        <div className="p-10 text-center"><div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" /></div>
      ) : displayed.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">Aucune absence enregistrée pour ce filtre.</div>
      ) : (
        <div className="space-y-2">
          {displayed.map(a => {
            const cfg = TYPE_CONFIG[a.type] || TYPE_CONFIG.absent;
            return (
              <div key={a.id} className={`flex items-center gap-4 p-3 rounded-xl border ${cfg.color}`}>
                <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${cfg.dot}`} />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground text-sm">{a.student_name}</p>
                  <p className="text-xs text-muted-foreground">{a.class_name} · {a.date ? new Date(a.date).toLocaleDateString("fr-FR") : ""}{a.arrival_time ? ` · Arrivée : ${a.arrival_time}` : ""}</p>
                  {a.reason && <p className="text-xs mt-0.5 italic">{a.reason}</p>}
                </div>
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${cfg.color}`}>{cfg.label}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}