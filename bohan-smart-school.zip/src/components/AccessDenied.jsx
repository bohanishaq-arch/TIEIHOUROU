import { ShieldAlert, LogOut } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";

export default function AccessDenied({ user }) {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="bg-card rounded-2xl border border-border shadow-xl max-w-md w-full p-10 text-center space-y-5">
        <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto">
          <ShieldAlert className="h-8 w-8 text-amber-600" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground">Accès non autorisé</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Bonjour <span className="font-semibold text-foreground">{user?.full_name || user?.email}</span>,<br />
            votre compte n'a pas encore été autorisé par l'administrateur.
          </p>
          <p className="text-xs text-muted-foreground mt-3 bg-muted rounded-lg p-3">
            Si vous avez soumis une demande d'accès, veuillez patienter. L'administrateur examinera votre dossier et vous notifiera par email.
          </p>
        </div>
        <Button variant="outline" className="gap-2 w-full" onClick={() => base44.auth.logout()}>
          <LogOut className="h-4 w-4" /> Se déconnecter
        </Button>
      </div>
    </div>
  );
}