import { useState } from "react";
import { GraduationCap, Printer, Download, Mail, Loader2, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { jsPDF } from "jspdf";

export default function ReportCardView({ student, grades, subjects, classes, trimester }) {
  const classObj = classes.find((c) => c.id === student.class_id);
  const studentGrades = grades.filter(
    (g) => g.student_id === student.id && g.trimester === trimester
  );

  const subjectMap = {};
  subjects.forEach((s) => (subjectMap[s.id] = s));

  const subjectAverages = {};
  studentGrades.forEach((g) => {
    if (!subjectAverages[g.subject_id]) subjectAverages[g.subject_id] = { total: 0, count: 0 };
    subjectAverages[g.subject_id].total += g.score;
    subjectAverages[g.subject_id].count += 1;
  });

  const rows = Object.entries(subjectAverages).map(([subId, vals]) => {
    const sub = subjectMap[subId];
    const avg = vals.total / vals.count;
    return {
      subject: sub?.name || "—",
      coefficient: sub?.coefficient || 1,
      average: Math.round(avg * 100) / 100,
      gradeCount: vals.count,
    };
  });

  const totalCoef = rows.reduce((sum, r) => sum + r.coefficient, 0);
  const weightedSum = rows.reduce((sum, r) => sum + r.average * r.coefficient, 0);
  const generalAverage = totalCoef > 0 ? Math.round((weightedSum / totalCoef) * 100) / 100 : 0;

  const [sendingEmail, setSendingEmail] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  function generatePDF(download = true) {
    const doc = new jsPDF();
    const pageW = doc.internal.pageSize.getWidth();

    // Header
    doc.setFillColor(30, 64, 120);
    doc.rect(0, 0, pageW, 28, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text("Scolaris — Bulletin de notes", 14, 12);
    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");
    doc.text(`${trimester}  •  ${classObj?.academic_year || ""}`, 14, 22);

    // Student info
    doc.setTextColor(40, 40, 40);
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("Informations élève", 14, 38);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text(`Nom : ${student.first_name} ${student.last_name}`, 14, 46);
    doc.text(`N° Étudiant : ${student.student_number}`, 14, 53);
    doc.text(`Classe : ${classObj?.name || "—"}`, 14, 60);
    doc.text(`Niveau : ${classObj?.level || "—"}`, 100, 46);
    doc.text(`Date de génération : ${new Date().toLocaleDateString("fr-FR")}`, 100, 53);

    // Average highlight
    doc.setFillColor(generalAverage >= 14 ? 220 : generalAverage >= 10 ? 254 : 254,
                     generalAverage >= 14 ? 252 : generalAverage >= 10 ? 240 : 226,
                     generalAverage >= 14 ? 231 : generalAverage >= 10 ? 199 : 226);
    doc.rect(14, 65, 80, 14, "F");
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(generalAverage >= 14 ? 21 : generalAverage >= 10 ? 133 : 185,
                     generalAverage >= 14 ? 128 : generalAverage >= 10 ? 77 : 28,
                     generalAverage >= 14 ? 61 : generalAverage >= 10 ? 14 : 28);
    doc.text(`Moyenne générale : ${generalAverage}/20`, 18, 74);

    // Table header
    doc.setFillColor(215, 225, 245);
    doc.rect(14, 85, pageW - 28, 9, "F");
    doc.setTextColor(40, 40, 40);
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Matière", 16, 91);
    doc.text("Coeff.", 110, 91);
    doc.text("Nb notes", 135, 91);
    doc.text("Moyenne", 165, 91);

    // Rows
    doc.setFont("helvetica", "normal");
    let y = 100;
    rows.forEach((r, i) => {
      if (i % 2 === 0) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, y - 5, pageW - 28, 8, "F");
      }
      doc.setTextColor(40, 40, 40);
      doc.text(r.subject, 16, y);
      doc.text(String(r.coefficient), 114, y);
      doc.text(String(r.gradeCount), 140, y);
      const avgColor = r.average >= 14 ? [21, 128, 61] : r.average >= 10 ? [133, 77, 14] : [185, 28, 28];
      doc.setTextColor(...avgColor);
      doc.setFont("helvetica", "bold");
      doc.text(`${r.average}/20`, 165, y);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(40, 40, 40);
      y += 9;
    });

    // Footer line
    doc.setDrawColor(200, 200, 200);
    doc.line(14, y + 3, pageW - 14, y + 3);
    doc.setFontSize(8);
    doc.setTextColor(130, 130, 130);
    doc.text("Ce bulletin est généré automatiquement par Scolaris.", 14, y + 10);

    if (download) {
      doc.save(`Bulletin_${student.last_name}_${student.first_name}_${trimester.replace(" ", "_")}.pdf`);
    }
    return doc;
  }

  function handleEmailToParent() {
    if (!student.parent_email) return alert("Aucun email parent renseigné pour cet élève.");

    const subjectLines = rows.map((r) => `• ${r.subject} (coeff. ${r.coefficient}) : ${r.average}/20`).join("%0A");
    const mention = generalAverage >= 14 ? "Très bien" : generalAverage >= 12 ? "Bien" : generalAverage >= 10 ? "Assez bien" : "Insuffisant";

    const body = `Madame, Monsieur ${student.parent_name || ""},%0A%0AVeuillez trouver ci-dessous le bulletin de notes de votre enfant ${student.first_name} ${student.last_name} pour le ${trimester} (${classObj?.academic_year || ""}).%0A%0AClasse : ${classObj?.name || "—"}%0ANiveau : ${classObj?.level || "—"}%0A%0ARésultats par matière :%0A${subjectLines}%0A%0AMoyenne générale : ${generalAverage}/20 — ${mention}%0A%0APour toute question, veuillez contacter le secrétariat.%0A%0ACordialement,%0AL'équipe pédagogique — Scolaris`;

    const mailtoLink = `mailto:${student.parent_email}?subject=${encodeURIComponent(`Bulletin de notes — ${student.first_name} ${student.last_name} — ${trimester}`)}&body=${body}`;
    window.open(mailtoLink, "_blank");
    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 4000);
  }

  return (
    <div className="bg-card rounded-xl border border-border" id="report-card">
      {/* Header */}
      <div className="border-b border-border p-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
              <GraduationCap className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h2 className="text-lg font-display font-bold text-foreground">Bulletin de notes</h2>
              <p className="text-sm text-muted-foreground">{trimester} — {classObj?.academic_year || ""}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" size="sm" className="gap-2" onClick={() => generatePDF(true)}>
              <Download className="h-4 w-4" /> Télécharger PDF
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-2"
              onClick={handleEmailToParent}
              disabled={sendingEmail || !student.parent_email}
              title={!student.parent_email ? "Aucun email parent renseigné" : "Envoyer par email aux parents"}
            >
              {sendingEmail ? (
                <><Loader2 className="h-4 w-4 animate-spin" /> Envoi...</>
              ) : emailSent ? (
                <><CheckCircle className="h-4 w-4 text-green-500" /> Envoyé</>
              ) : (
                <><Mail className="h-4 w-4" /> Envoyer aux parents</>
              )}
            </Button>
            <Button variant="outline" size="sm" className="gap-2" onClick={() => window.print()}>
              <Printer className="h-4 w-4" /> Imprimer
            </Button>
          </div>
        </div>
      </div>

      {/* Student info */}
      <div className="p-6 border-b border-border bg-muted/30">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <span className="text-muted-foreground text-xs">Nom</span>
            <p className="font-semibold">{student.first_name} {student.last_name}</p>
          </div>
          <div>
            <span className="text-muted-foreground text-xs">N° Étudiant</span>
            <p className="font-mono text-sm">{student.student_number}</p>
          </div>
          <div>
            <span className="text-muted-foreground text-xs">Classe</span>
            <p className="font-semibold">{classObj?.name || "—"}</p>
          </div>
          <div>
            <span className="text-muted-foreground text-xs">Moyenne générale</span>
            <p className={`text-2xl font-bold ${
              generalAverage >= 14 ? "text-green-600" :
              generalAverage >= 10 ? "text-yellow-600" :
              "text-red-600"
            }`}>
              {generalAverage}/20
            </p>
          </div>
        </div>
      </div>

      {/* Grades table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left py-3 px-6 text-xs font-semibold text-muted-foreground uppercase">Matière</th>
              <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Coefficient</th>
              <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Nb Notes</th>
              <th className="text-center py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Moyenne</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-8 text-center text-muted-foreground">
                  Aucune note pour ce trimestre
                </td>
              </tr>
            ) : (
              rows.map((r, i) => (
                <tr key={i} className="border-b border-border/50 hover:bg-muted/20">
                  <td className="py-3 px-6 font-medium">{r.subject}</td>
                  <td className="py-3 px-4 text-center text-muted-foreground">{r.coefficient}</td>
                  <td className="py-3 px-4 text-center text-muted-foreground">{r.gradeCount}</td>
                  <td className="py-3 px-4 text-center">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold ${
                      r.average >= 14 ? "bg-green-100 text-green-700" :
                      r.average >= 10 ? "bg-yellow-100 text-yellow-700" :
                      "bg-red-100 text-red-700"
                    }`}>
                      {r.average}/20
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
          {rows.length > 0 && (
            <tfoot>
              <tr className="bg-primary/5">
                <td className="py-3 px-6 font-bold" colSpan={3}>Moyenne Générale Pondérée</td>
                <td className="py-3 px-4 text-center">
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-bold ${
                    generalAverage >= 14 ? "bg-green-100 text-green-700" :
                    generalAverage >= 10 ? "bg-yellow-100 text-yellow-700" :
                    "bg-red-100 text-red-700"
                  }`}>
                    {generalAverage}/20
                  </span>
                </td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      {/* Parent email info */}
      {student.parent_email && (
        <div className="p-4 border-t border-border bg-muted/20 text-xs text-muted-foreground flex items-center gap-2">
          <Mail className="h-3.5 w-3.5" />
          Parent : {student.parent_name || "—"} — {student.parent_email}
        </div>
      )}
    </div>
  );
}