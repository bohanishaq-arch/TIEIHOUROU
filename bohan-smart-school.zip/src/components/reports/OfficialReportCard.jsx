import { useRef } from "react";
import { Printer, Download, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";

function avg(grades) {
  if (!grades.length) return null;
  return grades.reduce((a, b) => a + b, 0) / grades.length;
}

function getMention(v) {
  if (v === null || v === undefined) return "—";
  if (v >= 16) return "Très Bien";
  if (v >= 14) return "Bien";
  if (v >= 12) return "Assez Bien";
  if (v >= 10) return "Passable";
  return "Insuffisant";
}

function fmt(v, decimals = 2) {
  if (v === null || v === undefined) return "—";
  return Number(v).toFixed(decimals);
}

export default function OfficialReportCard({
  student, classObj, subjects, grades, bulletinData, settings, allStudents, allGrades, trimester
}) {
  const printRef = useRef();

  const studentGrades = grades.filter((g) => g.student_id === student.id && g.trimester === trimester);

  const rows = subjects.map((sub) => {
    const sg = studentGrades.filter((g) => g.subject_id === sub.id);
    const average = avg(sg.map((g) => g.score));
    const coeff = sub.coefficient || 1;
    return { subject: sub, average, coeff, weighted: average !== null ? average * coeff : null };
  }).filter((r) => r.average !== null);

  const totalCoeff = rows.reduce((s, r) => s + r.coeff, 0);
  const totalWeighted = rows.reduce((s, r) => s + (r.weighted || 0), 0);
  const trimesterAvg = totalCoeff > 0 ? totalWeighted / totalCoeff : null;

  const classStudents = allStudents.filter((s) => s.class_id === student.class_id);
  const classAverages = classStudents.map((s) => {
    const sg = allGrades.filter((g) => g.student_id === s.id && g.trimester === trimester);
    const subRows = subjects.map((sub) => {
      const ssg = sg.filter((g) => g.subject_id === sub.id);
      const a = avg(ssg.map((g) => g.score));
      return { coeff: sub.coefficient || 1, average: a };
    }).filter((r) => r.average !== null);
    const tc = subRows.reduce((x, r) => x + r.coeff, 0);
    const tw = subRows.reduce((x, r) => x + r.average * r.coeff, 0);
    return { id: s.id, avg: tc > 0 ? tw / tc : null };
  }).filter((x) => x.avg !== null).sort((a, b) => b.avg - a.avg);

  const rank = classAverages.findIndex((x) => x.id === student.id) + 1;
  const effectif = classStudents.length;
  const classMin = classAverages.length ? classAverages[classAverages.length - 1].avg : null;
  const classMax = classAverages.length ? classAverages[0].avg : null;
  const classAvgAll = classAverages.length
    ? classAverages.reduce((s, x) => s + x.avg, 0) / classAverages.length
    : null;
  const mention = getMention(trimesterAvg);
  const bd = bulletinData || {};

  async function handleDownloadPDF() {
    const element = printRef.current;
    const canvas = await html2canvas(element, {
      scale: 2, useCORS: true, backgroundColor: "#ffffff",
      scrollX: 0, scrollY: 0,
      windowWidth: element.scrollWidth, windowHeight: element.scrollHeight,
      width: element.scrollWidth, height: element.scrollHeight,
    });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const imgHeight = (canvas.height * pdfWidth) / canvas.width;
    const scale = imgHeight > pdfHeight ? pdfHeight / imgHeight : 1;
    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth * scale, imgHeight * scale);
    pdf.save(`Bulletin_${student.last_name}_${student.first_name}_${trimester}.pdf`);
  }

  function handleEmail() {
    if (!student.parent_email) return alert("Aucun email parent renseigné.");
    const body = `Madame, Monsieur ${student.parent_name || ""},\n\nVeuillez trouver ci-joint le bulletin de notes de votre enfant ${student.first_name} ${student.last_name} pour le ${trimester}.\n\nMoyenne : ${trimesterAvg ? trimesterAvg.toFixed(2) : "—"}/20\nRang : ${rank || "—"}/${effectif}\nMention : ${mention}\n\nCordialement,\n${settings?.director_name || "La Direction"}`;
    window.open(`mailto:${student.parent_email}?subject=${encodeURIComponent(`Bulletin ${trimester} - ${student.first_name} ${student.last_name}`)}&body=${encodeURIComponent(body)}`, "_blank");
  }

  const s = settings || {};
  const schoolName = s.school_name || "ÉTABLISSEMENT";
  const republic = s.republic_name || "RÉPUBLIQUE DE CÔTE D'IVOIRE";
  const ministry = s.ministry_name || "MINISTÈRE DE L'ÉDUCATION NATIONALE ET DE L'ALPHABÉTISATION";
  const isLycee = /lyc[eé]/i.test(schoolName);
  const directorTitle = isLycee ? "LE PROVISEUR" : "LE CHEF D'ÉTABLISSEMENT";
  const printDate = new Date().toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });

  // Style constants
  const border = "1px solid #000";
  const borderLight = "1px solid #bbb";
  const mono = "'Courier New', Courier, monospace";
  const sans = "Arial, sans-serif";
  const headerBg = "#1a1a2e";
  const cellPad = "3px 7px";

  return (
    <div>
      {/* Action buttons */}
      <div className="flex gap-2 mb-4 no-print">
        <Button variant="outline" size="sm" className="gap-2" onClick={() => window.print()}>
          <Printer className="h-4 w-4" /> Imprimer
        </Button>
        <Button size="sm" className="gap-2" onClick={handleDownloadPDF}>
          <Download className="h-4 w-4" /> Télécharger PDF
        </Button>
        <Button variant="outline" size="sm" className="gap-2" onClick={handleEmail} disabled={!student.parent_email}>
          <Mail className="h-4 w-4" /> Envoyer aux parents
        </Button>
      </div>

      {/* ══════════════════════════════════════════════
          BULLETIN — FORMAT FICHE DE PAIE
          ══════════════════════════════════════════════ */}
      <div
        id="bulletin-print"
        ref={printRef}
        style={{
          fontFamily: mono,
          background: "#fff",
          color: "#000",
          maxWidth: "794px",
          margin: "0 auto",
          fontSize: "9px",
          border: "1px solid #888",
          boxShadow: "0 2px 12px rgba(0,0,0,0.12)",
        }}
      >

        {/* ── TOP HEADER BAND ── */}
        <div style={{ background: headerBg, color: "#fff", padding: "8px 14px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            {s.logo_url
              ? <img src={s.logo_url} alt="Logo" style={{ height: "44px", objectFit: "contain", filter: "brightness(0) invert(1)" }} />
              : <div style={{ width: 44, height: 44, border: "1px solid #555", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 8, color: "#aaa" }}>LOGO</div>
            }
            <div>
              <div style={{ fontSize: "7px", opacity: 0.7, letterSpacing: "1px", textTransform: "uppercase" }}>{republic}</div>
              <div style={{ fontSize: "7px", opacity: 0.6, marginTop: "1px" }}>{ministry}</div>
              <div style={{ fontSize: "11px", fontWeight: "bold", letterSpacing: "1.5px", textTransform: "uppercase", marginTop: "3px", fontFamily: sans }}>{schoolName}</div>
              {s.school_motto && <div style={{ fontSize: "7px", fontStyle: "italic", opacity: 0.7, marginTop: "1px" }}>{s.school_motto}</div>}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: "7px", opacity: 0.6, letterSpacing: "2px", textTransform: "uppercase" }}>CONFIDENTIEL</div>
            <div style={{ fontSize: "14px", fontWeight: "bold", letterSpacing: "2px", marginTop: "4px", fontFamily: sans }}>BULLETIN DE NOTES</div>
            <div style={{ fontSize: "8px", opacity: 0.8, marginTop: "2px" }}>{trimester} — {classObj?.academic_year || "—"}</div>
            <div style={{ fontSize: "7px", opacity: 0.6, marginTop: "1px" }}>Édité le {printDate}</div>
          </div>
        </div>

        {/* ── IDENTITY BLOCK ── */}
        <div style={{ borderBottom: border, background: "#f5f5f5" }}>
          {/* Row 1 */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", borderBottom: borderLight }}>
            {[
              ["NO ÉTS.", s.school_address?.slice(0,12) || "—"],
              ["MATRICULE", student.student_number || "—"],
              ["RÉGIME", bd.regime || "NON RED"],
              ["ANNÉE SCOLAIRE", classObj?.academic_year || "—"],
            ].map(([lbl, val]) => (
              <div key={lbl} style={{ padding: cellPad, borderRight: borderLight }}>
                <div style={{ fontSize: "7px", color: "#555", fontFamily: sans }}>{lbl}</div>
                <div style={{ fontWeight: "bold", marginTop: "1px" }}>{val}</div>
              </div>
            ))}
          </div>
          {/* Row 2 */}
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", borderBottom: borderLight }}>
            {[
              ["NOM, PRÉNOM", `${student.last_name?.toUpperCase() || ""}, ${student.first_name || ""}`],
              ["CLASSE", classObj?.name || "—"],
              ["EFFECTIF", `${effectif} élèves`],
              ["SEXE", student.gender || "—"],
            ].map(([lbl, val]) => (
              <div key={lbl} style={{ padding: cellPad, borderRight: borderLight }}>
                <div style={{ fontSize: "7px", color: "#555", fontFamily: sans }}>{lbl}</div>
                <div style={{ fontWeight: "bold", marginTop: "1px" }}>{val}</div>
              </div>
            ))}
          </div>
          {/* Row 3 */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr" }}>
            {[
              ["DATE DE NAISSANCE", student.date_of_birth ? new Date(student.date_of_birth).toLocaleDateString("fr-FR") : "—"],
              ["ABSENCES JUSTIF.", `${bd.absences_justified || 0} h`],
              ["ABSENCES NON JUSTIF.", `${bd.absences_unjustified || 0} h`],
              ["RANG", rank > 0 ? `${rank} / ${effectif}` : "—"],
            ].map(([lbl, val]) => (
              <div key={lbl} style={{ padding: cellPad, borderRight: borderLight }}>
                <div style={{ fontSize: "7px", color: "#555", fontFamily: sans }}>{lbl}</div>
                <div style={{ fontWeight: "bold", marginTop: "1px" }}>{val}</div>
              </div>
            ))}
          </div>
        </div>

        {/* ── MAIN GRADES TABLE ── */}
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "8.5px" }}>
          <thead>
            <tr style={{ background: "#2d2d2d", color: "#fff" }}>
              <th style={{ border, padding: "4px 7px", textAlign: "left", fontFamily: sans, fontWeight: "bold", letterSpacing: ".5px" }}>DISCIPLINE</th>
              <th style={{ border, padding: "4px 6px", textAlign: "left", fontFamily: sans, fontWeight: "bold", width: "100px" }}>ENSEIGNANT</th>
              <th style={{ border, padding: "4px 5px", textAlign: "center", fontFamily: sans, fontWeight: "bold", width: "38px" }}>COEFF</th>
              <th style={{ border, padding: "4px 5px", textAlign: "center", fontFamily: sans, fontWeight: "bold", width: "55px" }}>MOY. /20</th>
              <th style={{ border, padding: "4px 5px", textAlign: "center", fontFamily: sans, fontWeight: "bold", width: "58px" }}>MOY × COEF</th>
              <th style={{ border, padding: "4px 5px", textAlign: "center", fontFamily: sans, fontWeight: "bold", width: "65px" }}>MENTION</th>
              <th style={{ border, padding: "4px 5px", textAlign: "center", fontFamily: sans, fontWeight: "bold", width: "70px" }}>APPRÉCIATION</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => {
              const m = getMention(row.average);
              const appr = row.average !== null ? (row.average >= 10 ? "VALIDÉ" : "NON VALIDÉ") : "—";
              const avgColor = row.average !== null
                ? row.average >= 10 ? "#000" : "#cc0000"
                : "#777";
              return (
                <tr key={row.subject.id} style={{ background: i % 2 === 0 ? "#fff" : "#f9f9f9" }}>
                  <td style={{ border: borderLight, padding: "3px 7px", fontWeight: "600" }}>{row.subject.name}</td>
                  <td style={{ border: borderLight, padding: "3px 6px", fontSize: "8px", color: "#333" }}>{row.subject.teacher_name || "—"}</td>
                  <td style={{ border: borderLight, padding: "3px 5px", textAlign: "center" }}>{row.coeff}</td>
                  <td style={{ border: borderLight, padding: "3px 5px", textAlign: "center", fontWeight: "bold", color: avgColor }}>
                    {row.average !== null ? row.average.toFixed(2) : "—"}
                  </td>
                  <td style={{ border: borderLight, padding: "3px 5px", textAlign: "center" }}>
                    {row.weighted !== null ? row.weighted.toFixed(2) : "—"}
                  </td>
                  <td style={{ border: borderLight, padding: "3px 5px", textAlign: "center", fontStyle: "italic", fontSize: "8px" }}>{m}</td>
                  <td style={{ border: borderLight, padding: "3px 5px", textAlign: "center", fontWeight: "bold", fontSize: "8px", color: row.average !== null && row.average >= 10 ? "#006600" : "#cc0000" }}>
                    {appr}
                  </td>
                </tr>
              );
            })}
            {/* TOTAUX */}
            <tr style={{ background: "#e0e0e0", fontWeight: "bold" }}>
              <td style={{ border, padding: "4px 7px", fontFamily: sans }} colSpan={2}>TOTAUX</td>
              <td style={{ border, padding: "4px 5px", textAlign: "center", fontFamily: sans }}>{totalCoeff}</td>
              <td style={{ border, padding: "4px 5px", textAlign: "center" }}>—</td>
              <td style={{ border, padding: "4px 5px", textAlign: "center", fontFamily: sans }}>{totalWeighted.toFixed(2)}</td>
              <td style={{ border, padding: "4px 5px" }} colSpan={2}></td>
            </tr>
          </tbody>
        </table>

        {/* ── SUMMARY + CLASS STATS ── */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", borderTop: border }}>

          {/* LEFT — SOMMAIRE */}
          <div style={{ borderRight: border }}>
            <div style={{ background: "#2d2d2d", color: "#fff", padding: "3px 7px", fontFamily: sans, fontWeight: "bold", fontSize: "8px", letterSpacing: ".5px" }}>
              SOMMAIRE
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "8.5px" }}>
              <thead>
                <tr style={{ background: "#e8e8e8" }}>
                  <th style={{ border: borderLight, padding: "3px 7px", textAlign: "left", fontFamily: sans, fontSize: "7.5px" }}></th>
                  <th style={{ border: borderLight, padding: "3px 7px", textAlign: "center", fontFamily: sans, fontSize: "7.5px" }}>VALEUR</th>
                  <th style={{ border: borderLight, padding: "3px 7px", textAlign: "center", fontFamily: sans, fontSize: "7.5px" }}>CLASSE</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["MOYENNE TRIMESTRIELLE", trimesterAvg !== null ? `${trimesterAvg.toFixed(2)} / 20` : "—", classAvgAll !== null ? `${classAvgAll.toFixed(2)} / 20` : "—"],
                  ["MOYENNE CLASSE MIN.", "—", classMin !== null ? `${classMin.toFixed(2)} / 20` : "—"],
                  ["MOYENNE CLASSE MAX.", "—", classMax !== null ? `${classMax.toFixed(2)} / 20` : "—"],
                  ["RANG", rank > 0 ? `${rank} / ${effectif}` : "—", ""],
                  ["MENTION", mention, ""],
                  ["DISTINCTION", bd.distinction && bd.distinction !== "Aucune" ? bd.distinction : "Aucune", ""],
                  ["DÉCISION CONSEIL", bd.year_end_decision || "En attente", ""],
                ].map(([label, val, cls]) => (
                  <tr key={label}>
                    <td style={{ border: borderLight, padding: "3px 7px", background: "#f2f2f2", fontWeight: "600", fontFamily: sans, fontSize: "7.5px" }}>{label}</td>
                    <td style={{ border: borderLight, padding: "3px 7px", textAlign: "center", fontWeight: "bold", color: label === "MOYENNE TRIMESTRIELLE" && trimesterAvg !== null ? (trimesterAvg >= 10 ? "#005500" : "#cc0000") : "#000" }}>{val}</td>
                    <td style={{ border: borderLight, padding: "3px 7px", textAlign: "center", color: "#444" }}>{cls}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* RIGHT — APPRÉCIATION + SIGNATURES */}
          <div style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ background: "#2d2d2d", color: "#fff", padding: "3px 7px", fontFamily: sans, fontWeight: "bold", fontSize: "8px", letterSpacing: ".5px" }}>
              APPRÉCIATION DU CONSEIL DE CLASSE
            </div>
            <div style={{ flex: 1, padding: "8px 10px", borderBottom: borderLight, minHeight: "50px", fontStyle: "italic", fontSize: "8.5px", color: "#222", lineHeight: "1.5" }}>
              {bd.council_appreciation || ""}
            </div>
            {bd.sanction && (
              <div style={{ padding: "4px 10px", borderBottom: borderLight, fontSize: "8px" }}>
                <strong>Sanction :</strong> {bd.sanction}
              </div>
            )}

            {/* SIGNATURES */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", borderTop: borderLight, marginTop: "auto" }}>
              <div style={{ padding: "8px 10px", borderRight: borderLight, textAlign: "center" }}>
                <div style={{ fontSize: "7.5px", fontFamily: sans, fontWeight: "bold", textTransform: "uppercase" }}>{directorTitle}</div>
                <div style={{ fontSize: "7.5px", fontStyle: "italic", marginTop: "1px", color: "#444" }}>{s.director_name || "—"}</div>
                <div style={{ borderTop: borderLight, marginTop: "28px", paddingTop: "3px", fontSize: "7px", color: "#888" }}>Signature &amp; cachet</div>
              </div>
              <div style={{ padding: "8px 10px", textAlign: "center" }}>
                <div style={{ fontSize: "7.5px", fontFamily: sans, fontWeight: "bold", textTransform: "uppercase" }}>Signature Parent/Tuteur</div>
                <div style={{ borderTop: borderLight, marginTop: "28px", paddingTop: "3px", fontSize: "7px", color: "#888" }}>Lu et approuvé</div>
              </div>
            </div>
          </div>
        </div>

        {/* ── FOOTER BAND ── */}
        <div style={{ background: "#1a1a2e", color: "#ccc", padding: "6px 14px", display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: "7.5px", fontFamily: sans }}>
          <span style={{ fontWeight: "bold", letterSpacing: "2px", color: "#fff", fontSize: "9px" }}>BOHAN</span>
          <span>{schoolName} {s.school_address ? `· ${s.school_address}` : ""}</span>
          <span>Édité le {printDate} · {trimester} {classObj?.academic_year || ""}</span>
        </div>

      </div>

      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #bulletin-print, #bulletin-print * { visibility: visible !important; }
          #bulletin-print {
            position: fixed !important;
            top: 0 !important; left: 0 !important;
            width: 100% !important;
            margin: 0 !important; padding: 0 !important;
            max-width: 100% !important;
          }
          @page { size: A4 portrait; margin: 6mm; }
          * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        }
      `}</style>
    </div>
  );
}