import { ClipboardList, Lock, Unlock, Pencil, Trash2, ChevronRight, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ExamList({ exams, subjects, classes, onEdit, onDelete, onLock, onSelectExam }) {
  const subjectMap = {};
  subjects.forEach((s) => (subjectMap[s.id] = s.name));
  const classMap = {};
  classes.forEach((c) => (classMap[c.id] = c.name));

  if (exams.length === 0) {
    return (
      <div className="bg-card rounded-xl border border-border p-12 text-center">
        <ClipboardList className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
        <p className="text-muted-foreground">Aucun examen créé</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted/50 border-b border-border">
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Examen</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Matière</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Classe</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Date</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Barème</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Trimestre</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Statut</th>
              <th className="text-right py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Actions</th>
            </tr>
          </thead>
          <tbody>
            {exams.map((ex) => (
              <tr key={ex.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                <td className="py-3 px-4">
                  <button
                    onClick={() => onSelectExam(ex)}
                    className="text-left hover:underline group"
                  >
                    <p className="font-medium text-primary group-hover:text-primary/80 transition-colors">{ex.title || ex.exam_type}</p>
                    <p className="text-xs text-muted-foreground">{ex.exam_type}</p>
                  </button>
                </td>
                <td className="py-3 px-4 text-muted-foreground">{subjectMap[ex.subject_id] || "—"}</td>
                <td className="py-3 px-4 text-muted-foreground">{classMap[ex.class_id] || "—"}</td>
                <td className="py-3 px-4">
                  {ex.date ? (
                    <div className="flex items-center gap-1 text-sm">
                      <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                      {new Date(ex.date).toLocaleDateString("fr-FR")}
                    </div>
                  ) : "—"}
                </td>
                <td className="py-3 px-4">
                  <span className="font-semibold">/{ex.max_score || 20}</span>
                </td>
                <td className="py-3 px-4 text-muted-foreground text-xs">{ex.trimester}</td>
                <td className="py-3 px-4">
                  {ex.is_locked ? (
                    <span className="inline-flex items-center gap-1 text-xs text-green-600 font-medium">
                      <Lock className="h-3 w-3" /> Verrouillé
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs text-orange-500 font-medium">
                      <Unlock className="h-3 w-3" /> Ouvert
                    </span>
                  )}
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Button variant="ghost" size="sm" className="h-8 text-xs gap-1" onClick={() => onSelectExam(ex)}>
                      Saisir notes <ChevronRight className="h-3.5 w-3.5" />
                    </Button>
                    {!ex.is_locked && (
                      <>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(ex)} title="Modifier">
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onLock(ex)} title="Verrouiller">
                          <Lock className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => onDelete(ex.id)} title="Supprimer">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}