import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { X, CheckCircle, XCircle, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const STATUS_LABELS = {
  en_attente_educateur: { label: "En attente éducateur", color: "bg-yellow-100 text-yellow-700" },
  en_attente_directeur: { label: "En attente directeur", color: "bg-blue-100 text-blue-700" },
  approuvee: { label: "Approuvée", color: "bg-green-100 text-green-700" },
  rejetee: { label: "Rejetée", color: "bg-red-100 text-red-700" },
};

export default function CorrectionModal({ grade, studentName, subjectName, currentUser, onClose, onSaved }) {
  const [reason, setReason] = useState(grade.correction_reason || "");
  const [educatorNote, setEducatorNote] = useState(grade.correction_educator_note || "");
  const [directorNote, setDirectorNote] = useState(grade.correction_director_note || "");
  const [correctedScore, setCorrectedScore] = useState(grade.corrected_score ?? "");
  const [saving, setSaving] = useState(false);

  const isAdmin = currentUser?.role === "admin";
  const isDirector = currentUser?.role === "directeur" || isAdmin;
  const isEducator = currentUser?.role === "educateur" || isDirector;
  const isTeacher = true; // all can request

  const status = grade.correction_status;
  const statusInfo = STATUS_LABELS[status] || null;

  async function handleRequest() {
    setSaving(true);
    await base44.entities.Grade.update(grade.id, {
      correction_requested: true,
      correction_reason: reason,
      correction_status: "en_attente_educateur",
    });
    setSaving(false);
    onSaved();
    onClose();
  }

  async function handleEducatorValidate(approved) {
    setSaving(true);
    await base44.entities.Grade.update(grade.id, {
      correction_educator_note: educatorNote,
      correction_status: approved ? "en_attente_directeur" : "rejetee",
    });
    setSaving(false);
    onSaved();
    onClose();
  }

  async function handleDirectorValidate(approved) {
    setSaving(true);
    const updates = {
      correction_director_note: directorNote,
      correction_status: approved ? "approuvee" : "rejetee",
    };
    if (approved && correctedScore !== "") {
      updates.corrected_score = Number(correctedScore);
      updates.score = Number(correctedScore);
      updates.modification_reason = directorNote;
    }
    await base44.entities.Grade.update(grade.id, updates);
    setSaving(false);
    onSaved();
    onClose();
  }

  async function handleAdminOverride() {
    setSaving(true);
    await base44.entities.Grade.update(grade.id, {
      score: Number(correctedScore),
      corrected_score: Number(correctedScore),
      modification_reason: directorNote,
      correction_status: "approuvee",
    });
    setSaving(false);
    onSaved();
    onClose();
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-2xl border border-border w-full max-w-lg shadow-xl">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <div>
            <h2 className="font-bold text-foreground">Demande de correction</h2>
            <p className="text-sm text-muted-foreground">{studentName} • {subjectName} • {grade.score}/{grade.max_score}</p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="h-4 w-4" /></Button>
        </div>

        <div className="p-5 space-y-4">
          {statusInfo && (
            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium ${statusInfo.color}`}>
              <MessageSquare className="h-3.5 w-3.5" />
              {statusInfo.label}
            </div>
          )}

          {/* Step 1: Teacher request */}
          <div>
            <Label className="text-xs text-muted-foreground uppercase tracking-wide">Motif du professeur</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Expliquer la raison de la demande de correction..."
              rows={3}
              disabled={!!status}
            />
          </div>

          {/* Step 2: Educator note */}
          {(status === "en_attente_educateur" || status === "en_attente_directeur" || status === "approuvee" || status === "rejetee") && (
            <div>
              <Label className="text-xs text-muted-foreground uppercase tracking-wide">Avis de l'éducateur</Label>
              <Textarea
                value={educatorNote}
                onChange={(e) => setEducatorNote(e.target.value)}
                placeholder="Commentaire de l'éducateur..."
                rows={2}
                disabled={status !== "en_attente_educateur" || !isEducator}
              />
            </div>
          )}

          {/* Step 3: Director note + corrected score */}
          {(status === "en_attente_directeur" || status === "approuvee") && (
            <div className="space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">Avis du directeur</Label>
                <Textarea
                  value={directorNote}
                  onChange={(e) => setDirectorNote(e.target.value)}
                  placeholder="Décision du directeur..."
                  rows={2}
                  disabled={status !== "en_attente_directeur" || !isDirector}
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">Note corrigée (sur {grade.max_score})</Label>
                <Input
                  type="number"
                  min={0}
                  max={grade.max_score}
                  step={0.25}
                  value={correctedScore}
                  onChange={(e) => setCorrectedScore(e.target.value)}
                  disabled={status !== "en_attente_directeur" || !isDirector}
                  placeholder="Nouvelle note..."
                />
              </div>
            </div>
          )}

          {/* Admin override */}
          {isAdmin && status === "approuvee" && (
            <div className="border-t border-border pt-3">
              <p className="text-xs text-muted-foreground mb-2 font-semibold uppercase tracking-wide">Modification administrateur</p>
              <div className="grid grid-cols-2 gap-3">
                <Input
                  type="number"
                  min={0}
                  max={grade.max_score}
                  step={0.25}
                  value={correctedScore}
                  onChange={(e) => setCorrectedScore(e.target.value)}
                  placeholder="Nouvelle note..."
                />
                <Input
                  value={directorNote}
                  onChange={(e) => setDirectorNote(e.target.value)}
                  placeholder="Motif..."
                />
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2 p-5 border-t border-border">
          <Button variant="outline" onClick={onClose}>Fermer</Button>

          {/* Teacher can request if not yet requested */}
          {!status && !grade.correction_requested && (
            <Button onClick={handleRequest} disabled={saving || !reason.trim()}>
              Soumettre la demande
            </Button>
          )}

          {/* Educator can validate */}
          {status === "en_attente_educateur" && isEducator && (
            <>
              <Button variant="outline" onClick={() => handleEducatorValidate(false)} disabled={saving} className="text-destructive">
                <XCircle className="h-4 w-4 mr-1" /> Rejeter
              </Button>
              <Button onClick={() => handleEducatorValidate(true)} disabled={saving}>
                <CheckCircle className="h-4 w-4 mr-1" /> Valider → Directeur
              </Button>
            </>
          )}

          {/* Director can validate */}
          {status === "en_attente_directeur" && isDirector && (
            <>
              <Button variant="outline" onClick={() => handleDirectorValidate(false)} disabled={saving} className="text-destructive">
                <XCircle className="h-4 w-4 mr-1" /> Rejeter
              </Button>
              <Button onClick={() => handleDirectorValidate(true)} disabled={saving}>
                <CheckCircle className="h-4 w-4 mr-1" /> Approuver
              </Button>
            </>
          )}

          {/* Admin override */}
          {isAdmin && status === "approuvee" && correctedScore !== "" && (
            <Button onClick={handleAdminOverride} disabled={saving}>
              Modifier (Admin)
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}