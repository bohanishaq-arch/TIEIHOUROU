import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X } from "lucide-react";

const EXAM_TYPES = ["Devoir", "Interrogation", "Examen", "TP", "Oral"];
const TRIMESTERS = ["Trimestre 1", "Trimestre 2", "Trimestre 3"];

export default function GradeForm({ students, subjects, classes, onSave, onCancel }) {
  const currentYear = new Date().getFullYear();
  const [form, setForm] = useState({
    student_id: "",
    subject_id: "",
    class_id: "",
    score: "",
    max_score: 20,
    exam_type: "",
    trimester: "",
    academic_year: `${currentYear}-${currentYear + 1}`,
    comment: "",
  });

  const [selectedClass, setSelectedClass] = useState("");
  const filteredStudents = selectedClass
    ? students.filter((s) => s.class_id === selectedClass)
    : students;

  function handleClassChange(v) {
    setSelectedClass(v);
    setForm({ ...form, class_id: v, student_id: "" });
  }

  function handleSubmit(e) {
    e.preventDefault();
    onSave({ ...form, score: Number(form.score), max_score: Number(form.max_score) });
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-foreground">Saisir une note</h3>
        <Button variant="ghost" size="icon" onClick={onCancel}><X className="h-4 w-4" /></Button>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div>
          <Label>Classe *</Label>
          <Select value={selectedClass} onValueChange={handleClassChange}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Élève *</Label>
          <Select value={form.student_id} onValueChange={(v) => setForm({ ...form, student_id: v })}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {filteredStudents.map((s) => (
                <SelectItem key={s.id} value={s.id}>{s.first_name} {s.last_name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Matière *</Label>
          <Select value={form.subject_id} onValueChange={(v) => setForm({ ...form, subject_id: v })}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {subjects.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Note * (sur {form.max_score})</Label>
          <Input type="number" min={0} max={form.max_score} step={0.25} value={form.score}
            onChange={(e) => setForm({ ...form, score: e.target.value })} required />
        </div>
        <div>
          <Label>Type d'évaluation *</Label>
          <Select value={form.exam_type} onValueChange={(v) => setForm({ ...form, exam_type: v })}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {EXAM_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Trimestre *</Label>
          <Select value={form.trimester} onValueChange={(v) => setForm({ ...form, trimester: v })}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {TRIMESTERS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="md:col-span-2 lg:col-span-3">
          <Label>Commentaire</Label>
          <Textarea value={form.comment} onChange={(e) => setForm({ ...form, comment: e.target.value })}
            placeholder="Commentaire optionnel..." rows={2} />
        </div>
        <div className="md:col-span-2 lg:col-span-3 flex justify-end gap-3 pt-2">
          <Button type="button" variant="outline" onClick={onCancel}>Annuler</Button>
          <Button type="submit">Enregistrer la note</Button>
        </div>
      </form>
    </div>
  );
}