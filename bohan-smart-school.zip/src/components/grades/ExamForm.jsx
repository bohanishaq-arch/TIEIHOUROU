import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Clock, BookOpen, User } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";

import { usePeriodType } from "@/hooks/usePeriodType";

const EXAM_TYPES = ["Devoir", "Interrogation", "Examen trimestriel", "TP", "Oral"];

export default function ExamForm({ exam, subjects, classes, onSave, onCancel }) {
  const { user } = useAuth();
  const { periods, periodLabel } = usePeriodType();
  const currentYear = new Date().getFullYear();
  const [form, setForm] = useState({
    subject_id: exam?.subject_id || "",
    class_id: exam?.class_id || "",
    title: exam?.title || "",
    chapter: exam?.chapter || "",
    date: exam?.date || "",
    exam_type: exam?.exam_type || "",
    max_score: exam?.max_score || 20,
    duration_minutes: exam?.duration_minutes || "",
    trimester: exam?.trimester || "",
    academic_year: exam?.academic_year || `${currentYear}-${currentYear + 1}`,
    description: exam?.description || "",
    teacher_email: exam?.teacher_email || user?.email || "",
    teacher_name: exam?.teacher_name || user?.full_name || "",
  });

  function handleSubmit(e) {
    e.preventDefault();
    onSave({ ...form, max_score: Number(form.max_score) });
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-foreground">
          {exam ? "Modifier l'examen" : "Créer un examen"}
        </h3>
        <Button variant="ghost" size="icon" onClick={onCancel}><X className="h-4 w-4" /></Button>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Professeur info (auto-rempli) */}
        <div className="lg:col-span-3 bg-blue-50 border border-blue-200 rounded-lg px-4 py-3 flex items-center gap-3">
          <User className="h-5 w-5 text-blue-600 shrink-0" />
          <div className="text-sm">
            <p className="text-blue-700 font-semibold">{form.teacher_name || "Professeur"}</p>
            <p className="text-blue-600 text-xs font-mono">{form.teacher_email}</p>
          </div>
        </div>

        <div className="lg:col-span-2">
          <Label>Titre de l'examen</Label>
          <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ex: Devoir 1 de Mathématiques" />
        </div>
        <div>
          <Label>Date *</Label>
          <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} required />
        </div>
        <div className="lg:col-span-2">
          <Label className="flex items-center gap-2"><BookOpen className="h-4 w-4" /> Chapitre / Sujet traité</Label>
          <Input value={form.chapter} onChange={(e) => setForm({ ...form, chapter: e.target.value })} placeholder="Ex: Les équations du 2e degré, Conjugaison verbes irréguliers" />
        </div>
        <div>
          <Label className="flex items-center gap-2"><Clock className="h-4 w-4" /> Durée (minutes)</Label>
          <Input type="number" min="1" value={form.duration_minutes} onChange={(e) => setForm({ ...form, duration_minutes: e.target.value })} placeholder="Ex: 50, 120" />
        </div>
        <div>
          <Label>Matière *</Label>
          <Select value={form.subject_id} onValueChange={(v) => setForm({ ...form, subject_id: v })}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {subjects.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.code ? `[${s.code}] ` : ""}{s.name}{s.teacher_name ? ` — ${s.teacher_name}` : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {/* Subject info panel */}
          {(() => {
            const sel = subjects.find((s) => s.id === form.subject_id);
            if (!sel) return null;
            return (
              <div className="mt-1.5 flex flex-wrap gap-3 text-xs bg-accent/50 rounded-lg px-3 py-2 text-muted-foreground">
                {sel.code && <span><span className="font-semibold text-foreground">Code :</span> {sel.code}</span>}
                <span><span className="font-semibold text-foreground">Coeff. :</span> {sel.coefficient || 1}</span>
                {sel.teacher_name && <span><span className="font-semibold text-foreground">Professeur :</span> {sel.teacher_name}</span>}
              </div>
            );
          })()}
        </div>
        <div>
          <Label>Classe *</Label>
          <Select value={form.class_id} onValueChange={(v) => setForm({ ...form, class_id: v })}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Type d'évaluation *</Label>
          <Select value={form.exam_type} onValueChange={(v) => setForm({ ...form, exam_type: v })}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {EXAM_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Barème *</Label>
          <div className="flex gap-2 mt-1">
            <button type="button" onClick={() => setForm({ ...form, max_score: 10 })} className={`px-3 py-1.5 rounded-lg border text-sm font-semibold transition-all ${Number(form.max_score) === 10 ? 'bg-indigo-600 text-white border-indigo-600' : 'border-input hover:bg-muted'}`}>/10</button>
            <button type="button" onClick={() => setForm({ ...form, max_score: 20 })} className={`px-3 py-1.5 rounded-lg border text-sm font-semibold transition-all ${Number(form.max_score) === 20 ? 'bg-indigo-600 text-white border-indigo-600' : 'border-input hover:bg-muted'}`}>/20</button>
            <Input type="number" min={1} max={100} value={form.max_score} onChange={(e) => setForm({ ...form, max_score: e.target.value })} required className="flex-1" placeholder="Autre barème" />
          </div>
        </div>
        <div>
          <Label>{periodLabel} *</Label>
          <Select value={form.trimester} onValueChange={(v) => setForm({ ...form, trimester: v })}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {periods.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Année scolaire</Label>
          <Input value={form.academic_year} onChange={(e) => setForm({ ...form, academic_year: e.target.value })} />
        </div>
        <div className="md:col-span-2 lg:col-span-3">
          <Label>Description / Instructions</Label>
          <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Instructions pour les élèves..." rows={2} />
        </div>
        <div className="lg:col-span-3 bg-amber-50 border border-amber-200 rounded-lg px-4 py-3">
         <p className="text-sm font-semibold text-amber-900 mb-1">📋 Validation requise</p>
         <p className="text-xs text-amber-700">Cet examen sera soumis au Proviseur pour validation avant d'être visible aux élèves.</p>
        </div>
        <div className="lg:col-span-3 flex justify-end gap-3 pt-2 border-t border-border">
         <Button type="button" variant="outline" onClick={onCancel}>Annuler</Button>
         <Button type="submit">{exam ? "Enregistrer" : "Soumettre pour validation"}</Button>
        </div>
      </form>
    </div>
  );
}