import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { X, Save, Lock, Loader2 } from "lucide-react";
import { getSchoolId } from "../../hooks/useSchool";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function GradeEntryModal({ exam, students, subjects, classes, onClose, onSaved }) {
  const classStudents = students.filter((s) => s.class_id === exam.class_id);
  const subject = subjects.find((s) => s.id === exam.subject_id);
  const cls = classes.find((c) => c.id === exam.class_id);

  // Optimistic: grades/comments are updated immediately on change; save persists them
  const [grades, setGrades] = useState({});
  const [comments, setComments] = useState({});
  const [pendingStudents, setPendingStudents] = useState(new Set()); // optimistic pending indicator

  function autoComment(score, maxScore) {
    if (score === "" || score === undefined || score === null) return "";
    const pct = (Number(score) / maxScore) * 20;
    if (pct >= 18) return "Excellent travail, continuez ainsi !";
    if (pct >= 16) return "Très bien, bon travail !";
    if (pct >= 14) return "Bien, encouragements mérités.";
    if (pct >= 12) return "Assez bien, peut mieux faire.";
    if (pct >= 10) return "Passable, des efforts sont nécessaires.";
    if (pct >= 8) return "Insuffisant, travaillez davantage.";
    return "Résultats très insuffisants, un soutien est recommandé.";
  }

  // Optimistic update: set locally immediately, then debounce-save in background
  const saveTimers = useRef({});

  function handleGradeChange(studentId, value) {
    // Optimistic: update UI immediately
    setGrades(prev => ({ ...prev, [studentId]: value }));
    setComments(prev => ({ ...prev, [studentId]: autoComment(value, exam.max_score) }));

    // Mark as pending
    setPendingStudents(prev => new Set(prev).add(studentId));

    // Debounce background save (800ms after last keystroke)
    clearTimeout(saveTimers.current[studentId]);
    saveTimers.current[studentId] = setTimeout(async () => {
      if (value === "" || value === undefined) {
        setPendingStudents(prev => { const s = new Set(prev); s.delete(studentId); return s; });
        return;
      }
      const existing = existingGrades.find(g => g.student_id === studentId);
      const data = {
        exam_id: exam.id, student_id: studentId,
        subject_id: exam.subject_id, class_id: exam.class_id,
        score: Number(value), max_score: exam.max_score,
        exam_type: exam.exam_type, trimester: exam.trimester,
        academic_year: exam.academic_year,
        comment: autoComment(value, exam.max_score),
        school_id: getSchoolId(),
      };
      if (existing) {
        await base44.entities.Grade.update(existing.id, data);
      } else {
        const created = await base44.entities.Grade.create(data);
        setExistingGrades(prev => [...prev.filter(g => g.student_id !== studentId), created]);
      }
      setPendingStudents(prev => { const s = new Set(prev); s.delete(studentId); return s; });
    }, 800);
  }

  const [existingGrades, setExistingGrades] = useState([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.entities.Grade.filter({ exam_id: exam.id }).then((list) => {
      setExistingGrades(list);
      const gradeMap = {};
      const commentMap = {};
      list.forEach((g) => {
        gradeMap[g.student_id] = g.score;
        commentMap[g.student_id] = g.comment || "";
      });
      setGrades(gradeMap);
      setComments(commentMap);
    });
  }, [exam.id]);

  async function handleSave() {
    setSaving(true);
    for (const student of classStudents) {
      const score = grades[student.id];
      if (score === undefined || score === "") continue;
      const existing = existingGrades.find((g) => g.student_id === student.id);
      const data = {
        exam_id: exam.id,
        student_id: student.id,
        subject_id: exam.subject_id,
        class_id: exam.class_id,
        score: Number(score),
        max_score: exam.max_score,
        exam_type: exam.exam_type,
        trimester: exam.trimester,
        academic_year: exam.academic_year,
        comment: comments[student.id] || "",
        school_id: getSchoolId(),
      };
      if (existing) {
        await base44.entities.Grade.update(existing.id, data);
      } else {
        await base44.entities.Grade.create(data);
      }
    }
    setSaving(false);
    onSaved();
    onClose();
  }

  async function handleLockAll() {
    setSaving(true);
    await handleSave();
    await base44.entities.Exam.update(exam.id, { is_locked: true, locked_date: new Date().toISOString() });
    const all = await base44.entities.Grade.filter({ exam_id: exam.id });
    for (const g of all) {
      await base44.entities.Grade.update(g.id, { is_locked: true, locked_date: new Date().toISOString() });
    }
    setSaving(false);
    onSaved();
    onClose();
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-2xl border border-border w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-xl">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-lg font-bold text-foreground">Saisie des notes</h2>
            <p className="text-sm text-muted-foreground">
              {subject?.name} • {cls?.name} • {exam.exam_type} • /{exam.max_score}
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="h-4 w-4" /></Button>
        </div>

        <div className="p-6">
          {classStudents.length === 0 ? (
            <p className="text-muted-foreground text-sm italic">Aucun élève dans cette classe</p>
          ) : (
            <div className="space-y-3">
              {classStudents.map((student) => {
                const isPending = pendingStudents.has(student.id);
                return (
                  <div key={student.id} className={`grid grid-cols-3 gap-3 items-center p-3 rounded-lg transition-colors ${isPending ? "bg-amber-50 border border-amber-200" : "bg-muted/20"}`}>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <p className="font-medium text-sm">{student.first_name} {student.last_name}</p>
                        {isPending && <Loader2 className="h-3 w-3 animate-spin text-amber-500 shrink-0" />}
                      </div>
                      <p className="text-xs text-muted-foreground font-mono">{student.student_number}</p>
                    </div>
                    <div>
                      <Input
                        type="number"
                        min={0}
                        max={exam.max_score}
                        step={0.25}
                        placeholder={`Note /${exam.max_score}`}
                        value={grades[student.id] ?? ""}
                        onChange={(e) => handleGradeChange(student.id, e.target.value)}
                        disabled={exam.is_locked}
                        className={isPending ? "border-amber-300" : ""}
                      />
                    </div>
                    <div>
                      <Input
                        placeholder="Commentaire..."
                        value={comments[student.id] ?? ""}
                        onChange={(e) => setComments({ ...comments, [student.id]: e.target.value })}
                        disabled={exam.is_locked}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {!exam.is_locked && (
          <div className="flex justify-end gap-3 p-6 border-t border-border">
            <Button variant="outline" onClick={onClose}>Annuler</Button>
            <Button variant="outline" onClick={handleSave} disabled={saving} className="gap-2">
              <Save className="h-4 w-4" /> Enregistrer
            </Button>
            <Button onClick={handleLockAll} disabled={saving} className="gap-2">
              <Lock className="h-4 w-4" /> Valider et verrouiller
            </Button>
          </div>
        )}
        {exam.is_locked && (
          <div className="p-6 border-t border-border text-center text-sm text-muted-foreground">
            Cet examen est verrouillé. Les notes ne peuvent plus être modifiées.
          </div>
        )}
      </div>
    </div>
  );
}