import { Lock, Unlock, Trash2, ClipboardList, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function GradeTable({ grades, students, subjects, classes, onLock, onDelete, onRequestCorrection, currentUser }) {
  const studentMap = {};
  students.forEach((s) => (studentMap[s.id] = `${s.first_name} ${s.last_name}`));
  const subjectMap = {};
  subjects.forEach((s) => (subjectMap[s.id] = s.name));
  const classMap = {};
  classes.forEach((c) => (classMap[c.id] = c.name));

  if (grades.length === 0) {
    return (
      <div className="bg-card rounded-xl border border-border p-12 text-center">
        <ClipboardList className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
        <p className="text-muted-foreground">Aucune note trouvée</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted/50 border-b border-border">
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Élève</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Classe</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Matière</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Note</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Type</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Trimestre</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Statut</th>
              <th className="text-right py-3 px-4 text-xs font-semibold text-muted-foreground uppercase">Actions</th>
            </tr>
          </thead>
          <tbody>
            {grades.map((g) => (
              <tr key={g.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                <td className="py-3 px-4 font-medium">{studentMap[g.student_id] || "—"}</td>
                <td className="py-3 px-4 text-muted-foreground">{classMap[g.class_id] || "—"}</td>
                <td className="py-3 px-4 text-muted-foreground">{subjectMap[g.subject_id] || "—"}</td>
                <td className="py-3 px-4">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${
                    g.score >= 14 ? "bg-green-100 text-green-700" :
                    g.score >= 10 ? "bg-yellow-100 text-yellow-700" :
                    "bg-red-100 text-red-700"
                  }`}>
                    {g.score}/{g.max_score || 20}
                  </span>
                </td>
                <td className="py-3 px-4 text-muted-foreground text-xs">{g.exam_type}</td>
                <td className="py-3 px-4 text-muted-foreground text-xs">{g.trimester}</td>
                <td className="py-3 px-4">
                  {g.is_locked ? (
                    <span className="inline-flex items-center gap-1 text-xs text-green-600 font-medium">
                      <Lock className="h-3 w-3" /> Verrouillée
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs text-orange-500 font-medium">
                      <Unlock className="h-3 w-3" /> Ouverte
                    </span>
                  )}
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-1">
                    {g.is_locked && !g.correction_requested && onRequestCorrection && (
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onRequestCorrection(g)} title="Demander correction">
                        <MessageSquare className="h-3.5 w-3.5" />
                      </Button>
                    )}
                    {g.correction_requested && (
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-yellow-500" onClick={() => onRequestCorrection && onRequestCorrection(g)} title="Voir correction">
                        <MessageSquare className="h-3.5 w-3.5" />
                      </Button>
                    )}
                    {!g.is_locked && onLock && (
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onLock(g)} title="Verrouiller">
                        <Lock className="h-3.5 w-3.5" />
                      </Button>
                    )}
                    {!g.is_locked && onDelete && (
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => onDelete(g.id)} title="Supprimer">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}