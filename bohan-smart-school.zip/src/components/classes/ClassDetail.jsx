import { X, Users, BookOpen, UserCheck, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";

const LEVEL_ORDER = ["6ème", "5ème", "4ème", "3ème", "2nde", "1ère", "Terminale"];

export default function ClassDetail({ classData, students, subjects, onClose, onEdit }) {
  const classStudents = students.filter((s) => s.class_id === classData.id);
  // Subjects relevant to this class level (or "Tous")
  const classSubjects = subjects.filter(
    (sub) => sub.level === classData.level || sub.level === "Tous" || !sub.level
  );

  const maleCount = classStudents.filter((s) => s.gender === "Masculin").length;
  const femaleCount = classStudents.filter((s) => s.gender === "Féminin").length;

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-2xl border border-border w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-accent flex items-center justify-center">
              <GraduationCap className="h-7 w-7 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">{classData.name}</h2>
              <p className="text-sm text-muted-foreground">
                {classData.academic_year} • Niveau : {classData.level}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => onEdit(classData)}>Modifier</Button>
            <Button variant="ghost" size="icon" onClick={onClose}><X className="h-4 w-4" /></Button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Stats rapides */}
          <div className="grid grid-cols-3 gap-4">
            <StatBox icon={Users} label="Total élèves" value={classStudents.length} />
            <StatBox icon={UserCheck} label="Garçons" value={maleCount} />
            <StatBox icon={UserCheck} label="Filles" value={femaleCount} />
          </div>

          {classData.head_teacher && (
            <div className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">Professeur principal :</span>
              <span className="font-medium text-foreground">{classData.head_teacher}</span>
            </div>
          )}

          {/* Élèves affectés */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-2">
              <Users className="h-4 w-4" /> Élèves affectés ({classStudents.length})
            </h3>
            {classStudents.length === 0 ? (
              <p className="text-sm text-muted-foreground italic">Aucun élève affecté à cette classe</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/50">
                      <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">N°</th>
                      <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Nom complet</th>
                      <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Sexe</th>
                      <th className="text-left py-2 px-3 text-xs font-semibold text-muted-foreground">Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {classStudents.map((s) => (
                      <tr key={s.id} className="border-t border-border/50 hover:bg-muted/20">
                        <td className="py-2 px-3 font-mono text-xs text-primary">{s.student_number}</td>
                        <td className="py-2 px-3 font-medium">{s.first_name} {s.last_name}</td>
                        <td className="py-2 px-3 text-muted-foreground">{s.gender || "—"}</td>
                        <td className="py-2 px-3">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            s.status === "Actif" ? "bg-green-100 text-green-700" :
                            s.status === "Inactif" ? "bg-gray-100 text-gray-600" :
                            "bg-orange-100 text-orange-700"
                          }`}>{s.status || "Actif"}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Matières & professeurs */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-2">
              <BookOpen className="h-4 w-4" /> Matières enseignées ({classSubjects.length})
            </h3>
            {classSubjects.length === 0 ? (
              <p className="text-sm text-muted-foreground italic">Aucune matière assignée à ce niveau</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {classSubjects.map((sub) => (
                  <div key={sub.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-foreground">{sub.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {sub.teacher_name || "Professeur non assigné"} • Coeff. {sub.coefficient || 1}
                      </p>
                    </div>
                    {sub.code && (
                      <span className="text-xs font-mono bg-accent text-accent-foreground px-2 py-1 rounded">
                        {sub.code}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatBox({ icon: Icon, label, value }) {
  return (
    <div className="bg-muted/30 rounded-xl p-4 text-center">
      <Icon className="h-5 w-5 text-muted-foreground mx-auto mb-1" />
      <p className="text-2xl font-bold text-foreground">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}