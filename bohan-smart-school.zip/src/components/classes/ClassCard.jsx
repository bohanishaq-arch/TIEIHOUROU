import { Users, Pencil, Trash2, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ClassCard({ classData, studentCount, onEdit, onDelete, onView }) {
  return (
    <div className="bg-card rounded-xl border border-border p-5 hover:shadow-md transition-shadow group">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="font-semibold text-foreground">{classData.name}</h3>
          <p className="text-xs text-muted-foreground">{classData.academic_year}</p>
        </div>
        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-accent text-accent-foreground">
          {classData.level}
        </span>
      </div>

      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
        <Users className="h-4 w-4" />
        <span>{studentCount} élève{studentCount !== 1 ? "s" : ""}</span>
      </div>

      {classData.head_teacher && (
        <p className="text-xs text-muted-foreground mb-4">Prof. principal: {classData.head_teacher}</p>
      )}

      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button variant="outline" size="sm" onClick={onView} className="gap-1 h-8 text-xs">
          <Eye className="h-3 w-3" /> Détails
        </Button>
        <Button variant="outline" size="sm" onClick={onEdit} className="gap-1 h-8 text-xs">
          <Pencil className="h-3 w-3" /> Modifier
        </Button>
        <Button variant="outline" size="sm" onClick={onDelete} className="gap-1 h-8 text-xs text-destructive hover:text-destructive">
          <Trash2 className="h-3 w-3" /> Supprimer
        </Button>
      </div>
    </div>
  );
}