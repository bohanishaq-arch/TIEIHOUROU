import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X } from "lucide-react";

const LEVELS = [
  "6ème", "5ème", "4ème", "3ème", "2nde",
  "1ère A", "1ère C", "1ère D",
  "Tle A", "Tle C", "Tle D",
];
const DIVISIONS = ["1", "2", "3", "4", "A", "B", "C", "D"];

export default function ClassForm({ classData, onSave, onCancel }) {
  const currentYear = new Date().getFullYear();
  const [teachers, setTeachers] = useState([]);
  const [form, setForm] = useState({
    level: classData?.level || "",
    division: classData?.division || "",
    name: classData?.name || "",
    academic_year: classData?.academic_year || `${currentYear}-${currentYear + 1}`,
    room: classData?.room || "",
    head_teacher: classData?.head_teacher || "",
    teacher_email: classData?.teacher_email || "",
    capacity: classData?.capacity || 50,
  });

  useEffect(() => {
    base44.entities.User.filter({ role: "teacher" }).then(setTeachers);
  }, []);

  function handleLevelOrDivisionChange(field, value) {
    const updated = { ...form, [field]: value };
    if (updated.level && updated.division) {
      // Ex: Tle A1, Tle C2, 6ème A1
      updated.name = `${updated.level}${updated.division}`;
    }
    setForm(updated);
  }

  function handleSubmit(e) {
    e.preventDefault();
    onSave(form);
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-semibold text-foreground">
          {classData ? "Modifier la classe" : "Créer une nouvelle classe"}
        </h3>
        <Button variant="ghost" size="icon" onClick={onCancel}><X className="h-4 w-4" /></Button>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div>
          <Label>Niveau *</Label>
          <Select value={form.level} onValueChange={(v) => handleLevelOrDivisionChange("level", v)}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {LEVELS.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Division *</Label>
          <Select value={form.division} onValueChange={(v) => handleLevelOrDivisionChange("division", v)}>
            <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
            <SelectContent>
              {DIVISIONS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Nom de la classe</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} readOnly className="bg-muted/50" />
        </div>
        <div>
          <Label>Année scolaire</Label>
          <Input value={form.academic_year} onChange={(e) => setForm({ ...form, academic_year: e.target.value })} />
        </div>
        <div>
          <Label>Professeur principal</Label>
          <Input value={form.head_teacher} onChange={(e) => setForm({ ...form, head_teacher: e.target.value })} />
        </div>
        <div>
          <Label>Professeur responsable de la classe</Label>
          <Select value={form.teacher_email || ""} onValueChange={(v) => {
            const t = teachers.find((t) => t.email === v);
            setForm({ ...form, teacher_email: v, head_teacher: t ? t.full_name : form.head_teacher });
          }}>
            <SelectTrigger><SelectValue placeholder="Attribuer un professeur" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>— Aucun —</SelectItem>
              {teachers.map((t) => (
                <SelectItem key={t.id} value={t.email}>{t.full_name} — {t.email}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Salle</Label>
          <Input value={form.room} placeholder="Ex: Salle N°12, Salle B3" onChange={(e) => setForm({ ...form, room: e.target.value })} />
        </div>
        <div>
          <Label>Capacité</Label>
          <Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} />
        </div>

        <div className="md:col-span-2 lg:col-span-3 flex justify-end gap-3 pt-2">
          <Button type="button" variant="outline" onClick={onCancel}>Annuler</Button>
          <Button type="submit">{classData ? "Enregistrer" : "Créer la classe"}</Button>
        </div>
      </form>
    </div>
  );
}