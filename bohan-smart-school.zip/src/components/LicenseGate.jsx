import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { KeyRound, ShieldCheck, Copy, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function LicenseGate({ school, onActivated }) {
  const [inputKey, setInputKey] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  async function handleActivate(e) {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (inputKey.trim().toUpperCase() !== school.license_key?.toUpperCase()) {
      setError("Numéro de série invalide. Vérifiez le code fourni.");
      setLoading(false);
      return;
    }

    await base44.entities.School.update(school.id, {
      license_activated: true,
      license_activated_date: new Date().toISOString(),
    });

    setLoading(false);
    onActivated();
  }

  function handleCopy() {
    navigator.clipboard.writeText(school.license_key || "");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="bg-card rounded-2xl border border-border shadow-xl w-full max-w-md overflow-hidden">
        {/* Header */}
        <div className="bg-primary p-6 text-center">
          <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <KeyRound className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-xl font-bold text-white font-display">Activation de licence</h1>
          <p className="text-white/70 text-xs mt-1">Scolaris — Plateforme de gestion scolaire</p>
        </div>

        <div className="p-6 space-y-5">
          {/* School info */}
          <div className="bg-muted/50 rounded-xl p-4 text-center space-y-1">
            <p className="text-sm font-semibold text-foreground">{school.name}</p>
            {school.city && <p className="text-xs text-muted-foreground">{school.city}{school.country ? `, ${school.country}` : ""}</p>}
            {school.code && <span className="inline-block font-mono text-xs bg-primary/10 text-primary px-2 py-0.5 rounded mt-1">{school.code}</span>}
          </div>

          {/* License key display */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Numéro de série attribué</p>
            <div className="flex items-center gap-2 bg-muted rounded-lg p-3">
              <code className="flex-1 text-sm font-mono font-bold text-foreground tracking-wider">
                {school.license_key || "—"}
              </code>
              <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={handleCopy}>
                {copied ? <CheckCircle className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          {/* Activation form */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">
              Saisissez le numéro de série pour activer la plateforme pour cet établissement.
            </p>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-2.5 text-sm text-red-700 text-center">
                {error}
              </div>
            )}

            <form onSubmit={handleActivate} className="space-y-3">
              <Input
                value={inputKey}
                onChange={(e) => setInputKey(e.target.value.toUpperCase())}
                placeholder="Ex: SCOL-ABJ-2026-001"
                className="font-mono text-center tracking-widest"
                required
              />
              <Button type="submit" className="w-full gap-2" disabled={loading}>
                <ShieldCheck className="h-4 w-4" />
                {loading ? "Activation…" : "Activer la licence"}
              </Button>
            </form>
          </div>

          <p className="text-[10px] text-center text-muted-foreground/60">
            Ce numéro de série identifie votre établissement et sécurise l'accès à la plateforme.
          </p>
        </div>
      </div>
    </div>
  );
}