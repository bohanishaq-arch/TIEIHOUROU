import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getSchoolId } from "../../hooks/useSchool";
import { CheckCircle, XCircle, Clock, BookOpen, Clock2, User, MessageSquare } from "lucide-react";

export default function ExamValidation() {
  const [exams, setExams] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [validating, setValidating] = useState(null);
  const [selectedExam, setSelectedExam] = useState(null);
  const [notes, setNotes] = useState("");

  useEffect(() => {
    async function load() {
      const schoolId = getSchoolId();
      const f = schoolId ? { school_id: schoolId } : {};
      const [exs, subs] = await Promise.all([
        base44.entities.Exam.filter(f, "-created_date", 100),
        base44.entities.Subject.filter(f),
      ]);
      setExams(exs);
      setSubjects(subs);
      setLoading(false);
    }
    load();
  }, []);

  async function handleValidate(exam, status) {
    setValidating(exam.id);
    await base44.entities.Exam.update(exam.id, {
      validation_status: status,
      validation_date: new Date().toISOString(),
      validated_by: "Proviseur",
      validation_notes: notes,
    });
    setNotes("");
    setSelectedExam(null);
    const updated = exams.map(e => e.id === exam.id ? { ...e, validation_status: status, validation_notes: notes } : e);
    setExams(updated);
    setValidating(null);
  }

  if (loading) return <div className="flex justify-center py-10"><div className="w-7 h-7 border-4 border-primary/20 border-t-primary rounded-full animate-spin" /></div>;

  const pending = exams.filter(e => e.validation_status === "en_attente");
  const approved = exams.filter(e => e.validation_status === "approuvé");
  const rejected = exams.filter(e => e.validation_status === "rejeté");

  const ExamCard = ({ exam, status }) => {
    const subject = subjects.find(s => s.id === exam.subject_id);
    const statusColor = status === "en_attente" ? "bg-amber-50 border-amber-200" : status === "approuvé" ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200";
    const statusIcon = status === "en_attente" ? <Clock className="h-4 w-4 text-amber-600" /> : status === "approuvé" ? <CheckCircle className="h-4 w-4 text-emerald-600" /> : <XCircle className="h-4 w-4 text-red-600" />;

    return (
      <div className={`rounded-xl border p-4 space-y-3 ${statusColor}`}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              {statusIcon}
              <p className="font-bold text-sm">{exam.title || "Examen"}</p>
            </div>
            <p className="text-xs text-muted-foreground">{exam.exam_type} • {subject?.name || "—"}</p>
          </div>
          {status === "en_attente" && (
            <button
              onClick={() => setSelectedExam(exam)}
              className="text-xs bg-primary text-primary-foreground px-2.5 py-1 rounded-lg font-semibold hover:bg-primary/90"
            >
              Valider
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs bg-white/50 rounded-lg px-3 py-2">
          <div className="flex items-center gap-1.5">
            <BookOpen className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-muted-foreground">{exam.chapter || "—"}</span>
          </div>
          {exam.duration_minutes && (
            <div className="flex items-center gap-1.5">
              <Clock2 className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-muted-foreground">{exam.duration_minutes}min</span>
            </div>
          )}
          <div className="flex items-center gap-1.5 col-span-2">
            <User className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-muted-foreground">{exam.teacher_name || "—"}</span>
          </div>
        </div>

        {exam.validation_notes && (
          <div className="text-xs bg-white/60 rounded px-2 py-1.5 border-l-2 border-current">
            <p className="font-semibold mb-0.5">Notes:</p>
            <p className="text-muted-foreground italic">{exam.validation_notes}</p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* En attente */}
      <div>
        <h3 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
          <Clock className="h-5 w-5 text-amber-600" />
          En attente de validation ({pending.length})
        </h3>
        {pending.length === 0 ? (
          <p className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-4 text-center">Aucun examen en attente</p>
        ) : (
          <div className="grid gap-3">
            {pending.map(exam => <ExamCard key={exam.id} exam={exam} status="en_attente" />)}
          </div>
        )}
      </div>

      {/* Approuvés */}
      {approved.length > 0 && (
        <div>
          <h3 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-emerald-600" />
            Approuvés ({approved.length})
          </h3>
          <div className="grid gap-3">
            {approved.map(exam => <ExamCard key={exam.id} exam={exam} status="approuvé" />)}
          </div>
        </div>
      )}

      {/* Rejetés */}
      {rejected.length > 0 && (
        <div>
          <h3 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
            <XCircle className="h-5 w-5 text-red-600" />
            Rejetés ({rejected.length})
          </h3>
          <div className="grid gap-3">
            {rejected.map(exam => <ExamCard key={exam.id} exam={exam} status="rejeté" />)}
          </div>
        </div>
      )}

      {/* Modal de validation */}
      {selectedExam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={() => setSelectedExam(null)}>
          <div className="bg-background rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-5" onClick={e => e.stopPropagation()}>
            <div>
              <h2 className="text-lg font-bold text-foreground mb-1">{selectedExam.title}</h2>
              <p className="text-sm text-muted-foreground">{selectedExam.exam_type} • {subjects.find(s => s.id === selectedExam.subject_id)?.name || "—"}</p>
            </div>

            <div className="space-y-2 bg-muted/50 rounded-lg p-3 text-xs">
              {selectedExam.chapter && <div><span className="font-semibold">Chapitre:</span> {selectedExam.chapter}</div>}
              {selectedExam.duration_minutes && <div><span className="font-semibold">Durée:</span> {selectedExam.duration_minutes} minutes</div>}
              {selectedExam.date && <div><span className="font-semibold">Date:</span> {new Date(selectedExam.date).toLocaleDateString("fr-FR")}</div>}
              <div><span className="font-semibold">Professeur:</span> {selectedExam.teacher_name}</div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground block mb-2 flex items-center gap-1">
                <MessageSquare className="h-4 w-4" /> Notes (optionnel)
              </label>
              <textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Commentaires ou motif de rejet..."
                className="w-full border border-input rounded-lg px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
                rows={3}
              />
            </div>

            <div className="flex gap-3 pt-2 border-t border-border">
              <button
                onClick={() => setSelectedExam(null)}
                className="flex-1 border border-input rounded-lg px-3 py-2 text-sm font-semibold hover:bg-muted"
              >
                Annuler
              </button>
              <button
                onClick={() => handleValidate(selectedExam, "rejeté")}
                disabled={validating === selectedExam.id}
                className="flex-1 flex items-center justify-center gap-2 bg-red-100 text-red-700 rounded-lg px-3 py-2 text-sm font-semibold hover:bg-red-200 disabled:opacity-60"
              >
                <XCircle className="h-4 w-4" />
                {validating === selectedExam.id ? "…" : "Rejeter"}
              </button>
              <button
                onClick={() => handleValidate(selectedExam, "approuvé")}
                disabled={validating === selectedExam.id}
                className="flex-1 flex items-center justify-center gap-2 bg-emerald-100 text-emerald-700 rounded-lg px-3 py-2 text-sm font-semibold hover:bg-emerald-200 disabled:opacity-60"
              >
                <CheckCircle className="h-4 w-4" />
                {validating === selectedExam.id ? "…" : "Approuver"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}