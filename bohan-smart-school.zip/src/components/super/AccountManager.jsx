import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { UserPlus, Copy, CheckCircle, Eye, EyeOff, Trash2, X, Users, RefreshCw, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Le super-admin ne crée QUE l'informaticien (sous-admin) de l'école
const ROLES = [
  { value: "it_manager", label: "💻 Informaticien / Sous-admin", domain: "it.bohan.ci", color: "bg-indigo-100 text-indigo-700" },
];

function generatePassword() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#";
  return Array.from({ length: 10 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

function generateAccessId(role, schoolCode) {
  const prefix = "IT";
  const seq = String(Math.floor(Math.random() * 9999) + 1).padStart(4, "0");
  return `${schoolCode || "SCL"}-${prefix}-${seq}`;
}

function toSlug(str) {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, ".").toLowerCase().replace(/[^a-z0-9.]/g, "");
}

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  function handle() {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }
  return (
    <button onClick={handle} className="shrink-0 hover:text-foreground transition-colors">
      {copied ? <CheckCircle className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5 text-muted-foreground" />}
    </button>
  );
}

export default function AccountManager({ school, onClose }) {
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ first_name: "", last_name: "", role: "teacher" });
  const [preview, setPreview] = useState(null); // newly created account preview
  const [saving, setSaving] = useState(false);
  const [showPasswords, setShowPasswords] = useState({});

  async function loadAccounts() {
    setLoading(true);
    const list = await base44.entities.AppAccess.filter({ school_id: school.id });
    setAccounts(list);
    setLoading(false);
  }

  useEffect(() => { loadAccounts(); }, [school.id]);

  function buildEmail(firstName, lastName, role) {
    if (!firstName && !lastName) return "";
    const slug = toSlug(`${firstName}${lastName ? "." + lastName : ""}`);
    const roleCfg = ROLES.find(r => r.value === role);
    return `${slug}@${roleCfg?.domain || "school.is"}`;
  }

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    const email = buildEmail(form.first_name, form.last_name, form.role);
    const password = generatePassword();
    const accessId = generateAccessId(form.role, school.code);
    const fullName = `${form.first_name} ${form.last_name}`.trim();

    // Save in AppAccess
    await base44.entities.AppAccess.create({
      user_email: email,
      full_name: fullName,
      access_id: accessId,
      access_password: password,
      role: form.role,
      is_active: true,
      school_id: school.id,
      school_name: school.name,
    });

    // Invite the user
    try {
      await base44.users.inviteUser(email, form.role === "user" ? "user" : form.role);
    } catch {
      // invitation may fail if email domain is not real — store credentials anyway
    }

    setPreview({ email, password, accessId, fullName, role: form.role });
    setForm({ first_name: "", last_name: "", role: "teacher" });
    setShowForm(false);
    setSaving(false);
    loadAccounts();
  }

  async function handleDelete(acc) {
    if (!confirm(`Supprimer le compte ${acc.user_email} ?`)) return;
    await base44.entities.AppAccess.delete(acc.id);
    loadAccounts();
  }

  function togglePass(id) {
    setShowPasswords(p => ({ ...p, [id]: !p[id] }));
  }

  const roleCfgFor = (role) => ROLES.find(r => r.value === role) || ROLES[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-background rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-card shrink-0">
          <div>
            <h2 className="text-lg font-bold text-foreground">Informaticien de l'école</h2>
            <p className="text-xs text-muted-foreground">{school.name} · Sous-administrateur responsable de la gestion des accès</p>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={loadAccounts} className="gap-1.5"><RefreshCw className="h-3.5 w-3.5" /></Button>
            {accounts.filter(a => a.role === "it_manager").length === 0 && (
              <Button size="sm" className="gap-1.5 bg-indigo-600 hover:bg-indigo-700" onClick={() => { setShowForm(true); setPreview(null); }}>
                <UserPlus className="h-3.5 w-3.5" /> Créer l'informaticien
              </Button>
            )}
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-muted">
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto flex-1 p-6 space-y-5">
          {/* Preview of new account */}
          {preview && (
            <div className="bg-green-50 border border-green-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <p className="font-semibold text-green-800">Compte créé avec succès !</p>
              </div>
              <p className="text-sm text-green-700">Transmettez ces identifiants à <strong>{preview.fullName}</strong> :</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { label: "Email", value: preview.email },
                  { label: "Mot de passe", value: preview.password },
                  { label: "Identifiant", value: preview.accessId },
                ].map(item => (
                  <div key={item.label} className="bg-white rounded-lg px-3 py-2 border border-green-200">
                    <p className="text-[10px] text-green-600 font-semibold uppercase mb-0.5">{item.label}</p>
                    <div className="flex items-center gap-2">
                      <code className="text-xs font-mono text-green-900 flex-1 truncate">{item.value}</code>
                      <CopyBtn text={item.value} />
                    </div>
                  </div>
                ))}
              </div>
              <button onClick={() => setPreview(null)} className="text-xs text-green-600 underline">Masquer</button>
            </div>
          )}

          {/* Info box */}
          <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4 text-sm text-indigo-800 space-y-1">
            <p className="font-bold flex items-center gap-2">💻 Rôle de l'informaticien</p>
            <p className="text-xs">L'informaticien est le <strong>sous-administrateur</strong> de l'école. Une fois créé, il peut :</p>
            <ul className="text-xs list-disc list-inside space-y-0.5 mt-1">
              <li>Créer les comptes professeurs, comptables, éducateurs, directeurs</li>
              <li>Gérer les identifiants d'accès de tous les personnels</li>
              <li>Inscrire les élèves et gérer les classes</li>
            </ul>
            <p className="text-xs text-indigo-600 mt-1">Le grand administrateur BOHAN n'intervient plus dans la gestion quotidienne.</p>
          </div>

          {/* Create form */}
          {showForm && (
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="font-semibold mb-1">Créer l'informaticien</h3>
              <p className="text-xs text-muted-foreground mb-4">Un seul informaticien par école. Il sera le responsable de tous les accès.</p>
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Prénom *</Label>
                    <Input className="mt-1" value={form.first_name} onChange={e => setForm(f => ({ ...f, first_name: e.target.value }))} required />
                  </div>
                  <div>
                    <Label>Nom *</Label>
                    <Input className="mt-1" value={form.last_name} onChange={e => setForm(f => ({ ...f, last_name: e.target.value }))} required />
                  </div>
                </div>
                <div className="bg-indigo-50 rounded-lg px-3 py-2 text-sm">
                  <span className="text-muted-foreground">Rôle : </span>
                  <strong className="text-indigo-700">💻 Informaticien / Sous-admin</strong>
                </div>
                {form.first_name && (
                  <div className="bg-muted/50 rounded-lg px-3 py-2 text-sm">
                    <span className="text-muted-foreground">Email généré : </span>
                    <code className="font-mono text-foreground">{buildEmail(form.first_name, form.last_name, "it_manager")}</code>
                  </div>
                )}
                <div className="flex gap-3 justify-end">
                  <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Annuler</Button>
                  <Button type="submit" disabled={saving} className="bg-indigo-600 hover:bg-indigo-700">{saving ? "Création…" : "✅ Créer l'informaticien"}</Button>
                </div>
              </form>
            </div>
          )}

          {/* Accounts list */}
          {loading ? (
            <div className="flex items-center justify-center py-10">
              <div className="w-6 h-6 border-2 border-primary/20 border-t-primary rounded-full animate-spin" />
            </div>
          ) : accounts.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-12 text-muted-foreground">
              <Users className="h-10 w-10 opacity-20" />
              <p className="text-sm">Aucun compte créé pour cet établissement.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {accounts.map(acc => {
                const cfg = roleCfgFor(acc.role);
                const showPw = showPasswords[acc.id];
                return (
                  <div key={acc.id} className="flex items-center gap-3 bg-card border border-border rounded-xl px-4 py-3">
                    <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center shrink-0 text-sm font-bold text-muted-foreground">
                      {(acc.full_name || acc.user_email || "?")[0].toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        {acc.full_name && <p className="text-sm font-semibold text-foreground">{acc.full_name}</p>}
                        <p className="text-xs text-muted-foreground truncate">{acc.user_email}</p>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${cfg.color}`}>{cfg.label}</span>
                        {!acc.is_active && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-red-100 text-red-700 font-medium">Inactif</span>}
                      </div>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-xs text-muted-foreground font-mono">{acc.access_id}</span>
                        <div className="flex items-center gap-1">
                          <code className="text-xs font-mono text-muted-foreground">{showPw ? acc.access_password : "••••••••"}</code>
                          <button onClick={() => togglePass(acc.id)} className="text-muted-foreground hover:text-foreground">
                            {showPw ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                          </button>
                          {showPw && <CopyBtn text={acc.access_password} />}
                        </div>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive shrink-0" onClick={() => handleDelete(acc)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}