export default function StatCard({ icon: Icon, label, value, subtitle, color = "primary", trend }) {
  return (
    <div className="bg-card rounded-2xl border border-border p-4 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 group cursor-pointer">
      <div className="flex items-start justify-between mb-3">
        <div className="w-9 h-9 rounded-xl bg-accent flex items-center justify-center ring-1 ring-border">
          <Icon className="h-4.5 w-4.5 text-accent-foreground" style={{ width: 18, height: 18 }} />
        </div>
      </div>
      <p className="text-2xl font-bold text-foreground">{typeof value === "number" ? value.toLocaleString() : value}</p>
      <p className="text-xs font-medium text-muted-foreground mt-0.5">{label}</p>
      {subtitle && <p className="text-[10px] text-muted-foreground/60 mt-0.5">{subtitle}</p>}
    </div>
  );
}