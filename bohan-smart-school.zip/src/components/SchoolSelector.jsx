import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Building2, ChevronDown, X, Globe, KeyRound } from "lucide-react";
import { getSchoolId, getSchoolName, setSchool, clearSchool } from "../hooks/useSchool";

export default function SchoolSelector({ onSchoolChange }) {
  const { user } = useAuth();
  const [schools, setSchools] = useState([]);
  const [open, setOpen] = useState(false);
  const [currentId, setCurrentId] = useState(getSchoolId());
  const currentName = getSchoolName();

  // Super admin is the platform owner (no AppAccess record, role=admin with no school_id constraint)
  // Regular admins created via AppAccess with role=admin are school-scoped
  const isSuperAdmin = user?.role === "admin";

  useEffect(() => {
    if (!isSuperAdmin) return;
    // Super admin (role=admin) can always see all schools
    base44.entities.School.list().then(setSchools);
  }, [isSuperAdmin, user?.email]);

  // For non-admin users, get school from AppAccess
  useEffect(() => {
    if (isSuperAdmin) return;
    if (getSchoolId()) return; // already set
    base44.entities.AppAccess.filter({ user_email: user?.email }).then((records) => {
      const active = records.find((r) => r.is_active && r.school_id);
      if (active) {
        setSchool(active.school_id, active.school_name || "");
        setCurrentId(active.school_id);
        onSchoolChange?.();
      }
    });
  }, [isSuperAdmin, user?.email]);

  useEffect(() => {
    // Also load schools for non-admins if they don't have one selected yet
    if (!isSuperAdmin && !currentId) {
      base44.entities.School.filter({ is_active: true }).then(setSchools);
    }
  }, [isSuperAdmin, currentId]);

  if (!isSuperAdmin) {
    if (!currentId) {
      return (
        <div className="relative mx-3 mb-2">
          <button
            onClick={() => setOpen(!open)}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg bg-sidebar-accent/60 hover:bg-sidebar-accent transition-colors text-left"
          >
            <Building2 className="h-4 w-4 text-sidebar-primary shrink-0" />
            <span className="text-xs text-sidebar-foreground/90 truncate flex-1">Choisir un établissement</span>
            <ChevronDown className="h-3.5 w-3.5 text-sidebar-foreground/50 shrink-0" />
          </button>
          {open && (
            <div className="absolute left-0 right-0 top-full mt-1 bg-popover border border-border rounded-lg shadow-xl z-[9999] max-h-60 overflow-y-auto">
              {schools.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setSchool(s.id, s.name);
                    setCurrentId(s.id);
                    setOpen(false);
                    onSchoolChange?.();
                    window.location.reload();
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs hover:bg-muted transition-colors text-left"
                >
                  <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
                  <div className="flex-1 truncate">
                    <span className="font-medium text-foreground">{s.name}</span>
                    {s.city && <span className="text-muted-foreground ml-1">— {s.city}</span>}
                  </div>
                </button>
              ))}
              {schools.length === 0 && (
                <p className="px-3 py-2 text-xs text-muted-foreground text-center">Chargement...</p>
              )}
            </div>
          )}
        </div>
      );
    }
    
    return (
      <div className="flex items-center gap-2 px-3 py-2 mx-3 mb-2 rounded-lg bg-sidebar-accent/50">
        <Building2 className="h-4 w-4 text-sidebar-primary" />
        <span className="text-xs text-sidebar-foreground/80 truncate">{currentName || "Établissement"}</span>
      </div>
    );
  }

  function select(school) {
    setSchool(school.id, school.name);
    setCurrentId(school.id);
    setOpen(false);
    onSchoolChange?.();
    window.location.reload();
  }

  function handleClear() {
    clearSchool();
    setCurrentId(null);
    setOpen(false);
    onSchoolChange?.();
    window.location.reload();
  }

  return (
    <div className="relative mx-3 mb-2">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg bg-sidebar-accent/60 hover:bg-sidebar-accent transition-colors text-left"
      >
        <Building2 className="h-4 w-4 text-sidebar-primary shrink-0" />
        <span className="text-xs text-sidebar-foreground/90 truncate flex-1">
          {currentId ? (currentName || "Établissement sélectionné") : "Tous les établissements"}
        </span>
        <ChevronDown className="h-3.5 w-3.5 text-sidebar-foreground/50 shrink-0" />
      </button>

      {open && (
        <div className="absolute left-0 right-0 top-full mt-1 bg-popover border border-border rounded-lg shadow-xl z-[9999] max-h-60 overflow-y-auto">
          <button
            onClick={handleClear}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs hover:bg-muted transition-colors text-left border-b border-border"
          >
            <Globe className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="font-medium">Tous les établissements</span>
          </button>
          {schools.map((s) => (
            <button
              key={s.id}
              onClick={() => select(s)}
              className={`w-full flex items-center gap-2 px-3 py-2 text-xs hover:bg-muted transition-colors text-left ${currentId === s.id ? "bg-accent" : ""}`}
            >
              <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
              <div className="flex-1 truncate">
                <span className="font-medium text-foreground">{s.name}</span>
                {s.city && <span className="text-muted-foreground ml-1">— {s.city}</span>}
                {!s.license_activated && (
                  <span className="ml-1.5 inline-flex items-center gap-0.5 text-[9px] text-orange-600 bg-orange-50 px-1 py-0.5 rounded">
                    <KeyRound className="h-2.5 w-2.5" /> Non activée
                  </span>
                )}
              </div>
            </button>
          ))}
          {schools.length === 0 && (
            <p className="px-3 py-2 text-xs text-muted-foreground text-center">Aucun établissement</p>
          )}
        </div>
      )}
    </div>
  );
}