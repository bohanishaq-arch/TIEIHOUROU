import { useState, useEffect, useCallback } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Students from './pages/Students';
import Classes from './pages/Classes';
import Subjects from './pages/Subjects';
import Grades from './pages/Grades';
import Reports from './pages/Reports';
import Statistics from './pages/Statistics';
import Averages from './pages/Averages';
import Teachers from './pages/Teachers';
import SchoolConfig from './pages/SchoolConfig';
import StudentPortal from './pages/StudentPortal';
import AccessRequests from './pages/AccessRequests';
import RequestAccessForm from './components/RequestAccessForm';
import AccessDenied from './components/AccessDenied';
import AccessGate, { isAccessVerified, clearAccessVerified, getVerifiedRole } from './components/AccessGate';
import { base44 } from '@/api/base44Client';
import ManageAccess from './pages/ManageAccess';
import TeacherDashboard from './pages/TeacherDashboard';
import SuperAdmin from './pages/SuperAdmin';
import TeacherReports from './pages/TeacherReports';
import DirecteurDashboard from './pages/DirecteurDashboard';
import DirecteurRequests from './pages/DirecteurRequests';
import EducateurDashboard from './pages/EducateurDashboard';
import Inscription from './pages/Inscription';
import SubjectRequests from './pages/SubjectRequests';
import ScheduleManager from './pages/ScheduleManager';
import LicenseGate from './components/LicenseGate';
import AccountantDashboard from './pages/AccountantDashboard';
import Documentation from './pages/Documentation';
import BohanFinances from './pages/BohanFinances';

const ALLOWED_ROLES = ['admin', 'teacher', 'student', 'user', 'accountant', 'it_manager'];

// Shown when user is authenticated with Google but not yet registered in the app.
// Fetches the user profile directly from the token and shows the AccessGate.
function UnregisteredUserGate() {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Try to get user info even if not registered (the SDK may still return basic info)
    base44.auth.me()
      .then(u => { setCurrentUser(u); setLoading(false); })
      .catch(() => {
        // Can't get user — redirect to login
        base44.auth.redirectToLogin(window.location.href);
      });
  }, []);

  if (loading) return (
    <div className="fixed inset-0 flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
    </div>
  );

  if (!currentUser) return null;

  return <AccessGate user={currentUser} onVerified={() => window.location.reload()} />;
}

// Hook to check license activation for the selected school
function useLicenseCheck(user, accessVerified) {
  const [school, setSchoolData] = useState(null);
  const [checking, setChecking] = useState(true);
  const [needsActivation, setNeedsActivation] = useState(false);

  useEffect(() => {
    async function check() {
      const { getSchoolId } = await import('./hooks/useSchool');
      const schoolId = getSchoolId();
      if (!schoolId || user?.role === 'admin') {
        setChecking(false);
        return;
      }
      const schools = await (await import('@/api/base44Client')).base44.entities.School.filter({ id: schoolId });
      const s = schools[0];
      if (s && !s.license_activated) {
        setSchoolData(s);
        setNeedsActivation(true);
      }
      setChecking(false);
    }
    if (user) check();
    else setChecking(false);
  }, [user]);

  return { school, checking, needsActivation, setNeedsActivation };
}

// Routes that only admins can access
const ADMIN_ONLY_PATHS = ['/students', '/classes', '/subjects', '/teachers', '/averages', '/reports', '/statistics', '/config', '/access-requests', '/manage-access'];

function AdminRoute({ children, verifiedRole, userRole }) {
  const location = useLocation();
  const isAdmin = userRole === 'admin';
  const isDirecteur = verifiedRole === 'user';
  if (!isAdmin && !isDirecteur && ADMIN_ONLY_PATHS.includes(location.pathname)) {
    return <Navigate to="/teacher" replace />;
  }
  return children;
}

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin, user } = useAuth();
  const [accessVerified, setAccessVerified] = useState(() => isAccessVerified());
  const verifiedRole = getVerifiedRole();
  const { school: licenseSchool, checking: licenseChecking, needsActivation, setNeedsActivation } = useLicenseCheck(user, accessVerified);

  // Show loading spinner while checking app public settings, auth, or license
  if (isLoadingPublicSettings || isLoadingAuth || licenseChecking) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'auth_required') {
      // Not logged in with Google yet → redirect to login
      base44.auth.redirectToLogin(window.location.href);
      return (
        <div className="fixed inset-0 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
        </div>
      );
    } else if (authError.type === 'user_not_registered') {
      // User is logged in with Google but not yet registered in the app.
      // We must show the AccessGate. The user object may be null here because
      // the platform returns 403 for unregistered users. We get it from the token
      // by rendering a small async loader.
      return <UnregisteredUserGate />;
    }
  }

  // Require secondary access gate for non-admin users (includes 'user' role pending role upgrade)
  if (user && user.role !== 'admin' && !accessVerified) {
    return <AccessGate user={user} onVerified={() => setAccessVerified(true)} />;
  }

  // Block users without an approved role after gate (shouldn't happen, but safety net)
  if (user && !ALLOWED_ROLES.includes(user.role)) {
    return <RequestAccessForm user={user} />;
  }

  // License activation gate for non-admin users
  if (needsActivation && licenseSchool) {
    return <LicenseGate school={licenseSchool} onActivated={() => { setNeedsActivation(false); window.location.reload(); }} />;
  }

  // Render the main app
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={verifiedRole === 'teacher' ? <Navigate to="/teacher" replace /> : verifiedRole === 'student' ? <Navigate to="/portal" replace /> : verifiedRole === 'user' ? <Navigate to="/directeur" replace /> : verifiedRole === 'educator' ? <Navigate to="/educateur" replace /> : verifiedRole === 'accountant' ? <Navigate to="/comptable" replace /> : verifiedRole === 'it_manager' ? <Navigate to="/manage-access" replace /> : <Dashboard />} />
        <Route path="/comptable" element={<AccountantDashboard />} />
        <Route path="/directeur" element={<DirecteurDashboard />} />
        <Route path="/directeur-requests" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><DirecteurRequests /></AdminRoute>} />
        <Route path="/educateur" element={<EducateurDashboard />} />
        <Route path="/super-admin" element={<SuperAdmin />} />
        <Route path="/students" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><Students /></AdminRoute>} />
        <Route path="/classes" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><Classes /></AdminRoute>} />
        <Route path="/subjects" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><Subjects /></AdminRoute>} />
        <Route path="/grades" element={<Grades />} />
        <Route path="/reports" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><Reports /></AdminRoute>} />
        <Route path="/statistics" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><Statistics /></AdminRoute>} />
        <Route path="/averages" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><Averages /></AdminRoute>} />
        <Route path="/teachers" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><Teachers /></AdminRoute>} />
        <Route path="/config" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><SchoolConfig /></AdminRoute>} />
        <Route path="/portal" element={<StudentPortal />} />
        <Route path="/access-requests" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><AccessRequests /></AdminRoute>} />
        <Route path="/manage-access" element={user?.role === 'admin' || verifiedRole === 'user' || verifiedRole === 'it_manager' ? <ManageAccess /> : <Navigate to="/" replace />} />
        <Route path="/teacher" element={<TeacherDashboard />} />
        <Route path="/inscription" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><Inscription /></AdminRoute>} />
        <Route path="/subject-requests" element={<AdminRoute verifiedRole={verifiedRole} userRole={user?.role}><SubjectRequests /></AdminRoute>} />
        <Route path="/schedule" element={<ScheduleManager />} />
        <Route path="/teacher-reports" element={user?.role === 'admin' || verifiedRole === 'user' ? <TeacherReports /> : <Navigate to="/teacher" replace />} />
        <Route path="/documentation" element={<Documentation />} />
        <Route path="/bohan-finances" element={user?.role === 'admin' ? <BohanFinances /> : <Navigate to="/" replace />} />
        <Route path="*" element={<PageNotFound />} />
      </Route>
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App