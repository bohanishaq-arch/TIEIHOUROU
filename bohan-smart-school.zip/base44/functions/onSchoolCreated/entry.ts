import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();

    // Extract school data from automation payload
    const school = payload.data;
    if (!school || !school.admin_email) {
      console.log("No admin_email provided, skipping email send");
      return Response.json({ success: true, message: "No email to send" });
    }

    // Prepare email content
    const schoolName = school.name || "Nouvelle école";
    const licenseKey = school.license_key || "À générer";
    const schoolCode = school.code || "À générer";
    const adminEmail = school.admin_email;

    const emailSubject = `Bienvenue sur Scolaris – ${schoolName}`;
    const emailBody = `
Bonjour,

Bienvenue sur Scolaris ! Votre établissement a été enregistré avec succès.

**Détails de votre établissement :**
- Nom : ${schoolName}
- Code établissement : ${schoolCode}
- Numéro de série (Licence) : ${licenseKey}
- Email administrateur : ${adminEmail}

Vous avez été désigné comme administrateur de votre établissement. Vous pouvez maintenant vous connecter à l'application en utilisant cet email : ${adminEmail}

**Prochaines étapes :**
1. Connectez-vous à la plateforme avec votre email
2. Activez votre licence scolaire en utilisant le numéro de série ci-dessus
3. Créez vos classes, matières et invitez vos professeurs

Si vous avez des questions, veuillez nous contacter.

Cordialement,
L'équipe Scolaris
`.trim();

    // Send email using Core integration
    await base44.integrations.Core.SendEmail({
      to: adminEmail,
      subject: emailSubject,
      body: emailBody,
      from_name: "Scolaris"
    });

    console.log(`Email sent successfully to ${adminEmail}`);
    return Response.json({ success: true, message: `Email sent to ${adminEmail}` });
  } catch (error) {
    console.error("Error in onSchoolCreated:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});