import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const { email, password, access_id } = await req.json();

  if (!email || !password || !access_id) {
    return Response.json({ success: false, error: "Champs manquants." }, { status: 400 });
  }

  const googleEmail = email.trim().toLowerCase();
  const accessIdTrimmed = access_id.trim();
  const passwordTrimmed = password.trim();

  // Fetch all AppAccess records
  const allRecords = await base44.asServiceRole.entities.AppAccess.list();

  // Strategy 1: match by user_email + access_id + password (email already linked)
  let match = allRecords.find(
    (r) =>
      r.user_email?.trim().toLowerCase() === googleEmail &&
      r.access_id?.trim() === accessIdTrimmed &&
      r.access_password?.trim() === passwordTrimmed
  );

  // Strategy 2: match by access_id + password only (user connecting for the first time with their Google email)
  // This handles the case where admin created the account with a placeholder email
  if (!match) {
    match = allRecords.find(
      (r) =>
        r.access_id?.trim() === accessIdTrimmed &&
        r.access_password?.trim() === passwordTrimmed
    );

    // If found, link the Google email to this AppAccess record
    if (match) {
      try {
        await base44.asServiceRole.entities.AppAccess.update(match.id, {
          user_email: googleEmail
        });
        match = { ...match, user_email: googleEmail };
      } catch {
        // Non-blocking
      }
    }
  }

  if (!match) {
    return Response.json(
      { success: false, error: "Identifiants incorrects. Vérifiez votre code permanent et mot de passe." },
      { status: 401 }
    );
  }

  // Activate the account if it's inactive (directeur, educateur created as inactive)
  if (match.is_active === false) {
    try {
      await base44.asServiceRole.entities.AppAccess.update(match.id, { is_active: true });
    } catch {
      // Non-blocking
    }
  }

  // Store school info in session via response (for school selector)
  if (match.school_id) {
    try {
      const schools = await base44.asServiceRole.entities.School.filter({ id: match.school_id });
      if (schools.length > 0) {
        match._school_name = schools[0].name;
      }
    } catch {
      // Non-blocking
    }
  }

  // Invite/register the user so they can log in with their Google account
  const finalRole = match.role || 'user';
  try {
    await base44.asServiceRole.users.inviteUser(googleEmail, finalRole);
  } catch {
    // Already registered — continue
  }

  // Update the user's display name and role
  if (match.full_name) {
    try {
      const users = await base44.asServiceRole.entities.User.filter({ email: googleEmail });
      if (users.length > 0) {
        await base44.asServiceRole.entities.User.update(users[0].id, {
          full_name: match.full_name,
          role: finalRole
        });
      }
    } catch (e) {
      console.error("Failed to update user display name:", e);
      // Non-blocking
    }
  }

  // If the user is a student, link their Google email to their Student record
  if (match.role === 'student') {
    try {
      // Try by student_number (access_id for students IS the student number)
      const studentsByNumber = await base44.asServiceRole.entities.Student.filter({
        student_number: accessIdTrimmed
      });
      if (studentsByNumber.length > 0) {
        await base44.asServiceRole.entities.Student.update(studentsByNumber[0].id, {
          student_user_email: googleEmail
        });
      } else if (match.full_name) {
        // Fallback: match by name
        const nameParts = match.full_name.trim().split(' ');
        const firstName = nameParts[0];
        const lastName = nameParts.slice(1).join(' ');
        const byName = await base44.asServiceRole.entities.Student.filter({
          first_name: firstName,
          last_name: lastName,
          school_id: match.school_id
        });
        if (byName.length > 0) {
          await base44.asServiceRole.entities.Student.update(byName[0].id, {
            student_user_email: googleEmail
          });
        }
      }
    } catch {
      // Non-blocking
    }
  }

  return Response.json({
    success: true,
    role: match.role || 'user',
    full_name: match.full_name || null,
    school_id: match.school_id || null,
    school_name: match._school_name || null
  });
});